package defpackage;

import defpackage.at0;
import defpackage.mu0;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Objects;

/* loaded from: classes.dex */
public final class su0 implements ps0, at0 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ int f36000do = 0;

    /* renamed from: break, reason: not valid java name */
    public int f36001break;

    /* renamed from: catch, reason: not valid java name */
    public wb1 f36003catch;

    /* renamed from: const, reason: not valid java name */
    public int f36005const;

    /* renamed from: else, reason: not valid java name */
    public int f36006else;

    /* renamed from: final, reason: not valid java name */
    public int f36007final;

    /* renamed from: goto, reason: not valid java name */
    public int f36009goto;

    /* renamed from: import, reason: not valid java name */
    public long[][] f36011import;

    /* renamed from: native, reason: not valid java name */
    public int f36012native;

    /* renamed from: public, reason: not valid java name */
    public long f36014public;

    /* renamed from: return, reason: not valid java name */
    public boolean f36015return;

    /* renamed from: super, reason: not valid java name */
    public int f36016super;

    /* renamed from: this, reason: not valid java name */
    public long f36017this;

    /* renamed from: throw, reason: not valid java name */
    public rs0 f36018throw;

    /* renamed from: while, reason: not valid java name */
    public a[] f36020while;

    /* renamed from: try, reason: not valid java name */
    public final wb1 f36019try = new wb1(16);

    /* renamed from: case, reason: not valid java name */
    public final ArrayDeque<mu0.a> f36002case = new ArrayDeque<>();

    /* renamed from: if, reason: not valid java name */
    public final wb1 f36010if = new wb1(ub1.f38658do);

    /* renamed from: for, reason: not valid java name */
    public final wb1 f36008for = new wb1(4);

    /* renamed from: new, reason: not valid java name */
    public final wb1 f36013new = new wb1();

    /* renamed from: class, reason: not valid java name */
    public int f36004class = -1;

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: do, reason: not valid java name */
        public final vu0 f36021do;

        /* renamed from: for, reason: not valid java name */
        public final ct0 f36022for;

        /* renamed from: if, reason: not valid java name */
        public final yu0 f36023if;

        /* renamed from: new, reason: not valid java name */
        public int f36024new;

        public a(vu0 vu0Var, yu0 yu0Var, ct0 ct0Var) {
            this.f36021do = vu0Var;
            this.f36023if = yu0Var;
            this.f36022for = ct0Var;
        }
    }

    static {
        ku0 ku0Var = new ss0() { // from class: ku0
            @Override // defpackage.ss0
            /* renamed from: do */
            public final ps0[] mo1515do() {
                return new ps0[]{new su0(0)};
            }
        };
    }

    public su0(int i) {
    }

    /* renamed from: catch, reason: not valid java name */
    public static long m14445catch(yu0 yu0Var, long j, long j2) {
        int m17751do = yu0Var.m17751do(j);
        if (m17751do == -1) {
            m17751do = yu0Var.m17752if(j);
        }
        return m17751do == -1 ? j2 : Math.min(yu0Var.f46161for[m17751do], j2);
    }

    /* renamed from: break, reason: not valid java name */
    public final void m14446break() {
        this.f36006else = 0;
        this.f36001break = 0;
    }

    @Override // defpackage.ps0
    /* renamed from: case */
    public void mo3861case(rs0 rs0Var) {
        this.f36018throw = rs0Var;
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:0x019b, code lost:
    
        r14 = r3.m16530try();
        r15 = r3.m16530try();
        r3.m16521private(4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:101:0x01aa, code lost:
    
        if (r15 != 1835360622) goto L96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x01ac, code lost:
    
        r8 = r3.m16507const(r14 - 12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x01b6, code lost:
    
        if (r15 != 1851878757) goto L99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x01b8, code lost:
    
        r11 = r3.m16507const(r14 - 12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:110:0x01c3, code lost:
    
        if (r15 != 1684108385) goto L102;
     */
    /* JADX WARN: Code restructure failed: missing block: B:111:0x01c5, code lost:
    
        r6 = r13;
        r12 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:112:0x01c7, code lost:
    
        r3.m16521private(r14 - 12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x01ce, code lost:
    
        if (r8 == null) goto L147;
     */
    /* JADX WARN: Code restructure failed: missing block: B:116:0x01d0, code lost:
    
        if (r11 == null) goto L147;
     */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x01d3, code lost:
    
        if (r6 != (-1)) goto L109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:120:0x01d7, code lost:
    
        r3.m16520package(r6);
        r3.m16521private(16);
        r11 = new defpackage.ty0(r8, r11, r3.m16507const(r12 - 16));
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x0282, code lost:
    
        r11 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x026a, code lost:
    
        android.util.Log.d("MetadataUtil", "Skipped unknown metadata entry: " + defpackage.mu0.m10617do(r6));
     */
    /* JADX WARN: Code restructure failed: missing block: B:124:0x00ac, code lost:
    
        r6 = defpackage.ru0.m13958case(r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x00b0, code lost:
    
        if (r6 <= 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:126:0x00b2, code lost:
    
        r11 = defpackage.ru0.f34391do;
     */
    /* JADX WARN: Code restructure failed: missing block: B:127:0x00b5, code lost:
    
        if (r6 > r11.length) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:128:0x00b7, code lost:
    
        r6 = r11[r6 - 1];
     */
    /* JADX WARN: Code restructure failed: missing block: B:129:0x00bd, code lost:
    
        if (r6 == null) goto L42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:130:0x00bf, code lost:
    
        r11 = new defpackage.wy0("TCON", r8, r6);
     */
    /* JADX WARN: Code restructure failed: missing block: B:131:0x00c6, code lost:
    
        android.util.Log.w("MetadataUtil", "Failed to parse standard genre code");
     */
    /* JADX WARN: Code restructure failed: missing block: B:132:0x00bc, code lost:
    
        r6 = r8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:134:0x01fc, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x029e, code lost:
    
        r3.m16520package(r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:137:0x02a1, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:0x01ed, code lost:
    
        r8 = 16777215 & r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:140:0x01f4, code lost:
    
        if (r8 != 6516084) goto L115;
     */
    /* JADX WARN: Code restructure failed: missing block: B:141:0x01f6, code lost:
    
        r11 = defpackage.ru0.m13959do(r6, r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:143:0x0202, code lost:
    
        if (r8 == 7233901) goto L149;
     */
    /* JADX WARN: Code restructure failed: missing block: B:145:0x0207, code lost:
    
        if (r8 != 7631467) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x020e, code lost:
    
        if (r8 == 6516589) goto L148;
     */
    /* JADX WARN: Code restructure failed: missing block: B:150:0x0213, code lost:
    
        if (r8 != 7828084) goto L125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:153:0x021a, code lost:
    
        if (r8 != 6578553) goto L128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:154:0x021c, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TDRC", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:156:0x0227, code lost:
    
        if (r8 != 4280916) goto L131;
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:0x0229, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TPE1", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:159:0x0233, code lost:
    
        if (r8 != 7630703) goto L134;
     */
    /* JADX WARN: Code restructure failed: missing block: B:160:0x0235, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TSSE", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:162:0x023f, code lost:
    
        if (r8 != 6384738) goto L137;
     */
    /* JADX WARN: Code restructure failed: missing block: B:163:0x0241, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TALB", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:165:0x024b, code lost:
    
        if (r8 != 7108978) goto L140;
     */
    /* JADX WARN: Code restructure failed: missing block: B:166:0x024d, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "USLT", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:168:0x0257, code lost:
    
        if (r8 != 6776174) goto L143;
     */
    /* JADX WARN: Code restructure failed: missing block: B:169:0x0259, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TCON", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:171:0x0261, code lost:
    
        if (r8 != 6779504) goto L146;
     */
    /* JADX WARN: Code restructure failed: missing block: B:172:0x0263, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TIT1", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:173:0x0284, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TCOM", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:174:0x028b, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TIT2", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:177:0x02a6, code lost:
    
        if (r5.isEmpty() == false) goto L159;
     */
    /* JADX WARN: Code restructure failed: missing block: B:178:0x02a9, code lost:
    
        r8 = new defpackage.tx0(r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0067, code lost:
    
        r3.m16520package(r12);
        r12 = r12 + r13;
        r3.m16521private(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x006e, code lost:
    
        r4 = r3.f41980if;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0070, code lost:
    
        if (r4 >= r12) goto L292;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0072, code lost:
    
        r6 = r3.m16530try();
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007a, code lost:
    
        if (r3.m16530try() != r5) goto L160;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x02af, code lost:
    
        r3.m16520package(r4 + r6);
        r11 = true;
        r5 = 1768715124;
        r7 = 8;
        r8 = null;
        r9 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x007c, code lost:
    
        r3.m16520package(r4);
        r4 = r4 + r6;
        r3.m16521private(r7);
        r5 = new java.util.ArrayList();
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0088, code lost:
    
        r6 = r3.f41980if;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008a, code lost:
    
        if (r6 >= r4) goto L294;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x008c, code lost:
    
        r7 = r3.m16530try() + r6;
        r6 = r3.m16530try();
        r12 = (r6 >> 24) & kotlin.KotlinVersion.MAX_COMPONENT_VALUE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x009f, code lost:
    
        if (r12 == 169) goto L110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00a3, code lost:
    
        if (r12 != 253) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00aa, code lost:
    
        if (r6 != 1735291493) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00d0, code lost:
    
        if (r6 != 1684632427) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00d2, code lost:
    
        r11 = defpackage.ru0.m13960for(r6, "TPOS", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0294, code lost:
    
        if (r11 == null) goto L296;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0296, code lost:
    
        r5.add(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0299, code lost:
    
        r11 = true;
        r8 = null;
        r9 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00dd, code lost:
    
        if (r6 != 1953655662) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00df, code lost:
    
        r11 = defpackage.ru0.m13960for(r6, "TRCK", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00ea, code lost:
    
        if (r6 != 1953329263) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00ec, code lost:
    
        r11 = defpackage.ru0.m13963try(r6, "TBPM", r3, r11, r9);
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00f7, code lost:
    
        if (r6 != 1668311404) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00f9, code lost:
    
        r11 = defpackage.ru0.m13963try(r6, "TCMP", r3, r11, r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x0104, code lost:
    
        if (r6 != 1668249202) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x0106, code lost:
    
        r11 = defpackage.ru0.m13961if(r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x010f, code lost:
    
        if (r6 != 1631670868) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0111, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TPE2", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x011c, code lost:
    
        if (r6 != 1936682605) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x011e, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TSOT", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0129, code lost:
    
        if (r6 != 1936679276) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x012b, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TSO2", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x0136, code lost:
    
        if (r6 != 1936679282) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x0138, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TSOA", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x0143, code lost:
    
        if (r6 != 1936679265) goto L73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x0145, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TSOP", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x0150, code lost:
    
        if (r6 != 1936679791) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x0152, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TSOC", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x015d, code lost:
    
        if (r6 != 1920233063) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x015f, code lost:
    
        r11 = defpackage.ru0.m13963try(r6, "ITUNESADVISORY", r3, r9, r9);
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x016a, code lost:
    
        if (r6 != 1885823344) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x016c, code lost:
    
        r11 = defpackage.ru0.m13963try(r6, "ITUNESGAPLESS", r3, r9, r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x0177, code lost:
    
        if (r6 != 1936683886) goto L85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0179, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TVSHOWSORT", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x0184, code lost:
    
        if (r6 != 1953919848) goto L88;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x0186, code lost:
    
        r11 = defpackage.ru0.m13962new(r6, "TVSHOW", r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:96:0x0191, code lost:
    
        if (r6 != 757935405) goto L146;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x0193, code lost:
    
        r6 = -1;
        r12 = -1;
        r11 = r8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x0197, code lost:
    
        r13 = r3.f41980if;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x0199, code lost:
    
        if (r13 >= r7) goto L297;
     */
    /* JADX WARN: Removed duplicated region for block: B:227:0x03fa  */
    /* JADX WARN: Removed duplicated region for block: B:281:0x04e2 A[LOOP:10: B:279:0x04df->B:281:0x04e2, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:286:0x04ff  */
    /* renamed from: class, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void m14447class(long r22) throws defpackage.mo0 {
        /*
            Method dump skipped, instructions count: 1396
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.su0.m14447class(long):void");
    }

    @Override // defpackage.ps0
    /* renamed from: else */
    public void mo3863else(long j, long j2) {
        this.f36002case.clear();
        this.f36001break = 0;
        this.f36004class = -1;
        this.f36005const = 0;
        this.f36007final = 0;
        this.f36016super = 0;
        if (j == 0) {
            m14446break();
            return;
        }
        a[] aVarArr = this.f36020while;
        if (aVarArr != null) {
            for (a aVar : aVarArr) {
                yu0 yu0Var = aVar.f36023if;
                int m17751do = yu0Var.m17751do(j2);
                if (m17751do == -1) {
                    m17751do = yu0Var.m17752if(j2);
                }
                aVar.f36024new = m17751do;
            }
        }
    }

    @Override // defpackage.ps0
    /* renamed from: for */
    public boolean mo3864for(qs0 qs0Var) throws IOException {
        return uu0.m15723do(qs0Var, false);
    }

    @Override // defpackage.at0
    /* renamed from: goto */
    public at0.a mo1503goto(long j) {
        long j2;
        long j3;
        long j4;
        long j5;
        int m17752if;
        long j6 = j;
        a[] aVarArr = this.f36020while;
        Objects.requireNonNull(aVarArr);
        if (aVarArr.length == 0) {
            return new at0.a(bt0.f4256do);
        }
        long j7 = -1;
        int i = this.f36012native;
        if (i != -1) {
            yu0 yu0Var = this.f36020while[i].f36023if;
            int m17751do = yu0Var.m17751do(j6);
            if (m17751do == -1) {
                m17751do = yu0Var.m17752if(j6);
            }
            if (m17751do == -1) {
                return new at0.a(bt0.f4256do);
            }
            long j8 = yu0Var.f46158case[m17751do];
            j2 = yu0Var.f46161for[m17751do];
            if (j8 >= j6 || m17751do >= yu0Var.f46163if - 1 || (m17752if = yu0Var.m17752if(j6)) == -1 || m17752if == m17751do) {
                j5 = -9223372036854775807L;
            } else {
                long j9 = yu0Var.f46158case[m17752if];
                long j10 = yu0Var.f46161for[m17752if];
                j5 = j9;
                j7 = j10;
            }
            j3 = j7;
            j4 = j5;
            j6 = j8;
        } else {
            j2 = Long.MAX_VALUE;
            j3 = -1;
            j4 = -9223372036854775807L;
        }
        int i2 = 0;
        while (true) {
            a[] aVarArr2 = this.f36020while;
            if (i2 >= aVarArr2.length) {
                break;
            }
            if (i2 != this.f36012native) {
                yu0 yu0Var2 = aVarArr2[i2].f36023if;
                long m14445catch = m14445catch(yu0Var2, j6, j2);
                if (j4 != -9223372036854775807L) {
                    j3 = m14445catch(yu0Var2, j4, j3);
                }
                j2 = m14445catch;
            }
            i2++;
        }
        bt0 bt0Var = new bt0(j6, j2);
        return j4 == -9223372036854775807L ? new at0.a(bt0Var) : new at0.a(bt0Var, new bt0(j4, j3));
    }

    @Override // defpackage.at0
    /* renamed from: new */
    public boolean mo1504new() {
        return true;
    }

    @Override // defpackage.ps0
    public void release() {
    }

    @Override // defpackage.at0
    /* renamed from: this */
    public long mo1505this() {
        return this.f36014public;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x03bf A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:137:0x0231 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:139:0x0006 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0006 A[SYNTHETIC] */
    @Override // defpackage.ps0
    /* renamed from: try */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public int mo3865try(defpackage.qs0 r30, defpackage.zs0 r31) throws java.io.IOException {
        /*
            Method dump skipped, instructions count: 968
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.su0.mo3865try(qs0, zs0):int");
    }
}
