package defpackage;

import android.net.Uri;
import defpackage.d01;
import defpackage.la1;
import defpackage.z41;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class t41 extends d01<a51> {
    public t41(fo0 fo0Var, la1.b bVar, Executor executor) {
        super(fo0Var, new b51(), bVar, executor);
    }

    /* renamed from: break, reason: not valid java name */
    public final void m14633break(z41 z41Var, z41.a aVar, HashSet<Uri> hashSet, ArrayList<d01.c> arrayList) {
        String str = z41Var.f278do;
        long j = z41Var.f46659case + aVar.f46679super;
        String str2 = aVar.f46681while;
        if (str2 != null) {
            Uri m7062extends = h81.m7062extends(str, str2);
            if (hashSet.add(m7062extends)) {
                arrayList.add(new d01.c(j, d01.m3965new(m7062extends)));
            }
        }
        arrayList.add(new d01.c(j, new n91(h81.m7062extends(str, aVar.f46671catch), aVar.f46676native, aVar.f46677public)));
    }

    @Override // defpackage.d01
    /* renamed from: case */
    public List mo3966case(k91 k91Var, a51 a51Var, boolean z) throws IOException, InterruptedException {
        a51 a51Var2 = a51Var;
        ArrayList arrayList = new ArrayList();
        if (a51Var2 instanceof y41) {
            List<Uri> list = ((y41) a51Var2).f44967try;
            for (int i = 0; i < list.size(); i++) {
                arrayList.add(d01.m3965new(list.get(i)));
            }
        } else {
            arrayList.add(d01.m3965new(Uri.parse(a51Var2.f278do)));
        }
        ArrayList<d01.c> arrayList2 = new ArrayList<>();
        HashSet<Uri> hashSet = new HashSet<>();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            n91 n91Var = (n91) it.next();
            arrayList2.add(new d01.c(0L, n91Var));
            try {
                z41 z41Var = (z41) m3971try(k91Var, n91Var, z);
                z41.a aVar = null;
                List<z41.a> list2 = z41Var.f46667super;
                for (int i2 = 0; i2 < list2.size(); i2++) {
                    z41.a aVar2 = list2.get(i2);
                    z41.a aVar3 = aVar2.f46672class;
                    if (aVar3 != null && aVar3 != aVar) {
                        m14633break(z41Var, aVar3, hashSet, arrayList2);
                        aVar = aVar3;
                    }
                    m14633break(z41Var, aVar2, hashSet, arrayList2);
                }
            } catch (IOException e) {
                if (!z) {
                    throw e;
                }
            }
        }
        return arrayList2;
    }
}
