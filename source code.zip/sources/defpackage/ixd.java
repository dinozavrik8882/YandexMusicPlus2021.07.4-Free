package defpackage;

@hrd
/* loaded from: classes2.dex */
public final class ixd {

    @qd3("close_after")
    private final Integer closeAfter;

    @ird("show_after")
    private final int showAfter;

    @ird("ttl")
    private final int ttl;

    public ixd() {
        this(0, null, 0, 7);
    }

    public ixd(int i, Integer num, int i2, int i3) {
        i = (i3 & 1) != 0 ? 0 : i;
        int i4 = i3 & 2;
        i2 = (i3 & 4) != 0 ? 0 : i2;
        this.showAfter = i;
        this.closeAfter = null;
        this.ttl = i2;
    }
}
