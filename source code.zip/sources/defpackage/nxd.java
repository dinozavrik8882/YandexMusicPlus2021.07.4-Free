package defpackage;

@hrd
/* loaded from: classes2.dex */
public final class nxd {

    @ird("need_upgrade")
    private final boolean needUpgrade;

    @qd3("pending_purchase_id")
    private final String pendingPurchaseId;

    @ird("status")
    private final oxd statusDto;

    @qd3("subscription_id")
    private final String subscriptionId;

    @qd3("webview")
    private final pxd webViewParams;

    public nxd() {
        oxd oxdVar = oxd.UNRECOGNIZED;
        jp5.m8570try(oxdVar, "statusDto");
        this.subscriptionId = null;
        this.statusDto = oxdVar;
        this.needUpgrade = false;
        this.pendingPurchaseId = null;
        this.webViewParams = null;
    }

    /* renamed from: do, reason: not valid java name */
    public final boolean m11255do() {
        return this.needUpgrade;
    }

    /* renamed from: for, reason: not valid java name */
    public final oxd m11256for() {
        return this.statusDto;
    }

    /* renamed from: if, reason: not valid java name */
    public final String m11257if() {
        return this.pendingPurchaseId;
    }

    /* renamed from: new, reason: not valid java name */
    public final String m11258new() {
        return this.subscriptionId;
    }

    /* renamed from: try, reason: not valid java name */
    public final pxd m11259try() {
        return this.webViewParams;
    }
}
