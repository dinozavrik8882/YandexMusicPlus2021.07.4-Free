package defpackage;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

/* loaded from: classes.dex */
public final class rw2 implements ServiceConnection {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ sw2 f34500do;

    public /* synthetic */ rw2(sw2 sw2Var) {
        this.f34500do = sw2Var;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.f34500do.f36120for.m7976if(4, "ServiceConnectionImpl.onServiceConnected(%s)", new Object[]{componentName});
        this.f34500do.m14491for(new pw2(this, iBinder));
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        this.f34500do.f36120for.m7976if(4, "ServiceConnectionImpl.onServiceDisconnected(%s)", new Object[]{componentName});
        this.f34500do.m14491for(new qw2(this));
    }
}
