package defpackage;

import android.util.Base64;
import com.yandex.metrica.YandexMetricaDefaultValues;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: classes2.dex */
public class bcd {

    /* renamed from: for, reason: not valid java name */
    public static volatile SecretKey f3412for;

    /* renamed from: new, reason: not valid java name */
    public final SecretKey f3414new;

    /* renamed from: try, reason: not valid java name */
    public final Cipher f3415try = Cipher.getInstance("AES");

    /* renamed from: do, reason: not valid java name */
    public static final Object f3411do = new Object();

    /* renamed from: if, reason: not valid java name */
    public static final byte[] f3413if = "YandexMusic".getBytes();

    public bcd(SecretKey secretKey) throws NoSuchPaddingException, NoSuchAlgorithmException {
        this.f3414new = secretKey;
    }

    /* renamed from: if, reason: not valid java name */
    public static SecretKey m1957if(String str, char[] cArr, byte[] bArr) throws NoSuchAlgorithmException, InvalidKeySpecException {
        return new SecretKeySpec(SecretKeyFactory.getInstance(str).generateSecret(new PBEKeySpec(cArr, bArr, YandexMetricaDefaultValues.DEFAULT_MAX_REPORTS_IN_DATABASE_COUNT, 256)).getEncoded(), "AES");
    }

    /* renamed from: do, reason: not valid java name */
    public byte[] m1958do(String str) {
        byte[] doFinal;
        byte[] decode = Base64.decode(str, 3);
        synchronized (this) {
            try {
                this.f3415try.init(2, this.f3414new);
                doFinal = this.f3415try.doFinal(decode);
            } catch (GeneralSecurityException e) {
                throw new IllegalStateException(e);
            }
        }
        return doFinal;
    }
}
