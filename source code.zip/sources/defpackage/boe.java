package defpackage;

import ru.yandex.video.data.Size;
import ru.yandex.video.data.VideoType;
import ru.yandex.video.player.impl.tracking.event.AudioTrack;
import ru.yandex.video.player.impl.tracking.event.ConnectionQuality;
import ru.yandex.video.player.impl.tracking.event.PlaybackState;
import ru.yandex.video.player.impl.tracking.event.VideoTrack;

/* loaded from: classes2.dex */
public final class boe {

    /* renamed from: break, reason: not valid java name */
    public final VideoType f4073break;

    /* renamed from: case, reason: not valid java name */
    public final Long f4074case;

    /* renamed from: catch, reason: not valid java name */
    public final ConnectionQuality f4075catch;

    /* renamed from: class, reason: not valid java name */
    public final Boolean f4076class;

    /* renamed from: const, reason: not valid java name */
    public final int f4077const;

    /* renamed from: do, reason: not valid java name */
    public final long f4078do;

    /* renamed from: else, reason: not valid java name */
    public final VideoTrack f4079else;

    /* renamed from: final, reason: not valid java name */
    public final long f4080final;

    /* renamed from: for, reason: not valid java name */
    public final long f4081for;

    /* renamed from: goto, reason: not valid java name */
    public final VideoTrack f4082goto;

    /* renamed from: if, reason: not valid java name */
    public final boolean f4083if;

    /* renamed from: import, reason: not valid java name */
    public final AudioTrack f4084import;

    /* renamed from: native, reason: not valid java name */
    public final Long f4085native;

    /* renamed from: new, reason: not valid java name */
    public final Long f4086new;

    /* renamed from: super, reason: not valid java name */
    public final Integer f4087super;

    /* renamed from: this, reason: not valid java name */
    public final Size f4088this;

    /* renamed from: throw, reason: not valid java name */
    public final Integer f4089throw;

    /* renamed from: try, reason: not valid java name */
    public final long f4090try;

    /* renamed from: while, reason: not valid java name */
    public final PlaybackState f4091while;

    public boe(long j, boolean z, long j2, Long l, long j3, Long l2, VideoTrack videoTrack, VideoTrack videoTrack2, Size size, VideoType videoType, ConnectionQuality connectionQuality, Boolean bool, int i, long j4, Integer num, Integer num2, PlaybackState playbackState, AudioTrack audioTrack, Long l3) {
        jp5.m8560case(connectionQuality, "connectionQuality");
        jp5.m8560case(playbackState, "playbackState");
        this.f4078do = j;
        this.f4083if = z;
        this.f4081for = j2;
        this.f4086new = l;
        this.f4090try = j3;
        this.f4074case = l2;
        this.f4079else = videoTrack;
        this.f4082goto = videoTrack2;
        this.f4088this = size;
        this.f4073break = videoType;
        this.f4075catch = connectionQuality;
        this.f4076class = bool;
        this.f4077const = i;
        this.f4080final = j4;
        this.f4087super = num;
        this.f4089throw = num2;
        this.f4091while = playbackState;
        this.f4084import = audioTrack;
        this.f4085native = l3;
    }

    public boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof boe) {
                boe boeVar = (boe) obj;
                if (this.f4078do == boeVar.f4078do) {
                    if (this.f4083if == boeVar.f4083if) {
                        if ((this.f4081for == boeVar.f4081for) && jp5.m8563do(this.f4086new, boeVar.f4086new)) {
                            if ((this.f4090try == boeVar.f4090try) && jp5.m8563do(this.f4074case, boeVar.f4074case) && jp5.m8563do(this.f4079else, boeVar.f4079else) && jp5.m8563do(this.f4082goto, boeVar.f4082goto) && jp5.m8563do(this.f4088this, boeVar.f4088this) && jp5.m8563do(this.f4073break, boeVar.f4073break) && jp5.m8563do(this.f4075catch, boeVar.f4075catch) && jp5.m8563do(this.f4076class, boeVar.f4076class)) {
                                if (this.f4077const == boeVar.f4077const) {
                                    if (!(this.f4080final == boeVar.f4080final) || !jp5.m8563do(this.f4087super, boeVar.f4087super) || !jp5.m8563do(this.f4089throw, boeVar.f4089throw) || !jp5.m8563do(this.f4091while, boeVar.f4091while) || !jp5.m8563do(this.f4084import, boeVar.f4084import) || !jp5.m8563do(this.f4085native, boeVar.f4085native)) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public int hashCode() {
        long j = this.f4078do;
        int i = ((int) (j ^ (j >>> 32))) * 31;
        boolean z = this.f4083if;
        int i2 = z;
        if (z != 0) {
            i2 = 1;
        }
        long j2 = this.f4081for;
        int i3 = (((i + i2) * 31) + ((int) (j2 ^ (j2 >>> 32)))) * 31;
        Long l = this.f4086new;
        int hashCode = l != null ? l.hashCode() : 0;
        long j3 = this.f4090try;
        int i4 = (((i3 + hashCode) * 31) + ((int) (j3 ^ (j3 >>> 32)))) * 31;
        Long l2 = this.f4074case;
        int hashCode2 = (i4 + (l2 != null ? l2.hashCode() : 0)) * 31;
        VideoTrack videoTrack = this.f4079else;
        int hashCode3 = (hashCode2 + (videoTrack != null ? videoTrack.hashCode() : 0)) * 31;
        VideoTrack videoTrack2 = this.f4082goto;
        int hashCode4 = (hashCode3 + (videoTrack2 != null ? videoTrack2.hashCode() : 0)) * 31;
        Size size = this.f4088this;
        int hashCode5 = (hashCode4 + (size != null ? size.hashCode() : 0)) * 31;
        VideoType videoType = this.f4073break;
        int hashCode6 = (hashCode5 + (videoType != null ? videoType.hashCode() : 0)) * 31;
        ConnectionQuality connectionQuality = this.f4075catch;
        int hashCode7 = (hashCode6 + (connectionQuality != null ? connectionQuality.hashCode() : 0)) * 31;
        Boolean bool = this.f4076class;
        int hashCode8 = (((hashCode7 + (bool != null ? bool.hashCode() : 0)) * 31) + this.f4077const) * 31;
        long j4 = this.f4080final;
        int i5 = (hashCode8 + ((int) ((j4 >>> 32) ^ j4))) * 31;
        Integer num = this.f4087super;
        int hashCode9 = (i5 + (num != null ? num.hashCode() : 0)) * 31;
        Integer num2 = this.f4089throw;
        int hashCode10 = (hashCode9 + (num2 != null ? num2.hashCode() : 0)) * 31;
        PlaybackState playbackState = this.f4091while;
        int hashCode11 = (hashCode10 + (playbackState != null ? playbackState.hashCode() : 0)) * 31;
        AudioTrack audioTrack = this.f4084import;
        int hashCode12 = (hashCode11 + (audioTrack != null ? audioTrack.hashCode() : 0)) * 31;
        Long l3 = this.f4085native;
        return hashCode12 + (l3 != null ? l3.hashCode() : 0);
    }

    public String toString() {
        StringBuilder r = by.r("PlayerState(timestamp=");
        r.append(this.f4078do);
        r.append(", isMuted=");
        r.append(this.f4083if);
        r.append(", watchedTime=");
        r.append(this.f4081for);
        r.append(", currentPosition=");
        r.append(this.f4086new);
        r.append(", remainingBufferedTime=");
        r.append(this.f4090try);
        r.append(", duration=");
        r.append(this.f4074case);
        r.append(", currentVideo=");
        r.append(this.f4079else);
        r.append(", maxVideoInPlaylist=");
        r.append(this.f4082goto);
        r.append(", capping=");
        r.append(this.f4088this);
        r.append(", videoType=");
        r.append(this.f4073break);
        r.append(", connectionQuality=");
        r.append(this.f4075catch);
        r.append(", isSelectedAdoptionTrackSelection=");
        r.append(this.f4076class);
        r.append(", totalStalledCount=");
        r.append(this.f4077const);
        r.append(", totalStalledTime=");
        r.append(this.f4080final);
        r.append(", droppedFrames=");
        r.append(this.f4087super);
        r.append(", shownFrames=");
        r.append(this.f4089throw);
        r.append(", playbackState=");
        r.append(this.f4091while);
        r.append(", audioTrack=");
        r.append(this.f4084import);
        r.append(", bandwidthEstimate=");
        r.append(this.f4085native);
        r.append(")");
        return r.toString();
    }
}
