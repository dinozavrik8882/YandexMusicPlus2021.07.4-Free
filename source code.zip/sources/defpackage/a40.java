package defpackage;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import java.security.MessageDigest;
import java.util.concurrent.locks.Lock;

/* loaded from: classes.dex */
public class a40 extends v30 {

    /* renamed from: if, reason: not valid java name */
    public static final byte[] f204if = "com.bumptech.glide.load.resource.bitmap.CircleCrop.1".getBytes(jz.f19522do);

    @Override // defpackage.jz
    /* renamed from: do, reason: not valid java name */
    public void mo103do(MessageDigest messageDigest) {
        messageDigest.update(f204if);
    }

    @Override // defpackage.jz
    public boolean equals(Object obj) {
        return obj instanceof a40;
    }

    @Override // defpackage.v30
    /* renamed from: for, reason: not valid java name */
    public Bitmap mo104for(o10 o10Var, Bitmap bitmap, int i, int i2) {
        Paint paint = q40.f30067do;
        int min = Math.min(i, i2);
        float f = min;
        float f2 = f / 2.0f;
        float width = bitmap.getWidth();
        float height = bitmap.getHeight();
        float max = Math.max(f / width, f / height);
        float f3 = width * max;
        float f4 = max * height;
        float f5 = (f - f3) / 2.0f;
        float f6 = (f - f4) / 2.0f;
        RectF rectF = new RectF(f5, f6, f3 + f5, f4 + f6);
        Bitmap m12462for = q40.m12462for(o10Var, bitmap);
        Bitmap mo11310case = o10Var.mo11310case(min, min, q40.m12464new(bitmap));
        mo11310case.setHasAlpha(true);
        Lock lock = q40.f30071try;
        lock.lock();
        try {
            Canvas canvas = new Canvas(mo11310case);
            canvas.drawCircle(f2, f2, f2, q40.f30069if);
            canvas.drawBitmap(m12462for, (Rect) null, rectF, q40.f30068for);
            canvas.setBitmap(null);
            lock.unlock();
            if (!m12462for.equals(bitmap)) {
                o10Var.mo4925try(m12462for);
            }
            return mo11310case;
        } catch (Throwable th) {
            q40.f30071try.unlock();
            throw th;
        }
    }

    @Override // defpackage.jz
    public int hashCode() {
        return 1101716364;
    }
}
