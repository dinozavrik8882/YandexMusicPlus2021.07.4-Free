package defpackage;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.util.Objects;

/* loaded from: classes.dex */
public abstract class x40<T extends Drawable> implements f10<T>, b10 {

    /* renamed from: catch, reason: not valid java name */
    public final T f43244catch;

    public x40(T t) {
        Objects.requireNonNull(t, "Argument must not be null");
        this.f43244catch = t;
    }

    /* renamed from: do */
    public void mo1627do() {
        T t = this.f43244catch;
        if (t instanceof BitmapDrawable) {
            ((BitmapDrawable) t).getBitmap().prepareToDraw();
        } else if (t instanceof f50) {
            ((f50) t).m5614if().prepareToDraw();
        }
    }

    @Override // defpackage.f10
    public Object get() {
        Drawable.ConstantState constantState = this.f43244catch.getConstantState();
        return constantState == null ? this.f43244catch : constantState.newDrawable();
    }
}
