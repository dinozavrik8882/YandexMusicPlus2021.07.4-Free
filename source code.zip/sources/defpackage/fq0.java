package defpackage;

import com.google.android.exoplayer2.util.Util;
import defpackage.up0;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class fq0 extends aq0 {

    /* renamed from: this, reason: not valid java name */
    public static final int f12408this = Float.floatToIntBits(Float.NaN);

    /* renamed from: class, reason: not valid java name */
    public static void m6195class(int i, ByteBuffer byteBuffer) {
        int floatToIntBits = Float.floatToIntBits((float) (i * 4.656612875245797E-10d));
        if (floatToIntBits == f12408this) {
            floatToIntBits = Float.floatToIntBits(0.0f);
        }
        byteBuffer.putInt(floatToIntBits);
    }

    @Override // defpackage.aq0
    /* renamed from: else */
    public up0.a mo1432else(up0.a aVar) throws up0.b {
        int i = aVar.f39284new;
        if (Util.isEncodingHighResolutionPcm(i)) {
            return i != 4 ? new up0.a(aVar.f39283if, aVar.f39282for, 4) : up0.a.f39281do;
        }
        throw new up0.b(aVar);
    }

    @Override // defpackage.up0
    /* renamed from: new */
    public void mo2262new(ByteBuffer byteBuffer) {
        ByteBuffer m1430catch;
        int position = byteBuffer.position();
        int limit = byteBuffer.limit();
        int i = limit - position;
        int i2 = this.f2380if.f39284new;
        if (i2 == 536870912) {
            m1430catch = m1430catch((i / 3) * 4);
            while (position < limit) {
                m6195class(((byteBuffer.get(position) & 255) << 8) | ((byteBuffer.get(position + 1) & 255) << 16) | ((byteBuffer.get(position + 2) & 255) << 24), m1430catch);
                position += 3;
            }
        } else {
            if (i2 != 805306368) {
                throw new IllegalStateException();
            }
            m1430catch = m1430catch(i);
            while (position < limit) {
                m6195class((byteBuffer.get(position) & 255) | ((byteBuffer.get(position + 1) & 255) << 8) | ((byteBuffer.get(position + 2) & 255) << 16) | ((byteBuffer.get(position + 3) & 255) << 24), m1430catch);
                position += 4;
            }
        }
        byteBuffer.position(byteBuffer.limit());
        m1430catch.flip();
    }
}
