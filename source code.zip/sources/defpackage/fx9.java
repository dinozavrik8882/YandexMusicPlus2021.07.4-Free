package defpackage;

import defpackage.ww9;

/* loaded from: classes2.dex */
public class fx9 extends ww9 {

    /* renamed from: const, reason: not valid java name */
    public final a f12724const;

    /* renamed from: final, reason: not valid java name */
    public final String f12725final;

    /* loaded from: classes2.dex */
    public enum a {
        NEW_RELEASES,
        NEW_PLAYLISTS,
        CHART,
        PODCAST
    }

    public fx9(String str, ww9.b bVar, a aVar, String str2) {
        super(ww9.c.TAB, str, bVar);
        this.f12724const = aVar;
        this.f12725final = str2;
    }
}
