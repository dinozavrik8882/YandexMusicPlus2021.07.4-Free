package defpackage;

import ru.yandex.music.search.suggestions.view.SuggestionSearchView;

/* loaded from: classes2.dex */
public final class ebc extends gqe {

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ SuggestionSearchView f9836class;

    public ebc(SuggestionSearchView suggestionSearchView) {
        this.f9836class = suggestionSearchView;
    }

    @Override // defpackage.gqe
    /* renamed from: do */
    public void mo2756do() {
        this.f9836class.setOnSearchListener(null);
    }
}
