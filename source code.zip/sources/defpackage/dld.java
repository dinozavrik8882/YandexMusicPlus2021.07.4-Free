package defpackage;

/* loaded from: classes2.dex */
public final class dld extends yq3 implements aae {

    /* renamed from: for, reason: not valid java name */
    public static final dld f8720for = new dld();

    @Override // defpackage.aae
    /* renamed from: break */
    public void mo385break(String str, int i, int i2, String str2, String str3, String str4) {
        jp5.m8570try(str, "currentStoryId");
        jp5.m8570try(str2, "screenKey");
        dn3.e0(m17714static(), "PlusHouse_Story_DownloadStarted", null, 2);
    }

    @Override // defpackage.aae
    /* renamed from: class */
    public void mo386class(String str, int i, int i2, boolean z, String str2, String str3, String str4) {
        jp5.m8570try(str, "lastStartedStoryId");
        jp5.m8570try(str2, "screenKey");
        dn3.e0(m17714static(), "PlusHouse_Story_DownloadFinished", null, 2);
    }

    @Override // defpackage.aae
    /* renamed from: do */
    public void mo387do(String str, int i, int i2, int i3, String str2, String str3, String str4) {
        jp5.m8570try(str, "currentStoryId");
        jp5.m8570try(str2, "screenKey");
        dn3.e0(m17714static(), "PlusHouse_Story_ButtonTapped", null, 2);
    }

    @Override // defpackage.aae
    /* renamed from: if */
    public void mo388if(String str, int i, int i2, int i3, String str2, String str3, String str4) {
        jp5.m8570try(str, "currentStoryId");
        jp5.m8570try(str2, "screenKey");
        dn3.e0(m17714static(), "PlusHouse_Story_PlaybackStarted", null, 2);
    }

    @Override // defpackage.aae
    /* renamed from: import */
    public void mo389import(String str, int i, int i2, long j, int i3, long j2, String str2, String str3, String str4) {
        jp5.m8570try(str, "lastStartedStoryId");
        jp5.m8570try(str2, "screenKey");
        dn3.e0(m17714static(), "PlusHouse_Story_PlaybackFinished", null, 2);
    }
}
