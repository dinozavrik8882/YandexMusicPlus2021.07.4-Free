package defpackage;

import defpackage.fx8;

/* loaded from: classes2.dex */
public final class gx8 {

    /* renamed from: do, reason: not valid java name */
    public final fx8 f14319do;

    /* renamed from: if, reason: not valid java name */
    public final fx8 f14320if;

    public gx8(fx8.a aVar, fx8.a aVar2) {
        jp5.m8570try(aVar, "prevActions");
        jp5.m8570try(aVar2, "nextActions");
        this.f14319do = new fx8(aVar, 100L);
        this.f14320if = new fx8(aVar2, 100L);
    }
}
