package defpackage;

import android.content.Context;
import android.content.SharedPreferences;
import android.opengl.GLES20;
import android.os.Bundle;
import com.yandex.auth.sync.AccountProvider;
import com.yandex.metrica.YandexMetricaDefaultValues;
import com.yandex.metrica.rtm.Constants;
import com.yandex.metrica.rtm.service.EventProcessor;
import defpackage.bz3;
import defpackage.j;
import defpackage.k1a;
import defpackage.o5a;
import defpackage.z78;
import defpackage.zq3;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import ru.yandex.music.common.media.context.Page;
import ru.yandex.music.common.media.context.PlaybackScope;

/* loaded from: classes2.dex */
public final class a4a {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f223do;
    public final mq5 a;

    /* renamed from: abstract, reason: not valid java name */
    public String f224abstract;
    public final el5 b;

    /* renamed from: break, reason: not valid java name */
    public final el5 f225break;
    public nv5 c;

    /* renamed from: case, reason: not valid java name */
    public final el5 f226case;

    /* renamed from: catch, reason: not valid java name */
    public final el5 f227catch;

    /* renamed from: class, reason: not valid java name */
    public final el5 f228class;

    /* renamed from: const, reason: not valid java name */
    public final vn8 f229const;

    /* renamed from: continue, reason: not valid java name */
    public t4c f230continue;
    public final nz5<Boolean> d;

    /* renamed from: default, reason: not valid java name */
    public final zzc f231default;
    public boolean e;

    /* renamed from: else, reason: not valid java name */
    public final el5 f232else;

    /* renamed from: extends, reason: not valid java name */
    public List<? extends v1a> f233extends;

    /* renamed from: final, reason: not valid java name */
    public final PlaybackScope f234final;

    /* renamed from: finally, reason: not valid java name */
    public Map<String, t4c> f235finally;

    /* renamed from: for, reason: not valid java name */
    public a f236for;

    /* renamed from: goto, reason: not valid java name */
    public final el5 f237goto;

    /* renamed from: if, reason: not valid java name */
    public final Context f238if;

    /* renamed from: implements, reason: not valid java name */
    public final nz5<Boolean> f239implements;

    /* renamed from: import, reason: not valid java name */
    public final v2a f240import;

    /* renamed from: instanceof, reason: not valid java name */
    public boolean f241instanceof;

    /* renamed from: interface, reason: not valid java name */
    public boolean f242interface;

    /* renamed from: native, reason: not valid java name */
    public final o f243native;

    /* renamed from: new, reason: not valid java name */
    public final mq5 f244new;

    /* renamed from: package, reason: not valid java name */
    public t4c f245package;

    /* renamed from: private, reason: not valid java name */
    public w68 f246private;

    /* renamed from: protected, reason: not valid java name */
    public boolean f247protected;

    /* renamed from: public, reason: not valid java name */
    public final zv4 f248public;

    /* renamed from: return, reason: not valid java name */
    public zv4 f249return;

    /* renamed from: static, reason: not valid java name */
    public final gu5 f250static;

    /* renamed from: strictfp, reason: not valid java name */
    public g1a f251strictfp;

    /* renamed from: super, reason: not valid java name */
    public final el5 f252super;

    /* renamed from: switch, reason: not valid java name */
    public yv4 f253switch;

    /* renamed from: synchronized, reason: not valid java name */
    public g69 f254synchronized;

    /* renamed from: this, reason: not valid java name */
    public final el5 f255this;

    /* renamed from: throw, reason: not valid java name */
    public final el5 f256throw;
    public boolean throwables;

    /* renamed from: throws, reason: not valid java name */
    public n4a f257throws;

    /* renamed from: transient, reason: not valid java name */
    public boolean f258transient;

    /* renamed from: try, reason: not valid java name */
    public final el5 f259try;

    /* renamed from: volatile, reason: not valid java name */
    public Integer f260volatile;

    /* renamed from: while, reason: not valid java name */
    public final a5a f261while;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: case, reason: not valid java name */
        void mo132case(int i);

        /* renamed from: do, reason: not valid java name */
        void mo133do();

        /* renamed from: for, reason: not valid java name */
        void mo134for();

        /* renamed from: if, reason: not valid java name */
        void mo135if();

        /* renamed from: new, reason: not valid java name */
        void mo136new();

        /* renamed from: try, reason: not valid java name */
        void mo137try(bo5<pl5> bo5Var);
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements bo5<pl5> {
        public b() {
            super(0);
        }

        @Override // defpackage.bo5
        public pl5 invoke() {
            SharedPreferences.Editor edit = ((r9d) a4a.this.f225break.getValue()).edit();
            jp5.m8567if(edit, "editor");
            edit.putBoolean("smart_radio_block_wizard_skipped", true);
            edit.apply();
            dn3.e0(l1a.f21386for.m17714static(), "RadioSmartBlock_WizardAlert_Closed", null, 2);
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements mo5<Integer, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ aq5 f263catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ ArrayList<Integer> f264class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ a4a f265const;

        /* renamed from: final, reason: not valid java name */
        public final /* synthetic */ boolean f266final;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(aq5 aq5Var, ArrayList<Integer> arrayList, a4a a4aVar, boolean z) {
            super(1);
            this.f263catch = aq5Var;
            this.f264class = arrayList;
            this.f265const = a4aVar;
            this.f266final = z;
        }

        @Override // defpackage.mo5
        public pl5 invoke(Integer num) {
            aq5 aq5Var;
            int i;
            int intValue = num.intValue();
            if (intValue <= 50 || (i = (aq5Var = this.f263catch).f2391catch) >= 3) {
                this.f264class.add(Integer.valueOf(intValue));
            } else {
                aq5Var.f2391catch = i + 1;
            }
            if (this.f264class.size() >= 10) {
                n4a n4aVar = this.f265const.f257throws;
                if (n4aVar != null) {
                    n4aVar.m10763new(null);
                }
                ArrayList<Integer> arrayList = this.f264class;
                jp5.m8570try(arrayList, "$this$sum");
                Iterator<T> it = arrayList.iterator();
                int i2 = 0;
                while (it.hasNext()) {
                    i2 += ((Number) it.next()).intValue();
                }
                final int size = YandexMetricaDefaultValues.DEFAULT_MAX_REPORTS_IN_DATABASE_COUNT / (i2 / arrayList.size());
                k2f.f19768new.mo8764do("onAnimationFpsMeasured(optimize=" + this.f266final + "): fps=" + size, new Object[0]);
                final a4a a4aVar = this.f265const;
                final ArrayList<Integer> arrayList2 = this.f264class;
                final aq5 aq5Var2 = this.f263catch;
                final boolean z = this.f266final;
                bad.m1888if(new Runnable() { // from class: l3a
                    @Override // java.lang.Runnable
                    public final void run() {
                        e6a e6aVar;
                        n4a n4aVar2;
                        a4a a4aVar2 = a4a.this;
                        int i3 = size;
                        ArrayList arrayList3 = arrayList2;
                        aq5 aq5Var3 = aq5Var2;
                        boolean z2 = z;
                        jp5.m8570try(a4aVar2, "this$0");
                        jp5.m8570try(arrayList3, "$fpsList");
                        jp5.m8570try(aq5Var3, "$dropCount");
                        final boolean z3 = true;
                        boolean z4 = i3 > 20;
                        a4aVar2.throwables = z4;
                        l1a l1aVar = l1a.f21386for;
                        int i4 = aq5Var3.f2391catch;
                        Objects.requireNonNull(l1aVar);
                        jp5.m8570try(arrayList3, "frameTimeList");
                        String str = z2 ? "_optimized" : "";
                        nq3 m17714static = l1aVar.m17714static();
                        el5 g1 = dn3.g1(fl5.NONE, zq3.a.f47754catch);
                        String m8559break = jp5.m8559break("available", str);
                        Boolean valueOf = Boolean.valueOf(z4);
                        jp5.m8570try(m8559break, AccountProvider.NAME);
                        ((Map) g1.getValue()).put(m8559break, valueOf);
                        String m8559break2 = jp5.m8559break("fps_average", str);
                        Integer valueOf2 = Integer.valueOf(i3);
                        jp5.m8570try(m8559break2, AccountProvider.NAME);
                        ((Map) g1.getValue()).put(m8559break2, valueOf2);
                        String m8559break3 = jp5.m8559break("frame_times", str);
                        String obj = arrayList3.toString();
                        jp5.m8570try(m8559break3, AccountProvider.NAME);
                        ((Map) g1.getValue()).put(m8559break3, obj);
                        String m8559break4 = jp5.m8559break("drop_count", str);
                        Integer valueOf3 = Integer.valueOf(i4);
                        jp5.m8570try(m8559break4, AccountProvider.NAME);
                        ((Map) g1.getValue()).put(m8559break4, valueOf3);
                        by.P("RadioSmartBlock_ShaderAnimation_GetInfo", g1.mo2941do() ? (Map) g1.getValue() : null, m17714static);
                        if (a4aVar2.throwables) {
                            g69 g69Var = a4aVar2.f254synchronized;
                            if (g69Var == null || (n4aVar2 = a4aVar2.f257throws) == null) {
                                return;
                            }
                            n4aVar2.m10764try(g69Var);
                            return;
                        }
                        if (z2) {
                            n4a n4aVar3 = a4aVar2.f257throws;
                            if (n4aVar3 == null || (e6aVar = n4aVar3.f25027catch) == null) {
                                return;
                            }
                            e6aVar.f9570do.queueEvent(new v5a(e6aVar, false));
                            return;
                        }
                        n4a n4aVar4 = a4aVar2.f257throws;
                        if (n4aVar4 != null) {
                            final e6a e6aVar2 = n4aVar4.f25027catch;
                            if (e6aVar2 != null) {
                                e6aVar2.f9570do.queueEvent(new Runnable() { // from class: x5a
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        e6a e6aVar3 = e6a.this;
                                        boolean z5 = z3;
                                        jp5.m8570try(e6aVar3, "this$0");
                                        d6a d6aVar = e6aVar3.f9574if;
                                        d6aVar.f8071default = z5;
                                        GLES20.glUniform1i(d6aVar.throwables, z5 ? 2 : 4);
                                    }
                                });
                            }
                            n4aVar4.f25029const = 0.16f;
                            n4aVar4.m10760do().getHolder().setFixedSize((int) (r2.getMeasuredWidth() * n4aVar4.f25029const), (int) (r2.getMeasuredHeight() * n4aVar4.f25029const));
                        }
                        a4aVar2.m123catch(true);
                    }
                });
            }
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends kp5 implements bo5<x0d> {

        /* renamed from: catch, reason: not valid java name */
        public static final d f267catch = new d();

        public d() {
            super(0);
        }

        @Override // defpackage.bo5
        public x0d invoke() {
            return new x0d();
        }
    }

    /* loaded from: classes2.dex */
    public static final class e extends kp5 implements bo5<t1a> {

        /* renamed from: catch, reason: not valid java name */
        public static final e f268catch = new e();

        public e() {
            super(0);
        }

        @Override // defpackage.bo5
        public t1a invoke() {
            return new t1a();
        }
    }

    /* loaded from: classes2.dex */
    public static final class f extends kp5 implements bo5<ayb> {

        /* renamed from: catch, reason: not valid java name */
        public static final f f269catch = new f();

        public f() {
            super(0);
        }

        @Override // defpackage.bo5
        public ayb invoke() {
            Page m16332do = w1a.Companion.m16332do(w1a.LANDING);
            jp5.m8570try(m16332do, "page");
            return new k1a(m16332do, k1a.a.MAIN);
        }
    }

    /* loaded from: classes2.dex */
    public static final class g extends lq5<Float> {

        /* renamed from: for, reason: not valid java name */
        public final /* synthetic */ a4a f270for;

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ Object f271if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(Object obj, Object obj2, a4a a4aVar) {
            super(obj2);
            this.f271if = obj;
            this.f270for = a4aVar;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, Float f, Float f2) {
            n4a n4aVar;
            jp5.m8570try(mr5Var, "property");
            float floatValue = f2.floatValue();
            float floatValue2 = f.floatValue();
            n4a n4aVar2 = this.f270for.f257throws;
            if (n4aVar2 != null) {
                n4aVar2.f25033if.mo9879do(n4aVar2, n4a.f25024do[0], Float.valueOf(floatValue));
            }
            if (!(floatValue == 0.0f) || floatValue2 <= 0.0f) {
                if (!(floatValue2 == 0.0f) || floatValue <= 0.0f || (n4aVar = this.f270for.f257throws) == null) {
                    return;
                }
                n4aVar.m10762if();
                return;
            }
            n4a n4aVar3 = this.f270for.f257throws;
            if (n4aVar3 == null) {
                return;
            }
            n4aVar3.f25025break.f17603package = true;
            e6a e6aVar = n4aVar3.f25027catch;
            if (e6aVar == null) {
                return;
            }
            e6aVar.f9570do.onPause();
        }
    }

    /* loaded from: classes2.dex */
    public static final class h extends lq5<j.f> {

        /* renamed from: for, reason: not valid java name */
        public final /* synthetic */ a4a f272for;

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ Object f273if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public h(Object obj, Object obj2, a4a a4aVar) {
            super(obj2);
            this.f273if = obj;
            this.f272for = a4aVar;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, j.f fVar, j.f fVar2) {
            o5a.b bVar;
            jp5.m8570try(mr5Var, "property");
            j.f fVar3 = fVar2;
            n4a n4aVar = this.f272for.f257throws;
            if (n4aVar != null) {
                jp5.m8570try(fVar3, "state");
                defpackage.j jVar = n4aVar.f25025break;
                Objects.requireNonNull(jVar);
                jp5.m8570try(fVar3, "<set-?>");
                jVar.f17602new.mo9879do(jVar, defpackage.j.f17583do[1], fVar3);
            }
            o oVar = this.f272for.f243native;
            Objects.requireNonNull(oVar);
            jp5.m8570try(fVar3, "rupState");
            k0f<o5a.b> k0fVar = oVar.f26337break;
            int ordinal = fVar3.ordinal();
            if (ordinal == 3) {
                bVar = oVar.m11279do() ? o5a.b.FLOW : o5a.b.NONE;
            } else if (ordinal == 4) {
                bVar = oVar.m11281if() ? o5a.b.HOME : o5a.b.NONE;
            } else if (ordinal != 5) {
                return;
            } else {
                bVar = o5a.b.NONE;
            }
            k0fVar.mo1523case(bVar);
        }
    }

    /* loaded from: classes2.dex */
    public static final class i extends kp5 implements bo5<w4a> {

        /* renamed from: catch, reason: not valid java name */
        public static final i f274catch = new i();

        public i() {
            super(0);
        }

        @Override // defpackage.bo5
        public w4a invoke() {
            return new w4a();
        }
    }

    /* loaded from: classes2.dex */
    public static final class j extends kp5 implements bo5<r9d> {
        public j() {
            super(0);
        }

        @Override // defpackage.bo5
        public r9d invoke() {
            a4a a4aVar = a4a.this;
            Context context = a4aVar.f238if;
            mg9 mo9658else = ((qg9) a4aVar.f259try.getValue()).mo9658else();
            jp5.m8568new(mo9658else, "userCenter.latestSmallUser()");
            jp5.m8570try(context, "context");
            jp5.m8570try(mo9658else, "smallUser");
            String id = mo9658else.getId();
            jp5.m8570try(context, "context");
            jp5.m8570try(id, EventProcessor.KEY_USER_ID);
            return new r9d(context, id, "prefs", 0, null);
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[13];
        op5 op5Var = new op5(dq5.m4763do(a4a.class), "blockAlpha", "getBlockAlpha()F");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        mr5VarArr[0] = op5Var;
        wp5 wp5Var = new wp5(dq5.m4763do(a4a.class), "userCenter", "getUserCenter()Lru/yandex/music/data/user/UserCenter;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[1] = wp5Var;
        wp5 wp5Var2 = new wp5(dq5.m4763do(a4a.class), "radioCatalogCenter", "getRadioCatalogCenter()Lru/yandex/music/radio/store/RadioCatalogCenter;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[2] = wp5Var2;
        wp5 wp5Var3 = new wp5(dq5.m4763do(a4a.class), "playbackControl", "getPlaybackControl()Lru/yandex/music/common/media/control/PlaybackControl;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[3] = wp5Var3;
        wp5 wp5Var4 = new wp5(dq5.m4763do(a4a.class), "playbackContextManager", "getPlaybackContextManager()Lru/yandex/music/common/media/context/PlaybackContextManager;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[4] = wp5Var4;
        wp5 wp5Var5 = new wp5(dq5.m4763do(a4a.class), "landingCenter", "getLandingCenter()Lru/yandex/music/landing/LandingCenter;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[5] = wp5Var5;
        op5 op5Var2 = new op5(dq5.m4763do(a4a.class), "blockState", "getBlockState()Lru/yandex/music/landing/rup/RupView$State;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[11] = op5Var2;
        wp5 wp5Var6 = new wp5(dq5.m4763do(a4a.class), "audioVisualizationCenter", "getAudioVisualizationCenter()Lru/yandex/music/landing/rup/shaderanim/utils/AudioVisualizationCenter;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[12] = wp5Var6;
        f223do = mr5VarArr;
    }

    public a4a(Context context, Bundle bundle) {
        jp5.m8570try(context, "context");
        this.f238if = context;
        Float valueOf = Float.valueOf(1.0f);
        this.f244new = new g(valueOf, valueOf, this);
        ez3 m2424if = bz3.m2424if(true, dn3.l3(qg9.class));
        mr5<Object>[] mr5VarArr = f223do;
        this.f259try = m2424if.m5533do(mr5VarArr[1]);
        this.f226case = bz3.m2424if(true, dn3.l3(nub.class)).m5533do(mr5VarArr[2]);
        this.f232else = bz3.m2424if(true, dn3.l3(oa8.class)).m5533do(mr5VarArr[3]);
        this.f237goto = bz3.m2424if(true, dn3.l3(w78.class)).m5533do(mr5VarArr[4]);
        this.f255this = bz3.m2424if(true, dn3.l3(jt9.class)).m5533do(mr5VarArr[5]);
        this.f225break = dn3.h1(new j());
        this.f227catch = dn3.h1(d.f267catch);
        this.f228class = dn3.h1(i.f274catch);
        this.f229const = new vn8();
        PlaybackScope m322const = a88.m322const();
        jp5.m8568new(m322const, "forRadio()");
        this.f234final = m322const;
        this.f252super = dn3.h1(f.f269catch);
        this.f256throw = dn3.h1(e.f268catch);
        this.f261while = new a5a();
        v2a v2aVar = new v2a(context);
        this.f240import = v2aVar;
        this.f243native = new o(context, v2aVar);
        cw4 cw4Var = new cw4(false);
        this.f248public = cw4Var;
        this.f249return = new cw4(false);
        this.f250static = dn3.m4644extends(cw4Var, kv4.m9275do());
        this.f231default = new zzc(context);
        this.f233extends = new ArrayList();
        this.f235finally = new HashMap();
        Boolean bool = Boolean.FALSE;
        this.f239implements = c06.m2489do(bool);
        j.f fVar = j.f.PLACEHOLDER;
        this.a = new h(fVar, fVar, this);
        this.b = bz3.m2424if(true, dn3.l3(i6a.class)).m5533do(mr5VarArr[12]);
        this.d = c06.m2489do(bool);
        Serializable serializable = bundle == null ? null : bundle.getSerializable("BUNDLE_KEY_STATION_DESCRIPTOR");
        this.f230continue = serializable instanceof t4c ? (t4c) serializable : null;
    }

    /* renamed from: break, reason: not valid java name */
    public static void m117break(a4a a4aVar, boolean z, bo5 bo5Var, int i2) {
        if ((i2 & 1) != 0) {
            z = false;
        }
        int i3 = i2 & 2;
        dn3.e1(a4aVar.f250static, null, null, new e4a(a4aVar, z, null, null), 3, null);
    }

    /* renamed from: do, reason: not valid java name */
    public static final j.f m118do(a4a a4aVar) {
        return (j.f) a4aVar.a.mo9880if(a4aVar, f223do[11]);
    }

    /* renamed from: for, reason: not valid java name */
    public static final void m119for(a4a a4aVar, Throwable th) {
        Objects.requireNonNull(a4aVar);
        k2f.f19768new.mo8761case(th, "Can't load radio dashboard items from network", new Object[0]);
        a4aVar.f258transient = true;
        a4aVar.f241instanceof = false;
        a4aVar.f246private = null;
        a4aVar.f245package = null;
        a4aVar.m128goto().m16386if(null);
        a4aVar.m127final(j.f.ERROR);
    }

    /* renamed from: if, reason: not valid java name */
    public static final Object m120if(a4a a4aVar, boolean z, wm5 wm5Var) {
        Objects.requireNonNull(a4aVar);
        return dn3.F3(kv4.f21091if, new g4a(a4aVar, z, null), wm5Var);
    }

    /* renamed from: new, reason: not valid java name */
    public static final void m121new(final a4a a4aVar, List list) {
        Objects.requireNonNull(a4aVar);
        k2f.f19768new.mo8764do(jp5.m8559break("setupRadioDashboard, flowItems: ", Integer.valueOf(list.size())), new Object[0]);
        a4aVar.f233extends = list;
        n4a n4aVar = a4aVar.f257throws;
        if (n4aVar != null) {
            n4aVar.f25036try.mo9879do(n4aVar, n4a.f25024do[3], Boolean.valueOf(xl5.m17161abstract(list) instanceof r1a));
            jp5.m8570try(list, Constants.KEY_DATA);
            defpackage.j jVar = n4aVar.f25025break;
            Objects.requireNonNull(jVar);
            jp5.m8570try(list, "items");
            jVar.f17593extends = list;
        }
        yv4 yv4Var = a4aVar.f253switch;
        boolean z = yv4Var == null;
        if (yv4Var != null) {
            yv4Var.x();
        }
        yv4 mo3909super = a4aVar.f248public.mo3909super();
        a4aVar.f253switch = mo3909super;
        a4aVar.f245package = null;
        a4aVar.f247protected = false;
        a4aVar.f258transient = false;
        spe m14387implements = spe.m14371break(a4aVar.m131try().mo10281switch(), a4aVar.m131try().mo10261catch().m14390interface(new yqe() { // from class: m3a
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                mr5<Object>[] mr5VarArr = a4a.f223do;
                z78 z78Var = ((go8) obj).f13952new;
                if (z78Var instanceof z78.a) {
                    return z78Var;
                }
                return null;
            }
        }), new zqe() { // from class: i3a
            @Override // defpackage.zqe
            /* renamed from: do */
            public final Object mo571do(Object obj, Object obj2) {
                mr5<Object>[] mr5VarArr = a4a.f223do;
                return new hl5((ia8) obj, (z78) obj2);
            }
        }).m14388import(new yqe() { // from class: g3a
            /* JADX WARN: Multi-variable type inference failed */
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                hl5 hl5Var = (hl5) obj;
                mr5<Object>[] mr5VarArr = a4a.f223do;
                ia8 ia8Var = (ia8) hl5Var.f15273catch;
                z78 z78Var = (z78) hl5Var.f15274class;
                return new hl5(ia8Var, z78Var == null ? null : z78Var.mo17875if());
            }
        }).m14387implements(jqe.m8590do());
        jp5.m8568new(m14387implements, "combineLatest(\n            playbackControl.queuesLaunches(),\n            playbackControl.queuesEvents().map { event -> event.playbackEntity.takeIf { it is PlaybackEntity.GlagolEntity } }\n        ) { descriptorEvent, playbackEntity -> descriptorEvent to playbackEntity }\n            .distinctUntilChanged { (descriptorEvent, playbackEntity) -> descriptorEvent to playbackEntity?.id }\n            .observeOn(AndroidSchedulers.mainThread())");
        dn3.z2(m14387implements, mo3909super, new j4a(a4aVar, z));
        spe m14387implements2 = spe.m14371break(a4aVar.m131try().mo10262class().m14390interface(new yqe() { // from class: h3a
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                mr5<Object>[] mr5VarArr = a4a.f223do;
                return Boolean.valueOf(((qb8) obj).f30427for);
            }
        }), a4aVar.m131try().mo10261catch().m14388import(new yqe() { // from class: f3a
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                mr5<Object>[] mr5VarArr = a4a.f223do;
                return ((go8) obj).f13952new.mo17875if();
            }
        }).m14390interface(new yqe() { // from class: j3a
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                a4a a4aVar2 = a4a.this;
                go8 go8Var = (go8) obj;
                jp5.m8570try(a4aVar2, "this$0");
                boolean z2 = false;
                if (!a4aVar2.f258transient) {
                    Map<String, t4c> map = a4aVar2.f235finally;
                    jp5.m8568new(go8Var, "it");
                    if (map.get(qd9.m12651break(go8Var)) != null) {
                        z2 = true;
                    }
                }
                return Boolean.valueOf(z2);
            }
        }), new zqe() { // from class: e3a
            @Override // defpackage.zqe
            /* renamed from: do */
            public final Object mo571do(Object obj, Object obj2) {
                boolean z2;
                Boolean bool = (Boolean) obj;
                Boolean bool2 = (Boolean) obj2;
                mr5<Object>[] mr5VarArr = a4a.f223do;
                jp5.m8568new(bool, "playWhenReady");
                if (bool.booleanValue()) {
                    jp5.m8568new(bool2, "isRadioStation");
                    if (bool2.booleanValue()) {
                        z2 = true;
                        return Boolean.valueOf(z2);
                    }
                }
                z2 = false;
                return Boolean.valueOf(z2);
            }
        }).m14403while().m14387implements(jqe.m8590do());
        jp5.m8568new(m14387implements2, "combineLatest(\n                playbackControl.playbackEvents().map { it.playWhenReady },\n                playbackControl.queuesEvents().distinctUntilChanged { event -> event.playbackEntity.id }.map {\n                    if (isLoadingFailed) {\n                        false\n                    } else {\n                        val matchedStationQueue = stations[it.contextId()]\n                        matchedStationQueue != null\n                    }\n                }\n            ) { playWhenReady, isRadioStation ->\n                playWhenReady && isRadioStation\n            }\n            .distinctUntilChanged()\n            .observeOn(AndroidSchedulers.mainThread())");
        dn3.z2(m14387implements2, mo3909super, new i4a(a4aVar));
        iz3 l3 = dn3.l3(v14.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        String m14341new = ((ui8) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(ui8.class))).m14341new();
        if (jp5.m8563do(m14341new, "on") || jp5.m8563do(m14341new, "on1")) {
            nv5 nv5Var = a4aVar.c;
            if (nv5Var != null) {
                dn3.i(nv5Var, null, 1, null);
            }
            a4aVar.c = dn3.e1(a4aVar.f250static, null, null, new k4a(dn3.z3(dn3.V(new jz5(a4aVar.d, a4aVar.f239implements, new m4a(null))), new l4a(null, a4aVar)), null, a4aVar), 3, null);
        }
    }

    /* renamed from: case, reason: not valid java name */
    public final x0d m122case() {
        return (x0d) this.f227catch.getValue();
    }

    /* renamed from: catch, reason: not valid java name */
    public final void m123catch(boolean z) {
        ArrayList arrayList = new ArrayList();
        aq5 aq5Var = new aq5();
        n4a n4aVar = this.f257throws;
        if (n4aVar == null) {
            return;
        }
        c cVar = new c(aq5Var, arrayList, this, z);
        e6a e6aVar = n4aVar.f25027catch;
        if (e6aVar == null) {
            return;
        }
        e6aVar.f9574if.f8079native = cVar;
    }

    /* renamed from: class, reason: not valid java name */
    public final void m124class(w68 w68Var) {
        t4c m129super = m129super(w68Var);
        w68 mo2231do = m131try().mo10269finally().mo2231do();
        jp5.m8568new(mo2231do, "playbackControl.playbackQueue.descriptor()");
        if (!jp5.m8563do(m129super, m129super(mo2231do))) {
            m130this(w68Var);
            return;
        }
        if (m131try().isPlaying()) {
            dn3.e0(l1a.f21386for.m17714static(), "RadioSmartBlock_Playing_Paused", null, 2);
        } else {
            g1a g1aVar = this.f251strictfp;
            if (g1aVar != null) {
                l1a.f21386for.m9366switch(g1aVar.m6332if());
            }
            if (this.f240import.m15873catch()) {
                a aVar = this.f236for;
                if (aVar != null) {
                    aVar.mo135if();
                }
                this.f240import.m15872case();
            }
        }
        m131try().toggle();
    }

    /* renamed from: const, reason: not valid java name */
    public final w68 m125const(t4c t4cVar) {
        t78 m16432new = ((w78) this.f237goto.getValue()).m16432new(this.f234final, t4cVar, ((qg9) this.f259try.getValue()).mo9664try().f45519class);
        jp5.m8568new(m16432new, "playbackContextManager.contextForStation(\n            playbackScope,\n            this,\n            userCenter.latestUser().user\n        )");
        w68 mo11102do = this.f229const.m16164do(m16432new, t4cVar).mo11105new((ayb) this.f252super.getValue()).mo11102do();
        jp5.m8568new(mo11102do, "playbackQueueBuilder\n            .station(playbackContext, this)\n            .radioFrom(radioFrom)\n            .build()");
        return mo11102do;
    }

    /* renamed from: else, reason: not valid java name */
    public final nub m126else() {
        return (nub) this.f226case.getValue();
    }

    /* renamed from: final, reason: not valid java name */
    public final void m127final(j.f fVar) {
        this.a.mo9879do(this, f223do[11], fVar);
    }

    /* renamed from: goto, reason: not valid java name */
    public final w4a m128goto() {
        return (w4a) this.f228class.getValue();
    }

    /* renamed from: super, reason: not valid java name */
    public final t4c m129super(w68 w68Var) {
        if (!(!jp5.m8563do(w68Var, sn8.f35685if))) {
            w68Var = null;
        }
        t4c t4cVar = w68Var != null ? (t4c) w68Var.mo6207do((t1a) this.f256throw.getValue()) : null;
        if (t4cVar != null) {
            return t4cVar;
        }
        t4c t4cVar2 = t4c.f36587catch;
        jp5.m8568new(t4cVar2, "NONE");
        return t4cVar2;
    }

    /* renamed from: this, reason: not valid java name */
    public final void m130this(w68 w68Var) {
        g1a g1aVar = this.f251strictfp;
        String m6332if = g1aVar == null ? null : g1aVar.m6332if();
        m122case().m16882new(w68Var);
        if (m6332if != null) {
            l1a.f21386for.m9366switch(m6332if);
        }
        iz3 l3 = dn3.l3(v14.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        if (!((x1a) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(x1a.class))).m13409else() || ((jt9) this.f255this.getValue()).f19265break || ((r9d) this.f225break.getValue()).getBoolean("smart_radio_block_wizard_skipped", false) || this.e) {
            return;
        }
        ftb ftbVar = w68Var instanceof ftb ? (ftb) w68Var : null;
        this.f230continue = ftbVar == null ? null : ftbVar.f12503new;
        dn3.e0(l1a.f21386for.m17714static(), "RadioSmartBlock_WizardAlert_Shown", null, 2);
        this.e = true;
        a aVar = this.f236for;
        if (aVar == null) {
            return;
        }
        aVar.mo137try(new b());
    }

    /* renamed from: try, reason: not valid java name */
    public final oa8 m131try() {
        return (oa8) this.f232else.getValue();
    }
}
