package defpackage;

/* loaded from: classes2.dex */
public final class mp7 extends ro4 {
    public mp7() {
        super("AndroidChartTrackCell", false, false, false, 14);
    }
}
