package defpackage;

import defpackage.xm5;

/* loaded from: classes2.dex */
public final class bu5 {

    /* renamed from: do, reason: not valid java name */
    public static final boolean f4328do;

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0027, code lost:
    
        if (r0.equals("on") != false) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0030, code lost:
    
        if (r0.equals("") != false) goto L21;
     */
    static {
        /*
            java.lang.String r0 = "kotlinx.coroutines.scheduler"
            java.lang.String r0 = defpackage.dn3.H2(r0)
            if (r0 == 0) goto L53
            int r1 = r0.hashCode()
            if (r1 == 0) goto L2a
            r2 = 3551(0xddf, float:4.976E-42)
            if (r1 == r2) goto L21
            r2 = 109935(0x1ad6f, float:1.54052E-40)
            if (r1 != r2) goto L33
            java.lang.String r1 = "off"
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L33
            r0 = 0
            goto L54
        L21:
            java.lang.String r1 = "on"
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L33
            goto L53
        L2a:
            java.lang.String r1 = ""
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L33
            goto L53
        L33:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "System property 'kotlinx.coroutines.scheduler' has unrecognized value '"
            r1.append(r2)
            r1.append(r0)
            r0 = 39
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L53:
            r0 = 1
        L54:
            defpackage.bu5.f4328do = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.bu5.<clinit>():void");
    }

    /* renamed from: do, reason: not valid java name */
    public static final ym5 m2327do(gu5 gu5Var, ym5 ym5Var) {
        ym5 plus = gu5Var.mo1035interface().plus(ym5Var);
        ru5 ru5Var = ru5.f34399do;
        du5 du5Var = ru5.f34401if;
        return (plus == du5Var || plus.get(xm5.a.f44043catch) != null) ? plus : plus.plus(du5Var);
    }

    /* renamed from: if, reason: not valid java name */
    public static final qw5<?> m2328if(wm5<?> wm5Var, ym5 ym5Var, Object obj) {
        qw5<?> qw5Var = null;
        if (!(wm5Var instanceof kn5)) {
            return null;
        }
        if (!(ym5Var.get(rw5.f34505catch) != null)) {
            return null;
        }
        kn5 kn5Var = (kn5) wm5Var;
        while (true) {
            if ((kn5Var instanceof ou5) || (kn5Var = kn5Var.mo1644case()) == null) {
                break;
            }
            if (kn5Var instanceof qw5) {
                qw5Var = (qw5) kn5Var;
                break;
            }
        }
        if (qw5Var != null) {
            qw5Var.f31439final = ym5Var;
            qw5Var.f31440super = obj;
        }
        return qw5Var;
    }
}
