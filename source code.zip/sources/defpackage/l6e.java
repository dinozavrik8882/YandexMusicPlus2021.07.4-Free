package defpackage;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;

/* loaded from: classes2.dex */
public final class l6e {

    /* renamed from: do, reason: not valid java name */
    public final SharedPreferences f21657do;

    /* renamed from: if, reason: not valid java name */
    public final Gson f21658if;

    /* loaded from: classes2.dex */
    public static final class a {

        @qd3("last_shown_at")
        private final long lastShownMs;

        @qd3("plaque_id")
        private final String plaqueId;

        @qd3("show_count")
        private final int showCount;

        @qd3("ttl")
        private final int ttl;

        /* renamed from: do, reason: not valid java name */
        public final long m9460do() {
            return this.lastShownMs;
        }

        /* renamed from: for, reason: not valid java name */
        public final int m9461for() {
            return this.showCount;
        }

        /* renamed from: if, reason: not valid java name */
        public final String m9462if() {
            return this.plaqueId;
        }

        /* renamed from: new, reason: not valid java name */
        public final int m9463new() {
            return this.ttl;
        }
    }

    public l6e(Context context) {
        jp5.m8570try(context, "context");
        this.f21657do = context.getSharedPreferences("plaque_storage", 0);
        this.f21658if = new Gson();
    }
}
