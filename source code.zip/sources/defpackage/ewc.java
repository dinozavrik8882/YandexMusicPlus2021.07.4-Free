package defpackage;

import android.view.View;
import com.yandex.metrica.rtm.Constants;
import defpackage.gwc;
import defpackage.hwc;
import java.util.HashMap;
import java.util.Objects;
import java.util.UUID;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class ewc {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f10803do;

    /* renamed from: case, reason: not valid java name */
    public final zv4 f10804case;

    /* renamed from: else, reason: not valid java name */
    public String f10805else;

    /* renamed from: for, reason: not valid java name */
    public final String f10806for;

    /* renamed from: goto, reason: not valid java name */
    public a f10807goto;

    /* renamed from: if, reason: not valid java name */
    public final pwc f10808if;

    /* renamed from: new, reason: not valid java name */
    public final String f10809new;

    /* renamed from: this, reason: not valid java name */
    public gwc f10810this;

    /* renamed from: try, reason: not valid java name */
    public final el5 f10811try;

    /* loaded from: classes2.dex */
    public interface a {
        void close();
    }

    /* loaded from: classes2.dex */
    public /* synthetic */ class b extends ip5 implements mo5<hwc.b, pl5> {
        public b(ewc ewcVar) {
            super(1, ewcVar, ewc.class, "handleState", "handleState(Lru/yandex/music/support/SupportCenter$ProgressState;)V", 0);
        }

        @Override // defpackage.mo5
        public pl5 invoke(hwc.b bVar) {
            gwc gwcVar;
            hwc.b bVar2 = bVar;
            jp5.m8570try(bVar2, "p0");
            ewc ewcVar = (ewc) this.receiver;
            Objects.requireNonNull(ewcVar);
            int ordinal = bVar2.ordinal();
            if (ordinal == 0) {
                gwc gwcVar2 = ewcVar.f10810this;
                if (gwcVar2 != null) {
                    gwcVar2.m6872do(false);
                }
                final gwc gwcVar3 = ewcVar.f10810this;
                if (gwcVar3 != null) {
                    boolean z = ewcVar.f10809new != null;
                    gwcVar3.f14289if.setImageResource(R.drawable.icon_feedback_success);
                    gwcVar3.f14288for.setText(z ? R.string.feedback_sent_successfully_with_answer : R.string.feedback_sent_successfully_without_answer);
                    gwcVar3.f14290new.setText(R.string.button_done);
                    gwcVar3.f14290new.setOnClickListener(new View.OnClickListener() { // from class: qvc
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            gwc.a aVar = gwc.this.f14291try;
                            if (aVar != null) {
                                aVar.mo6269do();
                            }
                        }
                    });
                    t2.b(gwcVar3.f14289if, gwcVar3.f14288for, gwcVar3.f14290new);
                }
            } else if (ordinal == 1) {
                gwc gwcVar4 = ewcVar.f10810this;
                if (gwcVar4 != null) {
                    gwcVar4.m6872do(false);
                }
                final gwc gwcVar5 = ewcVar.f10810this;
                if (gwcVar5 != null) {
                    gwcVar5.f14289if.setImageResource(R.drawable.icon_feedback_error);
                    gwcVar5.f14288for.setText(R.string.feedback_sending_failed);
                    gwcVar5.f14290new.setText(R.string.retry);
                    gwcVar5.f14290new.setOnClickListener(new View.OnClickListener() { // from class: pvc
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            gwc.a aVar = gwc.this.f14291try;
                            if (aVar != null) {
                                aVar.mo6270else();
                            }
                        }
                    });
                    t2.b(gwcVar5.f14289if, gwcVar5.f14288for, gwcVar5.f14290new);
                }
            } else if (ordinal == 2 && (gwcVar = ewcVar.f10810this) != null) {
                gwcVar.m6872do(true);
            }
            return pl5.f29126do;
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(ewc.class), "supportCenter", "getSupportCenter()Lru/yandex/music/support/SupportCenter;");
        Objects.requireNonNull(dq5.f8909do);
        f10803do = new mr5[]{wp5Var};
    }

    public ewc(pwc pwcVar, String str, String str2) {
        jp5.m8570try(pwcVar, "feedbackTopic");
        jp5.m8570try(str, Constants.KEY_MESSAGE);
        this.f10808if = pwcVar;
        this.f10806for = str;
        this.f10809new = str2;
        iz3 l3 = dn3.l3(hwc.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        jp5.m8570try(f10803do[0], "prop");
        this.f10811try = dn3.h1(cz3Var);
        this.f10804case = new cw4(true);
    }

    /* renamed from: do, reason: not valid java name */
    public final hwc m5487do() {
        return (hwc) this.f10811try.getValue();
    }

    /* renamed from: for, reason: not valid java name */
    public final void m5488for(String str) {
        hwc m5487do = m5487do();
        Objects.requireNonNull(m5487do);
        k0f<hwc.b> k0fVar = str != null ? m5487do.f15769else.get(str) : null;
        if (k0fVar == null) {
            return;
        }
        dn3.z2(k0fVar.m14387implements(jqe.m8590do()), this.f10804case, new b(this));
    }

    /* renamed from: if, reason: not valid java name */
    public final void m5489if() {
        this.f10804case.mo3910switch();
        hwc m5487do = m5487do();
        String str = this.f10805else;
        HashMap<String, k0f<hwc.b>> hashMap = m5487do.f15769else;
        if (str != null) {
            hashMap.remove(str);
        }
        hwc m5487do2 = m5487do();
        pwc pwcVar = this.f10808if;
        String str2 = this.f10806for;
        String str3 = this.f10809new;
        Objects.requireNonNull(m5487do2);
        jp5.m8570try(pwcVar, "topic");
        jp5.m8570try(str2, Constants.KEY_MESSAGE);
        k0f<hwc.b> t = k0f.t(hwc.b.IN_PROGRESS);
        String uuid = UUID.randomUUID().toString();
        jp5.m8568new(uuid, "randomUUID().toString()");
        dn3.e1(m5487do2.f15768case, null, null, new iwc(m5487do2, uuid, pwcVar, str2, str3, t, null), 3, null);
        HashMap<String, k0f<hwc.b>> hashMap2 = m5487do2.f15769else;
        jp5.m8568new(t, "progressState");
        hashMap2.put(uuid, t);
        this.f10805else = uuid;
        m5488for(uuid);
    }
}
