package defpackage;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes2.dex */
public class z7b {

    /* renamed from: new, reason: not valid java name */
    public oa9 f46822new;

    /* renamed from: do, reason: not valid java name */
    public final Map<e69, l8b> f46819do = new HashMap();

    /* renamed from: if, reason: not valid java name */
    public final l0f<Void> f46821if = l0f.s();

    /* renamed from: for, reason: not valid java name */
    public final Map<j8b, Integer> f46820for = new EnumMap(j8b.class);

    public z7b(oa9 oa9Var) {
        this.f46822new = oa9Var;
    }

    /* renamed from: do, reason: not valid java name */
    public int m17877do(j8b j8bVar) {
        Integer num = this.f46820for.get(j8bVar);
        if (num != null) {
            return num.intValue();
        }
        return 0;
    }

    /* renamed from: for, reason: not valid java name */
    public void m17878for(oa9 oa9Var, e69 e69Var, j8b j8bVar) {
        this.f46822new = oa9Var;
        this.f46819do.put(e69Var, l8b.NOT_ADDED);
        int m17877do = m17877do(j8bVar);
        if (m17877do > 0) {
            this.f46820for.put(j8bVar, Integer.valueOf(Math.max(m17877do - 1, 0)));
        }
        this.f46821if.f21357class.mo1523case(null);
    }

    /* renamed from: if, reason: not valid java name */
    public void m17879if(oa9 oa9Var, e69 e69Var, j8b j8bVar) {
        this.f46822new = oa9Var;
        this.f46819do.put(e69Var, l8b.ADDED);
        this.f46820for.put(j8bVar, Integer.valueOf(m17877do(j8bVar) + 1));
        this.f46821if.f21357class.mo1523case(null);
    }
}
