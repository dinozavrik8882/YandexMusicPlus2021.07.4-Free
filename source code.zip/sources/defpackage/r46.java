package defpackage;

/* loaded from: classes2.dex */
public interface r46 {
    /* renamed from: do, reason: not valid java name */
    k56 mo13127do();
}
