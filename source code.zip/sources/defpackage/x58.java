package defpackage;

import android.content.Context;
import android.view.View;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class x58 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f43295do;

    /* renamed from: case, reason: not valid java name */
    public final zv4 f43296case;

    /* renamed from: else, reason: not valid java name */
    public boolean f43297else;

    /* renamed from: for, reason: not valid java name */
    public a f43298for;

    /* renamed from: if, reason: not valid java name */
    public final Context f43299if;

    /* renamed from: new, reason: not valid java name */
    public final el5 f43300new;

    /* renamed from: try, reason: not valid java name */
    public y f43301try;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: case */
        void mo7387case();

        /* renamed from: try */
        void mo7388try();
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements mo5<bha, pl5> {
        public b() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(bha bhaVar) {
            a aVar;
            bha bhaVar2 = bhaVar;
            jp5.m8570try(bhaVar2, "info");
            if (bhaVar2.f3600do && (aVar = x58.this.f43298for) != null) {
                aVar.mo7387case();
            }
            x58 x58Var = x58.this;
            x58Var.f43297else = bhaVar2.f3602if == hha.OFFLINE;
            x58Var.m16963do();
            return pl5.f29126do;
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(x58.class), "connectivityBox", "getConnectivityBox()Lru/yandex/music/network/connectivity/ConnectivityBox;");
        Objects.requireNonNull(dq5.f8909do);
        f43295do = new mr5[]{wp5Var};
    }

    public x58(Context context) {
        jp5.m8570try(context, "context");
        this.f43299if = context;
        iz3 l3 = dn3.l3(wga.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        this.f43300new = new ez3(new cz3(l3)).m5533do(f43295do[0]);
        this.f43296case = new cw4(false);
    }

    /* renamed from: do, reason: not valid java name */
    public final void m16963do() {
        y yVar = this.f43301try;
        if (yVar == null) {
            return;
        }
        if (this.f43297else) {
            ey3 ey3Var = yVar.f44774else;
            mr5<Object>[] mr5VarArr = y.f44772do;
            t2.b((View) ey3Var.m5520do(mr5VarArr[4]));
            t2.m14613return((View) yVar.f44776goto.m5520do(mr5VarArr[7]));
            return;
        }
        ey3 ey3Var2 = yVar.f44776goto;
        mr5<Object>[] mr5VarArr2 = y.f44772do;
        t2.b((View) ey3Var2.m5520do(mr5VarArr2[7]));
        t2.m14613return((View) yVar.f44774else.m5520do(mr5VarArr2[4]));
    }

    /* renamed from: for, reason: not valid java name */
    public final void m16964for() {
        this.f43296case.mo3910switch();
        wuc.m16818super(this.f43299if, m16965if());
        y yVar = this.f43301try;
        if (yVar != null) {
            ((View) yVar.f44775for.m5520do(y.f44772do[0])).setVisibility(0);
        }
        this.f43297else = m16965if().mo16663else();
        spe<bha> m14403while = m16965if().mo16662do().m14403while();
        jp5.m8568new(m14403while, "connectivityBox.connectivityEvents()\n            .distinctUntilChanged()");
        dn3.z2(m14403while, this.f43296case, new b());
    }

    /* renamed from: if, reason: not valid java name */
    public final wga m16965if() {
        return (wga) this.f43300new.getValue();
    }
}
