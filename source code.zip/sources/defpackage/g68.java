package defpackage;

import java.util.Objects;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes2.dex */
public enum g68 {
    INITIAL(false),
    ATTACH(false),
    CREATE(false),
    CREATE_VIEW(false),
    START(false),
    RESUME(false),
    PAUSE(true),
    STOP(true),
    DESTROY_VIEW(true),
    DESTROY(true),
    DETACH(true);

    private final boolean mClosingLife;
    public static final b Companion = new b(null);
    private static final f68<g68> TERMINAL_INFO = new f68<g68>() { // from class: g68.a
        @Override // defpackage.f68
        /* renamed from: do */
        public g68 mo4239do(g68 g68Var) {
            g68 g68Var2 = g68Var;
            jp5.m8570try(g68Var2, DatabaseHelper.OttTrackingTable.COLUMN_EVENT);
            switch (g68Var2) {
                case INITIAL:
                case ATTACH:
                    return g68.DETACH;
                case CREATE:
                    return g68.DESTROY;
                case CREATE_VIEW:
                    return g68.DESTROY_VIEW;
                case START:
                    return g68.STOP;
                case RESUME:
                    return g68.PAUSE;
                case PAUSE:
                    return g68.PAUSE;
                case STOP:
                    return g68.STOP;
                case DESTROY_VIEW:
                    return g68.DESTROY_VIEW;
                case DESTROY:
                    return g68.DESTROY;
                case DETACH:
                    return g68.DETACH;
                default:
                    throw new gl5();
            }
        }

        @Override // defpackage.f68
        /* renamed from: for */
        public boolean mo4240for(g68 g68Var) {
            g68 g68Var2 = g68Var;
            jp5.m8570try(g68Var2, DatabaseHelper.OttTrackingTable.COLUMN_EVENT);
            return g68Var2.mClosingLife;
        }

        @Override // defpackage.f68
        /* renamed from: if */
        public g68 mo4241if() {
            return g68.INITIAL;
        }
    };

    /* loaded from: classes2.dex */
    public static final class b {
        public b(ep5 ep5Var) {
        }
    }

    g68(boolean z) {
        this.mClosingLife = z;
    }

    public static final f68<g68> terminalInfo() {
        Objects.requireNonNull(Companion);
        return TERMINAL_INFO;
    }
}
