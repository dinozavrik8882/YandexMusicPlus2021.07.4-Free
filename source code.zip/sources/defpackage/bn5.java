package defpackage;

import defpackage.il5;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* loaded from: classes2.dex */
public final class bn5<T> implements wm5<T>, kn5 {

    /* renamed from: catch, reason: not valid java name */
    @Deprecated
    public static final AtomicReferenceFieldUpdater<bn5<?>, Object> f3934catch = AtomicReferenceFieldUpdater.newUpdater(bn5.class, Object.class, "result");

    /* renamed from: class, reason: not valid java name */
    public final wm5<T> f3935class;
    private volatile Object result;

    /* JADX WARN: Multi-variable type inference failed */
    public bn5(wm5<? super T> wm5Var) {
        jp5.m8570try(wm5Var, "delegate");
        cn5 cn5Var = cn5.UNDECIDED;
        jp5.m8570try(wm5Var, "delegate");
        this.f3935class = wm5Var;
        this.result = cn5Var;
    }

    @Override // defpackage.kn5
    /* renamed from: case */
    public kn5 mo1644case() {
        wm5<T> wm5Var = this.f3935class;
        if (!(wm5Var instanceof kn5)) {
            wm5Var = null;
        }
        return (kn5) wm5Var;
    }

    @Override // defpackage.wm5
    /* renamed from: else */
    public void mo52else(Object obj) {
        while (true) {
            Object obj2 = this.result;
            cn5 cn5Var = cn5.UNDECIDED;
            if (obj2 != cn5Var) {
                cn5 cn5Var2 = cn5.COROUTINE_SUSPENDED;
                if (obj2 != cn5Var2) {
                    throw new IllegalStateException("Already resumed");
                }
                if (f3934catch.compareAndSet(this, cn5Var2, cn5.RESUMED)) {
                    this.f3935class.mo52else(obj);
                    return;
                }
            } else if (f3934catch.compareAndSet(this, cn5Var, obj)) {
                return;
            }
        }
    }

    @Override // defpackage.wm5
    public ym5 getContext() {
        return this.f3935class.getContext();
    }

    /* renamed from: if, reason: not valid java name */
    public final Object m2193if() {
        Object obj = this.result;
        cn5 cn5Var = cn5.UNDECIDED;
        if (obj == cn5Var) {
            AtomicReferenceFieldUpdater<bn5<?>, Object> atomicReferenceFieldUpdater = f3934catch;
            cn5 cn5Var2 = cn5.COROUTINE_SUSPENDED;
            if (atomicReferenceFieldUpdater.compareAndSet(this, cn5Var, cn5Var2)) {
                return cn5Var2;
            }
            obj = this.result;
        }
        if (obj == cn5.RESUMED) {
            return cn5.COROUTINE_SUSPENDED;
        }
        if (obj instanceof il5.a) {
            throw ((il5.a) obj).f16966catch;
        }
        return obj;
    }

    public String toString() {
        StringBuilder r = by.r("SafeContinuation for ");
        r.append(this.f3935class);
        return r.toString();
    }
}
