package defpackage;

import defpackage.hue;

/* loaded from: classes.dex */
public class kue implements sqe {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ hue.g f21082catch;

    public kue(hue.g gVar) {
        this.f21082catch = gVar;
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [T[], java.lang.Object[]] */
    @Override // defpackage.sqe
    public void call() {
        if (this.f21082catch.f15665import) {
            return;
        }
        synchronized (this.f21082catch.f15666native) {
            if (!this.f21082catch.f15665import) {
                hue.g gVar = this.f21082catch;
                exe<hue.d<T>> exeVar = gVar.f15666native;
                exeVar.f10861if = 0;
                exeVar.f10862new = new Object[0];
                gVar.f15670return++;
                this.f21082catch.f15665import = true;
            }
        }
    }
}
