package defpackage;

/* loaded from: classes.dex */
public final class lk4 extends qj4 {

    /* renamed from: do, reason: not valid java name */
    public static final lk4 f22317do = new lk4();

    public lk4() {
        super(null);
    }
}
