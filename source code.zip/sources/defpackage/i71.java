package defpackage;

import com.google.android.exoplayer2.util.Util;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
public final class i71 {

    /* renamed from: do, reason: not valid java name */
    public static final Pattern f16411do = Pattern.compile("^NOTE([ \t].*)?$");

    /* renamed from: do, reason: not valid java name */
    public static boolean m7655do(wb1 wb1Var) {
        String m16504case = wb1Var.m16504case();
        return m16504case != null && m16504case.startsWith("WEBVTT");
    }

    /* renamed from: for, reason: not valid java name */
    public static long m7656for(String str) throws NumberFormatException {
        String[] splitAtFirst = Util.splitAtFirst(str, "\\.");
        long j = 0;
        for (String str2 : Util.split(splitAtFirst[0], ":")) {
            j = (j * 60) + Long.parseLong(str2);
        }
        long j2 = j * 1000;
        if (splitAtFirst.length == 2) {
            j2 += Long.parseLong(splitAtFirst[1]);
        }
        return j2 * 1000;
    }

    /* renamed from: if, reason: not valid java name */
    public static float m7657if(String str) throws NumberFormatException {
        if (str.endsWith("%")) {
            return Float.parseFloat(str.substring(0, str.length() - 1)) / 100.0f;
        }
        throw new NumberFormatException("Percentages must end with %");
    }

    /* renamed from: new, reason: not valid java name */
    public static void m7658new(wb1 wb1Var) throws mo0 {
        int i = wb1Var.f41980if;
        if (m7655do(wb1Var)) {
            return;
        }
        wb1Var.m16520package(i);
        StringBuilder r = by.r("Expected WEBVTT. Got ");
        r.append(wb1Var.m16504case());
        throw new mo0(r.toString());
    }
}
