package defpackage;

/* loaded from: classes2.dex */
public enum ch9 {
    NONE(zh6.SUBSCRIPTION_TAG_NONE),
    RELEASE("release"),
    DEBUG("debug");

    public final String value;

    ch9(String str) {
        this.value = str;
    }

    public static ch9 mapString(String str) {
        if (str == null) {
            return RELEASE;
        }
        ch9[] values = values();
        for (int i = 0; i < 3; i++) {
            ch9 ch9Var = values[i];
            if (ch9Var.value.equals(str)) {
                return ch9Var;
            }
        }
        int i2 = e8d.f9711do;
        jr3.m8593do("Unknown logging mode value.");
        return NONE;
    }
}
