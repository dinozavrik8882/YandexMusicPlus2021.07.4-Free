package defpackage;

import java.util.Objects;

/* loaded from: classes2.dex */
public final class la5<T> implements al5<T>, ia5<T> {

    /* renamed from: do, reason: not valid java name */
    public static final Object f21849do = new Object();

    /* renamed from: for, reason: not valid java name */
    public volatile Object f21850for = f21849do;

    /* renamed from: if, reason: not valid java name */
    public volatile al5<T> f21851if;

    public la5(al5<T> al5Var) {
        this.f21851if = al5Var;
    }

    /* renamed from: do, reason: not valid java name */
    public static <P extends al5<T>, T> al5<T> m9555do(P p) {
        Objects.requireNonNull(p);
        return p instanceof la5 ? p : new la5(p);
    }

    /* renamed from: if, reason: not valid java name */
    public static Object m9556if(Object obj, Object obj2) {
        if (!(obj != f21849do) || obj == obj2) {
            return obj2;
        }
        throw new IllegalStateException("Scoped provider was invoked recursively returning different results: " + obj + " & " + obj2 + ". This is likely due to a circular dependency.");
    }

    @Override // defpackage.al5
    public T get() {
        T t = (T) this.f21850for;
        Object obj = f21849do;
        if (t == obj) {
            synchronized (this) {
                t = (T) this.f21850for;
                if (t == obj) {
                    t = this.f21851if.get();
                    m9556if(this.f21850for, t);
                    this.f21850for = t;
                    this.f21851if = null;
                }
            }
        }
        return t;
    }
}
