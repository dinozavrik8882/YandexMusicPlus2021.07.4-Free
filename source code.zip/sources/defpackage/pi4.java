package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import com.yandex.auth.sync.AccountProvider;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes.dex */
public final class pi4 implements Parcelable {
    public static final a CREATOR = new a(null);

    /* renamed from: catch, reason: not valid java name */
    public final String f29008catch;

    /* renamed from: class, reason: not valid java name */
    public final uf4 f29009class;

    /* renamed from: const, reason: not valid java name */
    public final ke4 f29010const;

    /* renamed from: final, reason: not valid java name */
    public final ke4 f29011final;

    /* renamed from: import, reason: not valid java name */
    public final boolean f29012import;

    /* renamed from: native, reason: not valid java name */
    public final boolean f29013native;

    /* renamed from: public, reason: not valid java name */
    public final boolean f29014public;

    /* renamed from: return, reason: not valid java name */
    public final boolean f29015return;

    /* renamed from: static, reason: not valid java name */
    public final rf4 f29016static;

    /* renamed from: super, reason: not valid java name */
    public final ke4 f29017super;

    /* renamed from: throw, reason: not valid java name */
    public final rf4 f29018throw;

    /* renamed from: while, reason: not valid java name */
    public final String f29019while;

    /* loaded from: classes.dex */
    public static final class a implements Parcelable.Creator<pi4> {
        public a(ep5 ep5Var) {
        }

        @Override // android.os.Parcelable.Creator
        public pi4 createFromParcel(Parcel parcel) {
            jp5.m8570try(parcel, "parcel");
            String readString = parcel.readString();
            jp5.m8565for(readString);
            jp5.m8568new(readString, "parcel.readString()!!");
            return new pi4(readString, dn3.h3(parcel.readString()), (ke4) by.m2390for(ke4.class, parcel, "parcel.readParcelable(Duration::class.java.classLoader)!!"), (ke4) parcel.readParcelable(ke4.class.getClassLoader()), (ke4) parcel.readParcelable(ke4.class.getClassLoader()), (rf4) parcel.readParcelable(rf4.class.getClassLoader()), parcel.readString(), parcel.readByte() != 0, parcel.readByte() != 0, parcel.readByte() != 0, parcel.readByte() != 0, (rf4) by.m2390for(rf4.class, parcel, "parcel.readParcelable(Price::class.java.classLoader)!!"));
        }

        @Override // android.os.Parcelable.Creator
        public pi4[] newArray(int i) {
            return new pi4[i];
        }
    }

    public pi4(String str, uf4 uf4Var, ke4 ke4Var, ke4 ke4Var2, ke4 ke4Var3, rf4 rf4Var, String str2, boolean z, boolean z2, boolean z3, boolean z4, rf4 rf4Var2) {
        jp5.m8570try(str, DatabaseHelper.OttTrackingTable.COLUMN_ID);
        jp5.m8570try(uf4Var, AccountProvider.TYPE);
        jp5.m8570try(ke4Var, "duration");
        jp5.m8570try(rf4Var2, "price");
        this.f29008catch = str;
        this.f29009class = uf4Var;
        this.f29010const = ke4Var;
        this.f29011final = ke4Var2;
        this.f29017super = ke4Var3;
        this.f29018throw = rf4Var;
        this.f29019while = str2;
        this.f29012import = z;
        this.f29013native = z2;
        this.f29014public = z3;
        this.f29015return = z4;
        this.f29016static = rf4Var2;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof pi4)) {
            return false;
        }
        pi4 pi4Var = (pi4) obj;
        return jp5.m8563do(this.f29008catch, pi4Var.f29008catch) && this.f29009class == pi4Var.f29009class && jp5.m8563do(this.f29010const, pi4Var.f29010const) && jp5.m8563do(this.f29011final, pi4Var.f29011final) && jp5.m8563do(this.f29017super, pi4Var.f29017super) && jp5.m8563do(this.f29018throw, pi4Var.f29018throw) && jp5.m8563do(this.f29019while, pi4Var.f29019while) && this.f29012import == pi4Var.f29012import && this.f29013native == pi4Var.f29013native && this.f29014public == pi4Var.f29014public && this.f29015return == pi4Var.f29015return && jp5.m8563do(this.f29016static, pi4Var.f29016static);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public int hashCode() {
        int hashCode = (this.f29010const.hashCode() + ((this.f29009class.hashCode() + (this.f29008catch.hashCode() * 31)) * 31)) * 31;
        ke4 ke4Var = this.f29011final;
        int hashCode2 = (hashCode + (ke4Var == null ? 0 : ke4Var.hashCode())) * 31;
        ke4 ke4Var2 = this.f29017super;
        int hashCode3 = (hashCode2 + (ke4Var2 == null ? 0 : ke4Var2.hashCode())) * 31;
        rf4 rf4Var = this.f29018throw;
        int hashCode4 = (hashCode3 + (rf4Var == null ? 0 : rf4Var.hashCode())) * 31;
        String str = this.f29019while;
        int hashCode5 = (hashCode4 + (str != null ? str.hashCode() : 0)) * 31;
        boolean z = this.f29012import;
        int i = z;
        if (z != 0) {
            i = 1;
        }
        int i2 = (hashCode5 + i) * 31;
        boolean z2 = this.f29013native;
        int i3 = z2;
        if (z2 != 0) {
            i3 = 1;
        }
        int i4 = (i2 + i3) * 31;
        boolean z3 = this.f29014public;
        int i5 = z3;
        if (z3 != 0) {
            i5 = 1;
        }
        int i6 = (i4 + i5) * 31;
        boolean z4 = this.f29015return;
        return this.f29016static.hashCode() + ((i6 + (z4 ? 1 : z4 ? 1 : 0)) * 31);
    }

    public String toString() {
        StringBuilder r = by.r("IncompleteInAppProduct(id=");
        r.append(this.f29008catch);
        r.append(", type=");
        r.append(this.f29009class);
        r.append(", duration=");
        r.append(this.f29010const);
        r.append(", trialDuration=");
        r.append(this.f29011final);
        r.append(", introDuration=");
        r.append(this.f29017super);
        r.append(", introPrice=");
        r.append(this.f29018throw);
        r.append(", description=");
        r.append((Object) this.f29019while);
        r.append(", available=");
        r.append(this.f29012import);
        r.append(", trialAvailable=");
        r.append(this.f29013native);
        r.append(", introAvailable=");
        r.append(this.f29014public);
        r.append(", yandexPlus=");
        r.append(this.f29015return);
        r.append(", price=");
        r.append(this.f29016static);
        r.append(')');
        return r.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        jp5.m8570try(parcel, "parcel");
        parcel.writeString(this.f29008catch);
        parcel.writeString(this.f29009class.getType());
        parcel.writeParcelable(this.f29010const, i);
        parcel.writeParcelable(this.f29011final, i);
        parcel.writeParcelable(this.f29017super, i);
        parcel.writeParcelable(this.f29018throw, i);
        parcel.writeString(this.f29019while);
        parcel.writeByte(this.f29012import ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.f29013native ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.f29014public ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.f29015return ? (byte) 1 : (byte) 0);
        parcel.writeParcelable(this.f29016static, i);
    }
}
