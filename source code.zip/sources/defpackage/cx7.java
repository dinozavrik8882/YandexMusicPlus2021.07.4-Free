package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class cx7 {

    /* renamed from: do, reason: not valid java name */
    public static final cx7 f7603do = new cx7();

    /* renamed from: if, reason: not valid java name */
    public static final bz3.b f7604if = new bz3.b(a.f7605catch);

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<az3, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public static final a f7605catch = new a();

        public a() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(az3 az3Var) {
            az3 az3Var2 = az3Var;
            jp5.m8570try(az3Var2, "$this$$receiver");
            az3Var2.m1595if(dn3.l3(ax7.class)).m1597if(bx7.f4469catch);
            return pl5.f29126do;
        }
    }
}
