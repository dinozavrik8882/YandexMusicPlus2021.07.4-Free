package defpackage;

import defpackage.k80;
import defpackage.n80;
import java.util.Objects;

/* loaded from: classes.dex */
public final class e10<Z> implements f10<Z>, k80.d {

    /* renamed from: catch, reason: not valid java name */
    public static final ie<e10<?>> f9299catch = k80.m8860do(20, new a());

    /* renamed from: class, reason: not valid java name */
    public final n80 f9300class = new n80.b();

    /* renamed from: const, reason: not valid java name */
    public f10<Z> f9301const;

    /* renamed from: final, reason: not valid java name */
    public boolean f9302final;

    /* renamed from: super, reason: not valid java name */
    public boolean f9303super;

    /* loaded from: classes.dex */
    public class a implements k80.b<e10<?>> {
        @Override // k80.b
        public e10<?> create() {
            return new e10<>();
        }
    }

    /* renamed from: do, reason: not valid java name */
    public static <Z> e10<Z> m4877do(f10<Z> f10Var) {
        e10<Z> e10Var = (e10) f9299catch.mo7765if();
        Objects.requireNonNull(e10Var, "Argument must not be null");
        e10Var.f9303super = false;
        e10Var.f9302final = true;
        e10Var.f9301const = f10Var;
        return e10Var;
    }

    @Override // defpackage.f10
    /* renamed from: for */
    public Class<Z> mo2606for() {
        return this.f9301const.mo2606for();
    }

    @Override // defpackage.f10
    public Z get() {
        return this.f9301const.get();
    }

    @Override // defpackage.f10
    public int getSize() {
        return this.f9301const.getSize();
    }

    @Override // k80.d
    /* renamed from: goto, reason: not valid java name */
    public n80 mo4878goto() {
        return this.f9300class;
    }

    @Override // defpackage.f10
    /* renamed from: if */
    public synchronized void mo2607if() {
        this.f9300class.mo10813do();
        this.f9303super = true;
        if (!this.f9302final) {
            this.f9301const.mo2607if();
            this.f9301const = null;
            f9299catch.mo7764do(this);
        }
    }

    /* renamed from: new, reason: not valid java name */
    public synchronized void m4879new() {
        this.f9300class.mo10813do();
        if (!this.f9302final) {
            throw new IllegalStateException("Already unlocked");
        }
        this.f9302final = false;
        if (this.f9303super) {
            mo2607if();
        }
    }
}
