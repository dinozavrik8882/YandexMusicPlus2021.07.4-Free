package defpackage;

import android.net.NetworkCapabilities;
import android.net.NetworkInfo;

/* loaded from: classes2.dex */
public enum gha {
    NONE,
    MOBILE,
    WIFI,
    OTHER;

    public static gha fromNetworkCapabilities(NetworkCapabilities networkCapabilities) {
        if (networkCapabilities == null) {
            return NONE;
        }
        return !(networkCapabilities.hasCapability(16) && networkCapabilities.hasCapability(12)) ? NONE : networkCapabilities.hasTransport(1) ? WIFI : networkCapabilities.hasTransport(0) ? MOBILE : OTHER;
    }

    public static gha fromNetworkInfo(NetworkInfo networkInfo) {
        if (networkInfo == null || !networkInfo.isConnected()) {
            return NONE;
        }
        int type = networkInfo.getType();
        return type != 0 ? type != 1 ? OTHER : WIFI : MOBILE;
    }
}
