package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class nj2 implements Parcelable.Creator<lj2> {
    @Override // android.os.Parcelable.Creator
    public final lj2 createFromParcel(Parcel parcel) {
        int m7283protected = hg1.m7283protected(parcel);
        int i = 0;
        pv1 pv1Var = null;
        while (parcel.dataPosition() < m7283protected) {
            int readInt = parcel.readInt();
            int i2 = 65535 & readInt;
            if (i2 == 1) {
                i = hg1.m7265continue(parcel, readInt);
            } else if (i2 != 2) {
                hg1.m7278interface(parcel, readInt);
            } else {
                pv1Var = (pv1) hg1.m7292throw(parcel, readInt, pv1.CREATOR);
            }
        }
        hg1.m7286static(parcel, m7283protected);
        return new lj2(i, pv1Var);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ lj2[] newArray(int i) {
        return new lj2[i];
    }
}
