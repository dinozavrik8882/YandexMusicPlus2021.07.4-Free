package defpackage;

import android.net.Uri;

/* loaded from: classes2.dex */
public class t09 implements dd9 {

    /* renamed from: if, reason: not valid java name */
    public final String f36396if;

    public t09(String str) {
        this.f36396if = str;
    }

    @Override // defpackage.dd9
    /* renamed from: do */
    public Uri mo484do(Uri uri) {
        return uri.buildUpon().appendQueryParameter("undoable", this.f36396if).build();
    }
}
