package defpackage;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.yandex.auth.sync.AccountProvider;
import defpackage.hg7;
import defpackage.jh7;
import defpackage.jm7;
import defpackage.ub4;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.catalog.buttons.RoundPlayButtonWithDescription;

/* loaded from: classes2.dex */
public final class kh7 implements jh7 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f20460do;

    /* renamed from: break, reason: not valid java name */
    public eh7 f20461break;

    /* renamed from: case, reason: not valid java name */
    public final ey3 f20462case;

    /* renamed from: else, reason: not valid java name */
    public final Context f20463else;

    /* renamed from: for, reason: not valid java name */
    public final ey3 f20464for;

    /* renamed from: goto, reason: not valid java name */
    public final jm7.a f20465goto;

    /* renamed from: if, reason: not valid java name */
    public final nt7 f20466if;

    /* renamed from: new, reason: not valid java name */
    public final ey3 f20467new;

    /* renamed from: this, reason: not valid java name */
    public final ug7 f20468this;

    /* renamed from: try, reason: not valid java name */
    public final ey3 f20469try;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<mr5<?>, ImageView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f20470catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(View view, int i) {
            super(1);
            this.f20470catch = view;
        }

        @Override // defpackage.mo5
        public ImageView invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f20470catch.findViewById(R.id.header_background);
                if (findViewById != null) {
                    return (ImageView) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.ImageView");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements mo5<mr5<?>, AppBarLayout> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f20471catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(View view, int i) {
            super(1);
            this.f20471catch = view;
        }

        @Override // defpackage.mo5
        public AppBarLayout invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f20471catch.findViewById(R.id.appbar);
                if (findViewById != null) {
                    return (AppBarLayout) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type com.google.android.material.appbar.AppBarLayout");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements mo5<mr5<?>, SwipeRefreshLayout> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f20472catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(View view, int i) {
            super(1);
            this.f20472catch = view;
        }

        @Override // defpackage.mo5
        public SwipeRefreshLayout invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f20472catch.findViewById(R.id.swipe_refresh);
                if (findViewById != null) {
                    return (SwipeRefreshLayout) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type androidx.swiperefreshlayout.widget.SwipeRefreshLayout");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends kp5 implements mo5<mr5<?>, RoundPlayButtonWithDescription> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f20473catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(View view, int i) {
            super(1);
            this.f20473catch = view;
        }

        @Override // defpackage.mo5
        public RoundPlayButtonWithDescription invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f20473catch.findViewById(R.id.play);
                if (findViewById != null) {
                    return (RoundPlayButtonWithDescription) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type ru.yandex.music.catalog.buttons.RoundPlayButtonWithDescription");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(kh7.class), "headerBackground", "getHeaderBackground()Landroid/widget/ImageView;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(kh7.class), "appBarLayout", "getAppBarLayout()Lcom/google/android/material/appbar/AppBarLayout;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var3 = new wp5(dq5.m4763do(kh7.class), "refreshLayout", "getRefreshLayout()Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var4 = new wp5(dq5.m4763do(kh7.class), "playbackButton", "getPlaybackButton()Lru/yandex/music/catalog/buttons/RoundPlayButtonWithDescription;");
        Objects.requireNonNull(eq5Var);
        f20460do = new mr5[]{wp5Var, wp5Var2, wp5Var3, wp5Var4};
    }

    public kh7(View view, nt7 nt7Var, mh7 mh7Var) {
        jp5.m8570try(view, "contentView");
        jp5.m8570try(nt7Var, "toolbarAdapter");
        jp5.m8570try(mh7Var, "adapter");
        this.f20466if = nt7Var;
        this.f20464for = new ey3(new a(view, R.id.header_background));
        this.f20467new = new ey3(new b(view, R.id.appbar));
        this.f20469try = new ey3(new c(view, R.id.swipe_refresh));
        this.f20462case = new ey3(new d(view, R.id.play));
        Context context = view.getContext();
        jp5.m8568new(context, "contentView.context");
        this.f20463else = context;
        m9044final().setColorSchemeResources(R.color.yellow_pressed);
        final boolean isEnabled = m9044final().isEnabled();
        m9041catch().m3119do(new AppBarLayout.c() { // from class: if7
            @Override // com.google.android.material.appbar.AppBarLayout.a
            /* renamed from: do */
            public final void mo1973do(AppBarLayout appBarLayout, int i) {
                kh7 kh7Var = kh7.this;
                boolean z = isEnabled;
                jp5.m8570try(kh7Var, "this$0");
                kh7Var.m9044final().setEnabled(z && i == 0);
            }
        });
        this.f20468this = new vg7(view, mh7Var);
        this.f20465goto = new u0d(m9043const());
    }

    @Override // defpackage.jh7
    /* renamed from: break */
    public ug7 mo8440break() {
        return this.f20468this;
    }

    @Override // defpackage.jh7
    /* renamed from: case */
    public void mo8441case(boolean z) {
        m9044final().setEnabled(z);
    }

    /* renamed from: catch, reason: not valid java name */
    public final AppBarLayout m9041catch() {
        return (AppBarLayout) this.f20467new.m5520do(f20460do[1]);
    }

    /* renamed from: class, reason: not valid java name */
    public final ImageView m9042class() {
        return (ImageView) this.f20464for.m5520do(f20460do[0]);
    }

    /* renamed from: const, reason: not valid java name */
    public final RoundPlayButtonWithDescription m9043const() {
        return (RoundPlayButtonWithDescription) this.f20462case.m5520do(f20460do[3]);
    }

    @Override // defpackage.jh7
    /* renamed from: do */
    public void mo8442do() {
        this.f20465goto.mo5482do();
    }

    @Override // defpackage.jh7
    /* renamed from: else */
    public void mo8443else() {
        t2.m14609package(m9044final(), new sqe() { // from class: gf7
            @Override // defpackage.sqe
            public final void call() {
                mr5<Object>[] mr5VarArr = kh7.f20460do;
                ub4 ub4Var = ub4.f38681if;
                ub4Var.mo4479case(ub4.a.HotTotalDuration);
                ub4Var.mo4479case(ub4.a.ColdTotalDuration);
            }
        });
    }

    /* renamed from: final, reason: not valid java name */
    public final SwipeRefreshLayout m9044final() {
        return (SwipeRefreshLayout) this.f20469try.m5520do(f20460do[2]);
    }

    @Override // defpackage.jh7
    /* renamed from: for */
    public void mo8444for(boolean z) {
        this.f20468this.mo15586for(z);
    }

    @Override // defpackage.jh7
    /* renamed from: goto */
    public void mo8445goto(final jh7.a aVar) {
        jp5.m8570try(aVar, "actions");
        m9044final().setOnRefreshListener(new SwipeRefreshLayout.h() { // from class: hf7
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.h
            /* renamed from: do */
            public final void mo222do() {
                jh7.a aVar2 = jh7.a.this;
                jp5.m8570try(aVar2, "$actions");
                ((ff7) aVar2).m5955do();
            }
        });
    }

    @Override // defpackage.jh7
    /* renamed from: if */
    public void mo8446if() {
        this.f20468this.mo15588if();
    }

    @Override // defpackage.jh7
    /* renamed from: new */
    public <T extends eh7> T mo8447new(hg7.a aVar) {
        eh7 n0Var;
        jp5.m8570try(aVar, AccountProvider.TYPE);
        eh7 eh7Var = this.f20461break;
        if (eh7Var != null) {
            jp5.m8565for(eh7Var);
            if (eh7Var.mo588do() == aVar) {
                return (T) this.f20461break;
            }
        }
        if (this.f20461break != null) {
            AppBarLayout m9041catch = m9041catch();
            eh7 eh7Var2 = this.f20461break;
            jp5.m8565for(eh7Var2);
            m9041catch.removeView(eh7Var2.mo5234else());
        }
        this.f20461break = null;
        int ordinal = aVar.ordinal();
        if (ordinal == 0) {
            n0Var = new n0(m9041catch(), this.f20466if, m9043const(), m9041catch(), m9042class());
        } else if (ordinal == 1) {
            n0Var = new m(m9041catch(), this.f20466if, m9043const(), m9041catch());
        } else {
            if (ordinal != 2) {
                throw new gl5();
            }
            n0Var = new ah7(m9041catch(), this.f20466if, m9043const(), m9041catch(), m9042class());
        }
        this.f20461break = n0Var;
        String m8559break = jp5.m8559break("unhandled header type: ", aVar);
        int i = e8d.f9711do;
        if (n0Var == null) {
            jr3.m8593do(m8559break);
        }
        if (this.f20461break == null) {
            this.f20461break = new n0(m9041catch(), this.f20466if, m9043const(), m9041catch(), m9042class());
        }
        AppBarLayout m9041catch2 = m9041catch();
        eh7 eh7Var3 = this.f20461break;
        jp5.m8565for(eh7Var3);
        m9041catch2.addView(eh7Var3.mo5234else());
        return (T) this.f20461break;
    }

    @Override // defpackage.jh7
    /* renamed from: this */
    public void mo8448this() {
        m9044final().setRefreshing(false);
    }

    @Override // defpackage.jh7
    /* renamed from: try */
    public void mo8449try(bha bhaVar) {
        jp5.m8570try(bhaVar, "info");
        m9044final().setRefreshing(false);
        if (bhaVar.f3600do) {
            i9d.m7694final(this.f20463else, R.string.error_sync_failed, 0);
        } else {
            wuc.m16820throw(this.f20463else, bhaVar);
        }
    }
}
