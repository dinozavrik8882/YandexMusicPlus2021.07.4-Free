package defpackage;

/* loaded from: classes2.dex */
public interface mhe<I, O> {
    /* renamed from: do */
    O mo1620do(I i) throws Throwable;
}
