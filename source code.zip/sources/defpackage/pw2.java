package defpackage;

import android.os.IBinder;
import android.os.RemoteException;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class pw2 extends jw2 {

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ IBinder f29643class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ rw2 f29644const;

    public pw2(rw2 rw2Var, IBinder iBinder) {
        this.f29644const = rw2Var;
        this.f29643class = iBinder;
    }

    @Override // defpackage.jw2
    /* renamed from: do */
    public final void mo6814do() {
        sw2 sw2Var = this.f29644const.f34500do;
        sw2Var.f36118class = (T) sw2Var.f36121goto.mo6904do(this.f29643class);
        sw2 sw2Var2 = this.f29644const.f34500do;
        sw2Var2.f36120for.m7976if(4, "linkToDeath", new Object[0]);
        try {
            sw2Var2.f36118class.asBinder().linkToDeath(sw2Var2.f36115break, 0);
        } catch (RemoteException e) {
            sw2Var2.f36120for.m7975do(e, "linkToDeath failed", new Object[0]);
        }
        sw2 sw2Var3 = this.f29644const.f34500do;
        sw2Var3.f36116case = false;
        Iterator<jw2> it = sw2Var3.f36125try.iterator();
        while (it.hasNext()) {
            it.next().run();
        }
        this.f29644const.f34500do.f36125try.clear();
    }
}
