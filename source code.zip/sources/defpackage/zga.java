package defpackage;

import android.content.Context;
import defpackage.bz3;

/* loaded from: classes2.dex */
public final class zga extends kp5 implements mo5<bz3.a, jha> {

    /* renamed from: catch, reason: not valid java name */
    public static final zga f47212catch = new zga();

    public zga() {
        super(1);
    }

    @Override // defpackage.mo5
    public jha invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        return new jha((Context) aVar2.m2427do(dn3.l3(Context.class)), (qg9) aVar2.m2427do(dn3.l3(qg9.class)));
    }
}
