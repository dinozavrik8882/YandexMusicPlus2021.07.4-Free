package defpackage;

import ru.yandex.music.landing.data.remote.BlockDto;

/* loaded from: classes2.dex */
public class mx9 extends BlockDto {
    private static final long serialVersionUID = 1;
}
