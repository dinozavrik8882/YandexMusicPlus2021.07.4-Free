package defpackage;

/* loaded from: classes2.dex */
public class mfc {

    /* renamed from: do, reason: not valid java name */
    public int f23929do;

    /* renamed from: for, reason: not valid java name */
    public int f23930for;

    /* renamed from: if, reason: not valid java name */
    public int f23931if;

    public mfc(int i) {
        this.f23930for = i;
    }
}
