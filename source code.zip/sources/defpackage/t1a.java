package defpackage;

import defpackage.bp9;
import defpackage.w68;

/* loaded from: classes2.dex */
public final class t1a implements w68.b<t4c> {
    @Override // w68.b
    /* renamed from: case */
    public t4c mo1333case(jp9 jp9Var) {
        jp5.m8570try(jp9Var, "descriptor");
        bp9 bp9Var = jp9Var.f19099try.f22329default.f10252this.getValue().f15432if;
        if (bp9Var instanceof bp9.e) {
            return ((bp9.e) bp9Var).f4134if;
        }
        if (!(bp9Var instanceof bp9.a ? true : bp9Var instanceof bp9.b ? true : bp9Var instanceof bp9.d ? true : bp9Var instanceof bp9.c)) {
            throw new gl5();
        }
        t4c t4cVar = t4c.f36587catch;
        jp5.m8568new(t4cVar, "NONE");
        return t4cVar;
    }

    @Override // w68.b
    /* renamed from: do */
    public t4c mo1334do(xo8 xo8Var) {
        jp5.m8570try(xo8Var, "descriptor");
        t4c t4cVar = t4c.f36587catch;
        jp5.m8568new(t4cVar, "NONE");
        return t4cVar;
    }

    @Override // w68.b
    /* renamed from: for */
    public t4c mo1336for(uj9 uj9Var) {
        jp5.m8570try(uj9Var, "descriptor");
        return uj9Var.f38962try;
    }

    @Override // w68.b
    /* renamed from: if */
    public t4c mo1337if(ftb ftbVar) {
        jp5.m8570try(ftbVar, "descriptor");
        t4c t4cVar = ftbVar.f12503new;
        jp5.m8568new(t4cVar, "descriptor.station()");
        return t4cVar;
    }

    @Override // w68.b
    /* renamed from: new */
    public t4c mo1338new(ho8 ho8Var) {
        jp5.m8570try(ho8Var, "descriptor");
        t4c t4cVar = t4c.f36587catch;
        jp5.m8568new(t4cVar, "NONE");
        return t4cVar;
    }

    @Override // w68.b
    /* renamed from: try */
    public t4c mo1339try(on8 on8Var) {
        jp5.m8570try(on8Var, "descriptor");
        t4c t4cVar = t4c.f36587catch;
        jp5.m8568new(t4cVar, "NONE");
        return t4cVar;
    }
}
