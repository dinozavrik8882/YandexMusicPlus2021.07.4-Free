package defpackage;

/* loaded from: classes.dex */
public enum s22 implements d92 {
    DEVICE_CONNECTION_TYPE_UNKNOWN(0),
    DEVICE_CONNECTION_TYPE_LOCAL(1),
    DEVICE_CONNECTION_TYPE_OPENCAST(2);

    private static final c92<s22> zzagd = new c92<s22>() { // from class: v22
    };
    private final int value;

    s22(int i) {
        this.value = i;
    }

    public static f92 zzfv() {
        return u22.f38279do;
    }

    @Override // defpackage.d92
    public final int getNumber() {
        return this.value;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return "<" + s22.class.getName() + '@' + Integer.toHexString(System.identityHashCode(this)) + " number=" + getNumber() + " name=" + name() + '>';
    }
}
