package defpackage;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes2.dex */
public class vs7 extends RecyclerView.b0 {

    /* renamed from: catch, reason: not valid java name */
    public final Context f41116catch;

    public vs7(View view) {
        super(view);
        this.f41116catch = view.getContext();
    }

    public vs7(ViewGroup viewGroup, int i) {
        this(by.m2413try(viewGroup, i, viewGroup, false));
    }
}
