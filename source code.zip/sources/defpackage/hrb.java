package defpackage;

import com.google.firebase.iid.FirebaseInstanceId;

/* loaded from: classes2.dex */
public final class hrb implements rrb {

    /* loaded from: classes2.dex */
    public static final class a<TResult> implements bk2 {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ kt5<String> f15531do;

        /* JADX WARN: Multi-variable type inference failed */
        public a(kt5<? super String> kt5Var) {
            this.f15531do = kt5Var;
        }

        @Override // defpackage.bk2
        public void onSuccess(Object obj) {
            this.f15531do.mo52else(((o93) obj).getToken());
        }
    }

    /* loaded from: classes2.dex */
    public static final class b implements yj2 {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ kt5<String> f15532do;

        /* JADX WARN: Multi-variable type inference failed */
        public b(kt5<? super String> kt5Var) {
            this.f15532do = kt5Var;
        }

        @Override // defpackage.yj2
        /* renamed from: if, reason: not valid java name */
        public final void mo7451if() {
            dn3.j(this.f15532do, null, 1, null);
        }
    }

    /* loaded from: classes2.dex */
    public static final class c implements ak2 {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ kt5<String> f15533do;

        /* JADX WARN: Multi-variable type inference failed */
        public c(kt5<? super String> kt5Var) {
            this.f15533do = kt5Var;
        }

        @Override // defpackage.ak2
        public final void onFailure(Exception exc) {
            jp5.m8570try(exc, "it");
            dn3.j(this.f15533do, null, 1, null);
        }
    }

    @Override // defpackage.rrb
    /* renamed from: do, reason: not valid java name */
    public Object mo7450do(wm5<? super String> wm5Var) {
        lt5 lt5Var = new lt5(dn3.R0(wm5Var), 1);
        lt5Var.m9969return();
        w93 w93Var = FirebaseInstanceId.f6475if;
        ek2<o93> m3336try = FirebaseInstanceId.getInstance(e13.m4882for()).m3336try();
        jp5.m8568new(m3336try, "getInstance().instanceId");
        m3336try.mo2124case(new a(lt5Var));
        m3336try.mo2128do(new b(lt5Var));
        m3336try.mo2136new(new c(lt5Var));
        Object m9968public = lt5Var.m9968public();
        if (m9968public == cn5.COROUTINE_SUSPENDED) {
            jp5.m8570try(wm5Var, "frame");
        }
        return m9968public;
    }
}
