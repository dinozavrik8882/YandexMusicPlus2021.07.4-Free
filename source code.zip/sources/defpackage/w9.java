package defpackage;

import defpackage.ba;
import defpackage.y9;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class w9 implements y9.a {

    /* renamed from: new, reason: not valid java name */
    public a f41864new;

    /* renamed from: do, reason: not valid java name */
    public ba f41861do = null;

    /* renamed from: if, reason: not valid java name */
    public float f41863if = 0.0f;

    /* renamed from: for, reason: not valid java name */
    public ArrayList<ba> f41862for = new ArrayList<>();

    /* renamed from: try, reason: not valid java name */
    public boolean f41865try = false;

    /* loaded from: classes.dex */
    public interface a {
        /* renamed from: break */
        float mo2689break(ba baVar, boolean z);

        /* renamed from: case */
        float mo2690case(ba baVar);

        /* renamed from: catch */
        void mo2691catch(float f);

        void clear();

        /* renamed from: do */
        int mo2694do();

        /* renamed from: else */
        boolean mo2695else(ba baVar);

        /* renamed from: for */
        void mo2697for();

        /* renamed from: goto */
        float mo2698goto(w9 w9Var, boolean z);

        /* renamed from: if */
        ba mo2699if(int i);

        /* renamed from: new */
        float mo2700new(int i);

        /* renamed from: this */
        void mo2701this(ba baVar, float f);

        /* renamed from: try */
        void mo2702try(ba baVar, float f, boolean z);
    }

    public w9() {
    }

    public w9(x9 x9Var) {
        this.f41864new = new v9(this, x9Var);
    }

    /* renamed from: break, reason: not valid java name */
    public void m16442break(ba baVar) {
        ba baVar2 = this.f41861do;
        if (baVar2 != null) {
            this.f41864new.mo2701this(baVar2, -1.0f);
            this.f41861do = null;
        }
        float mo2689break = this.f41864new.mo2689break(baVar, true) * (-1.0f);
        this.f41861do = baVar;
        if (mo2689break == 1.0f) {
            return;
        }
        this.f41863if /= mo2689break;
        this.f41864new.mo2691catch(mo2689break);
    }

    /* renamed from: case, reason: not valid java name */
    public w9 m16443case(ba baVar, ba baVar2, ba baVar3, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.f41863if = i;
        }
        if (z) {
            this.f41864new.mo2701this(baVar, 1.0f);
            this.f41864new.mo2701this(baVar2, -1.0f);
            this.f41864new.mo2701this(baVar3, 1.0f);
        } else {
            this.f41864new.mo2701this(baVar, -1.0f);
            this.f41864new.mo2701this(baVar2, 1.0f);
            this.f41864new.mo2701this(baVar3, -1.0f);
        }
        return this;
    }

    /* renamed from: catch, reason: not valid java name */
    public void m16444catch(ba baVar, boolean z) {
        if (baVar.f3250else) {
            float mo2690case = this.f41864new.mo2690case(baVar);
            this.f41863if = (baVar.f3246case * mo2690case) + this.f41863if;
            this.f41864new.mo2689break(baVar, z);
            if (z) {
                baVar.m1874if(this);
            }
        }
    }

    /* renamed from: class */
    public void mo373class(w9 w9Var, boolean z) {
        float mo2698goto = this.f41864new.mo2698goto(w9Var, z);
        this.f41863if = (w9Var.f41863if * mo2698goto) + this.f41863if;
        if (z) {
            w9Var.f41861do.m1874if(this);
        }
    }

    @Override // y9.a
    public void clear() {
        this.f41864new.clear();
        this.f41861do = null;
        this.f41863if = 0.0f;
    }

    @Override // y9.a
    /* renamed from: do */
    public void mo375do(ba baVar) {
        float f;
        int i = baVar.f3256try;
        if (i != 1) {
            if (i == 2) {
                f = 1000.0f;
            } else if (i == 3) {
                f = 1000000.0f;
            } else if (i == 4) {
                f = 1.0E9f;
            } else if (i == 5) {
                f = 1.0E12f;
            }
            this.f41864new.mo2701this(baVar, f);
        }
        f = 1.0f;
        this.f41864new.mo2701this(baVar, f);
    }

    /* renamed from: else, reason: not valid java name */
    public w9 m16445else(ba baVar, ba baVar2, ba baVar3, ba baVar4, float f) {
        this.f41864new.mo2701this(baVar3, 0.5f);
        this.f41864new.mo2701this(baVar4, 0.5f);
        this.f41864new.mo2701this(baVar, -0.5f);
        this.f41864new.mo2701this(baVar2, -0.5f);
        this.f41863if = -f;
        return this;
    }

    /* renamed from: for, reason: not valid java name */
    public w9 m16446for(y9 y9Var, int i) {
        this.f41864new.mo2701this(y9Var.m17500catch(i, "ep"), 1.0f);
        this.f41864new.mo2701this(y9Var.m17500catch(i, "em"), -1.0f);
        return this;
    }

    /* renamed from: goto, reason: not valid java name */
    public final boolean m16447goto(ba baVar) {
        return baVar.f3249const <= 1;
    }

    @Override // y9.a
    /* renamed from: if */
    public ba mo377if(y9 y9Var, boolean[] zArr) {
        return m16449this(zArr, null);
    }

    /* renamed from: new, reason: not valid java name */
    public w9 m16448new(ba baVar, ba baVar2, ba baVar3, ba baVar4, float f) {
        this.f41864new.mo2701this(baVar, -1.0f);
        this.f41864new.mo2701this(baVar2, 1.0f);
        this.f41864new.mo2701this(baVar3, f);
        this.f41864new.mo2701this(baVar4, -f);
        return this;
    }

    /* renamed from: this, reason: not valid java name */
    public final ba m16449this(boolean[] zArr, ba baVar) {
        ba.a aVar;
        int mo2694do = this.f41864new.mo2694do();
        ba baVar2 = null;
        float f = 0.0f;
        for (int i = 0; i < mo2694do; i++) {
            float mo2700new = this.f41864new.mo2700new(i);
            if (mo2700new < 0.0f) {
                ba mo2699if = this.f41864new.mo2699if(i);
                if ((zArr == null || !zArr[mo2699if.f3251for]) && mo2699if != baVar && (((aVar = mo2699if.f3245break) == ba.a.SLACK || aVar == ba.a.ERROR) && mo2700new < f)) {
                    f = mo2700new;
                    baVar2 = mo2699if;
                }
            }
        }
        return baVar2;
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x007f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.String toString() {
        /*
            r10 = this;
            ba r0 = r10.f41861do
            if (r0 != 0) goto L7
            java.lang.String r0 = "0"
            goto L16
        L7:
            java.lang.String r0 = ""
            java.lang.StringBuilder r0 = defpackage.by.r(r0)
            ba r1 = r10.f41861do
            r0.append(r1)
            java.lang.String r0 = r0.toString()
        L16:
            java.lang.String r1 = " = "
            java.lang.String r0 = defpackage.by.m2405strictfp(r0, r1)
            float r1 = r10.f41863if
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            r3 = 0
            r4 = 1
            if (r1 == 0) goto L34
            java.lang.StringBuilder r0 = defpackage.by.r(r0)
            float r1 = r10.f41863if
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r1 = r4
            goto L35
        L34:
            r1 = r3
        L35:
            w9$a r5 = r10.f41864new
            int r5 = r5.mo2694do()
        L3b:
            if (r3 >= r5) goto L9a
            w9$a r6 = r10.f41864new
            ba r6 = r6.mo2699if(r3)
            if (r6 != 0) goto L46
            goto L97
        L46:
            w9$a r7 = r10.f41864new
            float r7 = r7.mo2700new(r3)
            int r8 = (r7 > r2 ? 1 : (r7 == r2 ? 0 : -1))
            if (r8 != 0) goto L51
            goto L97
        L51:
            java.lang.String r6 = r6.toString()
            r9 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r1 != 0) goto L64
            int r1 = (r7 > r2 ? 1 : (r7 == r2 ? 0 : -1))
            if (r1 >= 0) goto L74
            java.lang.String r1 = "- "
            java.lang.String r0 = defpackage.by.m2405strictfp(r0, r1)
            goto L73
        L64:
            if (r8 <= 0) goto L6d
            java.lang.String r1 = " + "
            java.lang.String r0 = defpackage.by.m2405strictfp(r0, r1)
            goto L74
        L6d:
            java.lang.String r1 = " - "
            java.lang.String r0 = defpackage.by.m2405strictfp(r0, r1)
        L73:
            float r7 = r7 * r9
        L74:
            r1 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1))
            if (r1 != 0) goto L7f
            java.lang.String r0 = defpackage.by.m2405strictfp(r0, r6)
            goto L96
        L7f:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            r1.append(r7)
            java.lang.String r0 = " "
            r1.append(r0)
            r1.append(r6)
            java.lang.String r0 = r1.toString()
        L96:
            r1 = r4
        L97:
            int r3 = r3 + 1
            goto L3b
        L9a:
            if (r1 != 0) goto La2
            java.lang.String r1 = "0.0"
            java.lang.String r0 = defpackage.by.m2405strictfp(r0, r1)
        La2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.w9.toString():java.lang.String");
    }

    /* renamed from: try, reason: not valid java name */
    public w9 m16450try(ba baVar, ba baVar2, ba baVar3, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.f41863if = i;
        }
        if (z) {
            this.f41864new.mo2701this(baVar, 1.0f);
            this.f41864new.mo2701this(baVar2, -1.0f);
            this.f41864new.mo2701this(baVar3, -1.0f);
        } else {
            this.f41864new.mo2701this(baVar, -1.0f);
            this.f41864new.mo2701this(baVar2, 1.0f);
            this.f41864new.mo2701this(baVar3, 1.0f);
        }
        return this;
    }
}
