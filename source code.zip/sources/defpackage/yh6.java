package defpackage;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes2.dex */
public class yh6 implements Serializable {
    private static final long serialVersionUID = 1;
    public int givenDays;
    public int orderId;
    public a status;
    public String statusDescription;

    /* loaded from: classes2.dex */
    public enum a {
        SUCCESS,
        NOT_EXISTS,
        ALREADY_CONSUMED,
        EXPIRED,
        BANNED,
        TEMPORARY_CAMPAIGN_RESTRICTIONS,
        FOR_NEW_USERS_ONLY,
        FAILED,
        UNKNOWN;

        private static final Map<String, a> STATUS_MESSAGES;

        static {
            a aVar = SUCCESS;
            a aVar2 = NOT_EXISTS;
            a aVar3 = ALREADY_CONSUMED;
            a aVar4 = EXPIRED;
            a aVar5 = BANNED;
            a aVar6 = TEMPORARY_CAMPAIGN_RESTRICTIONS;
            a aVar7 = FOR_NEW_USERS_ONLY;
            a aVar8 = FAILED;
            HashMap hashMap = new HashMap();
            STATUS_MESSAGES = hashMap;
            hashMap.put("success", aVar);
            hashMap.put("code-not-exists", aVar2);
            hashMap.put("code-already-consumed", aVar3);
            hashMap.put("code-expired", aVar4);
            hashMap.put("user-temporary-banned", aVar5);
            hashMap.put("user-has-temporary-campaign-restrictions", aVar6);
            hashMap.put("failed-to-create-payment", aVar8);
            hashMap.put("code-only-for-new-users", aVar7);
        }

        public static a byMessageString(String str) {
            a aVar = STATUS_MESSAGES.get(str);
            if (aVar == null) {
                aVar = UNKNOWN;
            }
            k2f.f19768new.mo8764do("PromoCodeStatus.byMessageString. msg: %s, status: %s", str, aVar);
            return aVar;
        }
    }

    public String toString() {
        StringBuilder r = by.r("PromoCodeStatus{status=");
        r.append(this.status);
        r.append(", orderId=");
        r.append(this.orderId);
        r.append(", givenDays=");
        return by.m2395instanceof(r, this.givenDays, '}');
    }
}
