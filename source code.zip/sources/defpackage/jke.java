package defpackage;

/* loaded from: classes2.dex */
public interface jke {
    /* renamed from: do */
    String mo5577do(String str);
}
