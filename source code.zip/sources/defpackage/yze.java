package defpackage;

import java.util.Objects;

/* loaded from: classes.dex */
public final class yze implements yqe<Throwable, Throwable> {
    @Override // defpackage.yqe
    public Throwable call(Throwable th) {
        Throwable th2 = th;
        Objects.requireNonNull(d0f.f7797do.m3992for());
        return th2;
    }
}
