package defpackage;

import android.os.RemoteException;
import defpackage.np1;
import defpackage.rp1;
import defpackage.wo1;

/* loaded from: classes.dex */
public final class ls1 extends zr1<Void> {

    /* renamed from: for, reason: not valid java name */
    public final vr1 f22703for;

    public ls1(vr1 vr1Var, fk2<Void> fk2Var) {
        super(3, fk2Var);
        this.f22703for = vr1Var;
    }

    @Override // defpackage.ks1
    /* renamed from: case */
    public final po1[] mo9219case(np1.a<?> aVar) {
        return this.f22703for.f41050do.f40973if;
    }

    @Override // defpackage.ks1
    /* renamed from: else */
    public final boolean mo9220else(np1.a<?> aVar) {
        return this.f22703for.f41050do.f40972for;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.zr1
    /* renamed from: goto, reason: not valid java name */
    public final void mo9916goto(np1.a<?> aVar) throws RemoteException {
        vp1<wo1.b, ?> vp1Var = this.f22703for.f41050do;
        ((yr1) vp1Var).f46064try.f42645do.mo11035do(aVar.f25883if, this.f47792if);
        rp1.a<?> aVar2 = this.f22703for.f41050do.f40971do.f32821if;
        if (aVar2 != null) {
            aVar.f25875case.put(aVar2, this.f22703for);
        }
    }

    @Override // defpackage.br1
    /* renamed from: new */
    public final /* bridge */ /* synthetic */ void mo2271new(ct1 ct1Var, boolean z) {
    }
}
