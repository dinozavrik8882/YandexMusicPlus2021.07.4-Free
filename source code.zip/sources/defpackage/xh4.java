package defpackage;

import java.util.Collection;
import java.util.Comparator;

/* loaded from: classes.dex */
public final class xh4<T> implements Comparator<T> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ Collection f43810catch;

    public xh4(Collection collection) {
        this.f43810catch = collection;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x002d, code lost:
    
        r8 = java.lang.Integer.valueOf(r2);
        r9 = (defpackage.oi4) r9;
        r0 = r7.f43810catch.iterator();
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x003d, code lost:
    
        if (r0.hasNext() == false) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x003f, code lost:
    
        r2 = r0.next();
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0043, code lost:
    
        if (r1 < 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x004f, code lost:
    
        if (defpackage.jp5.m8563do(r9.f27275catch, ((defpackage.pi4) r2).f29008catch) == false) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0053, code lost:
    
        r1 = r1 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0051, code lost:
    
        r5 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0062, code lost:
    
        return defpackage.dn3.z(r8, java.lang.Integer.valueOf(r5));
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0056, code lost:
    
        defpackage.xl5.t();
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0059, code lost:
    
        throw null;
     */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int compare(T r8, T r9) {
        /*
            r7 = this;
            oi4 r8 = (defpackage.oi4) r8
            java.util.Collection r0 = r7.f43810catch
            java.util.Iterator r0 = r0.iterator()
            r1 = 0
            r2 = r1
        La:
            boolean r3 = r0.hasNext()
            r4 = 0
            r5 = -1
            if (r3 == 0) goto L2c
            java.lang.Object r3 = r0.next()
            if (r2 < 0) goto L28
            pi4 r3 = (defpackage.pi4) r3
            java.lang.String r6 = r8.f27275catch
            java.lang.String r3 = r3.f29008catch
            boolean r3 = defpackage.jp5.m8563do(r6, r3)
            if (r3 == 0) goto L25
            goto L2d
        L25:
            int r2 = r2 + 1
            goto La
        L28:
            defpackage.xl5.t()
            throw r4
        L2c:
            r2 = r5
        L2d:
            java.lang.Integer r8 = java.lang.Integer.valueOf(r2)
            oi4 r9 = (defpackage.oi4) r9
            java.util.Collection r0 = r7.f43810catch
            java.util.Iterator r0 = r0.iterator()
        L39:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L5a
            java.lang.Object r2 = r0.next()
            if (r1 < 0) goto L56
            pi4 r2 = (defpackage.pi4) r2
            java.lang.String r3 = r9.f27275catch
            java.lang.String r2 = r2.f29008catch
            boolean r2 = defpackage.jp5.m8563do(r3, r2)
            if (r2 == 0) goto L53
            r5 = r1
            goto L5a
        L53:
            int r1 = r1 + 1
            goto L39
        L56:
            defpackage.xl5.t()
            throw r4
        L5a:
            java.lang.Integer r9 = java.lang.Integer.valueOf(r5)
            int r8 = defpackage.dn3.z(r8, r9)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.xh4.compare(java.lang.Object, java.lang.Object):int");
    }
}
