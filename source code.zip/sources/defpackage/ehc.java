package defpackage;

import defpackage.bic;

/* loaded from: classes2.dex */
public final /* synthetic */ class ehc implements bic.e {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ bic f10011do;
}
