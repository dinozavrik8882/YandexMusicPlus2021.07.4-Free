package defpackage;

import defpackage.v7c;
import java.util.concurrent.Callable;

/* loaded from: classes2.dex */
public final class h7c<T> implements v7c.c<T> {

    /* renamed from: do, reason: not valid java name */
    public final Callable<T> f14822do;

    public h7c(Callable<T> callable) {
        this.f14822do = callable;
    }

    @Override // v7c.c, defpackage.l8c
    /* renamed from: do, reason: not valid java name */
    public void call(w7c<? super T> w7cVar) {
        t7c t7cVar = new t7c();
        w7cVar.mo9470if(t7cVar);
        if (t7cVar.f36737catch) {
            return;
        }
        try {
            T call = this.f14822do.call();
            if (call != null) {
                w7cVar.onSuccess(call);
            } else {
                w7cVar.mo1867do(new NullPointerException("callable result must not be null"));
            }
        } catch (Throwable th) {
            qd9.x(th);
            w7cVar.mo1867do(th);
        }
    }
}
