package defpackage;

/* loaded from: classes.dex */
public final class km4 {

    /* renamed from: do, reason: not valid java name */
    public final String f20642do;

    /* renamed from: if, reason: not valid java name */
    public final String f20643if;

    public km4(String str, String str2) {
        this.f20642do = str;
        this.f20643if = str2;
    }
}
