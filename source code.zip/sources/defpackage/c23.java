package defpackage;

/* loaded from: classes.dex */
public class c23 {

    /* renamed from: do, reason: not valid java name */
    public final Class<?> f4727do;

    /* renamed from: if, reason: not valid java name */
    public final boolean f4728if;

    public c23(Class cls, boolean z, a23 a23Var) {
        this.f4727do = cls;
        this.f4728if = z;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof c23)) {
            return false;
        }
        c23 c23Var = (c23) obj;
        return c23Var.f4727do.equals(this.f4727do) && c23Var.f4728if == this.f4728if;
    }

    public int hashCode() {
        return ((this.f4727do.hashCode() ^ 1000003) * 1000003) ^ Boolean.valueOf(this.f4728if).hashCode();
    }
}
