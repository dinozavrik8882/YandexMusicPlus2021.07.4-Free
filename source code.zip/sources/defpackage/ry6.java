package defpackage;

import android.content.res.Resources;
import android.database.DataSetObserver;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import defpackage.py6;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public class ry6 implements py6.b {

    /* renamed from: case, reason: not valid java name */
    public boolean f34589case = false;

    /* renamed from: do, reason: not valid java name */
    public final int f34590do;

    /* renamed from: for, reason: not valid java name */
    public final View f34591for;

    /* renamed from: if, reason: not valid java name */
    public final int f34592if;

    /* renamed from: new, reason: not valid java name */
    public View f34593new;

    /* renamed from: try, reason: not valid java name */
    public ViewPager f34594try;

    /* loaded from: classes2.dex */
    public class a extends DataSetObserver {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ vp f34595do;

        public a(vp vpVar) {
            this.f34595do = vpVar;
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            super.onChanged();
            boolean z = this.f34595do.mo6328for() <= 1;
            ry6 ry6Var = ry6.this;
            if (z == ry6Var.f34589case) {
                return;
            }
            ry6Var.f34589case = z;
            ry6Var.f34593new.setPadding(ry6Var.f34590do, 0, z ? ry6Var.f34590do : ry6Var.f34592if, 0);
        }
    }

    public ry6(ViewGroup viewGroup) {
        View m2413try = by.m2413try(viewGroup, R.layout.view_artist_concerts, viewGroup, false);
        this.f34591for = m2413try;
        this.f34593new = m2413try.findViewById(R.id.pager_container);
        this.f34594try = (ViewPager) m2413try.findViewById(R.id.pager);
        Resources resources = viewGroup.getContext().getResources();
        int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.edge_margin);
        this.f34590do = dimensionPixelSize;
        this.f34592if = resources.getDimensionPixelSize(R.dimen.double_edge_margin);
        this.f34594try.setPageMargin(dimensionPixelSize);
    }

    @Override // defpackage.py6
    /* renamed from: native */
    public void mo9317native(String str) {
        this.f34591for.setContentDescription(str);
    }

    @Override // py6.b
    /* renamed from: throw */
    public void mo12349throw(RecyclerView.e<? extends RecyclerView.b0> eVar) {
        l0d l0dVar = new l0d(eVar);
        l0dVar.f40967do.registerObserver(new a(l0dVar));
        this.f34594try.setAdapter(l0dVar);
    }

    @Override // defpackage.py6
    /* renamed from: try */
    public View mo9319try() {
        return this.f34591for;
    }
}
