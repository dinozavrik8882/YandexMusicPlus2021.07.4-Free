package defpackage;

import android.view.View;
import android.view.ViewTreeObserver;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes2.dex */
public final class ijb implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ RecyclerView f16913catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ View f16914class;

    public ijb(RecyclerView recyclerView, View view) {
        this.f16913catch = recyclerView;
        this.f16914class = view;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public void onGlobalLayout() {
        this.f16913catch.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        qd9.m12663for(this.f16914class);
    }
}
