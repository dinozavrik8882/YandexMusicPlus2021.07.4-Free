package defpackage;

import java.util.concurrent.Callable;

/* JADX INFO: Add missing generic type declarations: [T] */
/* loaded from: classes.dex */
public class n33<T> implements wj2<Void, T> {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ Callable f24933do;

    public n33(l33 l33Var, Callable callable) {
        this.f24933do = callable;
    }

    @Override // defpackage.wj2
    /* renamed from: do */
    public T mo160do(ek2<Void> ek2Var) throws Exception {
        return (T) this.f24933do.call();
    }
}
