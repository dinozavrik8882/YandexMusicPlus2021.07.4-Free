package defpackage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class nb0 {

    /* renamed from: do, reason: not valid java name */
    public static boolean f25327do;

    /* renamed from: if, reason: not valid java name */
    public static final List<a> f25329if = new ArrayList();

    /* renamed from: for, reason: not valid java name */
    public static final Set<String> f25328for = new HashSet();

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: do, reason: not valid java name */
        public String f25330do;

        /* renamed from: if, reason: not valid java name */
        public List<String> f25331if;

        public a(String str, List<String> list) {
            this.f25330do = str;
            this.f25331if = list;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public static synchronized void m10886do() {
        td0 m15509case;
        ArrayList arrayList;
        synchronized (nb0.class) {
            if (se0.m14224if(nb0.class)) {
                return;
            }
            try {
                HashSet<l90> hashSet = b90.f3183do;
                ge0.m6598try();
                m15509case = ud0.m15509case(b90.f3186for, false);
            } catch (Exception unused) {
            } catch (Throwable th) {
                se0.m14223do(th, nb0.class);
                return;
            }
            if (m15509case == null) {
                return;
            }
            String str = m15509case.f37010final;
            if (!str.isEmpty()) {
                JSONObject jSONObject = new JSONObject(str);
                f25329if.clear();
                Iterator<String> keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String next = keys.next();
                    JSONObject jSONObject2 = jSONObject.getJSONObject(next);
                    if (jSONObject2 != null) {
                        if (jSONObject2.optBoolean("is_deprecated_event")) {
                            f25328for.add(next);
                        } else {
                            JSONArray optJSONArray = jSONObject2.optJSONArray("deprecated_param");
                            a aVar = new a(next, new ArrayList());
                            if (optJSONArray != null) {
                                try {
                                    arrayList = new ArrayList();
                                    for (int i = 0; i < optJSONArray.length(); i++) {
                                        arrayList.add(optJSONArray.getString(i));
                                    }
                                } catch (JSONException unused2) {
                                    arrayList = new ArrayList();
                                }
                                aVar.f25331if = arrayList;
                            }
                            f25329if.add(aVar);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: if, reason: not valid java name */
    public static void m10887if(List<x90> list) {
        if (se0.m14224if(nb0.class)) {
            return;
        }
        try {
            if (f25327do) {
                Iterator<x90> it = list.iterator();
                while (it.hasNext()) {
                    if (f25328for.contains(it.next().f43426super)) {
                        it.remove();
                    }
                }
            }
        } catch (Throwable th) {
            se0.m14223do(th, nb0.class);
        }
    }
}
