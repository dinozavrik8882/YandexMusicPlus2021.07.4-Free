package defpackage;

import android.os.Bundle;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import ru.yandex.music.settings.network.NetworkModeView;

/* loaded from: classes2.dex */
public final class moc {

    /* renamed from: do, reason: not valid java name */
    public final Map<hha, NetworkModeView> f24385do = new HashMap();

    /* renamed from: for, reason: not valid java name */
    public a f24386for;

    /* renamed from: if, reason: not valid java name */
    public hha f24387if;

    /* loaded from: classes2.dex */
    public interface a {
    }

    public moc(Bundle bundle) {
        this.f24387if = bundle != null ? (hha) bundle.getSerializable("NetworkModesCoordinator.checked_mode") : null;
    }

    /* renamed from: do, reason: not valid java name */
    public void m10540do(final hha hhaVar, final NetworkModeView networkModeView) {
        this.f24385do.put(hhaVar, networkModeView);
        if (this.f24387if == hhaVar) {
            networkModeView.setChecked(true);
        }
        networkModeView.setOnUserCheckedChangedListener(new tqe() { // from class: loc
            @Override // defpackage.tqe
            public final void call(Object obj) {
                moc mocVar = moc.this;
                hha hhaVar2 = hhaVar;
                NetworkModeView networkModeView2 = networkModeView;
                Objects.requireNonNull(mocVar);
                if (((Boolean) obj).booleanValue()) {
                    mocVar.m10541if(hhaVar2);
                    return;
                }
                boolean z = hhaVar2 == mocVar.f24387if;
                int i = e8d.f9711do;
                if (!z) {
                    jr3.m8593do("unchecked mode is not mCheckedMode");
                }
                networkModeView2.setChecked(true);
            }
        });
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x00ac  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x009b  */
    /* renamed from: if, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void m10541if(defpackage.hha r8) {
        /*
            r7 = this;
            hha r0 = r7.f24387if
            if (r0 != r8) goto L5
            return
        L5:
            java.util.Map<hha, ru.yandex.music.settings.network.NetworkModeView> r0 = r7.f24385do
            java.lang.Object r0 = r0.get(r8)
            ru.yandex.music.settings.network.NetworkModeView r0 = (ru.yandex.music.settings.network.NetworkModeView) r0
            if (r0 != 0) goto L17
            int r8 = defpackage.e8d.f9711do
            java.lang.String r8 = "setChecked(): call add() before using it"
            defpackage.jr3.m8593do(r8)
            return
        L17:
            hha r1 = r7.f24387if
            r2 = 0
            r3 = 1
            if (r1 != 0) goto L20
        L1d:
            r4 = r3
            goto Laa
        L20:
            moc$a r1 = r7.f24386for
            if (r1 == 0) goto La1
            ync r1 = (defpackage.ync) r1
            java.util.Objects.requireNonNull(r1)
            int r4 = r8.ordinal()
            if (r4 == 0) goto L93
            if (r4 == r3) goto L8d
            r5 = 2
            if (r4 == r5) goto L4c
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r4 = "onUserSelected(): unhandled mode "
            r1.append(r4)
            r1.append(r8)
            java.lang.String r1 = r1.toString()
            int r4 = defpackage.e8d.f9711do
            defpackage.jr3.m8593do(r1)
            r4 = r2
            goto Laa
        L4c:
            qg9 r4 = r1.f45850synchronized
            yg9 r4 = r4.mo9664try()
            boolean r5 = r4.f45521continue
            if (r5 != 0) goto L61
            lr7 r4 = r1.m17679continue()
            a48 r5 = defpackage.a48.CACHE
            r6 = 0
            defpackage.v56.m15908implements(r4, r5, r6)
            goto L85
        L61:
            ru.yandex.music.data.user.Permission r5 = ru.yandex.music.data.user.Permission.LIBRARY_CACHE
            boolean r4 = r4.m17618try(r5)
            if (r4 != 0) goto L71
            android.content.Context r4 = r1.getContext()
            defpackage.qsa.m12930do(r4, r5)
            goto L85
        L71:
            hx7 r4 = defpackage.gx7.m6886if(r2)
            int r4 = r4.m7520if()
            if (r4 != 0) goto L87
            android.content.Context r4 = r1.getContext()
            r5 = 2131952579(0x7f1303c3, float:1.9541605E38)
            defpackage.i9d.m7694final(r4, r5, r2)
        L85:
            r4 = r2
            goto L99
        L87:
            java.lang.String r4 = "Settings_Offline"
            defpackage.pic.m12144if(r4)
            goto L98
        L8d:
            java.lang.String r4 = "Settings_WiFiOnly"
            defpackage.pic.m12144if(r4)
            goto L98
        L93:
            java.lang.String r4 = "Settings_WiFi_3G"
            defpackage.pic.m12144if(r4)
        L98:
            r4 = r3
        L99:
            if (r4 == 0) goto Laa
            wga r1 = r1.f
            r1.mo16664for(r8)
            goto Laa
        La1:
            int r1 = defpackage.e8d.f9711do
            java.lang.String r1 = "setChecked(): listener is null"
            defpackage.jr3.m8593do(r1)
            goto L1d
        Laa:
            if (r4 != 0) goto Lb0
            r0.setChecked(r2)
            return
        Lb0:
            r7.f24387if = r8
            java.util.Map<hha, ru.yandex.music.settings.network.NetworkModeView> r8 = r7.f24385do
            java.util.Collection r8 = r8.values()
            java.util.Iterator r8 = r8.iterator()
        Lbc:
            boolean r1 = r8.hasNext()
            if (r1 == 0) goto Ld1
            java.lang.Object r1 = r8.next()
            ru.yandex.music.settings.network.NetworkModeView r1 = (ru.yandex.music.settings.network.NetworkModeView) r1
            if (r1 != r0) goto Lcc
            r4 = r3
            goto Lcd
        Lcc:
            r4 = r2
        Lcd:
            r1.setChecked(r4)
            goto Lbc
        Ld1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.moc.m10541if(hha):void");
    }
}
