package defpackage;

import android.content.Context;
import android.os.Handler;
import defpackage.cq0;

/* loaded from: classes2.dex */
public class sj8 extends gq0 {
    public final mj8 o0;

    public sj8(Context context, px0 px0Var, Handler handler, vp0 vp0Var, mj8 mj8Var, up0[] up0VarArr) {
        super(context, px0Var, false, null, null, new cq0(null, new cq0.d(up0VarArr), false, false, false));
        this.o0 = mj8Var;
    }

    @Override // defpackage.gq0
    public void N(int i) {
        this.o0.onAudioSessionId(i);
    }

    @Override // defpackage.gq0, defpackage.ox0, defpackage.on0
    /* renamed from: finally */
    public void mo5906finally() {
        super.mo5906finally();
        this.o0.mo7119do();
    }
}
