package defpackage;

/* loaded from: classes2.dex */
public final class dva extends ro4 {
    public dva() {
        super("androidUniversalWidget", false, false, true, 6);
    }
}
