package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class tp extends sp {

    /* renamed from: break, reason: not valid java name */
    public int f37602break;

    /* renamed from: case, reason: not valid java name */
    public final int f37603case;

    /* renamed from: catch, reason: not valid java name */
    public int f37604catch;

    /* renamed from: else, reason: not valid java name */
    public final int f37605else;

    /* renamed from: goto, reason: not valid java name */
    public final String f37606goto;

    /* renamed from: new, reason: not valid java name */
    public final SparseIntArray f37607new;

    /* renamed from: this, reason: not valid java name */
    public int f37608this;

    /* renamed from: try, reason: not valid java name */
    public final Parcel f37609try;

    public tp(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new d8(), new d8(), new d8());
    }

    public tp(Parcel parcel, int i, int i2, String str, d8<String, Method> d8Var, d8<String, Method> d8Var2, d8<String, Class> d8Var3) {
        super(d8Var, d8Var2, d8Var3);
        this.f37607new = new SparseIntArray();
        this.f37608this = -1;
        this.f37602break = 0;
        this.f37604catch = -1;
        this.f37609try = parcel;
        this.f37603case = i;
        this.f37605else = i2;
        this.f37602break = i;
        this.f37606goto = str;
    }

    @Override // defpackage.sp
    /* renamed from: break */
    public int mo14343break() {
        return this.f37609try.readInt();
    }

    @Override // defpackage.sp
    /* renamed from: case */
    public boolean mo14344case() {
        return this.f37609try.readInt() != 0;
    }

    @Override // defpackage.sp
    /* renamed from: class */
    public <T extends Parcelable> T mo14346class() {
        return (T) this.f37609try.readParcelable(tp.class.getClassLoader());
    }

    @Override // defpackage.sp
    /* renamed from: do */
    public void mo14348do() {
        int i = this.f37608this;
        if (i >= 0) {
            int i2 = this.f37607new.get(i);
            int dataPosition = this.f37609try.dataPosition();
            this.f37609try.setDataPosition(i2);
            this.f37609try.writeInt(dataPosition - i2);
            this.f37609try.setDataPosition(dataPosition);
        }
    }

    @Override // defpackage.sp
    /* renamed from: else */
    public byte[] mo14349else() {
        int readInt = this.f37609try.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f37609try.readByteArray(bArr);
        return bArr;
    }

    @Override // defpackage.sp
    /* renamed from: final */
    public String mo14350final() {
        return this.f37609try.readString();
    }

    @Override // defpackage.sp
    /* renamed from: goto */
    public CharSequence mo14352goto() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f37609try);
    }

    @Override // defpackage.sp
    /* renamed from: if */
    public sp mo14353if() {
        Parcel parcel = this.f37609try;
        int dataPosition = parcel.dataPosition();
        int i = this.f37602break;
        if (i == this.f37603case) {
            i = this.f37605else;
        }
        return new tp(parcel, dataPosition, i, by.e(new StringBuilder(), this.f37606goto, "  "), this.f35813do, this.f35815if, this.f35814for);
    }

    @Override // defpackage.sp
    /* renamed from: import */
    public void mo14354import(byte[] bArr) {
        if (bArr == null) {
            this.f37609try.writeInt(-1);
        } else {
            this.f37609try.writeInt(bArr.length);
            this.f37609try.writeByteArray(bArr);
        }
    }

    @Override // defpackage.sp
    /* renamed from: native */
    public void mo14355native(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f37609try, 0);
    }

    @Override // defpackage.sp
    /* renamed from: public */
    public void mo14357public(int i) {
        this.f37609try.writeInt(i);
    }

    @Override // defpackage.sp
    /* renamed from: return */
    public void mo14358return(Parcelable parcelable) {
        this.f37609try.writeParcelable(parcelable, 0);
    }

    @Override // defpackage.sp
    /* renamed from: static */
    public void mo14359static(String str) {
        this.f37609try.writeString(str);
    }

    @Override // defpackage.sp
    /* renamed from: this */
    public boolean mo14362this(int i) {
        while (this.f37602break < this.f37605else) {
            int i2 = this.f37604catch;
            if (i2 == i) {
                return true;
            }
            if (String.valueOf(i2).compareTo(String.valueOf(i)) > 0) {
                return false;
            }
            this.f37609try.setDataPosition(this.f37602break);
            int readInt = this.f37609try.readInt();
            this.f37604catch = this.f37609try.readInt();
            this.f37602break += readInt;
        }
        return this.f37604catch == i;
    }

    @Override // defpackage.sp
    /* renamed from: throw */
    public void mo14363throw(int i) {
        mo14348do();
        this.f37608this = i;
        this.f37607new.put(i, this.f37609try.dataPosition());
        this.f37609try.writeInt(0);
        this.f37609try.writeInt(i);
    }

    @Override // defpackage.sp
    /* renamed from: while */
    public void mo14365while(boolean z) {
        this.f37609try.writeInt(z ? 1 : 0);
    }
}
