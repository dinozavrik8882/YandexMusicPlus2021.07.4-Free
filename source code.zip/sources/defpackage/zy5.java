package defpackage;

/* JADX INFO: Add missing generic type declarations: [T] */
/* loaded from: classes2.dex */
public final class zy5<T> implements fy5<T> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ cq5 f48009catch;

    public zy5(cq5 cq5Var) {
        this.f48009catch = cq5Var;
    }

    @Override // defpackage.fy5
    /* renamed from: if */
    public Object mo600if(T t, wm5<? super pl5> wm5Var) {
        this.f48009catch.f7342catch = t;
        throw new g06(this);
    }
}
