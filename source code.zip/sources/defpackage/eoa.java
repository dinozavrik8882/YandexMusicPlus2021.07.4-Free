package defpackage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.ju9;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.landing.autoplaylists.FixedItemWidthLayoutManager;
import ru.yandex.music.ui.view.recyclerview.RecyclerPageIndicator;

/* loaded from: classes2.dex */
public final class eoa {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f10445do;

    /* renamed from: case, reason: not valid java name */
    public final ns7<moa> f10446case;

    /* renamed from: else, reason: not valid java name */
    public boolean f10447else;

    /* renamed from: for, reason: not valid java name */
    public final ey3 f10448for;

    /* renamed from: if, reason: not valid java name */
    public final View f10449if;

    /* renamed from: new, reason: not valid java name */
    public final ey3 f10450new;

    /* renamed from: try, reason: not valid java name */
    public final ey3 f10451try;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<mr5<?>, TextView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f10452catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(View view, int i) {
            super(1);
            this.f10452catch = view;
        }

        @Override // defpackage.mo5
        public TextView invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f10452catch.findViewById(R.id.radio_title);
                if (findViewById != null) {
                    return (TextView) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements mo5<mr5<?>, RecyclerView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f10453catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(View view, int i) {
            super(1);
            this.f10453catch = view;
        }

        @Override // defpackage.mo5
        public RecyclerView invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f10453catch.findViewById(R.id.radio_recycler_view);
                if (findViewById != null) {
                    return (RecyclerView) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type androidx.recyclerview.widget.RecyclerView");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements mo5<mr5<?>, RecyclerPageIndicator> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f10454catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(View view, int i) {
            super(1);
            this.f10454catch = view;
        }

        @Override // defpackage.mo5
        public RecyclerPageIndicator invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f10454catch.findViewById(R.id.radio_page_indicator);
                if (findViewById != null) {
                    return (RecyclerPageIndicator) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type ru.yandex.music.ui.view.recyclerview.RecyclerPageIndicator");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(eoa.class), "title", "getTitle()Landroid/widget/TextView;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(eoa.class), "recycler", "getRecycler()Landroidx/recyclerview/widget/RecyclerView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var3 = new wp5(dq5.m4763do(eoa.class), "indicator", "getIndicator()Lru/yandex/music/ui/view/recyclerview/RecyclerPageIndicator;");
        Objects.requireNonNull(eq5Var);
        f10445do = new mr5[]{wp5Var, wp5Var2, wp5Var3};
    }

    public eoa(Context context, iy3 iy3Var, ViewGroup viewGroup) {
        jp5.m8570try(context, "context");
        jp5.m8570try(iy3Var, "containerComponents");
        jp5.m8570try(viewGroup, "parent");
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.view_podcasts_radio, viewGroup, false);
        jp5.m8568new(inflate, "from(context).inflate(layoutId, this, attachToRoot)");
        this.f10449if = inflate;
        this.f10448for = new ey3(new a(inflate, R.id.radio_title));
        this.f10450new = new ey3(new b(inflate, R.id.radio_recycler_view));
        ey3 ey3Var = new ey3(new c(inflate, R.id.radio_page_indicator));
        this.f10451try = ey3Var;
        ns7<moa> ns7Var = new ns7<>(new moa(context, iy3Var));
        this.f10446case = ns7Var;
        this.f10447else = true;
        Context context2 = m5406do().getContext();
        jp5.m8568new(context2, "recycler.context");
        ju9.a m8629do = ju9.m8629do(context2);
        m8629do.f19321if.m8633do(m5406do(), new tqe() { // from class: coa
            @Override // defpackage.tqe
            public final void call(Object obj) {
                eoa eoaVar = eoa.this;
                int intValue = ((Integer) obj).intValue();
                jp5.m8570try(eoaVar, "this$0");
                RecyclerView.m layoutManager = eoaVar.m5406do().getLayoutManager();
                Objects.requireNonNull(layoutManager, "null cannot be cast to non-null type ru.yandex.music.landing.autoplaylists.FixedItemWidthLayoutManager");
                FixedItemWidthLayoutManager fixedItemWidthLayoutManager = (FixedItemWidthLayoutManager) layoutManager;
                fixedItemWidthLayoutManager.f33389volatile = intValue;
                fixedItemWidthLayoutManager.d0();
            }
        });
        int i = m8629do.f19320goto;
        int i2 = m8629do.f19317do.f19336if;
        int i3 = i - (i2 / 2);
        m5406do().setPadding(i3, 0, i3, 0);
        m5406do().setClipToPadding(false);
        m5406do().m1107goto(new gxc(0, i2, 0));
        m5406do().setAdapter(ns7Var);
        m5406do().setLayoutManager(new FixedItemWidthLayoutManager(m5406do().getContext()));
        ((RecyclerPageIndicator) ey3Var.m5520do(f10445do[2])).m13785do(m5406do(), new c1d(m5406do()));
        new hz9(1).mo6967do(m5406do());
    }

    /* renamed from: do, reason: not valid java name */
    public final RecyclerView m5406do() {
        return (RecyclerView) this.f10450new.m5520do(f10445do[1]);
    }
}
