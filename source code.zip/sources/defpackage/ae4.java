package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes.dex */
public final class ae4 extends ce4 {
    public static final a CREATOR = new a(null);

    /* renamed from: class, reason: not valid java name */
    public final String f732class;

    /* renamed from: const, reason: not valid java name */
    public final String f733const;

    /* renamed from: final, reason: not valid java name */
    public final String f734final;

    /* renamed from: super, reason: not valid java name */
    public final el5 f735super;

    /* loaded from: classes.dex */
    public static final class a implements Parcelable.Creator<ae4> {
        public a(ep5 ep5Var) {
        }

        @Override // android.os.Parcelable.Creator
        public ae4 createFromParcel(Parcel parcel) {
            jp5.m8570try(parcel, "parcel");
            String readString = parcel.readString();
            jp5.m8565for(readString);
            jp5.m8568new(readString, "parcel.readString()!!");
            String readString2 = parcel.readString();
            jp5.m8565for(readString2);
            jp5.m8568new(readString2, "parcel.readString()!!");
            String readString3 = parcel.readString();
            jp5.m8565for(readString3);
            jp5.m8568new(readString3, "parcel.readString()!!");
            return new ae4(readString, readString2, readString3);
        }

        @Override // android.os.Parcelable.Creator
        public ae4[] newArray(int i) {
            return new ae4[i];
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends kp5 implements bo5<fe4> {
        public b() {
            super(0);
        }

        @Override // defpackage.bo5
        public fe4 invoke() {
            fe4 fe4Var;
            String str = ae4.this.f734final;
            jp5.m8570try(str, "<this>");
            fe4[] values = fe4.values();
            int i = 0;
            while (true) {
                if (i >= 9) {
                    fe4Var = null;
                    break;
                }
                fe4Var = values[i];
                if (ts5.m15181goto(str, fe4Var.getSystem(), true)) {
                    break;
                }
                i++;
            }
            return fe4Var == null ? fe4.UNKNOWN : fe4Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ae4(String str, String str2, String str3) {
        super(if4.CARD, null);
        jp5.m8570try(str, DatabaseHelper.OttTrackingTable.COLUMN_ID);
        jp5.m8570try(str2, "number");
        jp5.m8570try(str3, "system");
        this.f732class = str;
        this.f733const = str2;
        this.f734final = str3;
        this.f735super = dn3.h1(new b());
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ae4)) {
            return false;
        }
        ae4 ae4Var = (ae4) obj;
        return jp5.m8563do(this.f732class, ae4Var.f732class) && jp5.m8563do(this.f733const, ae4Var.f733const) && jp5.m8563do(this.f734final, ae4Var.f734final);
    }

    public int hashCode() {
        return this.f734final.hashCode() + by.A(this.f733const, this.f732class.hashCode() * 31, 31);
    }

    public String toString() {
        StringBuilder r = by.r("BoundCardInfo(id=");
        r.append(this.f732class);
        r.append(", number=");
        r.append(this.f733const);
        r.append(", system=");
        return by.c(r, this.f734final, ')');
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        jp5.m8570try(parcel, "parcel");
        parcel.writeString(this.f732class);
        parcel.writeString(this.f733const);
        parcel.writeString(this.f734final);
    }
}
