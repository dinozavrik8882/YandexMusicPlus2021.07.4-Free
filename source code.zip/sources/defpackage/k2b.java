package defpackage;

import android.view.ViewGroup;

/* loaded from: classes2.dex */
public abstract class k2b extends vs7 {
    public k2b(ViewGroup viewGroup, int i) {
        super(viewGroup, i);
    }

    /* renamed from: goto */
    public void mo6979goto(i2b i2bVar) {
    }
}
