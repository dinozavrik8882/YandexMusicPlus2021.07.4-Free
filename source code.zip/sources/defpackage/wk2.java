package defpackage;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class wk2 implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ ek2 f42458catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ xk2 f42459class;

    public wk2(xk2 xk2Var, ek2 ek2Var) {
        this.f42459class = xk2Var;
        this.f42458catch = ek2Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            ek2 mo4560do = this.f42459class.f43916if.mo4560do(this.f42458catch.mo2126class());
            if (mo4560do == null) {
                xk2 xk2Var = this.f42459class;
                xk2Var.f43915for.m2134import(new NullPointerException("Continuation returned null"));
            } else {
                Executor executor = gk2.f13722if;
                mo4560do.mo2129else(executor, this.f42459class);
                mo4560do.mo2143try(executor, this.f42459class);
                mo4560do.mo2133if(executor, this.f42459class);
            }
        } catch (ck2 e) {
            if (!(e.getCause() instanceof Exception)) {
                this.f42459class.f43915for.m2134import(e);
                return;
            }
            xk2 xk2Var2 = this.f42459class;
            xk2Var2.f43915for.m2134import((Exception) e.getCause());
        } catch (CancellationException unused) {
            this.f42459class.f43915for.m2137public();
        } catch (Exception e2) {
            this.f42459class.f43915for.m2134import(e2);
        }
    }
}
