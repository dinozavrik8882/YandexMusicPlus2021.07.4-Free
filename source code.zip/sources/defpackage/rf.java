package defpackage;

import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class rf implements ActionMode.Callback {

    /* renamed from: case, reason: not valid java name */
    public boolean f32279case = false;

    /* renamed from: do, reason: not valid java name */
    public final ActionMode.Callback f32280do;

    /* renamed from: for, reason: not valid java name */
    public Class<?> f32281for;

    /* renamed from: if, reason: not valid java name */
    public final TextView f32282if;

    /* renamed from: new, reason: not valid java name */
    public Method f32283new;

    /* renamed from: try, reason: not valid java name */
    public boolean f32284try;

    public rf(ActionMode.Callback callback, TextView textView) {
        this.f32280do = callback;
        this.f32282if = textView;
    }

    @Override // android.view.ActionMode.Callback
    public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
        return this.f32280do.onActionItemClicked(actionMode, menuItem);
    }

    @Override // android.view.ActionMode.Callback
    public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
        return this.f32280do.onCreateActionMode(actionMode, menu);
    }

    @Override // android.view.ActionMode.Callback
    public void onDestroyActionMode(ActionMode actionMode) {
        this.f32280do.onDestroyActionMode(actionMode);
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x00d1 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x009f A[SYNTHETIC] */
    @Override // android.view.ActionMode.Callback
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onPrepareActionMode(android.view.ActionMode r13, android.view.Menu r14) {
        /*
            Method dump skipped, instructions count: 304
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.rf.onPrepareActionMode(android.view.ActionMode, android.view.Menu):boolean");
    }
}
