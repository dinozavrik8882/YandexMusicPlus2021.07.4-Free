package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.util.Util;

/* loaded from: classes.dex */
public final class ty0 extends sy0 {
    public static final Parcelable.Creator<ty0> CREATOR = new a();

    /* renamed from: class, reason: not valid java name */
    public final String f38002class;

    /* renamed from: const, reason: not valid java name */
    public final String f38003const;

    /* renamed from: final, reason: not valid java name */
    public final String f38004final;

    /* loaded from: classes.dex */
    public class a implements Parcelable.Creator<ty0> {
        @Override // android.os.Parcelable.Creator
        public ty0 createFromParcel(Parcel parcel) {
            return new ty0(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public ty0[] newArray(int i) {
            return new ty0[i];
        }
    }

    public ty0(Parcel parcel) {
        super("----");
        this.f38002class = (String) Util.castNonNull(parcel.readString());
        this.f38003const = (String) Util.castNonNull(parcel.readString());
        this.f38004final = (String) Util.castNonNull(parcel.readString());
    }

    public ty0(String str, String str2, String str3) {
        super("----");
        this.f38002class = str;
        this.f38003const = str2;
        this.f38004final = str3;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || ty0.class != obj.getClass()) {
            return false;
        }
        ty0 ty0Var = (ty0) obj;
        return Util.areEqual(this.f38003const, ty0Var.f38003const) && Util.areEqual(this.f38002class, ty0Var.f38002class) && Util.areEqual(this.f38004final, ty0Var.f38004final);
    }

    public int hashCode() {
        String str = this.f38002class;
        int hashCode = (527 + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f38003const;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.f38004final;
        return hashCode2 + (str3 != null ? str3.hashCode() : 0);
    }

    @Override // defpackage.sy0
    public String toString() {
        return this.f36226catch + ": domain=" + this.f38002class + ", description=" + this.f38003const;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f36226catch);
        parcel.writeString(this.f38002class);
        parcel.writeString(this.f38004final);
    }
}
