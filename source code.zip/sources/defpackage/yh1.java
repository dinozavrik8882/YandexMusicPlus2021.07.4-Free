package defpackage;

import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.Objects;

/* loaded from: classes.dex */
public interface yh1 extends IInterface {

    /* loaded from: classes.dex */
    public static abstract class a extends tz1 implements yh1 {
        public a() {
            super("com.google.android.gms.cast.framework.media.IImagePicker");
        }

        @Override // defpackage.tz1
        /* renamed from: const */
        public final boolean mo619const(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i == 1) {
                uf1 uf1Var = (uf1) r02.m13054do(parcel, uf1.CREATOR);
                parcel.readInt();
                nt1 m12063do = pg1.this.m12063do(uf1Var);
                parcel2.writeNoException();
                r02.m13057new(parcel2, m12063do);
            } else if (i == 2) {
                ix1 ix1Var = new ix1(pg1.this);
                parcel2.writeNoException();
                r02.m13056if(parcel2, ix1Var);
            } else if (i == 3) {
                parcel2.writeNoException();
                parcel2.writeInt(12451009);
            } else {
                if (i != 4) {
                    return false;
                }
                uf1 uf1Var2 = (uf1) r02.m13054do(parcel, uf1.CREATOR);
                og1 og1Var = (og1) r02.m13054do(parcel, og1.CREATOR);
                pg1 pg1Var = pg1.this;
                Objects.requireNonNull(pg1Var);
                int i3 = og1Var.f27179catch;
                nt1 m12063do2 = pg1Var.m12063do(uf1Var2);
                parcel2.writeNoException();
                r02.m13057new(parcel2, m12063do2);
            }
            return true;
        }
    }

    hx1 A0() throws RemoteException;
}
