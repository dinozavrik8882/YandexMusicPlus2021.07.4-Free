package defpackage;

import java.util.Objects;

/* loaded from: classes2.dex */
public final class c8a {

    /* renamed from: do, reason: not valid java name */
    public final p8a f4979do;

    public c8a(p8a p8aVar) {
        this.f4979do = p8aVar;
    }

    /* renamed from: do, reason: not valid java name */
    public <T extends d8a<T>> void m2679do(T t) {
        if (this.f4979do.m11944try(t)) {
            p8a p8aVar = this.f4979do;
            Objects.requireNonNull(p8aVar);
            jp5.m8570try(t, "entity");
            p8aVar.f28596if.m12549do(t);
            return;
        }
        p8a p8aVar2 = this.f4979do;
        Objects.requireNonNull(p8aVar2);
        jp5.m8570try(t, "entity");
        p8aVar2.m11940new();
        p8aVar2.f28596if.m12554new(t);
    }
}
