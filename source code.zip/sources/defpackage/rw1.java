package defpackage;

import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class rw1 {
    static {
        Pattern.compile("\\$\\{(.*?)\\}");
    }

    /* renamed from: do, reason: not valid java name */
    public static boolean m13987do(String str) {
        return str == null || str.trim().isEmpty();
    }
}
