package defpackage;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

/* loaded from: classes.dex */
public final class pu1 extends mz1 implements qu1 {
    public pu1(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.common.internal.service.IClientTelemetryService");
    }

    @Override // defpackage.qu1
    public final void b1(yu1 yu1Var) throws RemoteException {
        Parcel m10673const = m10673const();
        int i = nz1.f26316do;
        if (yu1Var == null) {
            m10673const.writeInt(0);
        } else {
            m10673const.writeInt(1);
            yu1Var.writeToParcel(m10673const, 0);
        }
        try {
            this.f24744do.transact(1, m10673const, null, 1);
        } finally {
            m10673const.recycle();
        }
    }
}
