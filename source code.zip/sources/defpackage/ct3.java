package defpackage;

import android.app.Application;
import defpackage.bz3;

/* loaded from: classes.dex */
public final class ct3 extends kp5 implements mo5<bz3.a, bt3> {

    /* renamed from: catch, reason: not valid java name */
    public static final ct3 f7415catch = new ct3();

    public ct3() {
        super(1);
    }

    @Override // defpackage.mo5
    public bt3 invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        return new bt3((Application) aVar2.m2427do(dn3.l3(Application.class)), (gt3) aVar2.m2427do(dn3.l3(gt3.class)));
    }
}
