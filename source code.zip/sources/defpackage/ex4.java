package defpackage;

import com.yandex.auth.sync.AccountProvider;

/* loaded from: classes.dex */
public final class ex4 extends yx4 {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ex4(String str, String str2) {
        super(str, str2, null);
        jp5.m8570try(str, "tableName");
        jp5.m8570try(str2, AccountProvider.NAME);
    }
}
