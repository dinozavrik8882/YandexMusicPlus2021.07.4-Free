package defpackage;

import java.util.List;

/* loaded from: classes2.dex */
public final class esa {

    /* renamed from: do, reason: not valid java name */
    public final scd<Boolean, List<cra>, Throwable> f10644do;

    /* loaded from: classes2.dex */
    public interface a {
    }

    public esa(scd<Boolean, List<cra>, Throwable> scdVar) {
        this.f10644do = scdVar;
    }
}
