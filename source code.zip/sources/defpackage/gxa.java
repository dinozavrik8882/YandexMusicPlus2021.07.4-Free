package defpackage;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.data.user.Permission;

/* loaded from: classes2.dex */
public final class gxa {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f14322do;

    /* renamed from: break, reason: not valid java name */
    public final el5 f14323break;

    /* renamed from: case, reason: not valid java name */
    public final String f14324case;

    /* renamed from: catch, reason: not valid java name */
    public final el5 f14325catch;

    /* renamed from: class, reason: not valid java name */
    public final yua f14326class;

    /* renamed from: const, reason: not valid java name */
    public final sua f14327const;

    /* renamed from: else, reason: not valid java name */
    public final zv4 f14328else;

    /* renamed from: final, reason: not valid java name */
    public v f14329final;

    /* renamed from: for, reason: not valid java name */
    public final nya f14330for;

    /* renamed from: goto, reason: not valid java name */
    public final gu5 f14331goto;

    /* renamed from: if, reason: not valid java name */
    public final Context f14332if;

    /* renamed from: import, reason: not valid java name */
    public a f14333import;

    /* renamed from: new, reason: not valid java name */
    public final Permission f14334new;

    /* renamed from: super, reason: not valid java name */
    public List<? extends d94> f14335super;

    /* renamed from: this, reason: not valid java name */
    public final el5 f14336this;

    /* renamed from: throw, reason: not valid java name */
    public fg4 f14337throw;

    /* renamed from: try, reason: not valid java name */
    public final oya f14338try;

    /* renamed from: while, reason: not valid java name */
    public boolean f14339while;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: break, reason: not valid java name */
        void mo6890break();

        /* renamed from: case, reason: not valid java name */
        void mo6891case(mg4 mg4Var);

        void close();

        /* renamed from: do, reason: not valid java name */
        void mo6892do(ee4 ee4Var);

        /* renamed from: else, reason: not valid java name */
        void mo6893else(ye4 ye4Var);

        /* renamed from: for, reason: not valid java name */
        void mo6894for();

        /* renamed from: goto, reason: not valid java name */
        void mo6895goto();

        /* renamed from: if, reason: not valid java name */
        void mo6896if(cg4 cg4Var);

        /* renamed from: new, reason: not valid java name */
        void mo6897new();

        /* renamed from: this, reason: not valid java name */
        void mo6898this(fg4 fg4Var);

        /* renamed from: try, reason: not valid java name */
        void mo6899try(Uri uri);
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(gxa.class), "userCenter", "getUserCenter()Lru/yandex/music/data/user/UserCenter;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(gxa.class), "billing", "getBilling()Lcom/yandex/music/model/payment/Billing;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var3 = new wp5(dq5.m4763do(gxa.class), "connectivityBox", "getConnectivityBox()Lru/yandex/music/network/connectivity/ConnectivityBox;");
        Objects.requireNonNull(eq5Var);
        f14322do = new mr5[]{wp5Var, wp5Var2, wp5Var3};
    }

    public gxa(Context context, nya nyaVar, Permission permission, oya oyaVar, Bundle bundle) {
        jp5.m8570try(context, "context");
        jp5.m8570try(nyaVar, "purchaseSource");
        this.f14332if = context;
        this.f14330for = nyaVar;
        this.f14334new = permission;
        this.f14338try = oyaVar;
        this.f14324case = "saveStateSubscriptions";
        cw4 cw4Var = new cw4(false);
        this.f14328else = cw4Var;
        this.f14331goto = dn3.m4644extends(cw4Var, kv4.m9275do());
        iz3 l3 = dn3.l3(qg9.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        mr5<Object>[] mr5VarArr = f14322do;
        jp5.m8570try(mr5VarArr[0], "prop");
        this.f14336this = dn3.h1(cz3Var);
        iz3 l32 = dn3.l3(z1.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        bz3Var2.m2425do(l32);
        cz3 cz3Var2 = new cz3(l32);
        jp5.m8570try(cz3Var2, "provider");
        jp5.m8570try(mr5VarArr[1], "prop");
        this.f14323break = dn3.h1(cz3Var2);
        iz3 l33 = dn3.l3(wga.class);
        jp5.m8570try(l33, "typeSpec");
        bz3 bz3Var3 = bz3.f4526do;
        jp5.m8565for(bz3Var3);
        bz3Var3.m2425do(l33);
        cz3 cz3Var3 = new cz3(l33);
        jp5.m8570try(cz3Var3, "provider");
        jp5.m8570try(mr5VarArr[2], "prop");
        this.f14325catch = dn3.h1(cz3Var3);
        this.f14326class = new yua(context, permission, oyaVar, bundle, nyaVar);
        this.f14327const = new sua(nyaVar, bundle);
        this.f14339while = ((nyaVar instanceof jya) && ((jya) nyaVar).f19499catch == kya.FULLSCREEN_PAYWALL) ? false : true;
        if (bundle != null) {
            this.f14337throw = (fg4) bundle.getParcelable("saveStateSubscriptions");
        }
        if (this.f14339while) {
            Objects.requireNonNull(pya.f29708for);
            pya.f29711try = null;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public final void m6888do() {
        v vVar;
        List<? extends d94> list = this.f14335super;
        if (list == null || (vVar = this.f14329final) == null) {
            return;
        }
        jp5.m8570try(list, "offers");
        if (g8d.m6476final(vVar.f39839this, list)) {
            return;
        }
        if (list.isEmpty()) {
            k2f.f19768new.mo8777while("populate(): empty offers, show progress...", new Object[0]);
            return;
        }
        vVar.f39839this = list;
        fxa fxaVar = vVar.f39836goto;
        fxaVar.f20987do.clear();
        fxaVar.f20987do.addAll(list);
        fxaVar.notifyDataSetChanged();
        t2.m14613return((View) vVar.f39838new.m5520do(v.f39831do[1]));
        t2.b(vVar.m15793do());
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:6:0x0045  */
    /* renamed from: if, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void m6889if(defpackage.mya r13) {
        /*
            r12 = this;
            el5 r0 = r12.f14336this
            java.lang.Object r0 = r0.getValue()
            qg9 r0 = (defpackage.qg9) r0
            yg9 r2 = r0.mo9664try()
            nya r3 = r12.f14330for
            ru.yandex.music.data.user.Permission r4 = r12.f14334new
            oya r5 = r12.f14338try
            java.util.List<? extends d94> r0 = r12.f14335super
            r1 = 0
            if (r0 != 0) goto L19
        L17:
            r6 = r1
            goto L3e
        L19:
            java.util.Iterator r0 = r0.iterator()
        L1d:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L2f
            java.lang.Object r6 = r0.next()
            r7 = r6
            d94 r7 = (defpackage.d94) r7
            boolean r7 = r7 instanceof defpackage.x84
            if (r7 == 0) goto L1d
            goto L30
        L2f:
            r6 = r1
        L30:
            d94 r6 = (defpackage.d94) r6
            if (r6 != 0) goto L35
            goto L17
        L35:
            x84 r6 = (defpackage.x84) r6
            af4 r0 = r6.m16993do()
            java.lang.String r0 = r0.f767catch
            r6 = r0
        L3e:
            java.util.List<? extends d94> r0 = r12.f14335super
            r7 = 1
            r8 = 0
            if (r0 != 0) goto L45
            goto L6a
        L45:
            java.util.Iterator r0 = r0.iterator()
        L49:
            boolean r9 = r0.hasNext()
            if (r9 == 0) goto L68
            java.lang.Object r9 = r0.next()
            r10 = r9
            d94 r10 = (defpackage.d94) r10
            boolean r11 = r10 instanceof defpackage.e94
            if (r11 == 0) goto L64
            e94 r10 = (defpackage.e94) r10
            boolean r10 = r10.mo5061do()
            if (r10 == 0) goto L64
            r10 = r7
            goto L65
        L64:
            r10 = r8
        L65:
            if (r10 == 0) goto L49
            r1 = r9
        L68:
            d94 r1 = (defpackage.d94) r1
        L6a:
            if (r1 == 0) goto L6d
            goto L6e
        L6d:
            r7 = r8
        L6e:
            r1 = r13
            defpackage.qd9.p(r1, r2, r3, r4, r5, r6, r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.gxa.m6889if(mya):void");
    }
}
