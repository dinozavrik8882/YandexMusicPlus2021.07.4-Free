package defpackage;

/* loaded from: classes.dex */
public class iq {

    /* renamed from: do, reason: not valid java name */
    public static int f17164do;

    /* renamed from: do, reason: not valid java name */
    public static float m7927do(String str) {
        int i = f17164do;
        if (i > 0) {
            f17164do = i - 1;
        }
        return 0.0f;
    }
}
