package defpackage;

/* loaded from: classes2.dex */
public final class e49 extends kp5 implements qo5<String, String, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ a49 f9468catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e49(a49 a49Var) {
        super(2);
        this.f9468catch = a49Var;
    }

    @Override // defpackage.qo5
    public pl5 invoke(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        jp5.m8570try(str3, "uid");
        jp5.m8570try(str4, "kind");
        a49 a49Var = this.f9468catch;
        a49Var.f217do.m1687for(new d49(a49Var, str3, str4));
        return pl5.f29126do;
    }
}
