package defpackage;

import java.util.logging.Logger;

/* loaded from: classes2.dex */
public final class yi5 {

    /* renamed from: do, reason: not valid java name */
    public static final Logger f45628do = Logger.getLogger(yi5.class.getName());

    /* renamed from: if, reason: not valid java name */
    public static final byte[] f45629if = "-bin".getBytes(gz2.f14398do);

    /* renamed from: do, reason: not valid java name */
    public static boolean m17648do(byte[] bArr, byte[] bArr2) {
        int length = bArr.length - bArr2.length;
        if (length < 0) {
            return false;
        }
        for (int i = length; i < bArr.length; i++) {
            if (bArr[i] != bArr2[i - length]) {
                return false;
            }
        }
        return true;
    }
}
