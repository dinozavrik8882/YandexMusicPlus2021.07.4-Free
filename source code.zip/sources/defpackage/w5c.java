package defpackage;

import com.squareup.moshi.Json;
import java.util.Date;

/* loaded from: classes2.dex */
public class w5c {

    /* renamed from: do, reason: not valid java name */
    public static final w5c f41709do = new w5c();

    @Json(name = "end")
    private final Date end = new Date(0);

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return this.end.equals(((w5c) obj).end);
    }

    public int hashCode() {
        return this.end.hashCode();
    }

    public String toString() {
        StringBuilder r = by.r("Subscription{end=");
        r.append(this.end);
        r.append('}');
        return r.toString();
    }
}
