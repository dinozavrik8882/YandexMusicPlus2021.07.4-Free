package defpackage;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import defpackage.ph;
import defpackage.zg;

/* loaded from: classes.dex */
public final class pg extends AnimatorListenerAdapter {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ ViewGroup f28921do;

    /* renamed from: for, reason: not valid java name */
    public final /* synthetic */ Fragment f28922for;

    /* renamed from: if, reason: not valid java name */
    public final /* synthetic */ View f28923if;

    /* renamed from: new, reason: not valid java name */
    public final /* synthetic */ ph.a f28924new;

    /* renamed from: try, reason: not valid java name */
    public final /* synthetic */ od f28925try;

    public pg(ViewGroup viewGroup, View view, Fragment fragment, ph.a aVar, od odVar) {
        this.f28921do = viewGroup;
        this.f28923if = view;
        this.f28922for = fragment;
        this.f28924new = aVar;
        this.f28925try = odVar;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f28921do.endViewTransition(this.f28923if);
        Animator animator2 = this.f28922for.getAnimator();
        this.f28922for.setAnimator(null);
        if (animator2 == null || this.f28921do.indexOfChild(this.f28923if) >= 0) {
            return;
        }
        ((zg.b) this.f28924new).m18059do(this.f28922for, this.f28925try);
    }
}
