package defpackage;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.ui.view.YaRotatingProgress;

/* loaded from: classes2.dex */
public final class n1 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f24866do;

    /* renamed from: case, reason: not valid java name */
    public final ey3 f24867case;

    /* renamed from: else, reason: not valid java name */
    public final int f24868else;

    /* renamed from: for, reason: not valid java name */
    public final ey3 f24869for;

    /* renamed from: goto, reason: not valid java name */
    public b f24870goto;

    /* renamed from: if, reason: not valid java name */
    public final Context f24871if;

    /* renamed from: new, reason: not valid java name */
    public final ey3 f24872new;

    /* renamed from: try, reason: not valid java name */
    public final ey3 f24873try;

    /* loaded from: classes.dex */
    public static final class a extends kp5 implements mo5<mr5<?>, Button> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f24874catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ int f24875class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ Object f24876const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(int i, int i2, Object obj) {
            super(1);
            this.f24874catch = i;
            this.f24875class = i2;
            this.f24876const = obj;
        }

        @Override // defpackage.mo5
        public final Button invoke(mr5<?> mr5Var) {
            int i = this.f24874catch;
            if (i == 0) {
                mr5<?> mr5Var2 = mr5Var;
                jp5.m8570try(mr5Var2, "property");
                try {
                    View findViewById = ((View) this.f24876const).findViewById(R.id.text_view_resend_code);
                    if (findViewById != null) {
                        return (Button) findViewById;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.Button");
                } catch (ClassCastException e) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
                }
            }
            if (i != 1) {
                throw null;
            }
            mr5<?> mr5Var3 = mr5Var;
            jp5.m8570try(mr5Var3, "property");
            try {
                View findViewById2 = ((View) this.f24876const).findViewById(R.id.button_done);
                if (findViewById2 != null) {
                    return (Button) findViewById2;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.Button");
            } catch (ClassCastException e2) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var3).toString(), e2);
            }
        }
    }

    /* loaded from: classes2.dex */
    public interface b {
        /* renamed from: do */
        void mo7956do(String str);
    }

    /* loaded from: classes2.dex */
    public static final class c implements TextWatcher {
        public c() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            n1.this.m10698try(charSequence);
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends kp5 implements mo5<mr5<?>, EditText> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f24878catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(View view, int i) {
            super(1);
            this.f24878catch = view;
        }

        @Override // defpackage.mo5
        public EditText invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f24878catch.findViewById(R.id.input);
                if (findViewById != null) {
                    return (EditText) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.EditText");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class e extends kp5 implements mo5<mr5<?>, YaRotatingProgress> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f24879catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(View view, int i) {
            super(1);
            this.f24879catch = view;
        }

        @Override // defpackage.mo5
        public YaRotatingProgress invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f24879catch.findViewById(R.id.progress_view);
                if (findViewById != null) {
                    return (YaRotatingProgress) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type ru.yandex.music.ui.view.YaRotatingProgress");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(n1.class), "codeInput", "getCodeInput()Landroid/widget/EditText;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(n1.class), "retry", "getRetry()Landroid/widget/Button;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var3 = new wp5(dq5.m4763do(n1.class), "send", "getSend()Landroid/widget/Button;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var4 = new wp5(dq5.m4763do(n1.class), "progress", "getProgress()Lru/yandex/music/ui/view/YaRotatingProgress;");
        Objects.requireNonNull(eq5Var);
        f24866do = new mr5[]{wp5Var, wp5Var2, wp5Var3, wp5Var4};
    }

    public n1(Context context, View view) {
        jp5.m8570try(context, "context");
        jp5.m8570try(view, "root");
        this.f24871if = context;
        this.f24869for = new ey3(new d(view, R.id.input));
        this.f24872new = new ey3(new a(0, R.id.text_view_resend_code, view));
        this.f24873try = new ey3(new a(1, R.id.button_done, view));
        this.f24867case = new ey3(new e(view, R.id.progress_view));
        this.f24868else = 6;
        m10696if().setVisibility(8);
        m10695for().setOnClickListener(new View.OnClickListener() { // from class: xsa
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                n1 n1Var = n1.this;
                jp5.m8570try(n1Var, "this$0");
                n1Var.m10697new(n1Var.m10694do().getText());
            }
        });
        m10694do().setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: ysa
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                n1 n1Var = n1.this;
                jp5.m8570try(n1Var, "this$0");
                Editable text = n1Var.m10694do().getText();
                jp5.m8568new(text, "codeInput.text");
                if (ts5.m15187native(text)) {
                    return false;
                }
                if (i != 3 && i != 6 && (keyEvent.getAction() != 0 || keyEvent.getKeyCode() != 66)) {
                    return false;
                }
                n1Var.m10697new(n1Var.m10694do().getText());
                return true;
            }
        });
        m10698try(m10694do().getText());
        m10694do().addTextChangedListener(new c());
    }

    /* renamed from: do, reason: not valid java name */
    public final EditText m10694do() {
        return (EditText) this.f24869for.m5520do(f24866do[0]);
    }

    /* renamed from: for, reason: not valid java name */
    public final Button m10695for() {
        return (Button) this.f24873try.m5520do(f24866do[2]);
    }

    /* renamed from: if, reason: not valid java name */
    public final Button m10696if() {
        return (Button) this.f24872new.m5520do(f24866do[1]);
    }

    /* renamed from: new, reason: not valid java name */
    public final void m10697new(CharSequence charSequence) {
        b bVar;
        if (!m10698try(charSequence) || (bVar = this.f24870goto) == null) {
            return;
        }
        bVar.mo7956do(m10694do().getText().toString());
    }

    /* renamed from: try, reason: not valid java name */
    public final boolean m10698try(CharSequence charSequence) {
        boolean z = false;
        if (charSequence != null && charSequence.length() == this.f24868else) {
            z = true;
        }
        m10695for().setEnabled(z);
        return z;
    }
}
