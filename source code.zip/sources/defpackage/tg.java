package defpackage;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import ru.yandex.music.R;

/* loaded from: classes.dex */
public final class tg extends FrameLayout {

    /* renamed from: catch, reason: not valid java name */
    public ArrayList<View> f37146catch;

    /* renamed from: class, reason: not valid java name */
    public ArrayList<View> f37147class;

    /* renamed from: const, reason: not valid java name */
    public boolean f37148const;

    public tg(Context context, AttributeSet attributeSet, zg zgVar) {
        super(context, attributeSet);
        this.f37148const = true;
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ig.f16730if);
        classAttribute = classAttribute == null ? obtainStyledAttributes.getString(0) : classAttribute;
        String string = obtainStyledAttributes.getString(1);
        obtainStyledAttributes.recycle();
        int id = getId();
        Fragment m18057volatile = zgVar.m18057volatile(id);
        if (classAttribute == null || m18057volatile != null) {
            return;
        }
        if (id <= 0) {
            throw new IllegalStateException(by.m2414volatile("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? by.m2405strictfp(" with tag ", string) : ""));
        }
        Fragment mo16083do = zgVar.m18038instanceof().mo16083do(context.getClassLoader(), classAttribute);
        mo16083do.onInflate(context, attributeSet, (Bundle) null);
        jg jgVar = new jg(zgVar);
        jgVar.f16789throw = true;
        mo16083do.mContainer = this;
        jgVar.mo7815this(getId(), mo16083do, string, 1);
        jgVar.mo7812goto();
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof Fragment ? (Fragment) tag : null) != null) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.");
    }

    @Override // android.view.ViewGroup
    public boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof Fragment ? (Fragment) tag : null) != null) {
            return super.addViewInLayout(view, i, layoutParams, z);
        }
        throw new IllegalStateException("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.");
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        if (this.f37148const && this.f37146catch != null) {
            for (int i = 0; i < this.f37146catch.size(); i++) {
                super.drawChild(canvas, this.f37146catch.get(i), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    /* renamed from: do, reason: not valid java name */
    public final void m14890do(View view) {
        ArrayList<View> arrayList;
        if (view.getAnimation() != null || ((arrayList = this.f37147class) != null && arrayList.contains(view))) {
            if (this.f37146catch == null) {
                this.f37146catch = new ArrayList<>();
            }
            this.f37146catch.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j) {
        ArrayList<View> arrayList;
        if (!this.f37148const || (arrayList = this.f37146catch) == null || arrayList.size() <= 0 || !this.f37146catch.contains(view)) {
            return super.drawChild(canvas, view, j);
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public void endViewTransition(View view) {
        ArrayList<View> arrayList = this.f37147class;
        if (arrayList != null) {
            arrayList.remove(view);
            ArrayList<View> arrayList2 = this.f37146catch;
            if (arrayList2 != null && arrayList2.remove(view)) {
                this.f37148const = true;
            }
        }
        super.endViewTransition(view);
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).dispatchApplyWindowInsets(new WindowInsets(windowInsets));
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public void removeAllViewsInLayout() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            m14890do(getChildAt(childCount));
        }
        super.removeAllViewsInLayout();
    }

    @Override // android.view.ViewGroup
    public void removeDetachedView(View view, boolean z) {
        if (z) {
            m14890do(view);
        }
        super.removeDetachedView(view, z);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        m14890do(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public void removeViewAt(int i) {
        m14890do(getChildAt(i));
        super.removeViewAt(i);
    }

    @Override // android.view.ViewGroup
    public void removeViewInLayout(View view) {
        m14890do(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public void removeViews(int i, int i2) {
        for (int i3 = i; i3 < i + i2; i3++) {
            m14890do(getChildAt(i3));
        }
        super.removeViews(i, i2);
    }

    @Override // android.view.ViewGroup
    public void removeViewsInLayout(int i, int i2) {
        for (int i3 = i; i3 < i + i2; i3++) {
            m14890do(getChildAt(i3));
        }
        super.removeViewsInLayout(i, i2);
    }

    public void setDrawDisappearingViewsLast(boolean z) {
        this.f37148const = z;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.ViewGroup
    public void startViewTransition(View view) {
        if (view.getParent() == this) {
            if (this.f37147class == null) {
                this.f37147class = new ArrayList<>();
            }
            this.f37147class.add(view);
        }
        super.startViewTransition(view);
    }
}
