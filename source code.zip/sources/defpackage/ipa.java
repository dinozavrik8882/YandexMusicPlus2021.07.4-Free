package defpackage;

/* loaded from: classes2.dex */
public final class ipa extends kp5 implements mo5<Object, Boolean> {

    /* renamed from: catch, reason: not valid java name */
    public static final ipa f17157catch = new ipa();

    public ipa() {
        super(1);
    }

    @Override // defpackage.mo5
    public Boolean invoke(Object obj) {
        return Boolean.valueOf(obj instanceof xoa);
    }
}
