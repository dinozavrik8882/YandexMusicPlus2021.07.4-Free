package defpackage;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import defpackage.xd;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class cd extends ad {

    /* renamed from: break, reason: not valid java name */
    public final Method f5173break;

    /* renamed from: catch, reason: not valid java name */
    public final Method f5174catch;

    /* renamed from: class, reason: not valid java name */
    public final Method f5175class;

    /* renamed from: const, reason: not valid java name */
    public final Method f5176const;

    /* renamed from: else, reason: not valid java name */
    public final Class<?> f5177else;

    /* renamed from: goto, reason: not valid java name */
    public final Constructor<?> f5178goto;

    /* renamed from: this, reason: not valid java name */
    public final Method f5179this;

    public cd() {
        Method method;
        Method method2;
        Constructor<?> constructor;
        Method method3;
        Method method4;
        Method method5;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(new Class[0]);
            method3 = m2785final(cls2);
            method4 = m2788super(cls2);
            method5 = cls2.getMethod("freeze", new Class[0]);
            method2 = cls2.getMethod("abortCreation", new Class[0]);
            method = mo2790throw(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            StringBuilder r = by.r("Unable to collect necessary methods for class ");
            r.append(e.getClass().getName());
            Log.e("TypefaceCompatApi26Impl", r.toString(), e);
            method = null;
            method2 = null;
            constructor = null;
            method3 = null;
            method4 = null;
            method5 = null;
        }
        this.f5177else = cls;
        this.f5178goto = constructor;
        this.f5179this = method3;
        this.f5173break = method4;
        this.f5174catch = method5;
        this.f5175class = method2;
        this.f5176const = method;
    }

    /* renamed from: const, reason: not valid java name */
    private Object m2781const() {
        try {
            return this.f5178goto.newInstance(new Object[0]);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            return null;
        }
    }

    /* renamed from: break, reason: not valid java name */
    public Typeface mo2782break(Object obj) {
        try {
            Object newInstance = Array.newInstance(this.f5177else, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) this.f5176const.invoke(null, newInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    /* renamed from: catch, reason: not valid java name */
    public final boolean m2783catch(Object obj) {
        try {
            return ((Boolean) this.f5174catch.invoke(obj, new Object[0])).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    /* renamed from: class, reason: not valid java name */
    public final boolean m2784class() {
        if (this.f5179this == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        return this.f5179this != null;
    }

    @Override // defpackage.ad, defpackage.gd
    /* renamed from: do */
    public Typeface mo491do(Context context, qc qcVar, Resources resources, int i) {
        if (!m2784class()) {
            return super.mo491do(context, qcVar, resources, i);
        }
        Object m2781const = m2781const();
        if (m2781const == null) {
            return null;
        }
        for (rc rcVar : qcVar.f30438do) {
            if (!m2789this(context, m2781const, rcVar.f32179do, rcVar.f32183try, rcVar.f32181if, rcVar.f32180for ? 1 : 0, FontVariationAxis.fromFontVariationSettings(rcVar.f32182new))) {
                m2786goto(m2781const);
                return null;
            }
        }
        if (m2783catch(m2781const)) {
            return mo2782break(m2781const);
        }
        return null;
    }

    /* renamed from: final, reason: not valid java name */
    public Method m2785final(Class<?> cls) throws NoSuchMethodException {
        Class<?> cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls2, Boolean.TYPE, cls2, cls2, cls2, FontVariationAxis[].class);
    }

    /* renamed from: goto, reason: not valid java name */
    public final void m2786goto(Object obj) {
        try {
            this.f5175class.invoke(obj, new Object[0]);
        } catch (IllegalAccessException | InvocationTargetException unused) {
        }
    }

    @Override // defpackage.ad, defpackage.gd
    /* renamed from: if */
    public Typeface mo492if(Context context, CancellationSignal cancellationSignal, xd.c[] cVarArr, int i) {
        Typeface mo2782break;
        boolean z;
        if (cVarArr.length < 1) {
            return null;
        }
        if (!m2784class()) {
            xd.c cVar = (xd.c) gd.m6574try(cVarArr, i, new fd(this));
            try {
                ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(cVar.f43624do, "r", cancellationSignal);
                if (openFileDescriptor == null) {
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                    }
                    return null;
                }
                try {
                    Typeface build = new Typeface.Builder(openFileDescriptor.getFileDescriptor()).setWeight(cVar.f43625for).setItalic(cVar.f43627new).build();
                    openFileDescriptor.close();
                    return build;
                } finally {
                }
            } catch (IOException unused) {
                return null;
            }
        }
        i8<String, Typeface> i8Var = xd.f43617do;
        HashMap hashMap = new HashMap();
        for (xd.c cVar2 : cVarArr) {
            if (cVar2.f43628try == 0) {
                Uri uri = cVar2.f43624do;
                if (!hashMap.containsKey(uri)) {
                    hashMap.put(uri, qb.m12602continue(context, cancellationSignal, uri));
                }
            }
        }
        Map unmodifiableMap = Collections.unmodifiableMap(hashMap);
        Object m2781const = m2781const();
        if (m2781const == null) {
            return null;
        }
        int length = cVarArr.length;
        int i2 = 0;
        boolean z2 = false;
        while (i2 < length) {
            xd.c cVar3 = cVarArr[i2];
            ByteBuffer byteBuffer = (ByteBuffer) unmodifiableMap.get(cVar3.f43624do);
            if (byteBuffer != null) {
                try {
                    z = ((Boolean) this.f5173break.invoke(m2781const, byteBuffer, Integer.valueOf(cVar3.f43626if), null, Integer.valueOf(cVar3.f43625for), Integer.valueOf(cVar3.f43627new ? 1 : 0))).booleanValue();
                } catch (IllegalAccessException | InvocationTargetException unused2) {
                    z = false;
                }
                if (!z) {
                    m2786goto(m2781const);
                    return null;
                }
                z2 = true;
            }
            i2++;
            z2 = z2;
        }
        if (!z2) {
            m2786goto(m2781const);
            return null;
        }
        if (m2783catch(m2781const) && (mo2782break = mo2782break(m2781const)) != null) {
            return Typeface.create(mo2782break, i);
        }
        return null;
    }

    @Override // defpackage.gd
    /* renamed from: new, reason: not valid java name */
    public Typeface mo2787new(Context context, Resources resources, int i, String str, int i2) {
        if (!m2784class()) {
            return super.mo2787new(context, resources, i, str, i2);
        }
        Object m2781const = m2781const();
        if (m2781const == null) {
            return null;
        }
        if (!m2789this(context, m2781const, str, 0, -1, -1, null)) {
            m2786goto(m2781const);
            return null;
        }
        if (m2783catch(m2781const)) {
            return mo2782break(m2781const);
        }
        return null;
    }

    /* renamed from: super, reason: not valid java name */
    public Method m2788super(Class<?> cls) throws NoSuchMethodException {
        Class<?> cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromBuffer", ByteBuffer.class, cls2, FontVariationAxis[].class, cls2, cls2);
    }

    /* renamed from: this, reason: not valid java name */
    public final boolean m2789this(Context context, Object obj, String str, int i, int i2, int i3, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f5179this.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    /* renamed from: throw, reason: not valid java name */
    public Method mo2790throw(Class<?> cls) throws NoSuchMethodException {
        Class cls2 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass(), cls2, cls2);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
