package defpackage;

import android.database.Cursor;
import defpackage.f59;

/* loaded from: classes2.dex */
public class xd9 extends td9<f59> {
    @Override // defpackage.ue9
    /* renamed from: do */
    public Object mo58do(Cursor cursor) {
        Cursor cursor2 = cursor;
        int m14878if = m14878if(cursor2, "_id");
        int m14878if2 = m14878if(cursor2, "operation");
        int m14878if3 = m14878if(cursor2, "playlist_id");
        int m14878if4 = m14878if(cursor2, "position");
        int m14878if5 = m14878if(cursor2, "track_id");
        int m14878if6 = m14878if(cursor2, "album_id");
        return new f59(String.valueOf(cursor2.getLong(m14878if)), cursor2.getLong(m14878if3), f59.a.byCode(cursor2.getInt(m14878if2)), cursor2.getInt(m14878if4), cursor2.getString(m14878if5), cursor2.getString(m14878if6));
    }
}
