package defpackage;

/* loaded from: classes2.dex */
public class p7c implements x7c<Object> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ s7c f28574catch;

    public p7c(q7c q7cVar, s7c s7cVar) {
        this.f28574catch = s7cVar;
    }

    @Override // defpackage.x7c
    /* renamed from: do */
    public void mo1867do(Throwable th) {
        this.f28574catch.mo369do(th);
    }

    @Override // defpackage.x7c
    public void onSuccess(Object obj) {
        this.f28574catch.mo370if();
    }
}
