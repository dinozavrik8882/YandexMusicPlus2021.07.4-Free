package defpackage;

import defpackage.z82;

/* loaded from: classes.dex */
public final class f62 extends z82<f62, a> implements la2 {
    private static volatile sa2<f62> zzafw;
    private static final f62 zzbgy;
    private int zzafi;
    private int zzbgv;
    private int zzbgw;
    private int zzbgx;

    /* loaded from: classes.dex */
    public static final class a extends z82.a<f62, a> implements la2 {
        public a(r72 r72Var) {
            super(f62.zzbgy);
        }
    }

    static {
        f62 f62Var = new f62();
        zzbgy = f62Var;
        z82.m17881catch(f62.class, f62Var);
    }

    /* JADX WARN: Type inference failed for: r2v13, types: [z82$c, sa2<f62>] */
    @Override // defpackage.z82
    /* renamed from: this */
    public final Object mo270this(z82.d dVar, Object obj, Object obj2) {
        sa2<f62> sa2Var;
        switch (r72.f31978do[dVar.ordinal()]) {
            case 1:
                return new f62();
            case 2:
                return new a(null);
            case 3:
                return new za2(zzbgy, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0004\u0000\u0002\u0004\u0001\u0003\u0004\u0002", new Object[]{"zzafi", "zzbgv", "zzbgw", "zzbgx"});
            case 4:
                return zzbgy;
            case 5:
                sa2<f62> sa2Var2 = zzafw;
                sa2<f62> sa2Var3 = sa2Var2;
                if (sa2Var2 == null) {
                    synchronized (f62.class) {
                        sa2<f62> sa2Var4 = zzafw;
                        sa2Var = sa2Var4;
                        if (sa2Var4 == null) {
                            ?? cVar = new z82.c(zzbgy);
                            zzafw = cVar;
                            sa2Var = cVar;
                        }
                    }
                    sa2Var3 = sa2Var;
                }
                return sa2Var3;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
