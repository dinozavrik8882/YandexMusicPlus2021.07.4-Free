package defpackage;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import com.google.android.exoplayer2.util.Util;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes.dex */
public class ua1 {

    /* renamed from: case, reason: not valid java name */
    public c f38626case;

    /* renamed from: do, reason: not valid java name */
    public final HashMap<String, ta1> f38627do;

    /* renamed from: for, reason: not valid java name */
    public final SparseBooleanArray f38628for;

    /* renamed from: if, reason: not valid java name */
    public final SparseArray<String> f38629if;

    /* renamed from: new, reason: not valid java name */
    public final SparseBooleanArray f38630new;

    /* renamed from: try, reason: not valid java name */
    public c f38631try;

    /* loaded from: classes.dex */
    public static final class a implements c {

        /* renamed from: do, reason: not valid java name */
        public static final String[] f38632do = {DatabaseHelper.OttTrackingTable.COLUMN_ID, "key", "metadata"};

        /* renamed from: for, reason: not valid java name */
        public final SparseArray<ta1> f38633for = new SparseArray<>();

        /* renamed from: if, reason: not valid java name */
        public final oq0 f38634if;

        /* renamed from: new, reason: not valid java name */
        public String f38635new;

        /* renamed from: try, reason: not valid java name */
        public String f38636try;

        public a(oq0 oq0Var) {
            this.f38634if = oq0Var;
        }

        /* renamed from: break, reason: not valid java name */
        public final void m15443break(SQLiteDatabase sQLiteDatabase) throws nq0 {
            String str = this.f38635new;
            Objects.requireNonNull(str);
            cd0.d(sQLiteDatabase, 1, str, 1);
            String str2 = this.f38636try;
            Objects.requireNonNull(str2);
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS " + str2);
            sQLiteDatabase.execSQL("CREATE TABLE " + this.f38636try + " (id INTEGER PRIMARY KEY NOT NULL,key TEXT NOT NULL,metadata BLOB NOT NULL)");
        }

        @Override // ua1.c
        /* renamed from: case, reason: not valid java name */
        public void mo15444case(long j) {
            String hexString = Long.toHexString(j);
            this.f38635new = hexString;
            this.f38636try = by.m2405strictfp("ExoPlayerCacheIndex", hexString);
        }

        @Override // ua1.c
        /* renamed from: do, reason: not valid java name */
        public void mo15445do(ta1 ta1Var, boolean z) {
            if (z) {
                this.f38633for.delete(ta1Var.f36863do);
            } else {
                this.f38633for.put(ta1Var.f36863do, null);
            }
        }

        @Override // ua1.c
        /* renamed from: else, reason: not valid java name */
        public void mo15446else(HashMap<String, ta1> hashMap, SparseArray<String> sparseArray) throws IOException {
            h81.m7061else(this.f38633for.size() == 0);
            try {
                SQLiteDatabase readableDatabase = this.f38634if.getReadableDatabase();
                String str = this.f38635new;
                Objects.requireNonNull(str);
                if (cd0.m2816public(readableDatabase, 1, str) != 1) {
                    SQLiteDatabase writableDatabase = this.f38634if.getWritableDatabase();
                    writableDatabase.beginTransactionNonExclusive();
                    try {
                        m15443break(writableDatabase);
                        writableDatabase.setTransactionSuccessful();
                        writableDatabase.endTransaction();
                    } catch (Throwable th) {
                        writableDatabase.endTransaction();
                        throw th;
                    }
                }
                SQLiteDatabase readableDatabase2 = this.f38634if.getReadableDatabase();
                String str2 = this.f38636try;
                Objects.requireNonNull(str2);
                Cursor query = readableDatabase2.query(str2, f38632do, null, null, null, null, null);
                while (query.moveToNext()) {
                    try {
                        int i = query.getInt(0);
                        String string = query.getString(1);
                        hashMap.put(string, new ta1(i, string, ua1.m15436do(new DataInputStream(new ByteArrayInputStream(query.getBlob(2))))));
                        sparseArray.put(i, string);
                    } finally {
                    }
                }
                query.close();
            } catch (SQLiteException e) {
                hashMap.clear();
                sparseArray.clear();
                throw new nq0(e);
            }
        }

        @Override // ua1.c
        /* renamed from: for, reason: not valid java name */
        public void mo15447for(ta1 ta1Var) {
            this.f38633for.put(ta1Var.f36863do, ta1Var);
        }

        @Override // ua1.c
        /* renamed from: goto, reason: not valid java name */
        public void mo15448goto() throws nq0 {
            oq0 oq0Var = this.f38634if;
            String str = this.f38635new;
            Objects.requireNonNull(str);
            try {
                String str2 = "ExoPlayerCacheIndex" + str;
                SQLiteDatabase writableDatabase = oq0Var.getWritableDatabase();
                writableDatabase.beginTransactionNonExclusive();
                try {
                    try {
                        if (Util.tableExists(writableDatabase, "ExoPlayerVersions")) {
                            writableDatabase.delete("ExoPlayerVersions", "feature = ? AND instance_uid = ?", new String[]{Integer.toString(1), str});
                        }
                        writableDatabase.execSQL("DROP TABLE IF EXISTS " + str2);
                        writableDatabase.setTransactionSuccessful();
                    } catch (SQLException e) {
                        throw new nq0(e);
                    }
                } finally {
                    writableDatabase.endTransaction();
                }
            } catch (SQLException e2) {
                throw new nq0(e2);
            }
        }

        @Override // ua1.c
        /* renamed from: if, reason: not valid java name */
        public void mo15449if(HashMap<String, ta1> hashMap) throws IOException {
            try {
                SQLiteDatabase writableDatabase = this.f38634if.getWritableDatabase();
                writableDatabase.beginTransactionNonExclusive();
                try {
                    m15443break(writableDatabase);
                    Iterator<ta1> it = hashMap.values().iterator();
                    while (it.hasNext()) {
                        m15451this(writableDatabase, it.next());
                    }
                    writableDatabase.setTransactionSuccessful();
                    this.f38633for.clear();
                } finally {
                    writableDatabase.endTransaction();
                }
            } catch (SQLException e) {
                throw new nq0(e);
            }
        }

        @Override // ua1.c
        /* renamed from: new, reason: not valid java name */
        public boolean mo15450new() throws nq0 {
            SQLiteDatabase readableDatabase = this.f38634if.getReadableDatabase();
            String str = this.f38635new;
            Objects.requireNonNull(str);
            return cd0.m2816public(readableDatabase, 1, str) != -1;
        }

        /* renamed from: this, reason: not valid java name */
        public final void m15451this(SQLiteDatabase sQLiteDatabase, ta1 ta1Var) throws IOException {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ua1.m15437if(ta1Var.f36867try, new DataOutputStream(byteArrayOutputStream));
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseHelper.OttTrackingTable.COLUMN_ID, Integer.valueOf(ta1Var.f36863do));
            contentValues.put("key", ta1Var.f36865if);
            contentValues.put("metadata", byteArray);
            String str = this.f38636try;
            Objects.requireNonNull(str);
            sQLiteDatabase.replaceOrThrow(str, null, contentValues);
        }

        @Override // ua1.c
        /* renamed from: try, reason: not valid java name */
        public void mo15452try(HashMap<String, ta1> hashMap) throws IOException {
            if (this.f38633for.size() == 0) {
                return;
            }
            try {
                SQLiteDatabase writableDatabase = this.f38634if.getWritableDatabase();
                writableDatabase.beginTransactionNonExclusive();
                for (int i = 0; i < this.f38633for.size(); i++) {
                    try {
                        ta1 valueAt = this.f38633for.valueAt(i);
                        if (valueAt == null) {
                            int keyAt = this.f38633for.keyAt(i);
                            String str = this.f38636try;
                            Objects.requireNonNull(str);
                            writableDatabase.delete(str, "id = ?", new String[]{Integer.toString(keyAt)});
                        } else {
                            m15451this(writableDatabase, valueAt);
                        }
                    } catch (Throwable th) {
                        writableDatabase.endTransaction();
                        throw th;
                    }
                }
                writableDatabase.setTransactionSuccessful();
                this.f38633for.clear();
                writableDatabase.endTransaction();
            } catch (SQLException e) {
                throw new nq0(e);
            }
        }
    }

    /* loaded from: classes.dex */
    public static class b implements c {

        /* renamed from: case, reason: not valid java name */
        public boolean f38637case;

        /* renamed from: do, reason: not valid java name */
        public final boolean f38638do;

        /* renamed from: else, reason: not valid java name */
        public zb1 f38639else;

        /* renamed from: for, reason: not valid java name */
        public final SecretKeySpec f38640for;

        /* renamed from: if, reason: not valid java name */
        public final Cipher f38641if;

        /* renamed from: new, reason: not valid java name */
        public final SecureRandom f38642new;

        /* renamed from: try, reason: not valid java name */
        public final gb1 f38643try;

        public b(File file, byte[] bArr, boolean z) {
            Cipher cipher;
            SecretKeySpec secretKeySpec;
            h81.m7061else((bArr == null && z) ? false : true);
            if (bArr != null) {
                h81.m7064for(bArr.length == 16);
                try {
                    if (Util.SDK_INT == 18) {
                        try {
                            cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING", "BC");
                        } catch (Throwable unused) {
                        }
                        secretKeySpec = new SecretKeySpec(bArr, "AES");
                    }
                    cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
                    secretKeySpec = new SecretKeySpec(bArr, "AES");
                } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
                    throw new IllegalStateException(e);
                }
            } else {
                h81.m7064for(!z);
                cipher = null;
                secretKeySpec = null;
            }
            this.f38638do = z;
            this.f38641if = cipher;
            this.f38640for = secretKeySpec;
            this.f38642new = z ? new SecureRandom() : null;
            this.f38643try = new gb1(file);
        }

        /* renamed from: break, reason: not valid java name */
        public final ta1 m15453break(int i, DataInputStream dataInputStream) throws IOException {
            xa1 m15436do;
            int readInt = dataInputStream.readInt();
            String readUTF = dataInputStream.readUTF();
            if (i < 2) {
                long readLong = dataInputStream.readLong();
                wa1 wa1Var = new wa1();
                wa1.m16472do(wa1Var, readLong);
                m15436do = xa1.f43474do.m17012if(wa1Var);
            } else {
                m15436do = ua1.m15436do(dataInputStream);
            }
            return new ta1(readInt, readUTF, m15436do);
        }

        @Override // ua1.c
        /* renamed from: case */
        public void mo15444case(long j) {
        }

        @Override // ua1.c
        /* renamed from: do */
        public void mo15445do(ta1 ta1Var, boolean z) {
            this.f38637case = true;
        }

        /* JADX WARN: Removed duplicated region for block: B:57:0x00c0  */
        /* JADX WARN: Removed duplicated region for block: B:59:? A[RETURN, SYNTHETIC] */
        @Override // ua1.c
        /* renamed from: else */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void mo15446else(java.util.HashMap<java.lang.String, defpackage.ta1> r11, android.util.SparseArray<java.lang.String> r12) {
            /*
                Method dump skipped, instructions count: 211
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: ua1.b.mo15446else(java.util.HashMap, android.util.SparseArray):void");
        }

        @Override // ua1.c
        /* renamed from: for */
        public void mo15447for(ta1 ta1Var) {
            this.f38637case = true;
        }

        @Override // ua1.c
        /* renamed from: goto */
        public void mo15448goto() {
            gb1 gb1Var = this.f38643try;
            gb1Var.f13370do.delete();
            gb1Var.f13371if.delete();
        }

        @Override // ua1.c
        /* renamed from: if */
        public void mo15449if(HashMap<String, ta1> hashMap) throws IOException {
            DataOutputStream dataOutputStream = null;
            try {
                OutputStream m6550for = this.f38643try.m6550for();
                zb1 zb1Var = this.f38639else;
                if (zb1Var == null) {
                    this.f38639else = new zb1(m6550for);
                } else {
                    zb1Var.m17926do(m6550for);
                }
                zb1 zb1Var2 = this.f38639else;
                DataOutputStream dataOutputStream2 = new DataOutputStream(zb1Var2);
                try {
                    dataOutputStream2.writeInt(2);
                    dataOutputStream2.writeInt(this.f38638do ? 1 : 0);
                    if (this.f38638do) {
                        byte[] bArr = new byte[16];
                        ((SecureRandom) Util.castNonNull(this.f38642new)).nextBytes(bArr);
                        dataOutputStream2.write(bArr);
                        try {
                            ((Cipher) Util.castNonNull(this.f38641if)).init(1, (Key) Util.castNonNull(this.f38640for), new IvParameterSpec(bArr));
                            dataOutputStream2.flush();
                            dataOutputStream2 = new DataOutputStream(new CipherOutputStream(zb1Var2, this.f38641if));
                        } catch (InvalidAlgorithmParameterException e) {
                            e = e;
                            throw new IllegalStateException(e);
                        } catch (InvalidKeyException e2) {
                            e = e2;
                            throw new IllegalStateException(e);
                        }
                    }
                    dataOutputStream2.writeInt(hashMap.size());
                    int i = 0;
                    for (ta1 ta1Var : hashMap.values()) {
                        dataOutputStream2.writeInt(ta1Var.f36863do);
                        dataOutputStream2.writeUTF(ta1Var.f36865if);
                        ua1.m15437if(ta1Var.f36867try, dataOutputStream2);
                        i += m15454this(ta1Var, 2);
                    }
                    dataOutputStream2.writeInt(i);
                    gb1 gb1Var = this.f38643try;
                    Objects.requireNonNull(gb1Var);
                    dataOutputStream2.close();
                    gb1Var.f13371if.delete();
                    Util.closeQuietly((Closeable) null);
                    this.f38637case = false;
                } catch (Throwable th) {
                    th = th;
                    dataOutputStream = dataOutputStream2;
                    Util.closeQuietly(dataOutputStream);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @Override // ua1.c
        /* renamed from: new */
        public boolean mo15450new() {
            return this.f38643try.m6549do();
        }

        /* renamed from: this, reason: not valid java name */
        public final int m15454this(ta1 ta1Var, int i) {
            int i2;
            int hashCode;
            int hashCode2 = ta1Var.f36865if.hashCode() + (ta1Var.f36863do * 31);
            if (i < 2) {
                long m15999do = va1.m15999do(ta1Var.f36867try);
                i2 = hashCode2 * 31;
                hashCode = (int) (m15999do ^ (m15999do >>> 32));
            } else {
                i2 = hashCode2 * 31;
                hashCode = ta1Var.f36867try.hashCode();
            }
            return i2 + hashCode;
        }

        @Override // ua1.c
        /* renamed from: try */
        public void mo15452try(HashMap<String, ta1> hashMap) throws IOException {
            if (this.f38637case) {
                mo15449if(hashMap);
            }
        }
    }

    /* loaded from: classes.dex */
    public interface c {
        /* renamed from: case */
        void mo15444case(long j);

        /* renamed from: do */
        void mo15445do(ta1 ta1Var, boolean z);

        /* renamed from: else */
        void mo15446else(HashMap<String, ta1> hashMap, SparseArray<String> sparseArray) throws IOException;

        /* renamed from: for */
        void mo15447for(ta1 ta1Var);

        /* renamed from: goto */
        void mo15448goto() throws IOException;

        /* renamed from: if */
        void mo15449if(HashMap<String, ta1> hashMap) throws IOException;

        /* renamed from: new */
        boolean mo15450new() throws IOException;

        /* renamed from: try */
        void mo15452try(HashMap<String, ta1> hashMap) throws IOException;
    }

    public ua1(oq0 oq0Var, File file, byte[] bArr, boolean z, boolean z2) {
        h81.m7061else((oq0Var == null && file == null) ? false : true);
        this.f38627do = new HashMap<>();
        this.f38629if = new SparseArray<>();
        this.f38628for = new SparseBooleanArray();
        this.f38630new = new SparseBooleanArray();
        a aVar = oq0Var != null ? new a(oq0Var) : null;
        b bVar = file != null ? new b(new File(file, "cached_content_index.exi"), bArr, z) : null;
        if (aVar == null || (bVar != null && z2)) {
            this.f38631try = (c) Util.castNonNull(bVar);
            this.f38626case = aVar;
        } else {
            this.f38631try = aVar;
            this.f38626case = bVar;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public static xa1 m15436do(DataInputStream dataInputStream) throws IOException {
        int readInt = dataInputStream.readInt();
        HashMap hashMap = new HashMap();
        for (int i = 0; i < readInt; i++) {
            String readUTF = dataInputStream.readUTF();
            int readInt2 = dataInputStream.readInt();
            if (readInt2 < 0) {
                throw new IOException(by.m2404static("Invalid value size: ", readInt2));
            }
            int min = Math.min(readInt2, 10485760);
            byte[] bArr = Util.EMPTY_BYTE_ARRAY;
            int i2 = 0;
            while (i2 != readInt2) {
                int i3 = i2 + min;
                bArr = Arrays.copyOf(bArr, i3);
                dataInputStream.readFully(bArr, i2, min);
                min = Math.min(readInt2 - i3, 10485760);
                i2 = i3;
            }
            hashMap.put(readUTF, bArr);
        }
        return new xa1(hashMap);
    }

    /* renamed from: if, reason: not valid java name */
    public static void m15437if(xa1 xa1Var, DataOutputStream dataOutputStream) throws IOException {
        Set<Map.Entry<String, byte[]>> entrySet = xa1Var.f43475for.entrySet();
        dataOutputStream.writeInt(entrySet.size());
        for (Map.Entry<String, byte[]> entry : entrySet) {
            dataOutputStream.writeUTF(entry.getKey());
            byte[] value = entry.getValue();
            dataOutputStream.writeInt(value.length);
            dataOutputStream.write(value);
        }
    }

    /* renamed from: case, reason: not valid java name */
    public void m15438case(String str) {
        ta1 ta1Var = this.f38627do.get(str);
        if (ta1Var != null && ta1Var.f36864for.isEmpty() && ta1Var.f36866new.isEmpty()) {
            this.f38627do.remove(str);
            int i = ta1Var.f36863do;
            boolean z = this.f38630new.get(i);
            this.f38631try.mo15445do(ta1Var, z);
            if (z) {
                this.f38629if.remove(i);
                this.f38630new.delete(i);
            } else {
                this.f38629if.put(i, null);
                this.f38628for.put(i, true);
            }
        }
    }

    /* renamed from: else, reason: not valid java name */
    public void m15439else() throws IOException {
        this.f38631try.mo15452try(this.f38627do);
        int size = this.f38628for.size();
        for (int i = 0; i < size; i++) {
            this.f38629if.remove(this.f38628for.keyAt(i));
        }
        this.f38628for.clear();
        this.f38630new.clear();
    }

    /* renamed from: for, reason: not valid java name */
    public ta1 m15440for(String str) {
        return this.f38627do.get(str);
    }

    /* renamed from: new, reason: not valid java name */
    public ta1 m15441new(String str) {
        ta1 ta1Var = this.f38627do.get(str);
        if (ta1Var != null) {
            return ta1Var;
        }
        SparseArray<String> sparseArray = this.f38629if;
        int size = sparseArray.size();
        int i = 0;
        int keyAt = size == 0 ? 0 : sparseArray.keyAt(size - 1) + 1;
        if (keyAt < 0) {
            while (i < size && i == sparseArray.keyAt(i)) {
                i++;
            }
            keyAt = i;
        }
        ta1 ta1Var2 = new ta1(keyAt, str, xa1.f43474do);
        this.f38627do.put(str, ta1Var2);
        this.f38629if.put(keyAt, str);
        this.f38630new.put(keyAt, true);
        this.f38631try.mo15447for(ta1Var2);
        return ta1Var2;
    }

    /* renamed from: try, reason: not valid java name */
    public void m15442try(long j) throws IOException {
        c cVar;
        this.f38631try.mo15444case(j);
        c cVar2 = this.f38626case;
        if (cVar2 != null) {
            cVar2.mo15444case(j);
        }
        if (this.f38631try.mo15450new() || (cVar = this.f38626case) == null || !cVar.mo15450new()) {
            this.f38631try.mo15446else(this.f38627do, this.f38629if);
        } else {
            this.f38626case.mo15446else(this.f38627do, this.f38629if);
            this.f38631try.mo15449if(this.f38627do);
        }
        c cVar3 = this.f38626case;
        if (cVar3 != null) {
            cVar3.mo15448goto();
            this.f38626case = null;
        }
    }
}
