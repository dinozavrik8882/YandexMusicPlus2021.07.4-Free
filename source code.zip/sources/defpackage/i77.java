package defpackage;

import android.content.Context;
import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.ui.view.EllipsizingTextView;

/* loaded from: classes2.dex */
public final class i77 extends ms7<String> {

    /* renamed from: const, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f16419const;

    /* renamed from: final, reason: not valid java name */
    public final ey3 f16420final;

    /* renamed from: super, reason: not valid java name */
    public final ey3 f16421super;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<mr5<?>, EllipsizingTextView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f16422catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(View view, int i) {
            super(1);
            this.f16422catch = view;
        }

        @Override // defpackage.mo5
        public EllipsizingTextView invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f16422catch.findViewById(R.id.catalog_description);
                if (findViewById != null) {
                    return (EllipsizingTextView) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type ru.yandex.music.ui.view.EllipsizingTextView");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements mo5<mr5<?>, FrameLayout> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f16423catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(View view, int i) {
            super(1);
            this.f16423catch = view;
        }

        @Override // defpackage.mo5
        public FrameLayout invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f16423catch.findViewById(R.id.catalog_description_container);
                if (findViewById != null) {
                    return (FrameLayout) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.FrameLayout");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(i77.class), "description", "getDescription()Lru/yandex/music/ui/view/EllipsizingTextView;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(i77.class), "container", "getContainer()Landroid/widget/FrameLayout;");
        Objects.requireNonNull(eq5Var);
        f16419const = new mr5[]{wp5Var, wp5Var2};
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i77(ViewGroup viewGroup, final bo5<pl5> bo5Var) {
        super(viewGroup, R.layout.item_juicy_description_menu);
        jp5.m8570try(viewGroup, "parent");
        jp5.m8570try(bo5Var, "onClick");
        View view = this.itemView;
        jp5.m8568new(view, "itemView");
        ey3 ey3Var = new ey3(new a(view, R.id.catalog_description));
        this.f16420final = ey3Var;
        View view2 = this.itemView;
        jp5.m8568new(view2, "itemView");
        ey3 ey3Var2 = new ey3(new b(view2, R.id.catalog_description_container));
        this.f16421super = ey3Var2;
        mr5<Object>[] mr5VarArr = f16419const;
        ((FrameLayout) ey3Var2.m5520do(mr5VarArr[1])).setOnClickListener(new View.OnClickListener() { // from class: d77
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                bo5 bo5Var2 = bo5.this;
                jp5.m8570try(bo5Var2, "$onClick");
                bo5Var2.invoke();
            }
        });
        EllipsizingTextView ellipsizingTextView = (EllipsizingTextView) ey3Var.m5520do(mr5VarArr[0]);
        Context context = this.f41116catch;
        jp5.m8568new(context, "mContext");
        jp5.m8570try(context, "context");
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        spannableStringBuilder.append((CharSequence) "... ");
        ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(t2.m14594continue(context, android.R.attr.textColorLink));
        int length = spannableStringBuilder.length();
        spannableStringBuilder.append(context.getText(R.string.expand_more));
        spannableStringBuilder.setSpan(foregroundColorSpan, length, spannableStringBuilder.length(), 17);
        ellipsizingTextView.setEllipsisText(new SpannedString(spannableStringBuilder));
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.ms7
    /* renamed from: break, reason: not valid java name and merged with bridge method [inline-methods] */
    public void mo381goto(String str) {
        jp5.m8570try(str, "item");
        e8d.m5044case(str);
        this.f24507class = str;
        ((EllipsizingTextView) this.f16420final.m5520do(f16419const[0])).setText(str);
    }
}
