package defpackage;

@ln5(c = "com.yandex.music.core.async.rx.RxKt$asFlow$1", f = "rx.kt", l = {202}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class i1d extends pn5 implements qo5<qx5<? super qb8>, wm5<? super pl5>, Object> {

    /* renamed from: super, reason: not valid java name */
    public int f16045super;

    /* renamed from: throw, reason: not valid java name */
    public /* synthetic */ Object f16046throw;

    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ spe f16047while;

    /* loaded from: classes2.dex */
    public static final class a<T> implements tqe {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ qx5<T> f16048catch;

        public a(qx5 qx5Var) {
            this.f16048catch = qx5Var;
        }

        @Override // defpackage.tqe
        public final void call(T t) {
            try {
                dn3.C3(this.f16048catch, t);
            } catch (InterruptedException unused) {
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class b<T> implements tqe {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ qx5<T> f16049catch;

        public b(qx5 qx5Var) {
            this.f16049catch = qx5Var;
        }

        @Override // defpackage.tqe
        public void call(Object obj) {
            this.f16049catch.mo5499class((Throwable) obj);
        }
    }

    /* loaded from: classes2.dex */
    public static final class c implements sqe {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ qx5<qb8> f16050catch;

        public c(qx5 qx5Var) {
            this.f16050catch = qx5Var;
        }

        @Override // defpackage.sqe
        public final void call() {
            dn3.r(this.f16050catch, null, 1, null);
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends kp5 implements bo5<pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ fqe f16051catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(fqe fqeVar) {
            super(0);
            this.f16051catch = fqeVar;
        }

        @Override // defpackage.bo5
        public pl5 invoke() {
            this.f16051catch.unsubscribe();
            return pl5.f29126do;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i1d(spe speVar, wm5 wm5Var) {
        super(2, wm5Var);
        this.f16047while = speVar;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        i1d i1dVar = new i1d(this.f16047while, wm5Var);
        i1dVar.f16046throw = obj;
        return i1dVar;
    }

    @Override // defpackage.qo5
    public Object invoke(qx5<? super qb8> qx5Var, wm5<? super pl5> wm5Var) {
        i1d i1dVar = new i1d(this.f16047while, wm5Var);
        i1dVar.f16046throw = qx5Var;
        return i1dVar.mo76return(pl5.f29126do);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        int i = this.f16045super;
        if (i == 0) {
            dn3.N2(obj);
            qx5 qx5Var = (qx5) this.f16046throw;
            fqe i2 = this.f16047while.i(new a(qx5Var), new b(qx5Var), new c(qx5Var));
            jp5.m8568new(i2, "subscribe(\n        {\n            /*\n             * Channel was closed by the downstream, so the exception (if any)\n             * also was handled by the same downstream\n             */\n            try {\n                trySendBlocking(it)\n            } catch (e: InterruptedException) {\n                // RxJava interrupts the source\n            }\n        },\n        { close(it) },\n        { close() }\n    )");
            d dVar = new d(i2);
            this.f16045super = 1;
            if (ox5.m11782do(qx5Var, dVar, this) == cn5Var) {
                return cn5Var;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            dn3.N2(obj);
        }
        return pl5.f29126do;
    }
}
