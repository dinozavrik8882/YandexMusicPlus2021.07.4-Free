package defpackage;

/* loaded from: classes.dex */
public final class hi3 implements fi3 {
    /* JADX WARN: Removed duplicated region for block: B:14:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:273:0x0457  */
    @Override // defpackage.fi3
    /* renamed from: do */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public defpackage.qi3 mo2102do(java.lang.String r19, defpackage.zh3 r20, int r21, int r22, java.util.Map<defpackage.bi3, ?> r23) {
        /*
            Method dump skipped, instructions count: 1127
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.hi3.mo2102do(java.lang.String, zh3, int, int, java.util.Map):qi3");
    }
}
