package defpackage;

/* loaded from: classes2.dex */
public final class iqc extends vpc {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public iqc(mpc mpcVar, String str, Throwable th) {
        super(mpcVar, str, th);
        jp5.m8570try(mpcVar, "errorStep");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ iqc(mpc mpcVar, String str, Throwable th, int i) {
        this(mpcVar, (i & 2) != 0 ? null : str, null);
        int i2 = i & 4;
    }
}
