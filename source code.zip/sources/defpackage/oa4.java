package defpackage;

@ln5(c = "com.yandex.music.model.playback.progress.PlaybackProgressLocalStore$loadAll$$inlined$onDb$1", f = "PlaybackProgressLocalStore.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
public final class oa4 extends pn5 implements qo5<gu5, wm5<? super xx3<? extends na4>>, Object> {

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ va4 f26892super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ String f26893throw;

    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ xv4 f26894while;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public oa4(wm5 wm5Var, va4 va4Var, String str, xv4 xv4Var) {
        super(2, wm5Var);
        this.f26892super = va4Var;
        this.f26893throw = str;
        this.f26894while = xv4Var;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        return new oa4(wm5Var, this.f26892super, this.f26893throw, this.f26894while);
    }

    @Override // defpackage.qo5
    public Object invoke(gu5 gu5Var, wm5<? super xx3<? extends na4>> wm5Var) {
        wm5<? super xx3<? extends na4>> wm5Var2 = wm5Var;
        va4 va4Var = this.f26892super;
        String str = this.f26893throw;
        xv4 xv4Var = this.f26894while;
        if (wm5Var2 != null) {
            wm5Var2.getContext();
        }
        pl5 pl5Var = pl5.f29126do;
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(pl5Var);
        return pt3.m12293do(pt3.m12295if(va4Var.f40333if.m11247if(str).m18264for(pa4.f28710catch), wa4.f41921case), xv4Var, qa4.f30381catch);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(obj);
        return pt3.m12293do(pt3.m12295if(this.f26892super.f40333if.m11247if(this.f26893throw).m18264for(pa4.f28710catch), wa4.f41921case), this.f26894while, qa4.f30381catch);
    }
}
