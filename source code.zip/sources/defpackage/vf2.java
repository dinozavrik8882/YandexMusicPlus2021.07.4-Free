package defpackage;

import java.util.Map;

/* loaded from: classes.dex */
public interface vf2 {
    /* renamed from: do, reason: not valid java name */
    Map<?, ?> mo16069do(Object obj);

    /* renamed from: for, reason: not valid java name */
    Object mo16070for(Object obj);

    /* renamed from: if, reason: not valid java name */
    tf2<?, ?> mo16071if(Object obj);

    /* renamed from: new, reason: not valid java name */
    int mo16072new(int i, Object obj, Object obj2);

    /* renamed from: try, reason: not valid java name */
    Object mo16073try(Object obj, Object obj2);
}
