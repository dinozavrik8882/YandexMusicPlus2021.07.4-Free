package defpackage;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import java.util.Objects;
import ru.yandex.music.ui.widget.WidgetProvider;
import ru.yandex.music.widget.WidgetClickListener;

/* loaded from: classes2.dex */
public final /* synthetic */ class yed extends ip5 implements bo5<pl5> {
    public yed(afd afdVar) {
        super(0, afdVar, afd.class, "acceptClick", "acceptClick()V", 0);
    }

    @Override // defpackage.bo5
    public pl5 invoke() {
        afd afdVar = (afd) this.receiver;
        AppWidgetManager appWidgetManager = (AppWidgetManager) afdVar.f790new.getValue();
        if (appWidgetManager != null) {
            WidgetClickListener.a aVar = WidgetClickListener.f33921do;
            Context context = afdVar.f789for;
            Objects.requireNonNull(aVar);
            jp5.m8570try(context, "context");
            PendingIntent m13798if = aVar.m13798if(context, "user.action.widget.install.callback");
            ComponentName componentName = new ComponentName(afdVar.f789for, (Class<?>) WidgetProvider.class);
            if (Build.VERSION.SDK_INT >= 26) {
                appWidgetManager.requestPinAppWidget(componentName, null, m13798if);
            } else {
                jr3.m8593do("WidgetPromo: SDK version");
            }
        }
        return pl5.f29126do;
    }
}
