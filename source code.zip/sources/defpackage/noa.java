package defpackage;

import com.yandex.auth.sync.AccountProvider;
import com.yandex.metrica.rtm.Constants;

/* loaded from: classes2.dex */
public final class noa extends aqa {

    @qd3(Constants.KEY_DATA)
    private final wp7 data;

    @qd3(AccountProvider.TYPE)
    private final String type;

    /* renamed from: do, reason: not valid java name */
    public final wp7 m11106do() {
        return this.data;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof noa)) {
            return false;
        }
        noa noaVar = (noa) obj;
        return jp5.m8563do(this.type, noaVar.type) && jp5.m8563do(this.data, noaVar.data);
    }

    public int hashCode() {
        String str = this.type;
        int hashCode = (str == null ? 0 : str.hashCode()) * 31;
        wp7 wp7Var = this.data;
        return hashCode + (wp7Var != null ? wp7Var.hashCode() : 0);
    }

    public String toString() {
        StringBuilder r = by.r("AlbumChartEntityDto(type=");
        r.append((Object) this.type);
        r.append(", data=");
        r.append(this.data);
        r.append(')');
        return r.toString();
    }
}
