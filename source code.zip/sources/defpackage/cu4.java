package defpackage;

/* loaded from: classes.dex */
public final class cu4 extends Exception {
}
