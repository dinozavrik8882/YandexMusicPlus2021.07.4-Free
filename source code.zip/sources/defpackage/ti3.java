package defpackage;

import java.util.Objects;

/* loaded from: classes.dex */
public final class ti3 {

    /* renamed from: do, reason: not valid java name */
    public final si3 f37284do;

    /* renamed from: if, reason: not valid java name */
    public final int[] f37285if;

    public ti3(si3 si3Var, int[] iArr) {
        if (iArr.length == 0) {
            throw new IllegalArgumentException();
        }
        this.f37284do = si3Var;
        int length = iArr.length;
        if (length <= 1 || iArr[0] != 0) {
            this.f37285if = iArr;
            return;
        }
        int i = 1;
        while (i < length && iArr[i] == 0) {
            i++;
        }
        if (i == length) {
            this.f37285if = new int[]{0};
            return;
        }
        int i2 = length - i;
        int[] iArr2 = new int[i2];
        this.f37285if = iArr2;
        System.arraycopy(iArr, i, iArr2, 0, i2);
    }

    /* renamed from: do, reason: not valid java name */
    public ti3 m14999do(ti3 ti3Var) {
        if (!this.f37284do.equals(ti3Var.f37284do)) {
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        }
        if (m15002new()) {
            return ti3Var;
        }
        if (ti3Var.m15002new()) {
            return this;
        }
        int[] iArr = this.f37285if;
        int[] iArr2 = ti3Var.f37285if;
        if (iArr.length <= iArr2.length) {
            iArr = iArr2;
            iArr2 = iArr;
        }
        int[] iArr3 = new int[iArr.length];
        int length = iArr.length - iArr2.length;
        System.arraycopy(iArr, 0, iArr3, 0, length);
        for (int i = length; i < iArr.length; i++) {
            iArr3[i] = iArr2[i - length] ^ iArr[i];
        }
        return new ti3(this.f37284do, iArr3);
    }

    /* renamed from: for, reason: not valid java name */
    public int m15000for() {
        return this.f37285if.length - 1;
    }

    /* renamed from: if, reason: not valid java name */
    public int m15001if(int i) {
        return this.f37285if[(r0.length - 1) - i];
    }

    /* renamed from: new, reason: not valid java name */
    public boolean m15002new() {
        return this.f37285if[0] == 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(m15000for() * 8);
        for (int m15000for = m15000for(); m15000for >= 0; m15000for--) {
            int m15001if = m15001if(m15000for);
            if (m15001if != 0) {
                if (m15001if < 0) {
                    sb.append(" - ");
                    m15001if = -m15001if;
                } else if (sb.length() > 0) {
                    sb.append(" + ");
                }
                if (m15000for == 0 || m15001if != 1) {
                    si3 si3Var = this.f37284do;
                    Objects.requireNonNull(si3Var);
                    if (m15001if == 0) {
                        throw new IllegalArgumentException();
                    }
                    int i = si3Var.f35463goto[m15001if];
                    if (i == 0) {
                        sb.append('1');
                    } else if (i == 1) {
                        sb.append('a');
                    } else {
                        sb.append("a^");
                        sb.append(i);
                    }
                }
                if (m15000for != 0) {
                    if (m15000for == 1) {
                        sb.append('x');
                    } else {
                        sb.append("x^");
                        sb.append(m15000for);
                    }
                }
            }
        }
        return sb.toString();
    }

    /* renamed from: try, reason: not valid java name */
    public ti3 m15003try(int i, int i2) {
        if (i < 0) {
            throw new IllegalArgumentException();
        }
        if (i2 == 0) {
            return this.f37284do.f35464this;
        }
        int length = this.f37285if.length;
        int[] iArr = new int[i + length];
        for (int i3 = 0; i3 < length; i3++) {
            iArr[i3] = this.f37284do.m14264do(this.f37285if[i3], i2);
        }
        return new ti3(this.f37284do, iArr);
    }
}
