package defpackage;

import android.content.Context;
import defpackage.g2d;

/* loaded from: classes2.dex */
public class mj7 extends w2d<lj7, String> {
    public mj7() {
        super(true, true);
    }

    @Override // defpackage.w2d
    /* renamed from: if */
    public g2d<lj7, String> mo146if(Context context, lj7 lj7Var) {
        lj7 lj7Var2 = lj7Var;
        String m15883if = lj7Var2.m15883if(1);
        return g8d.g(m15883if) ? new g2d<>(lj7Var2, g2d.a.INVALID_DATA) : new g2d<>(lj7Var2, m15883if);
    }
}
