package defpackage;

import java.util.Objects;

/* loaded from: classes.dex */
public final class cq4 {
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof cq4)) {
            return false;
        }
        Objects.requireNonNull((cq4) obj);
        return jp5.m8563do(null, null) && jp5.m8563do(null, null);
    }

    public int hashCode() {
        throw null;
    }

    public String toString() {
        return "GenerativeSettings(type=null, temperature=0, genre=null, adaptive=false, manual=false)";
    }
}
