package defpackage;

import java.lang.reflect.Method;

/* loaded from: classes2.dex */
public final class z86 {

    /* renamed from: do, reason: not valid java name */
    public final Method f46840do;

    /* renamed from: for, reason: not valid java name */
    public final Method f46841for;

    /* renamed from: if, reason: not valid java name */
    public final Method f46842if;

    public z86(Method method, Method method2, Method method3) {
        this.f46840do = method;
        this.f46842if = method2;
        this.f46841for = method3;
    }
}
