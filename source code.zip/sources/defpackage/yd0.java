package defpackage;

import java.util.HashMap;

/* loaded from: classes.dex */
public class yd0 {

    /* renamed from: do, reason: not valid java name */
    public static final HashMap<String, String> f45375do = new HashMap<>();

    /* renamed from: for, reason: not valid java name */
    public final String f45376for;

    /* renamed from: if, reason: not valid java name */
    public final l90 f45377if;

    /* renamed from: new, reason: not valid java name */
    public StringBuilder f45378new;

    public yd0(l90 l90Var, String str) {
        ge0.m6597new(str, "tag");
        this.f45377if = l90Var;
        this.f45376for = by.m2405strictfp("FacebookSDK.", str);
        this.f45378new = new StringBuilder();
    }

    /* renamed from: do, reason: not valid java name */
    public static synchronized void m17577do(String str) {
        synchronized (yd0.class) {
            b90.m1848else(l90.INCLUDE_ACCESS_TOKENS);
            synchronized (yd0.class) {
                f45375do.put(str, "ACCESS_TOKEN_REMOVED");
            }
        }
    }
}
