package defpackage;

import android.view.View;

/* loaded from: classes2.dex */
public final class w27 extends kp5 implements mo5<View, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ z27 f41550catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ l59 f41551class;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w27(z27 z27Var, l59 l59Var) {
        super(1);
        this.f41550catch = z27Var;
        this.f41551class = l59Var;
    }

    @Override // defpackage.mo5
    public pl5 invoke(View view) {
        View view2 = view;
        jp5.m8570try(view2, "it");
        ut6.m15719extends(ut6.f39508for, this.f41550catch.f46531try, tt6.ARTIST_BOTTOMSHEET, st6.LIKE, null, 8);
        this.f41550catch.mo14072for(view2, this.f41551class);
        return pl5.f29126do;
    }
}
