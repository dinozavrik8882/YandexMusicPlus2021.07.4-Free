package defpackage;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.util.Util;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public final class wz0 implements Parcelable {
    public static final Parcelable.Creator<wz0> CREATOR = new a();

    /* renamed from: catch, reason: not valid java name */
    public final String f43000catch;

    /* renamed from: class, reason: not valid java name */
    public final Uri f43001class;

    /* renamed from: const, reason: not valid java name */
    public final String f43002const;

    /* renamed from: final, reason: not valid java name */
    public final List<e01> f43003final;

    /* renamed from: super, reason: not valid java name */
    public final byte[] f43004super;

    /* renamed from: throw, reason: not valid java name */
    public final String f43005throw;

    /* renamed from: while, reason: not valid java name */
    public final byte[] f43006while;

    /* loaded from: classes.dex */
    public class a implements Parcelable.Creator<wz0> {
        @Override // android.os.Parcelable.Creator
        public wz0 createFromParcel(Parcel parcel) {
            return new wz0(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public wz0[] newArray(int i) {
            return new wz0[i];
        }
    }

    public wz0(Parcel parcel) {
        this.f43000catch = (String) Util.castNonNull(parcel.readString());
        this.f43001class = Uri.parse((String) Util.castNonNull(parcel.readString()));
        this.f43002const = parcel.readString();
        int readInt = parcel.readInt();
        ArrayList arrayList = new ArrayList(readInt);
        for (int i = 0; i < readInt; i++) {
            arrayList.add((e01) parcel.readParcelable(e01.class.getClassLoader()));
        }
        this.f43003final = Collections.unmodifiableList(arrayList);
        this.f43004super = parcel.createByteArray();
        this.f43005throw = parcel.readString();
        this.f43006while = (byte[]) Util.castNonNull(parcel.createByteArray());
    }

    public wz0(String str, Uri uri, String str2, List<e01> list, byte[] bArr, String str3, byte[] bArr2) {
        int inferContentTypeForUriAndMimeType = Util.inferContentTypeForUriAndMimeType(uri, str2);
        if (inferContentTypeForUriAndMimeType == 0 || inferContentTypeForUriAndMimeType == 2 || inferContentTypeForUriAndMimeType == 1) {
            h81.m7069new(str3 == null, "customCacheKey must be null for type: " + inferContentTypeForUriAndMimeType);
        }
        this.f43000catch = str;
        this.f43001class = uri;
        this.f43002const = str2;
        ArrayList arrayList = new ArrayList(list);
        Collections.sort(arrayList);
        this.f43003final = Collections.unmodifiableList(arrayList);
        this.f43004super = bArr != null ? Arrays.copyOf(bArr, bArr.length) : null;
        this.f43005throw = str3;
        this.f43006while = bArr2 != null ? Arrays.copyOf(bArr2, bArr2.length) : Util.EMPTY_BYTE_ARRAY;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof wz0)) {
            return false;
        }
        wz0 wz0Var = (wz0) obj;
        return this.f43000catch.equals(wz0Var.f43000catch) && this.f43001class.equals(wz0Var.f43001class) && Util.areEqual(this.f43002const, wz0Var.f43002const) && this.f43003final.equals(wz0Var.f43003final) && Arrays.equals(this.f43004super, wz0Var.f43004super) && Util.areEqual(this.f43005throw, wz0Var.f43005throw) && Arrays.equals(this.f43006while, wz0Var.f43006while);
    }

    public final int hashCode() {
        int hashCode = (this.f43001class.hashCode() + (this.f43000catch.hashCode() * 31 * 31)) * 31;
        String str = this.f43002const;
        int hashCode2 = (Arrays.hashCode(this.f43004super) + ((this.f43003final.hashCode() + ((hashCode + (str != null ? str.hashCode() : 0)) * 31)) * 31)) * 31;
        String str2 = this.f43005throw;
        return Arrays.hashCode(this.f43006while) + ((hashCode2 + (str2 != null ? str2.hashCode() : 0)) * 31);
    }

    public String toString() {
        return this.f43002const + ":" + this.f43000catch;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f43000catch);
        parcel.writeString(this.f43001class.toString());
        parcel.writeString(this.f43002const);
        parcel.writeInt(this.f43003final.size());
        for (int i2 = 0; i2 < this.f43003final.size(); i2++) {
            parcel.writeParcelable(this.f43003final.get(i2), 0);
        }
        parcel.writeByteArray(this.f43004super);
        parcel.writeString(this.f43005throw);
        parcel.writeByteArray(this.f43006while);
    }
}
