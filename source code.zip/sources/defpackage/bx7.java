package defpackage;

import android.content.Context;
import defpackage.bz3;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes2.dex */
public final class bx7 extends kp5 implements mo5<bz3.a, ax7> {

    /* renamed from: catch, reason: not valid java name */
    public static final bx7 f4469catch = new bx7();

    public bx7() {
        super(1);
    }

    @Override // defpackage.mo5
    public ax7 invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        if (vi8.f40628else.m16102do()) {
            cx7 cx7Var = cx7.f7603do;
            return new dx7((ax7) aVar2.m2427do(dn3.l3(j18.class)), (qg9) aVar2.m2427do(dn3.l3(qg9.class)));
        }
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor(new ThreadFactory() { // from class: su7
            @Override // java.util.concurrent.ThreadFactory
            public final Thread newThread(Runnable runnable) {
                bx7 bx7Var = bx7.f4469catch;
                return new Thread(runnable, "DownloadControl");
            }
        });
        Context context = (Context) aVar2.m2427do(dn3.l3(Context.class));
        qg9 qg9Var = (qg9) aVar2.m2427do(dn3.l3(qg9.class));
        p8a p8aVar = (p8a) aVar2.m2427do(dn3.l3(p8a.class));
        tx7 tx7Var = (tx7) aVar2.m2427do(dn3.l3(tx7.class));
        AtomicReference<h0f> atomicReference = h0f.f14478do;
        dw7 dw7Var = new dw7(context, qg9Var, p8aVar, tx7Var, new jwe(newSingleThreadExecutor), (wga) aVar2.m2427do(dn3.l3(wga.class)), ((oa8) aVar2.m2427do(dn3.l3(oa8.class))).mo10261catch());
        cx7 cx7Var2 = cx7.f7603do;
        return new dx7(dw7Var, (qg9) aVar2.m2427do(dn3.l3(qg9.class)));
    }
}
