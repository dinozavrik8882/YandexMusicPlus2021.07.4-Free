package defpackage;

import defpackage.jg1;

/* loaded from: classes.dex */
public final class ui1<T extends jg1> extends pj1 {

    /* renamed from: do, reason: not valid java name */
    public final lg1<T> f38916do;

    /* renamed from: if, reason: not valid java name */
    public final Class<T> f38917if;

    public ui1(lg1<T> lg1Var, Class<T> cls) {
        this.f38916do = lg1Var;
        this.f38917if = cls;
    }
}
