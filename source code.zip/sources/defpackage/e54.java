package defpackage;

/* loaded from: classes.dex */
public final class e54 {

    /* renamed from: case, reason: not valid java name */
    public final String f9504case;

    /* renamed from: do, reason: not valid java name */
    public final int f9505do;

    /* renamed from: else, reason: not valid java name */
    public final String f9506else;

    /* renamed from: for, reason: not valid java name */
    public final String f9507for;

    /* renamed from: if, reason: not valid java name */
    public final String f9508if;

    /* renamed from: new, reason: not valid java name */
    public final String f9509new;

    /* renamed from: try, reason: not valid java name */
    public final String f9510try;

    public e54(int i, String str, String str2, String str3, String str4, String str5, String str6) {
        jp5.m8570try(str, "pageRef");
        jp5.m8570try(str2, "genreId");
        jp5.m8570try(str3, "partnerId");
        jp5.m8570try(str4, "genreName");
        jp5.m8570try(str5, "targetRef");
        jp5.m8570try(str6, "categoryId");
        this.f9505do = i;
        this.f9508if = str;
        this.f9507for = str2;
        this.f9509new = str3;
        this.f9510try = str4;
        this.f9504case = str5;
        this.f9506else = str6;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e54)) {
            return false;
        }
        e54 e54Var = (e54) obj;
        return this.f9505do == e54Var.f9505do && jp5.m8563do(this.f9508if, e54Var.f9508if) && jp5.m8563do(this.f9507for, e54Var.f9507for) && jp5.m8563do(this.f9509new, e54Var.f9509new) && jp5.m8563do(this.f9510try, e54Var.f9510try) && jp5.m8563do(this.f9504case, e54Var.f9504case) && jp5.m8563do(this.f9506else, e54Var.f9506else);
    }

    public int hashCode() {
        return this.f9506else.hashCode() + by.A(this.f9504case, by.A(this.f9510try, by.A(this.f9509new, by.A(this.f9507for, by.A(this.f9508if, Integer.hashCode(this.f9505do) * 31, 31), 31), 31), 31), 31);
    }

    public String toString() {
        StringBuilder r = by.r("AdvertParams(volume=");
        r.append(this.f9505do);
        r.append(", pageRef=");
        r.append(this.f9508if);
        r.append(", genreId=");
        r.append(this.f9507for);
        r.append(", partnerId=");
        r.append(this.f9509new);
        r.append(", genreName=");
        r.append(this.f9510try);
        r.append(", targetRef=");
        r.append(this.f9504case);
        r.append(", categoryId=");
        return by.c(r, this.f9506else, ')');
    }
}
