package defpackage;

import java.io.IOException;
import javax.net.ssl.SSLException;

/* loaded from: classes.dex */
public final class tn3 {

    /* renamed from: do, reason: not valid java name */
    public final int f37510do;

    /* renamed from: if, reason: not valid java name */
    public final Throwable f37511if;

    /* loaded from: classes.dex */
    public enum a {
        UNKNOWN,
        GENERIC_CONNECTIVITY_ERROR,
        TLS_ERROR,
        HTTP_RESPONSE_OTHER,
        HTTP_RESPONSE_2XX,
        HTTP_RESPONSE_200,
        HTTP_RESPONSE_3XX,
        HTTP_RESPONSE_301,
        HTTP_RESPONSE_302,
        HTTP_RESPONSE_4XX,
        HTTP_RESPONSE_403,
        HTTP_RESPONSE_404,
        HTTP_RESPONSE_408,
        HTTP_RESPONSE_413,
        HTTP_RESPONSE_5XX,
        HTTP_RESPONSE_500,
        HTTP_RESPONSE_503,
        MAX
    }

    public tn3(int i, Throwable th) {
        this.f37510do = i;
        this.f37511if = th;
        if (i == -1) {
            if (th == null) {
                a aVar = a.UNKNOWN;
                return;
            }
            if (th instanceof SSLException) {
                a aVar2 = a.TLS_ERROR;
                return;
            } else if (th instanceof IOException) {
                a aVar3 = a.GENERIC_CONNECTIVITY_ERROR;
                return;
            } else {
                a aVar4 = a.UNKNOWN;
                return;
            }
        }
        if (i == 200) {
            a aVar5 = a.HTTP_RESPONSE_200;
            return;
        }
        if (i == 408) {
            a aVar6 = a.HTTP_RESPONSE_408;
            return;
        }
        if (i == 413) {
            a aVar7 = a.HTTP_RESPONSE_413;
            return;
        }
        if (i == 500) {
            a aVar8 = a.HTTP_RESPONSE_500;
            return;
        }
        if (i == 503) {
            a aVar9 = a.HTTP_RESPONSE_503;
            return;
        }
        if (i == 301) {
            a aVar10 = a.HTTP_RESPONSE_301;
            return;
        }
        if (i == 302) {
            a aVar11 = a.HTTP_RESPONSE_302;
            return;
        }
        if (i == 403) {
            a aVar12 = a.HTTP_RESPONSE_403;
            return;
        }
        if (i == 404) {
            a aVar13 = a.HTTP_RESPONSE_404;
            return;
        }
        if (i >= 200 && i <= 299) {
            a aVar14 = a.HTTP_RESPONSE_2XX;
            return;
        }
        if (i >= 300 && i <= 399) {
            a aVar15 = a.HTTP_RESPONSE_3XX;
            return;
        }
        if (i >= 400 && i <= 499) {
            a aVar16 = a.HTTP_RESPONSE_4XX;
        } else if (i < 500 || i > 599) {
            a aVar17 = a.HTTP_RESPONSE_OTHER;
        } else {
            a aVar18 = a.HTTP_RESPONSE_5XX;
        }
    }
}
