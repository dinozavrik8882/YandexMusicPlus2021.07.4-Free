package defpackage;

/* loaded from: classes2.dex */
public abstract class rv5 extends zt5 implements tu5, hv5 {

    /* renamed from: final, reason: not valid java name */
    public sv5 f34440final;

    @Override // defpackage.hv5
    /* renamed from: do */
    public boolean mo6851do() {
        return true;
    }

    @Override // defpackage.tu5
    /* renamed from: final */
    public void mo4914final() {
        Object i;
        sv5 m13977synchronized = m13977synchronized();
        do {
            i = m13977synchronized.i();
            if (!(i instanceof rv5)) {
                if (!(i instanceof hv5) || ((hv5) i).mo6852this() == null) {
                    return;
                }
                mo13082volatile();
                return;
            }
            if (i != this) {
                return;
            }
        } while (!sv5.f36074catch.compareAndSet(m13977synchronized, i, tv5.f37905else));
    }

    /* renamed from: synchronized, reason: not valid java name */
    public final sv5 m13977synchronized() {
        sv5 sv5Var = this.f34440final;
        if (sv5Var != null) {
            return sv5Var;
        }
        jp5.m8562class("job");
        throw null;
    }

    @Override // defpackage.hv5
    /* renamed from: this */
    public xv5 mo6852this() {
        return null;
    }

    @Override // defpackage.t16
    public String toString() {
        return getClass().getSimpleName() + '@' + dn3.C0(this) + "[job@" + dn3.C0(m13977synchronized()) + ']';
    }
}
