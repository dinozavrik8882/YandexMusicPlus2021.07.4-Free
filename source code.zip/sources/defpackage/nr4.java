package defpackage;

/* loaded from: classes.dex */
public enum nr4 {
    RAW,
    HLS
}
