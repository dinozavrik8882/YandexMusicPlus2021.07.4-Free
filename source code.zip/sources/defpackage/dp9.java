package defpackage;

/* loaded from: classes2.dex */
public enum dp9 {
    RADIO,
    ALBUM,
    ARTIST,
    PLAYLIST,
    STREAM,
    OTHER
}
