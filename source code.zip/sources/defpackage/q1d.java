package defpackage;

import defpackage.s1d;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class q1d {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f29950do;

    /* renamed from: case, reason: not valid java name */
    public final a f29951case;

    /* renamed from: for, reason: not valid java name */
    public final zv4 f29952for;

    /* renamed from: if, reason: not valid java name */
    public final el5 f29953if;

    /* renamed from: new, reason: not valid java name */
    public final gu5 f29954new;

    /* renamed from: try, reason: not valid java name */
    public s1d f29955try;

    /* loaded from: classes2.dex */
    public static final class a implements s1d.a {
        public a() {
        }

        @Override // s1d.a
        /* renamed from: do, reason: not valid java name */
        public void mo12418do() {
            h1d m12417do = q1d.this.m12417do();
            Objects.requireNonNull(m12417do);
            k2f.f19768new.mo8774this("Completing the update", new Object[0]);
            m12417do.m6968do().mo9198do();
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(q1d.class), "center", "getCenter()Lru/yandex/music/update/InAppUpdateCenter;");
        Objects.requireNonNull(dq5.f8909do);
        f29950do = new mr5[]{wp5Var};
    }

    public q1d() {
        iz3 l3 = dn3.l3(h1d.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        this.f29953if = new ez3(new cz3(l3)).m5533do(f29950do[0]);
        cw4 cw4Var = new cw4(false);
        this.f29952for = cw4Var;
        this.f29954new = dn3.m4644extends(cw4Var, kv4.m9275do());
        this.f29951case = new a();
    }

    /* renamed from: do, reason: not valid java name */
    public final h1d m12417do() {
        return (h1d) this.f29953if.getValue();
    }
}
