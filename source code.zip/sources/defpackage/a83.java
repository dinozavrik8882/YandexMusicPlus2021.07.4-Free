package defpackage;

import java.io.IOException;

/* loaded from: classes.dex */
public interface a83<TValue, TContext> {
    /* renamed from: do, reason: not valid java name */
    void mo301do(TValue tvalue, TContext tcontext) throws IOException;
}
