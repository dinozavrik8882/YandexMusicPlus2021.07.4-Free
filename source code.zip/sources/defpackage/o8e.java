package defpackage;

/* loaded from: classes2.dex */
public interface o8e extends p8e {
}
