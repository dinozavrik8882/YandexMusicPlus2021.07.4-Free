package defpackage;

import java.util.List;

/* loaded from: classes2.dex */
public final class mn8 implements un8 {

    /* renamed from: case, reason: not valid java name */
    public fqe f24329case;

    /* renamed from: do, reason: not valid java name */
    public final w68 f24330do;

    /* renamed from: else, reason: not valid java name */
    public fqe f24331else;

    /* renamed from: if, reason: not valid java name */
    public final wpe<un8> f24333if;

    /* renamed from: new, reason: not valid java name */
    public volatile un8 f24334new;

    /* renamed from: for, reason: not valid java name */
    public final k0f<go8> f24332for = k0f.s();

    /* renamed from: try, reason: not valid java name */
    public final Object f24335try = new Object();

    public mn8(w68 w68Var, wpe<un8> wpeVar) {
        this.f24330do = w68Var;
        this.f24333if = wpeVar;
    }

    @Override // defpackage.un8
    /* renamed from: break */
    public void mo2226break(boolean z) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2226break(z);
        }
    }

    @Override // defpackage.un8
    /* renamed from: case */
    public void mo2227case(boolean z) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2227case(z);
        }
    }

    @Override // defpackage.un8
    /* renamed from: catch */
    public void mo2228catch(List<q68> list) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2228catch(list);
        }
    }

    @Override // defpackage.un8
    /* renamed from: class */
    public void mo2229class(int i) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2229class(i);
        }
    }

    @Override // defpackage.un8
    /* renamed from: const */
    public go8 mo2230const() {
        un8 un8Var = this.f24334new;
        return un8Var != null ? un8Var.mo2230const() : go8.f13940if;
    }

    @Override // defpackage.un8
    /* renamed from: do */
    public w68 mo2231do() {
        un8 un8Var = this.f24334new;
        return un8Var != null ? un8Var.mo2231do() : this.f24330do;
    }

    @Override // defpackage.un8
    /* renamed from: else */
    public void mo2232else() {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2232else();
        }
    }

    @Override // defpackage.un8
    /* renamed from: final */
    public void mo2233final(List<q68> list, int i) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2233final(list, i);
        }
    }

    @Override // defpackage.un8
    /* renamed from: for */
    public spe<go8> mo2234for() {
        return this.f24332for;
    }

    @Override // defpackage.un8
    /* renamed from: goto */
    public void mo2235goto(int i) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2235goto(i);
        }
    }

    @Override // defpackage.un8
    /* renamed from: if */
    public void mo2236if() {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2236if();
        }
    }

    @Override // defpackage.un8
    /* renamed from: new */
    public void mo2237new(y68 y68Var) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2237new(y68Var);
        }
    }

    @Override // defpackage.un8
    public void start() {
        synchronized (this.f24335try) {
            if (this.f24329case != null) {
                return;
            }
            wpe<un8> wpeVar = this.f24333if;
            tqe<? super un8> tqeVar = new tqe() { // from class: dm8
                @Override // defpackage.tqe
                public final void call(Object obj) {
                    mn8 mn8Var = mn8.this;
                    un8 un8Var = (un8) obj;
                    synchronized (mn8Var.f24335try) {
                        if (mn8Var.f24329case != null) {
                            mn8Var.f24334new = un8Var;
                            un8Var.start();
                            mn8Var.f24331else = un8Var.mo2234for().f(mn8Var.f24332for);
                        } else {
                            un8Var.stop();
                        }
                    }
                }
            };
            final k0f<go8> k0fVar = this.f24332for;
            k0fVar.getClass();
            this.f24329case = wpeVar.m16756const(tqeVar, new tqe() { // from class: em8
                @Override // defpackage.tqe
                public final void call(Object obj) {
                    k0f.this.mo1524do((Throwable) obj);
                }
            });
        }
    }

    @Override // defpackage.un8
    public void stop() {
        un8 un8Var;
        synchronized (this.f24335try) {
            un8Var = this.f24334new;
            this.f24334new = null;
            fqe fqeVar = this.f24329case;
            if (fqeVar != null) {
                fqeVar.unsubscribe();
                this.f24329case = null;
            }
            fqe fqeVar2 = this.f24331else;
            if (fqeVar2 != null) {
                fqeVar2.unsubscribe();
                this.f24331else = null;
            }
        }
        if (un8Var != null) {
            un8Var.stop();
        }
    }

    @Override // defpackage.un8
    /* renamed from: super */
    public void mo2238super(int i) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2238super(i);
        }
    }

    @Override // defpackage.un8
    /* renamed from: this */
    public <T> T mo2239this(lo8<T> lo8Var) {
        return lo8Var.mo9836else(this);
    }

    @Override // defpackage.un8
    /* renamed from: try */
    public void mo2240try(List<q68> list) {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2240try(list);
        }
    }

    @Override // defpackage.un8
    /* renamed from: while */
    public void mo2241while() {
        un8 un8Var = this.f24334new;
        if (un8Var != null) {
            un8Var.mo2241while();
        }
    }
}
