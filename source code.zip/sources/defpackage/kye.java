package defpackage;

/* loaded from: classes.dex */
public abstract class kye<E> extends eye<E> {
    public kye(int i) {
        super(i);
    }
}
