package defpackage;

import java.nio.charset.Charset;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.RandomAccess;

/* loaded from: classes.dex */
public final class b92 extends b82<Integer> implements j92<Integer>, va2, RandomAccess {

    /* renamed from: class, reason: not valid java name */
    public static final b92 f3201class;

    /* renamed from: const, reason: not valid java name */
    public int[] f3202const;

    /* renamed from: final, reason: not valid java name */
    public int f3203final;

    static {
        b92 b92Var = new b92(new int[0], 0);
        f3201class = b92Var;
        b92Var.f3127catch = false;
    }

    public b92() {
        this.f3202const = new int[10];
        this.f3203final = 0;
    }

    public b92(int[] iArr, int i) {
        this.f3202const = iArr;
        this.f3203final = i;
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* synthetic */ void add(int i, Object obj) {
        int i2;
        int intValue = ((Integer) obj).intValue();
        m1815if();
        if (i < 0 || i > (i2 = this.f3203final)) {
            throw new IndexOutOfBoundsException(m1857goto(i));
        }
        int[] iArr = this.f3202const;
        if (i2 < iArr.length) {
            System.arraycopy(iArr, i, iArr, i + 1, i2 - i);
        } else {
            int[] iArr2 = new int[by.m2401protected(i2, 3, 2, 1)];
            System.arraycopy(iArr, 0, iArr2, 0, i);
            System.arraycopy(this.f3202const, i, iArr2, i + 1, this.f3203final - i);
            this.f3202const = iArr2;
        }
        this.f3202const[i] = intValue;
        this.f3203final++;
        ((AbstractList) this).modCount++;
    }

    @Override // defpackage.b82, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final /* synthetic */ boolean add(Object obj) {
        int intValue = ((Integer) obj).intValue();
        m1815if();
        int i = this.f3203final;
        int[] iArr = this.f3202const;
        if (i == iArr.length) {
            int[] iArr2 = new int[by.m2401protected(i, 3, 2, 1)];
            System.arraycopy(iArr, 0, iArr2, 0, i);
            this.f3202const = iArr2;
        }
        int[] iArr3 = this.f3202const;
        int i2 = this.f3203final;
        this.f3203final = i2 + 1;
        iArr3[i2] = intValue;
        return true;
    }

    @Override // defpackage.b82, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection<? extends Integer> collection) {
        m1815if();
        Charset charset = a92.f535do;
        Objects.requireNonNull(collection);
        if (!(collection instanceof b92)) {
            return super.addAll(collection);
        }
        b92 b92Var = (b92) collection;
        int i = b92Var.f3203final;
        if (i == 0) {
            return false;
        }
        int i2 = this.f3203final;
        if (Integer.MAX_VALUE - i2 < i) {
            throw new OutOfMemoryError();
        }
        int i3 = i2 + i;
        int[] iArr = this.f3202const;
        if (i3 > iArr.length) {
            this.f3202const = Arrays.copyOf(iArr, i3);
        }
        System.arraycopy(b92Var.f3202const, 0, this.f3202const, this.f3203final, b92Var.f3203final);
        this.f3203final = i3;
        ((AbstractList) this).modCount++;
        return true;
    }

    @Override // defpackage.b82, java.util.AbstractList, java.util.Collection, java.util.List
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b92)) {
            return super.equals(obj);
        }
        b92 b92Var = (b92) obj;
        if (this.f3203final != b92Var.f3203final) {
            return false;
        }
        int[] iArr = b92Var.f3202const;
        for (int i = 0; i < this.f3203final; i++) {
            if (this.f3202const[i] != iArr[i]) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i) {
        m1859try(i);
        return Integer.valueOf(this.f3202const[i]);
    }

    /* renamed from: goto, reason: not valid java name */
    public final String m1857goto(int i) {
        return by.m2406super(35, "Index:", i, ", Size:", this.f3203final);
    }

    @Override // defpackage.b82, java.util.AbstractList, java.util.Collection, java.util.List
    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.f3203final; i2++) {
            i = (i * 31) + this.f3202const[i2];
        }
        return i;
    }

    /* renamed from: new, reason: not valid java name */
    public final int m1858new(int i) {
        m1859try(i);
        return this.f3202const[i];
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* synthetic */ Object remove(int i) {
        m1815if();
        m1859try(i);
        int[] iArr = this.f3202const;
        int i2 = iArr[i];
        if (i < this.f3203final - 1) {
            System.arraycopy(iArr, i + 1, iArr, i, (r2 - i) - 1);
        }
        this.f3203final--;
        ((AbstractList) this).modCount++;
        return Integer.valueOf(i2);
    }

    @Override // defpackage.b82, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean remove(Object obj) {
        m1815if();
        for (int i = 0; i < this.f3203final; i++) {
            if (obj.equals(Integer.valueOf(this.f3202const[i]))) {
                int[] iArr = this.f3202const;
                System.arraycopy(iArr, i + 1, iArr, i, (this.f3203final - i) - 1);
                this.f3203final--;
                ((AbstractList) this).modCount++;
                return true;
            }
        }
        return false;
    }

    @Override // java.util.AbstractList
    public final void removeRange(int i, int i2) {
        m1815if();
        if (i2 < i) {
            throw new IndexOutOfBoundsException("toIndex < fromIndex");
        }
        int[] iArr = this.f3202const;
        System.arraycopy(iArr, i2, iArr, i, this.f3203final - i2);
        this.f3203final -= i2 - i;
        ((AbstractList) this).modCount++;
    }

    @Override // java.util.AbstractList, java.util.List
    public final /* synthetic */ Object set(int i, Object obj) {
        int intValue = ((Integer) obj).intValue();
        m1815if();
        m1859try(i);
        int[] iArr = this.f3202const;
        int i2 = iArr[i];
        iArr[i] = intValue;
        return Integer.valueOf(i2);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f3203final;
    }

    /* renamed from: try, reason: not valid java name */
    public final void m1859try(int i) {
        if (i < 0 || i >= this.f3203final) {
            throw new IndexOutOfBoundsException(m1857goto(i));
        }
    }

    @Override // defpackage.j92
    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ j92<Integer> mo1860while(int i) {
        if (i >= this.f3203final) {
            return new b92(Arrays.copyOf(this.f3202const, i), this.f3203final);
        }
        throw new IllegalArgumentException();
    }
}
