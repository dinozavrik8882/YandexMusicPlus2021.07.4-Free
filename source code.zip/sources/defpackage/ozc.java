package defpackage;

/* loaded from: classes2.dex */
public interface ozc {
    /* renamed from: do */
    void mo10162do(boolean z);

    /* renamed from: if */
    void mo10163if(String str);
}
