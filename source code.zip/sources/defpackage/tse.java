package defpackage;

import defpackage.vpe;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/* loaded from: classes.dex */
public class tse implements sqe {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ spe f37772catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ eqe f37773class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ AtomicLong f37774const;

    /* renamed from: final, reason: not valid java name */
    public final /* synthetic */ vpe.a f37775final;

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ sqe f37776super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ AtomicBoolean f37777throw;

    /* loaded from: classes.dex */
    public class a extends eqe<Object> {
        public a(eqe eqeVar) {
            super(eqeVar, true);
        }

        @Override // defpackage.tpe
        /* renamed from: case */
        public void mo1523case(Object obj) {
            if (tse.this.f37773class.f10599catch.f26245class) {
                return;
            }
            if (tse.this.f37774const.get() <= 0) {
                tse.this.f37777throw.compareAndSet(false, true);
            } else {
                tse tseVar = tse.this;
                tseVar.f37775final.mo7510do(tseVar.f37776super);
            }
        }

        @Override // defpackage.tpe
        /* renamed from: do */
        public void mo1524do(Throwable th) {
            tse.this.f37773class.mo1524do(th);
        }

        @Override // defpackage.eqe
        /* renamed from: goto */
        public void mo2322goto(upe upeVar) {
            upeVar.mo1522break(Long.MAX_VALUE);
        }

        @Override // defpackage.tpe
        /* renamed from: if */
        public void mo1526if() {
            tse.this.f37773class.mo1526if();
        }
    }

    public tse(pse pseVar, spe speVar, eqe eqeVar, AtomicLong atomicLong, vpe.a aVar, sqe sqeVar, AtomicBoolean atomicBoolean) {
        this.f37772catch = speVar;
        this.f37773class = eqeVar;
        this.f37774const = atomicLong;
        this.f37775final = aVar;
        this.f37776super = sqeVar;
        this.f37777throw = atomicBoolean;
    }

    @Override // defpackage.sqe
    public void call() {
        this.f37772catch.r(new a(this.f37773class));
    }
}
