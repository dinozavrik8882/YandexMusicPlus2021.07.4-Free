package defpackage;

import ru.yandex.music.common.media.context.PlaybackScope;

/* loaded from: classes2.dex */
public final class loa {

    /* renamed from: do, reason: not valid java name */
    public final PlaybackScope f22513do;

    /* renamed from: if, reason: not valid java name */
    public final t4c f22514if;

    public loa(PlaybackScope playbackScope, t4c t4cVar) {
        jp5.m8570try(playbackScope, "playbackScope");
        jp5.m8570try(t4cVar, "stationDescriptor");
        this.f22513do = playbackScope;
        this.f22514if = t4cVar;
    }

    /* renamed from: do, reason: not valid java name */
    public String m9841do() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f22513do);
        sb.append(':');
        sb.append(this.f22514if.m14652for());
        return sb.toString();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof loa)) {
            return false;
        }
        loa loaVar = (loa) obj;
        return jp5.m8563do(this.f22513do, loaVar.f22513do) && jp5.m8563do(this.f22514if, loaVar.f22514if);
    }

    public int hashCode() {
        return this.f22514if.hashCode() + (this.f22513do.hashCode() * 31);
    }

    public String toString() {
        StringBuilder r = by.r("StationViewModelData(playbackScope=");
        r.append(this.f22513do);
        r.append(", stationDescriptor=");
        r.append(this.f22514if);
        r.append(')');
        return r.toString();
    }
}
