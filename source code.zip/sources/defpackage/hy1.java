package defpackage;

import android.content.Context;

/* loaded from: classes.dex */
public final class hy1 extends be1 {
    public hy1(Context context) {
        super(context);
    }
}
