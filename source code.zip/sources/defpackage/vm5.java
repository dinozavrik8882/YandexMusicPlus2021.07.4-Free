package defpackage;

import defpackage.ym5;
import java.io.Serializable;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class vm5 implements ym5, Serializable {

    /* renamed from: catch, reason: not valid java name */
    public final ym5 f40812catch;

    /* renamed from: class, reason: not valid java name */
    public final ym5.a f40813class;

    /* loaded from: classes2.dex */
    public static final class a implements Serializable {
        private static final long serialVersionUID = 0;

        /* renamed from: catch, reason: not valid java name */
        public final ym5[] f40814catch;

        public a(ym5[] ym5VarArr) {
            jp5.m8570try(ym5VarArr, "elements");
            this.f40814catch = ym5VarArr;
        }

        private final Object readResolve() {
            ym5[] ym5VarArr = this.f40814catch;
            ym5 ym5Var = an5.f1088catch;
            for (ym5 ym5Var2 : ym5VarArr) {
                ym5Var = ym5Var.plus(ym5Var2);
            }
            return ym5Var;
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements qo5<String, ym5.a, String> {

        /* renamed from: catch, reason: not valid java name */
        public static final b f40815catch = new b();

        public b() {
            super(2);
        }

        @Override // defpackage.qo5
        public String invoke(String str, ym5.a aVar) {
            String str2 = str;
            ym5.a aVar2 = aVar;
            jp5.m8570try(str2, "acc");
            jp5.m8570try(aVar2, "element");
            if (str2.length() == 0) {
                return aVar2.toString();
            }
            return str2 + ", " + aVar2;
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements qo5<pl5, ym5.a, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ ym5[] f40816catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ aq5 f40817class;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(ym5[] ym5VarArr, aq5 aq5Var) {
            super(2);
            this.f40816catch = ym5VarArr;
            this.f40817class = aq5Var;
        }

        @Override // defpackage.qo5
        public pl5 invoke(pl5 pl5Var, ym5.a aVar) {
            ym5.a aVar2 = aVar;
            jp5.m8570try(pl5Var, "<anonymous parameter 0>");
            jp5.m8570try(aVar2, "element");
            ym5[] ym5VarArr = this.f40816catch;
            aq5 aq5Var = this.f40817class;
            int i = aq5Var.f2391catch;
            aq5Var.f2391catch = i + 1;
            ym5VarArr[i] = aVar2;
            return pl5.f29126do;
        }
    }

    public vm5(ym5 ym5Var, ym5.a aVar) {
        jp5.m8570try(ym5Var, "left");
        jp5.m8570try(aVar, "element");
        this.f40812catch = ym5Var;
        this.f40813class = aVar;
    }

    private final Object writeReplace() {
        int m16149if = m16149if();
        ym5[] ym5VarArr = new ym5[m16149if];
        aq5 aq5Var = new aq5();
        aq5Var.f2391catch = 0;
        fold(pl5.f29126do, new c(ym5VarArr, aq5Var));
        if (aq5Var.f2391catch == m16149if) {
            return new a(ym5VarArr);
        }
        throw new IllegalStateException("Check failed.".toString());
    }

    public boolean equals(Object obj) {
        boolean z;
        if (this != obj) {
            if (!(obj instanceof vm5)) {
                return false;
            }
            vm5 vm5Var = (vm5) obj;
            if (vm5Var.m16149if() != m16149if()) {
                return false;
            }
            Objects.requireNonNull(vm5Var);
            vm5 vm5Var2 = this;
            while (true) {
                ym5.a aVar = vm5Var2.f40813class;
                if (!jp5.m8563do(vm5Var.get(aVar.getKey()), aVar)) {
                    z = false;
                    break;
                }
                ym5 ym5Var = vm5Var2.f40812catch;
                if (!(ym5Var instanceof vm5)) {
                    Objects.requireNonNull(ym5Var, "null cannot be cast to non-null type kotlin.coroutines.CoroutineContext.Element");
                    ym5.a aVar2 = (ym5.a) ym5Var;
                    z = jp5.m8563do(vm5Var.get(aVar2.getKey()), aVar2);
                    break;
                }
                vm5Var2 = (vm5) ym5Var;
            }
            if (!z) {
                return false;
            }
        }
        return true;
    }

    @Override // defpackage.ym5
    public <R> R fold(R r, qo5<? super R, ? super ym5.a, ? extends R> qo5Var) {
        jp5.m8570try(qo5Var, "operation");
        return qo5Var.invoke((Object) this.f40812catch.fold(r, qo5Var), this.f40813class);
    }

    @Override // defpackage.ym5
    public <E extends ym5.a> E get(ym5.b<E> bVar) {
        jp5.m8570try(bVar, "key");
        vm5 vm5Var = this;
        while (true) {
            E e = (E) vm5Var.f40813class.get(bVar);
            if (e != null) {
                return e;
            }
            ym5 ym5Var = vm5Var.f40812catch;
            if (!(ym5Var instanceof vm5)) {
                return (E) ym5Var.get(bVar);
            }
            vm5Var = (vm5) ym5Var;
        }
    }

    public int hashCode() {
        return this.f40813class.hashCode() + this.f40812catch.hashCode();
    }

    /* renamed from: if, reason: not valid java name */
    public final int m16149if() {
        int i = 2;
        vm5 vm5Var = this;
        while (true) {
            ym5 ym5Var = vm5Var.f40812catch;
            if (!(ym5Var instanceof vm5)) {
                ym5Var = null;
            }
            vm5Var = (vm5) ym5Var;
            if (vm5Var == null) {
                return i;
            }
            i++;
        }
    }

    @Override // defpackage.ym5
    public ym5 minusKey(ym5.b<?> bVar) {
        jp5.m8570try(bVar, "key");
        if (this.f40813class.get(bVar) != null) {
            return this.f40812catch;
        }
        ym5 minusKey = this.f40812catch.minusKey(bVar);
        return minusKey == this.f40812catch ? this : minusKey == an5.f1088catch ? this.f40813class : new vm5(minusKey, this.f40813class);
    }

    @Override // defpackage.ym5
    public ym5 plus(ym5 ym5Var) {
        jp5.m8570try(ym5Var, "context");
        jp5.m8570try(ym5Var, "context");
        return ym5Var == an5.f1088catch ? this : (ym5) ym5Var.fold(this, zm5.f47446catch);
    }

    public String toString() {
        return by.e(by.r("["), (String) fold("", b.f40815catch), "]");
    }
}
