package defpackage;

import java.util.ArrayList;
import ru.yandex.music.common.media.context.PlaybackContextName;
import ru.yandex.music.data.user.Permission;

/* loaded from: classes2.dex */
public class rad extends abd {

    /* renamed from: const, reason: not valid java name */
    public final ox7<?> f32146const;

    public rad(qg9 qg9Var, ox7<?> ox7Var) {
        super(qg9Var);
        this.f32146const = ox7Var;
    }

    @Override // defpackage.abd
    /* renamed from: for */
    public void mo453for(Permission... permissionArr) throws gbd, sad, uad {
        T t = this.f32146const.f28031if;
        ArrayList arrayList = new ArrayList(this.f32146const.f28030do);
        tad tadVar = null;
        e69 e69Var = arrayList.size() > 0 ? (e69) arrayList.get(0) : null;
        if (t == 0) {
            tadVar = new tad(e69Var, null, null);
        } else if (t.g() == p49.f28339for) {
            tadVar = new tad(e69Var, PlaybackContextName.PLAYLIST, t.mo4957do());
        } else if (t.g() == p49.f28338do) {
            tadVar = new tad(e69Var, PlaybackContextName.ALBUM, t.mo4957do());
        } else if (t.g() == p49.f28340if) {
            tadVar = new tad(e69Var, PlaybackContextName.ARTIST, t.mo4957do());
        }
        m454if(tadVar, permissionArr);
    }
}
