package defpackage;

import defpackage.mw;

/* loaded from: classes.dex */
public final class qx implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ mw.b f31461catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ rx f31462class;

    public qx(rx rxVar, mw.b bVar) {
        this.f31462class = rxVar;
        this.f31461catch = bVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        rw rwVar = this.f31462class.f34515if;
        mw.b bVar = this.f31461catch;
        ((xo3) rwVar).m17230if(bVar.f24668if, bVar.f24667do);
    }
}
