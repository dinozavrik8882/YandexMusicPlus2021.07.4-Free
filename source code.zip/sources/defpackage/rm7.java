package defpackage;

import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes2.dex */
public class rm7 extends ht7<e69> {

    /* renamed from: else, reason: not valid java name */
    public final u57 f32691else;

    public rm7(u57 u57Var) {
        super(new ue9() { // from class: hm7
            @Override // defpackage.ue9
            /* renamed from: do */
            public final Object mo58do(Object obj) {
                return ((e69) obj).f9541catch;
            }
        });
        this.f32691else = u57Var;
        this.f19226for = new us7() { // from class: fm7
            @Override // defpackage.us7
            /* renamed from: extends */
            public final void mo610extends(Object obj, int i) {
                hoc.m7417switch((e69) obj);
            }
        };
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    /* renamed from: case, reason: merged with bridge method [inline-methods] */
    public gt7<e69> onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new qm7(viewGroup, this.f32691else);
    }

    @Override // defpackage.it7, defpackage.js7, androidx.recyclerview.widget.RecyclerView.e
    public void onBindViewHolder(RecyclerView.b0 b0Var, int i) {
        gt7 gt7Var = (gt7) b0Var;
        ((qm7) gt7Var).f30922synchronized = i;
        super.onBindViewHolder(gt7Var, i);
    }

    @Override // defpackage.it7
    /* renamed from: try */
    public void onBindViewHolder(gt7<e69> gt7Var, int i) {
        ((qm7) gt7Var).f30922synchronized = i;
        super.onBindViewHolder(gt7Var, i);
    }
}
