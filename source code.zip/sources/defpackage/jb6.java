package defpackage;

/* loaded from: classes2.dex */
public class jb6 extends RuntimeException {

    /* renamed from: catch, reason: not valid java name */
    public final int f18338catch;

    /* renamed from: class, reason: not valid java name */
    public final transient ac6<?> f18339class;

    public jb6(ac6<?> ac6Var) {
        super("HTTP " + ac6Var.f645do.f30153super + " " + ac6Var.f645do.f30147final);
        this.f18338catch = ac6Var.f645do.f30153super;
        this.f18339class = ac6Var;
    }
}
