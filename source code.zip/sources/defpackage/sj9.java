package defpackage;

/* loaded from: classes2.dex */
public final class sj9 extends kp5 implements mo5<Long, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ tj9 f35504catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ bq5 f35505class;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public sj9(tj9 tj9Var, bq5 bq5Var) {
        super(1);
        this.f35504catch = tj9Var;
        this.f35505class = bq5Var;
    }

    @Override // defpackage.mo5
    public pl5 invoke(Long l) {
        tj9.m15034import(this.f35504catch, aq4.PLAYING, false);
        this.f35505class.f4152catch = 0L;
        return pl5.f29126do;
    }
}
