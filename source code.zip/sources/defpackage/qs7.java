package defpackage;

import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.e;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import defpackage.ct7;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes2.dex */
public class qs7<T extends RecyclerView.e<?>> extends ot7<T> {

    /* renamed from: case, reason: not valid java name */
    public boolean f31239case;

    /* renamed from: else, reason: not valid java name */
    public boolean f31240else;

    /* renamed from: for, reason: not valid java name */
    public int f31241for;

    /* renamed from: goto, reason: not valid java name */
    public final Map<RecyclerView.g, RecyclerView.g> f31242goto;

    /* renamed from: if, reason: not valid java name */
    public int f31243if;

    /* renamed from: new, reason: not valid java name */
    public final List<he<ct7, Integer>> f31244new;

    /* renamed from: try, reason: not valid java name */
    public final List<he<ct7, Integer>> f31245try;

    /* loaded from: classes2.dex */
    public class a extends RecyclerView.g {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ RecyclerView.g f31246do;

        public a(RecyclerView.g gVar) {
            this.f31246do = gVar;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        /* renamed from: case */
        public void mo1138case(int i, int i2) {
            this.f31246do.mo1138case(qs7.this.f31244new.size() + i, i2);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        /* renamed from: do */
        public void mo1139do() {
            this.f31246do.mo1139do();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        /* renamed from: for */
        public void mo1140for(int i, int i2, Object obj) {
            this.f31246do.mo1140for(qs7.this.f31244new.size() + i, i2, obj);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        /* renamed from: if */
        public void mo1141if(int i, int i2) {
            this.f31246do.mo1141if(qs7.this.f31244new.size() + i, i2);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        /* renamed from: new */
        public void mo1142new(int i, int i2) {
            this.f31246do.mo1142new(qs7.this.f31244new.size() + i, i2);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.g
        /* renamed from: try */
        public void mo1143try(int i, int i2, int i3) {
            this.f31246do.mo1143try(qs7.this.f31244new.size() + i, qs7.this.f31244new.size() + i2, i3);
        }
    }

    public qs7(T t, ct7 ct7Var, ct7 ct7Var2) {
        super(t);
        this.f31243if = -2147483647;
        this.f31241for = 2147483646;
        this.f31244new = new ArrayList();
        this.f31245try = new ArrayList();
        this.f31242goto = new HashMap();
        setHasStableIds(t.hasStableIds());
        if (ct7Var != null) {
            m12923else(ct7Var, false, false);
        }
        if (ct7Var2 != null) {
            m12920case(ct7Var2, false, false);
        }
    }

    /* renamed from: break, reason: not valid java name */
    public void m12919break(final ct7 ct7Var) {
        m12928this(g8d.c(this.f31245try, new g9d() { // from class: zr7
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((ct7) ((he) obj).f15016do).equals(ct7.this);
            }
        }));
    }

    /* renamed from: case, reason: not valid java name */
    public void m12920case(final ct7 ct7Var, boolean z, boolean z2) {
        if (g8d.c(this.f31245try, new g9d() { // from class: wr7
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((ct7) ((he) obj).f15016do).equals(ct7.this);
            }
        }) != -1) {
            return;
        }
        int i = this.f31241for;
        this.f31241for = i - 1;
        final he<ct7, Integer> heVar = new he<>(ct7Var, Integer.valueOf(i));
        if (z) {
            this.f31245try.add(0, heVar);
            if (!z2) {
                notifyItemInserted(this.f31244new.size() + super.getItemCount());
            }
        } else {
            this.f31245try.add(heVar);
            if (!z2) {
                notifyItemInserted((this.f31245try.size() + (this.f31244new.size() + super.getItemCount())) - 1);
            }
        }
        if (z2) {
            notifyDataSetChanged();
        }
        ct7Var.mo3839new(new ct7.a() { // from class: ur7
            @Override // ct7.a
            /* renamed from: do */
            public final void mo3840do() {
                qs7.this.m12929try(heVar);
            }
        });
    }

    /* renamed from: catch, reason: not valid java name */
    public void m12921catch(final ct7 ct7Var) {
        int c = g8d.c(this.f31244new, new g9d() { // from class: tr7
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((ct7) ((he) obj).f15016do).equals(ct7.this);
            }
        });
        if (c != -1) {
            this.f31244new.remove(c);
            notifyItemRemoved(c);
        }
    }

    /* renamed from: do, reason: not valid java name */
    public final int m12922do(int i) {
        return (i - this.f31244new.size()) - super.getItemCount();
    }

    /* renamed from: else, reason: not valid java name */
    public void m12923else(final ct7 ct7Var, boolean z, boolean z2) {
        if (g8d.c(this.f31244new, new g9d() { // from class: vr7
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((ct7) ((he) obj).f15016do).equals(ct7.this);
            }
        }) != -1) {
            return;
        }
        int i = this.f31243if;
        this.f31243if = i + 1;
        final he<ct7, Integer> heVar = new he<>(ct7Var, Integer.valueOf(i));
        if (z) {
            this.f31244new.add(0, heVar);
            if (!z2) {
                notifyItemInserted(0);
            }
        } else {
            this.f31244new.add(heVar);
            if (!z2) {
                notifyItemInserted(this.f31244new.size() - 1);
            }
        }
        if (z2) {
            notifyDataSetChanged();
        }
        ct7Var.mo3839new(new ct7.a() { // from class: xr7
            @Override // ct7.a
            /* renamed from: do */
            public final void mo3840do() {
                qs7 qs7Var = qs7.this;
                qs7Var.notifyItemChanged(qs7Var.f31244new.indexOf(heVar));
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    public int findRelativeAdapterPositionIn(RecyclerView.e<? extends RecyclerView.b0> eVar, RecyclerView.b0 b0Var, int i) {
        if (!ys7.m17747goto()) {
            return super.findRelativeAdapterPositionIn(eVar, b0Var, i);
        }
        int size = i - this.f31244new.size();
        return (size < 0 || size > this.f27867do.getItemCount()) ? i : size;
    }

    /* renamed from: for, reason: not valid java name */
    public boolean m12924for(int i) {
        return i >= this.f31244new.size() + super.getItemCount();
    }

    @Override // defpackage.ot7, androidx.recyclerview.widget.RecyclerView.e
    public int getItemCount() {
        return this.f31245try.size() + this.f31244new.size() + super.getItemCount();
    }

    @Override // defpackage.ot7, androidx.recyclerview.widget.RecyclerView.e
    public long getItemId(int i) {
        int intValue;
        if (m12927new(i)) {
            intValue = this.f31244new.get(i).f15017if.intValue();
        } else {
            if (!m12924for(i)) {
                if (super.getItemCount() >= 2147483637) {
                    throw new IllegalStateException("HeaderRecyclerViewAdapter offsets your BasicItemType by 10");
                }
                long itemId = super.getItemId(i - this.f31244new.size());
                if (itemId != -1) {
                    return 10 + itemId;
                }
                return -1L;
            }
            intValue = this.f31245try.get(m12922do(i)).f15017if.intValue();
        }
        return intValue;
    }

    @Override // defpackage.ot7, androidx.recyclerview.widget.RecyclerView.e
    public int getItemViewType(int i) {
        if (m12927new(i)) {
            return this.f31244new.get(i).f15017if.intValue();
        }
        if (m12924for(i)) {
            return this.f31245try.get(m12922do(i)).f15017if.intValue();
        }
        if (super.getItemCount() < 2147483637) {
            return super.getItemViewType(i - this.f31244new.size()) + 10;
        }
        throw new IllegalStateException("HeaderRecyclerViewAdapter offsets your BasicItemType by 10");
    }

    /* renamed from: goto, reason: not valid java name */
    public final void m12925goto(RecyclerView.b0 b0Var, boolean z) {
        View view = b0Var.itemView;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof StaggeredGridLayoutManager.c) {
            StaggeredGridLayoutManager.c cVar = (StaggeredGridLayoutManager.c) layoutParams;
            cVar.f2038case = z;
            view.setLayoutParams(cVar);
        } else {
            if ((layoutParams instanceof GridLayoutManager.b) || !z) {
                return;
            }
            int i = e8d.f9711do;
            jr3.m8593do("Works only with StaggeredGridLayoutManager");
        }
    }

    /* renamed from: if, reason: not valid java name */
    public boolean m12926if() {
        return !this.f31244new.isEmpty();
    }

    /* renamed from: new, reason: not valid java name */
    public boolean m12927new(int i) {
        return i < this.f31244new.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.e
    public void onBindViewHolder(RecyclerView.b0 b0Var, int i) {
        if (m12927new(i)) {
            m12925goto(b0Var, this.f31239case);
            this.f31244new.get(i).f15016do.mo292for(b0Var);
        } else if (m12924for(i)) {
            m12925goto(b0Var, this.f31240else);
            this.f31245try.get(m12922do(i)).f15016do.mo292for(b0Var);
        } else {
            this.f27867do.onBindViewHolder(b0Var, i - this.f31244new.size());
        }
    }

    @Override // defpackage.ot7, androidx.recyclerview.widget.RecyclerView.e
    public RecyclerView.b0 onCreateViewHolder(ViewGroup viewGroup, final int i) {
        int c = g8d.c(this.f31244new, new g9d() { // from class: sr7
            /* JADX WARN: Multi-variable type inference failed */
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((Integer) ((he) obj).f15017if).equals(Integer.valueOf(i));
            }
        });
        int c2 = g8d.c(this.f31245try, new g9d() { // from class: yr7
            /* JADX WARN: Multi-variable type inference failed */
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((Integer) ((he) obj).f15017if).equals(Integer.valueOf(i));
            }
        });
        if (c != -1) {
            return this.f31244new.get(c).f15016do.mo291do(viewGroup);
        }
        if (c2 != -1) {
            return this.f31245try.get(c2).f15016do.mo291do(viewGroup);
        }
        return this.f27867do.onCreateViewHolder(viewGroup, i - 10);
    }

    @Override // defpackage.ot7, androidx.recyclerview.widget.RecyclerView.e
    public void registerAdapterDataObserver(RecyclerView.g gVar) {
        super.registerAdapterDataObserver(gVar);
        a aVar = new a(gVar);
        this.f31242goto.put(gVar, aVar);
        this.f27867do.unregisterAdapterDataObserver(gVar);
        this.f27867do.registerAdapterDataObserver(aVar);
    }

    /* renamed from: this, reason: not valid java name */
    public void m12928this(int i) {
        if (i >= this.f31245try.size() || i == -1) {
            return;
        }
        this.f31245try.remove(i);
        notifyItemRemoved(this.f31244new.size() + super.getItemCount() + i);
    }

    /* renamed from: try, reason: not valid java name */
    public void m12929try(he heVar) {
        notifyItemChanged(this.f31245try.indexOf(heVar) + this.f31244new.size() + super.getItemCount());
    }

    @Override // defpackage.ot7, androidx.recyclerview.widget.RecyclerView.e
    public void unregisterAdapterDataObserver(RecyclerView.g gVar) {
        RecyclerView.g gVar2 = this.f31242goto.get(gVar);
        this.f31242goto.remove(gVar);
        this.f27867do.unregisterAdapterDataObserver(gVar2);
        this.f27867do.registerAdapterDataObserver(gVar);
        super.unregisterAdapterDataObserver(gVar);
    }
}
