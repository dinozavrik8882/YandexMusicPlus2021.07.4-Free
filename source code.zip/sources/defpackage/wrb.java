package defpackage;

/* loaded from: classes2.dex */
public final /* synthetic */ class wrb implements yqe {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ wpe f42715catch;

    @Override // defpackage.yqe
    public final Object call(Object obj) {
        wpe wpeVar = this.f42715catch;
        Boolean bool = (Boolean) obj;
        jp5.m8570try(wpeVar, "$this_startStation");
        jp5.m8568new(bool, "available");
        return bool.booleanValue() ? wpeVar : wpe.m16748case(new ctb());
    }
}
