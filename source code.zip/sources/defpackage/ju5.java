package defpackage;

import defpackage.yu5;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

/* loaded from: classes2.dex */
public final class ju5 extends yu5 implements Runnable {
    private static volatile Thread _thread;
    private static volatile int debugStatus;

    /* renamed from: import, reason: not valid java name */
    public static final ju5 f19305import;

    /* renamed from: native, reason: not valid java name */
    public static final long f19306native;

    static {
        Long l;
        ju5 ju5Var = new ju5();
        f19305import = ju5Var;
        ju5Var.d0(false);
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        try {
            l = Long.getLong("kotlinx.coroutines.DefaultExecutor.keepAlive", 1000L);
        } catch (SecurityException unused) {
            l = 1000L;
        }
        f19306native = timeUnit.toNanos(l.longValue());
    }

    @Override // defpackage.zu5
    public Thread h0() {
        Thread thread = _thread;
        if (thread == null) {
            synchronized (this) {
                thread = _thread;
                if (thread == null) {
                    thread = new Thread(this, "kotlinx.coroutines.DefaultExecutor");
                    _thread = thread;
                    thread.setDaemon(true);
                    thread.start();
                }
            }
        }
        return thread;
    }

    public final synchronized void n0() {
        if (o0()) {
            debugStatus = 3;
            l0();
            notifyAll();
        }
    }

    public final boolean o0() {
        int i = debugStatus;
        return i == 2 || i == 3;
    }

    @Override // defpackage.yu5, defpackage.nu5
    public tu5 r(long j, Runnable runnable, ym5 ym5Var) {
        long m1535do = av5.m1535do(j);
        if (m1535do >= 4611686018427387903L) {
            return zv5.f47949catch;
        }
        long nanoTime = System.nanoTime();
        yu5.b bVar = new yu5.b(m1535do + nanoTime, runnable);
        m0(nanoTime, bVar);
        return bVar;
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean z;
        boolean k0;
        kw5 kw5Var = kw5.f21127do;
        kw5.f21128if.set(this);
        try {
            synchronized (this) {
                if (o0()) {
                    z = false;
                } else {
                    z = true;
                    debugStatus = 1;
                    notifyAll();
                }
            }
            if (!z) {
                if (k0) {
                    return;
                } else {
                    return;
                }
            }
            long j = Long.MAX_VALUE;
            while (true) {
                Thread.interrupted();
                long f0 = f0();
                if (f0 == Long.MAX_VALUE) {
                    long nanoTime = System.nanoTime();
                    if (j == Long.MAX_VALUE) {
                        j = f19306native + nanoTime;
                    }
                    long j2 = j - nanoTime;
                    if (j2 <= 0) {
                        _thread = null;
                        n0();
                        if (k0()) {
                            return;
                        }
                        h0();
                        return;
                    }
                    f0 = br5.m2281for(f0, j2);
                } else {
                    j = Long.MAX_VALUE;
                }
                if (f0 > 0) {
                    if (o0()) {
                        _thread = null;
                        n0();
                        if (k0()) {
                            return;
                        }
                        h0();
                        return;
                    }
                    LockSupport.parkNanos(this, f0);
                }
            }
        } finally {
            _thread = null;
            n0();
            if (!k0()) {
                h0();
            }
        }
    }
}
