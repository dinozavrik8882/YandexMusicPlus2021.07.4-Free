package defpackage;

/* loaded from: classes2.dex */
public class q5b extends td9<oa9> {
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0214  */
    /* JADX WARN: Removed duplicated region for block: B:109:0x0201  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x01ed  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x01e1  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x01b8  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x01dc  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x01e6  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x01f2  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0209  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0278  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x031e  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x0375  */
    /* JADX WARN: Type inference failed for: r12v11 */
    /* JADX WARN: Type inference failed for: r12v12, types: [int] */
    /* JADX WARN: Type inference failed for: r12v20 */
    @Override // defpackage.ue9
    /* renamed from: for, reason: not valid java name and merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public defpackage.oa9 mo58do(android.database.Cursor r63) {
        /*
            Method dump skipped, instructions count: 908
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.q5b.mo58do(android.database.Cursor):oa9");
    }
}
