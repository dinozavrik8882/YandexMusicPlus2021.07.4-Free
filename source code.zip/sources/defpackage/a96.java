package defpackage;

import defpackage.b96;
import defpackage.n86;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.net.ssl.SSLSocket;
import org.conscrypt.Conscrypt;

/* loaded from: classes2.dex */
public final class a96 implements c96 {

    /* renamed from: do, reason: not valid java name */
    public static final b96.a f544do = new a();

    /* loaded from: classes2.dex */
    public static final class a implements b96.a {
        @Override // b96.a
        /* renamed from: do, reason: not valid java name */
        public boolean mo361do(SSLSocket sSLSocket) {
            jp5.m8570try(sSLSocket, "sslSocket");
            n86.a aVar = n86.f25218try;
            return n86.f25217new && Conscrypt.isConscrypt(sSLSocket);
        }

        @Override // b96.a
        /* renamed from: if, reason: not valid java name */
        public c96 mo362if(SSLSocket sSLSocket) {
            jp5.m8570try(sSLSocket, "sslSocket");
            return new a96();
        }
    }

    @Override // defpackage.c96
    /* renamed from: do, reason: not valid java name */
    public boolean mo357do(SSLSocket sSLSocket) {
        jp5.m8570try(sSLSocket, "sslSocket");
        return Conscrypt.isConscrypt(sSLSocket);
    }

    @Override // defpackage.c96
    /* renamed from: for, reason: not valid java name */
    public String mo358for(SSLSocket sSLSocket) {
        jp5.m8570try(sSLSocket, "sslSocket");
        if (mo357do(sSLSocket)) {
            return Conscrypt.getApplicationProtocol(sSLSocket);
        }
        return null;
    }

    @Override // defpackage.c96
    /* renamed from: if, reason: not valid java name */
    public boolean mo359if() {
        n86.a aVar = n86.f25218try;
        return n86.f25217new;
    }

    @Override // defpackage.c96
    /* renamed from: new, reason: not valid java name */
    public void mo360new(SSLSocket sSLSocket, String str, List<? extends k56> list) {
        jp5.m8570try(sSLSocket, "sslSocket");
        jp5.m8570try(list, "protocols");
        if (mo357do(sSLSocket)) {
            Conscrypt.setUseSessionTickets(sSLSocket, true);
            Object[] array = ((ArrayList) r86.f32054for.m13169do(list)).toArray(new String[0]);
            Objects.requireNonNull(array, "null cannot be cast to non-null type kotlin.Array<T>");
            Conscrypt.setApplicationProtocols(sSLSocket, (String[]) array);
        }
    }
}
