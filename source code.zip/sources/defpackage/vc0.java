package defpackage;

/* loaded from: classes.dex */
public final class vc0 implements Runnable {
    @Override // java.lang.Runnable
    public void run() {
        if (se0.m14224if(this)) {
            return;
        }
        try {
            if (wc0.m16553do().get()) {
                return;
            }
            wc0.m16553do().set(true);
            if (se0.m14224if(wc0.class)) {
                return;
            }
            try {
                wc0.m16555if();
            } catch (Throwable th) {
                se0.m14223do(th, wc0.class);
            }
        } catch (Throwable th2) {
            se0.m14223do(th2, this);
        }
    }
}
