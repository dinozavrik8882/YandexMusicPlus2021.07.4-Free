package defpackage;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.SharedPreferences;
import android.util.Property;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.cxb;

/* loaded from: classes2.dex */
public final class hxb implements cxb.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ fxb f15815do;

    public hxb(fxb fxbVar) {
        this.f15815do = fxbVar;
    }

    @Override // cxb.a
    public void close() {
        RecyclerView.m layoutManager;
        SharedPreferences.Editor edit = ((r9d) this.f15815do.f12738this.getValue()).edit();
        jp5.m8567if(edit, "editor");
        edit.putBoolean("rup_radio_message_block_closed", true);
        edit.apply();
        mxb mxbVar = this.f15815do.f12729break;
        if (mxbVar == null || (layoutManager = mxbVar.m10655do().getLayoutManager()) == null || layoutManager.m1170finally() != 2) {
            return;
        }
        View mo1081return = layoutManager.mo1081return(0);
        View mo1081return2 = layoutManager.mo1081return(1);
        int bottom = mo1081return == null ? 0 : mo1081return.getBottom();
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(mo1081return, (Property<View, Float>) View.ALPHA, 0.0f);
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(mo1081return2, (Property<View, Float>) View.TRANSLATION_Y, -bottom);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(ofFloat, ofFloat2);
        animatorSet.setDuration(300L);
        animatorSet.addListener(new nxb(mo1081return, mo1081return2));
        animatorSet.start();
    }
}
