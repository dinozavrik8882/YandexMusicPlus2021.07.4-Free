package defpackage;

import android.content.Context;
import com.yandex.auth.sync.AccountProvider;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class w9c {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f41896do;

    /* renamed from: for, reason: not valid java name */
    public final el5 f41897for;

    /* renamed from: if, reason: not valid java name */
    public final el5 f41898if;

    /* renamed from: new, reason: not valid java name */
    public final r9d f41899new;

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(w9c.class), "clock", "getClock()Lru/yandex/music/utils/Clock;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(w9c.class), "userCenter", "getUserCenter()Lru/yandex/music/data/user/UserCenter;");
        Objects.requireNonNull(eq5Var);
        f41896do = new mr5[]{wp5Var, wp5Var2};
    }

    public w9c(Context context) {
        jp5.m8570try(context, "context");
        iz3 l3 = dn3.l3(h8d.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        mr5<Object>[] mr5VarArr = f41896do;
        jp5.m8570try(mr5VarArr[0], "prop");
        this.f41898if = dn3.h1(cz3Var);
        iz3 l32 = dn3.l3(qg9.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        bz3Var2.m2425do(l32);
        cz3 cz3Var2 = new cz3(l32);
        jp5.m8570try(cz3Var2, "provider");
        jp5.m8570try(mr5VarArr[1], "prop");
        el5 h1 = dn3.h1(cz3Var2);
        this.f41897for = h1;
        mg9 mo9658else = ((qg9) ((kl5) h1).getValue()).mo9658else();
        jp5.m8568new(mo9658else, "userCenter.latestSmallUser()");
        jp5.m8570try(context, "context");
        jp5.m8570try(mo9658else, "userData");
        jp5.m8570try("ru.yandex.music.widget.promo.SamsungDialogShowController", AccountProvider.NAME);
        this.f41899new = new r9d(context, mo9658else.getId(), "ru.yandex.music.widget.promo.SamsungDialogShowController", 0, null);
    }

    /* renamed from: do, reason: not valid java name */
    public final h8d m16461do() {
        return (h8d) this.f41898if.getValue();
    }

    /* renamed from: if, reason: not valid java name */
    public final void m16462if() {
        int i = this.f41899new.getInt("samsung_show_count_key", 0);
        this.f41899new.edit().putLong("samsung_last_time_show_key", m16461do().currentTimeMillis()).putInt("samsung_show_count_key", i + 1).apply();
    }
}
