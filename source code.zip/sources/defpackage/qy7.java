package defpackage;

import java.io.IOException;

/* loaded from: classes2.dex */
public final class qy7 implements my7 {

    /* renamed from: do, reason: not valid java name */
    public final my7 f31499do;

    /* renamed from: for, reason: not valid java name */
    public final long f31500for;

    /* renamed from: if, reason: not valid java name */
    public final int f31501if;

    /* renamed from: new, reason: not valid java name */
    public int f31502new;

    /* renamed from: try, reason: not valid java name */
    public volatile boolean f31503try;

    public qy7(my7 my7Var) {
        jp5.m8570try(my7Var, "wrappedFetcher");
        this.f31499do = my7Var;
        wx7 wx7Var = wx7.f42930do;
        this.f31501if = wx7.f42932if;
        this.f31500for = wx7.f42931for;
    }

    @Override // defpackage.my7
    public void cancel() {
        this.f31499do.cancel();
        this.f31503try = true;
    }

    @Override // defpackage.my7
    /* renamed from: do */
    public t59 mo10665do(e69 e69Var, boolean z, boolean z2) throws IOException, py7 {
        jp5.m8570try(e69Var, "track");
        do {
            this.f31502new++;
            try {
                return this.f31499do.mo10665do(e69Var, z, z2);
            } catch (IOException e) {
                e = e;
                if (!m13033if(e)) {
                    throw e;
                }
                try {
                    Thread.sleep(this.f31500for);
                } catch (InterruptedException unused) {
                    cancel();
                }
            } catch (yfa e2) {
                e = e2;
                if (!m13033if(e)) {
                    throw e;
                }
                Thread.sleep(this.f31500for);
            }
        } while (!this.f31503try);
        throw e;
    }

    /* renamed from: if, reason: not valid java name */
    public final boolean m13033if(Exception exc) {
        return (!(exc instanceof yfa) || (exc.getCause() instanceof IOException)) && !this.f31503try && this.f31502new < this.f31501if;
    }
}
