package defpackage;

/* loaded from: classes.dex */
public interface ch3 {
}
