package defpackage;

import android.net.Uri;
import defpackage.k2f;
import java.io.File;
import java.io.IOException;

/* loaded from: classes2.dex */
public final class vx7 {

    /* renamed from: do, reason: not valid java name */
    public final xy7 f41346do;

    /* renamed from: for, reason: not valid java name */
    public final xw7 f41347for;

    /* renamed from: if, reason: not valid java name */
    public final tx7 f41348if;

    public vx7(xy7 xy7Var, tx7 tx7Var, xw7 xw7Var) {
        jp5.m8570try(xy7Var, "chunkDownloaderFactory");
        jp5.m8570try(tx7Var, "storageHelper");
        jp5.m8570try(xw7Var, "chunkCacheStorage");
        this.f41346do = xy7Var;
        this.f41348if = tx7Var;
        this.f41347for = xw7Var;
    }

    /* renamed from: do, reason: not valid java name */
    public final boolean m16299do(q59 q59Var) throws InterruptedException {
        jp5.m8570try(q59Var, "cacheInfo");
        k2f.c cVar = k2f.f19768new;
        cVar.mo8764do(this + " tries to remove " + q59Var, new Object[0]);
        Uri uri = q59Var.f30177const;
        if (uri == null) {
            File m15262break = this.f41348if.m15262break(q59Var);
            if (m15262break == null) {
                return false;
            }
            boolean m13172case = r8d.m13172case(m15262break);
            cVar.mo8764do(this + " file was deleted=" + m13172case, new Object[0]);
            return m13172case;
        }
        try {
            d01<?> m17372do = this.f41346do.m17372do(uri, this.f41347for.m17365do(q59Var.f30183try), em5.f10300catch, true);
            if (m17372do == null) {
                return false;
            }
            m17372do.remove();
            cVar.mo8764do(this + " chunks were removed", new Object[0]);
            return true;
        } catch (IOException unused) {
            k2f.f19768new.mo8774this(this + " can not get cache", new Object[0]);
            return false;
        }
    }
}
