package defpackage;

/* loaded from: classes.dex */
public final class xd4 extends ud4 {
    private static final long serialVersionUID = 1;

    /* renamed from: catch, reason: not valid java name */
    public final yf4 f43635catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public xd4(yf4 yf4Var, String str) {
        super(str, null, 2);
        jp5.m8570try(yf4Var, "reason");
        this.f43635catch = yf4Var;
    }
}
