package defpackage;

import java.io.Serializable;

/* loaded from: classes2.dex */
public final class x4c implements Serializable {
    private static final long serialVersionUID = 102844961999273668L;
}
