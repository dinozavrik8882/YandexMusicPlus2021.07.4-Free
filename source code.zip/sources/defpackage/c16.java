package defpackage;

/* loaded from: classes2.dex */
public final class c16 {

    /* renamed from: do, reason: not valid java name */
    public static final d26 f4698do = new d26("NULL");

    /* renamed from: if, reason: not valid java name */
    public static final d26 f4700if = new d26("UNINITIALIZED");

    /* renamed from: for, reason: not valid java name */
    public static final d26 f4699for = new d26("DONE");
}
