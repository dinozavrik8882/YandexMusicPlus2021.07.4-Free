package defpackage;

/* loaded from: classes.dex */
public final class va4 {

    /* renamed from: do, reason: not valid java name */
    public static final int f40332do = 999 / wa4.f41921case.mo12338do().size();

    /* renamed from: if, reason: not valid java name */
    public final nx3 f40333if;

    public va4(nx3 nx3Var) {
        jp5.m8570try(nx3Var, "sqlitePerformer");
        this.f40333if = nx3Var;
    }
}
