package defpackage;

/* loaded from: classes2.dex */
public final class oke extends kp5 implements mo5<Integer, n31> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ j31 f27396catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public oke(j31 j31Var) {
        super(1);
        this.f27396catch = j31Var;
    }

    @Override // defpackage.mo5
    public n31 invoke(Integer num) {
        return this.f27396catch.f17852class.get(num.intValue());
    }
}
