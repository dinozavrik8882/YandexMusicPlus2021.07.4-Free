package defpackage;

import java.io.Serializable;

/* loaded from: classes2.dex */
public class gka<T> implements Serializable {
    private static final eka FOR_NULLABILITY = new eka();
    private static final long serialVersionUID = -2308861173762577731L;

    @qd3("invocationInfo")
    private final eka mInvocationInfo = FOR_NULLABILITY;

    @qd3("result")
    private final T mResult = null;

    @qd3("error")
    private final fka mError = null;

    /* renamed from: case, reason: not valid java name */
    public void mo6670case() {
        if (this.mError != null) {
            throw new bfa(this.mError.m6089if(), this.mError.m6088do());
        }
    }

    /* renamed from: do, reason: not valid java name */
    public fka m6671do() {
        return this.mError;
    }

    /* renamed from: for, reason: not valid java name */
    public T m6672for() {
        return this.mResult;
    }

    /* renamed from: if, reason: not valid java name */
    public boolean m6673if() {
        return this.mResult != null;
    }

    /* renamed from: new, reason: not valid java name */
    public T m6674new() {
        mo6670case();
        T t = this.mResult;
        f9d.m5797for(t, "arg is null");
        return t;
    }

    public String toString() {
        StringBuilder r = by.r("YGsonResponse{invocationInfo=");
        r.append(this.mInvocationInfo);
        r.append(", result=");
        r.append(this.mResult);
        r.append(", error=");
        r.append(this.mError);
        r.append('}');
        return r.toString();
    }
}
