package defpackage;

import android.content.Context;
import defpackage.bz3;

/* loaded from: classes2.dex */
public final class zdd extends kp5 implements mo5<bz3.a, efd> {

    /* renamed from: catch, reason: not valid java name */
    public static final zdd f47081catch = new zdd();

    public zdd() {
        super(1);
    }

    @Override // defpackage.mo5
    public efd invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        return new efd((Context) aVar2.m2427do(dn3.l3(Context.class)));
    }
}
