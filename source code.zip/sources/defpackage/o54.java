package defpackage;

/* loaded from: classes.dex */
public enum o54 {
    ADVERT("ad"),
    SHOTS("shot");

    private final String queryValue;

    o54(String str) {
        this.queryValue = str;
    }

    public final String getQueryValue$model_gplayProdRelease() {
        return this.queryValue;
    }
}
