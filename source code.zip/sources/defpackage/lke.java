package defpackage;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import ru.yandex.music.R;
import ru.yandex.taxi.coordinator.AnchorBottomSheetBehavior;

/* loaded from: classes2.dex */
public class lke extends FrameLayout implements uud, CoordinatorLayout.b {

    /* renamed from: catch, reason: not valid java name */
    public final int f22373catch;

    /* renamed from: class, reason: not valid java name */
    public final int f22374class;

    /* renamed from: const, reason: not valid java name */
    public final int f22375const;

    /* renamed from: final, reason: not valid java name */
    public final dge<Integer> f22376final;

    /* renamed from: super, reason: not valid java name */
    public final int f22377super;

    /* loaded from: classes2.dex */
    public static class a<T extends View> extends CoordinatorLayout.c<T> {

        /* renamed from: do, reason: not valid java name */
        public final int f22378do;

        /* renamed from: for, reason: not valid java name */
        public final int f22379for;

        /* renamed from: if, reason: not valid java name */
        public final int f22380if;

        /* renamed from: new, reason: not valid java name */
        public final int f22381new;

        /* renamed from: try, reason: not valid java name */
        public final dge<Integer> f22382try;

        public a(int i, int i2, int i3, int i4, dge<Integer> dgeVar) {
            this.f22378do = i;
            this.f22380if = i2;
            this.f22379for = i3;
            this.f22381new = i4;
            this.f22382try = dgeVar;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        /* renamed from: case */
        public void mo959case(CoordinatorLayout.f fVar) {
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        /* renamed from: class */
        public boolean mo961class(CoordinatorLayout coordinatorLayout, T t, int i, int i2, int i3, int i4) {
            ViewGroup.LayoutParams layoutParams = t.getLayoutParams();
            View findViewById = !(layoutParams instanceof CoordinatorLayout.f) ? null : coordinatorLayout.findViewById(((CoordinatorLayout.f) layoutParams).f1662case);
            if (findViewById == null) {
                return false;
            }
            float scaleX = findViewById.getScaleX();
            int i5 = (int) (this.f22380if * scaleX);
            dge<Integer> dgeVar = this.f22382try;
            if (dgeVar != null) {
                i5 += dgeVar.get().intValue();
            }
            t.measure(View.MeasureSpec.makeMeasureSpec(Math.round(scaleX * (this.f22378do + this.f22379for)) + findViewById.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(findViewById.getMeasuredHeight() + i5, 1073741824));
            return true;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.c
        /* renamed from: else */
        public boolean mo965else(CoordinatorLayout coordinatorLayout, T t, View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            CoordinatorLayout.c cVar = layoutParams instanceof CoordinatorLayout.f ? ((CoordinatorLayout.f) layoutParams).f1666do : null;
            if ((cVar instanceof BottomSheetBehavior) || (cVar instanceof AnchorBottomSheetBehavior)) {
                float scaleX = view.getScaleX();
                int top = view.getTop() - ((int) (this.f22380if * scaleX));
                dge<Integer> dgeVar = this.f22382try;
                if (dgeVar != null) {
                    top += dgeVar.get().intValue();
                }
                if (t.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) t.getLayoutParams();
                    marginLayoutParams.leftMargin = -((int) (this.f22378do * scaleX));
                    marginLayoutParams.rightMargin = -((int) (this.f22379for * scaleX));
                    marginLayoutParams.topMargin = top;
                    marginLayoutParams.bottomMargin = -((int) (this.f22381new * scaleX));
                }
                t.layout(view.getLeft() - ((int) (this.f22378do * scaleX)), top, view.getRight() + ((int) (this.f22379for * scaleX)), view.getBottom() + ((int) (this.f22381new * scaleX)));
            }
            return false;
        }
    }

    public lke(Context context, int i, dge<Integer> dgeVar) {
        super(context);
        this.f22373catch = (int) m15744volatile(13.0f);
        this.f22374class = (int) m15744volatile(22.0f);
        this.f22375const = (int) m15744volatile(13.0f);
        setBackgroundResource(R.drawable.modal_view_shadow_patch);
        this.f22376final = dgeVar;
        this.f22377super = i;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.b
    public CoordinatorLayout.c getBehavior() {
        return new a(this.f22373catch, this.f22374class, this.f22375const, 0, this.f22376final);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        CoordinatorLayout.f fVar = (CoordinatorLayout.f) getLayoutParams();
        fVar.f1672new = 81;
        fVar.f1669for = 49;
        int i = this.f22377super;
        fVar.f1664class = null;
        fVar.f1663catch = null;
        fVar.f1662case = i;
    }

    public void setDebounceClickListener(Runnable runnable) {
        oud.m11768goto(mo3856super(), runnable);
    }

    @Override // defpackage.uud
    public /* bridge */ /* synthetic */ void setVisible(boolean z) {
        super.setVisible(z);
    }
}
