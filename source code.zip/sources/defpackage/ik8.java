package defpackage;

@ln5(c = "ru.yandex.music.common.media.player.shared.SharedPlayerAdapterKt$playWhenReadyStateFlowIn$flow$1", f = "SharedPlayerAdapter.kt", l = {198}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class ik8 extends pn5 implements qo5<qx5<? super Boolean>, wm5<? super pl5>, Object> {

    /* renamed from: super, reason: not valid java name */
    public int f16934super;

    /* renamed from: throw, reason: not valid java name */
    public /* synthetic */ Object f16935throw;

    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ is4 f16936while;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements bo5<pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ is4 f16937catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ mo5<Boolean, pl5> f16938class;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public a(is4 is4Var, mo5<? super Boolean, pl5> mo5Var) {
            super(0);
            this.f16937catch = is4Var;
            this.f16938class = mo5Var;
        }

        @Override // defpackage.bo5
        public pl5 invoke() {
            this.f16937catch.mo7946new(this.f16938class);
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements mo5<Boolean, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ qx5<Boolean> f16939catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public b(qx5<? super Boolean> qx5Var) {
            super(1);
            this.f16939catch = qx5Var;
        }

        @Override // defpackage.mo5
        public pl5 invoke(Boolean bool) {
            dn3.C3(this.f16939catch, Boolean.valueOf(bool.booleanValue()));
            return pl5.f29126do;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ik8(is4 is4Var, wm5<? super ik8> wm5Var) {
        super(2, wm5Var);
        this.f16936while = is4Var;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        ik8 ik8Var = new ik8(this.f16936while, wm5Var);
        ik8Var.f16935throw = obj;
        return ik8Var;
    }

    @Override // defpackage.qo5
    public Object invoke(qx5<? super Boolean> qx5Var, wm5<? super pl5> wm5Var) {
        ik8 ik8Var = new ik8(this.f16936while, wm5Var);
        ik8Var.f16935throw = qx5Var;
        return ik8Var.mo76return(pl5.f29126do);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        int i = this.f16934super;
        if (i == 0) {
            dn3.N2(obj);
            qx5 qx5Var = (qx5) this.f16935throw;
            b bVar = new b(qx5Var);
            this.f16936while.mo7943for(bVar);
            a aVar = new a(this.f16936while, bVar);
            this.f16934super = 1;
            if (ox5.m11782do(qx5Var, aVar, this) == cn5Var) {
                return cn5Var;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            dn3.N2(obj);
        }
        return pl5.f29126do;
    }
}
