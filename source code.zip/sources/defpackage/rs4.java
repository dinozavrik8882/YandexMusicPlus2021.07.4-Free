package defpackage;

import android.net.Uri;
import defpackage.bs4;
import defpackage.la1;
import java.util.Collections;
import java.util.Map;

/* loaded from: classes.dex */
public final class rs4 implements qo5<String, sr4, Boolean> {

    /* renamed from: catch, reason: not valid java name */
    public final bu4 f32983catch;

    public rs4(bu4 bu4Var) {
        jp5.m8570try(bu4Var, "simpleCacheStorage");
        this.f32983catch = bu4Var;
    }

    @Override // defpackage.qo5
    /* renamed from: do, reason: not valid java name and merged with bridge method [inline-methods] */
    public Boolean invoke(String str, sr4 sr4Var) throws bs4 {
        jp5.m8570try(str, "cacheKey");
        jp5.m8570try(sr4Var, "storage");
        bb1 m2326if = this.f32983catch.m2326if(sr4Var);
        if (m2326if == null) {
            throw new bs4.e(new cu4());
        }
        int i = 6 & 2;
        cr4 cr4Var = (6 & 4) != 0 ? cr4.f7379if : null;
        jp5.m8570try(m2326if, "simpleCache");
        jp5.m8570try(cr4Var, "cacheKeyFactory");
        la1.b bVar = new la1.b();
        bVar.f21837do = m2326if;
        bVar.f21841new = cr4Var;
        bVar.f21838else = 1;
        jp5.m8568new(bVar, "Factory()\n        .setCache(simpleCache)\n        .setCacheKeyFactory(cacheKeyFactory)\n        .setFlags(CacheDataSource.FLAG_BLOCK_ON_CACHE)\n        .apply {\n            if (upstreamDataSourceFactory != null) {\n                setUpstreamDataSourceFactory(upstreamDataSourceFactory)\n            }\n        }");
        jp5.m8570try(str, "cacheKey");
        Map emptyMap = Collections.emptyMap();
        Uri fromParts = Uri.fromParts("noop", "noop", null);
        h81.m7054break(fromParts, "The uri must be set.");
        n91 n91Var = new n91(fromParts, 0L, 1, null, emptyMap, 0L, -1L, str, 1, null);
        jp5.m8568new(n91Var, "Builder()\n            .setUri(Uri.fromParts(\"noop\", \"noop\", null))\n            .setKey(cacheKey)\n            .setFlags(DataSpec.FLAG_ALLOW_GZIP)\n            .build()");
        String mo2039do = cr4Var.mo2039do(n91Var);
        jp5.m8568new(mo2039do, "cacheKeyFactory.buildCacheKey(dataSpec)");
        long cachedBytes = m2326if.getCachedBytes(mo2039do, n91Var.f25241else, n91Var.f25243goto);
        long m15999do = va1.m15999do(m2326if.getContentMetadata(mo2039do));
        return Boolean.valueOf(m15999do > 0 && m15999do == cachedBytes);
    }
}
