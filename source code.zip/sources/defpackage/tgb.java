package defpackage;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import defpackage.bhb;
import defpackage.bz3;
import defpackage.k2f;
import defpackage.pgb;
import defpackage.qo0;
import defpackage.t11;
import defpackage.tgb;
import defpackage.yo0;
import java.util.LinkedHashSet;
import java.util.Objects;
import okhttp3.OkHttpClient;
import ru.yandex.video.data.dto.VideoData;
import ru.yandex.video.ott.data.dto.VhVideoData;
import ru.yandex.video.player.ExoPlayerDelegateFactory;
import ru.yandex.video.player.PlaybackException;
import ru.yandex.video.player.PlayerObserver;
import ru.yandex.video.player.YandexPlayer;
import ru.yandex.video.player.YandexPlayerBuilder;
import ru.yandex.video.player.tracks.Track;

/* loaded from: classes2.dex */
public final class tgb<Video extends pgb> {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f37203do;

    /* renamed from: abstract, reason: not valid java name */
    public yo0 f37204abstract;

    /* renamed from: break, reason: not valid java name */
    public final gr5 f37205break;

    /* renamed from: case, reason: not valid java name */
    public boolean f37206case;

    /* renamed from: catch, reason: not valid java name */
    public boolean f37207catch;

    /* renamed from: class, reason: not valid java name */
    public boolean f37208class;

    /* renamed from: const, reason: not valid java name */
    public boolean f37209const;

    /* renamed from: continue, reason: not valid java name */
    public final d f37210continue;

    /* renamed from: default, reason: not valid java name */
    public Video f37211default;

    /* renamed from: else, reason: not valid java name */
    public Video f37212else;

    /* renamed from: extends, reason: not valid java name */
    public Long f37213extends;

    /* renamed from: final, reason: not valid java name */
    public boolean f37214final;

    /* renamed from: finally, reason: not valid java name */
    public a f37215finally;

    /* renamed from: for, reason: not valid java name */
    public final qgb<Video> f37216for;

    /* renamed from: goto, reason: not valid java name */
    public final gr5 f37217goto;

    /* renamed from: if, reason: not valid java name */
    public final Context f37218if;

    /* renamed from: import, reason: not valid java name */
    public final el5 f37219import;

    /* renamed from: native, reason: not valid java name */
    public final el5 f37220native;

    /* renamed from: new, reason: not valid java name */
    public final ngb<Video> f37221new;

    /* renamed from: package, reason: not valid java name */
    public boolean f37222package;

    /* renamed from: private, reason: not valid java name */
    public String f37223private;

    /* renamed from: public, reason: not valid java name */
    public final el5 f37224public;

    /* renamed from: return, reason: not valid java name */
    public final Handler f37225return;

    /* renamed from: static, reason: not valid java name */
    public final Runnable f37226static;

    /* renamed from: strictfp, reason: not valid java name */
    public YandexPlayer<qo0> f37227strictfp;

    /* renamed from: super, reason: not valid java name */
    public final el5 f37228super;

    /* renamed from: switch, reason: not valid java name */
    public final Runnable f37229switch;

    /* renamed from: this, reason: not valid java name */
    public final gr5 f37230this;

    /* renamed from: throw, reason: not valid java name */
    public final el5 f37231throw;

    /* renamed from: throws, reason: not valid java name */
    public Video f37232throws;

    /* renamed from: try, reason: not valid java name */
    public boolean f37233try;

    /* renamed from: volatile, reason: not valid java name */
    public final i f37234volatile;

    /* renamed from: while, reason: not valid java name */
    public final el5 f37235while;

    /* loaded from: classes2.dex */
    public enum a {
        INVISIBLE,
        EMPTY,
        LOADING,
        READY,
        BUFFERING,
        ERROR,
        ERROR_INVISIBLE
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements bo5<OkHttpClient> {

        /* renamed from: catch, reason: not valid java name */
        public static final c f37236catch = new c();

        public c() {
            super(0);
        }

        @Override // defpackage.bo5
        public OkHttpClient invoke() {
            iz3 l3 = dn3.l3(vv3.class);
            jp5.m8570try(l3, "typeSpec");
            bz3 bz3Var = bz3.f4526do;
            jp5.m8565for(bz3Var);
            jp5.m8570try(l3, "typeSpec");
            LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
            return ((vv3) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m16271do();
        }
    }

    /* loaded from: classes2.dex */
    public static final class d implements qo0.b {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ tgb<Video> f37237catch;

        public d(tgb<Video> tgbVar) {
            this.f37237catch = tgbVar;
        }

        @Override // qo0.b
        /* renamed from: do */
        public void mo4400do(vn0 vn0Var) {
            jp5.m8570try(vn0Var, "error");
            k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: onPlayerError ", vn0Var), new Object[0]);
            this.f37237catch.m14934break(a.ERROR);
        }

        @Override // qo0.b
        /* renamed from: native */
        public void mo4401native(boolean z, int i) {
            k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: onPlayerStateChanged ", Integer.valueOf(i)), new Object[0]);
            tgb<Video> tgbVar = this.f37237catch;
            a aVar = tgbVar.f37215finally;
            if ((aVar == a.LOADING || aVar == a.BUFFERING) && i == 3) {
                tgbVar.m14934break(a.READY);
            } else if (aVar == a.READY && i == 2) {
                tgbVar.m14934break(a.BUFFERING);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class e extends kp5 implements bo5<pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ tgb<Video> f37238catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(tgb<Video> tgbVar) {
            super(0);
            this.f37238catch = tgbVar;
        }

        @Override // defpackage.bo5
        public pl5 invoke() {
            String mo7304do;
            this.f37238catch.m14943this();
            this.f37238catch.m14942new();
            boolean m11550do = ((ogb) this.f37238catch.f37224public.getValue()).m11550do();
            Video video = this.f37238catch.f37212else;
            pl5 pl5Var = null;
            if (video != null && (mo7304do = video.mo7304do()) != null) {
                if (!m11550do) {
                    mo7304do = null;
                }
                if (mo7304do != null) {
                    this.f37238catch.m14934break(a.LOADING);
                    pl5Var = pl5.f29126do;
                }
            }
            if (pl5Var == null) {
                this.f37238catch.m14939for(m11550do);
            }
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class f extends kp5 implements bo5<pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ tgb<Video> f37239catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(tgb<Video> tgbVar) {
            super(0);
            this.f37239catch = tgbVar;
        }

        @Override // defpackage.bo5
        public pl5 invoke() {
            this.f37239catch.m14943this();
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class i implements PlayerObserver<qo0> {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ tgb<Video> f37240do;

        /* loaded from: classes2.dex */
        public static final class a extends kp5 implements bo5<pl5> {

            /* renamed from: catch, reason: not valid java name */
            public final /* synthetic */ tgb<Video> f37241catch;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(tgb<Video> tgbVar) {
                super(0);
                this.f37241catch = tgbVar;
            }

            @Override // defpackage.bo5
            public pl5 invoke() {
                tgb<Video> tgbVar = this.f37241catch;
                a aVar = tgbVar.f37215finally;
                if (aVar == a.BUFFERING || aVar == a.LOADING) {
                    tgbVar.m14934break(a.READY);
                }
                return pl5.f29126do;
            }
        }

        /* loaded from: classes2.dex */
        public static final class b extends kp5 implements bo5<pl5> {

            /* renamed from: catch, reason: not valid java name */
            public final /* synthetic */ tgb<Video> f37242catch;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public b(tgb<Video> tgbVar) {
                super(0);
                this.f37242catch = tgbVar;
            }

            @Override // defpackage.bo5
            public pl5 invoke() {
                tgb<Video> tgbVar = this.f37242catch;
                if (tgbVar.f37215finally == a.READY) {
                    tgbVar.m14934break(a.BUFFERING);
                }
                return pl5.f29126do;
            }
        }

        /* loaded from: classes2.dex */
        public static final class c extends kp5 implements bo5<pl5> {

            /* renamed from: catch, reason: not valid java name */
            public final /* synthetic */ tgb<Video> f37243catch;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(tgb<Video> tgbVar) {
                super(0);
                this.f37243catch = tgbVar;
            }

            @Override // defpackage.bo5
            public pl5 invoke() {
                tgb<Video> tgbVar = this.f37243catch;
                a aVar = a.ERROR;
                mr5<Object>[] mr5VarArr = tgb.f37203do;
                tgbVar.m14934break(aVar);
                return pl5.f29126do;
            }
        }

        public i(tgb<Video> tgbVar) {
            this.f37240do = tgbVar;
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onContentDurationChanged(long j) {
            PlayerObserver.DefaultImpls.onContentDurationChanged(this, j);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onFirstFrame() {
            PlayerObserver.DefaultImpls.onFirstFrame(this);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onHidedPlayerReady(qo0 qo0Var) {
            qo0 qo0Var2 = qo0Var;
            jp5.m8570try(qo0Var2, "hidedPlayer");
            PlayerObserver.DefaultImpls.onHidedPlayerReady(this, qo0Var2);
            k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: onHidedPlayerReady ", Thread.currentThread()), new Object[0]);
            dn3.X1(new vgb(this.f37240do, qo0Var2));
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onLoadingFinished() {
            k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: onLoadingFinished ", Thread.currentThread()), new Object[0]);
            PlayerObserver.DefaultImpls.onLoadingFinished(this);
            dn3.X1(new a(this.f37240do));
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onLoadingStart() {
            PlayerObserver.DefaultImpls.onLoadingStart(this);
            k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: onLoadingStart ", Thread.currentThread()), new Object[0]);
            dn3.X1(new b(this.f37240do));
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onPausePlayback() {
            PlayerObserver.DefaultImpls.onPausePlayback(this);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onPlaybackEnded() {
            PlayerObserver.DefaultImpls.onPlaybackEnded(this);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onPlaybackError(PlaybackException playbackException) {
            jp5.m8570try(playbackException, "playbackException");
            PlayerObserver.DefaultImpls.onPlaybackError(this, playbackException);
            k2f.f19768new.mo8764do("VideoShotCover: onPlayerError " + playbackException + ' ' + Thread.currentThread(), new Object[0]);
            dn3.X1(new c(this.f37240do));
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onPlaybackProgress(long j) {
            PlayerObserver.DefaultImpls.onPlaybackProgress(this, j);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onPlaybackSpeedChanged(float f, boolean z) {
            PlayerObserver.DefaultImpls.onPlaybackSpeedChanged(this, f, z);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onReadyForFirstPlayback() {
            PlayerObserver.DefaultImpls.onReadyForFirstPlayback(this);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onResumePlayback() {
            PlayerObserver.DefaultImpls.onResumePlayback(this);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onSeek(long j, long j2) {
            PlayerObserver.DefaultImpls.onSeek(this, j, j2);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onTimelineLeftEdgeChanged(long j) {
            PlayerObserver.DefaultImpls.onTimelineLeftEdgeChanged(this, j);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onTracksChanged(Track track, Track track2, Track track3) {
            PlayerObserver.DefaultImpls.onTracksChanged(this, track, track2, track3);
        }

        @Override // ru.yandex.video.player.PlayerObserver
        public void onVideoSizeChanged(int i, int i2) {
            PlayerObserver.DefaultImpls.onVideoSizeChanged(this, i, i2);
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[9];
        wp5 wp5Var = new wp5(dq5.m4763do(tgb.class), "videoShotCache", "getVideoShotCache()Lru/yandex/music/player/videoshots/VideoShotCache;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        mr5VarArr[3] = wp5Var;
        wp5 wp5Var2 = new wp5(dq5.m4763do(tgb.class), "connectivityBox", "getConnectivityBox()Lru/yandex/music/network/connectivity/ConnectivityBox;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[4] = wp5Var2;
        wp5 wp5Var3 = new wp5(dq5.m4763do(tgb.class), "yandexPlayerProvider", "getYandexPlayerProvider()Lru/yandex/music/player/videoshots/YandexPlayerProvider;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[6] = wp5Var3;
        wp5 wp5Var4 = new wp5(dq5.m4763do(tgb.class), "clock", "getClock()Lru/yandex/music/utils/Clock;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[7] = wp5Var4;
        wp5 wp5Var5 = new wp5(dq5.m4763do(tgb.class), "videoSettings", "getVideoSettings()Lru/yandex/music/player/videoshots/VideoShotSettings;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[8] = wp5Var5;
        f37203do = mr5VarArr;
    }

    public tgb(Context context, qgb<Video> qgbVar, ngb<Video> ngbVar) {
        jp5.m8570try(context, "context");
        jp5.m8570try(qgbVar, "videoShotView");
        jp5.m8570try(ngbVar, "reporter");
        this.f37218if = context;
        this.f37216for = qgbVar;
        this.f37221new = ngbVar;
        this.f37217goto = new mp5(qgbVar) { // from class: tgb.b
            @Override // defpackage.jr5
            public Object get() {
                return Float.valueOf(1.0f - ((qgb) this.receiver).f30579if.getAlpha());
            }

            @Override // defpackage.gr5
            public void set(Object obj) {
                qgb qgbVar2 = (qgb) this.receiver;
                float floatValue = ((Number) obj).floatValue();
                qgbVar2.f30579if.setAlpha(1.0f - floatValue);
                View view = qgbVar2.f30580new;
                if (view == null) {
                    return;
                }
                view.setAlpha(floatValue);
            }
        };
        this.f37230this = new mp5(qgbVar) { // from class: tgb.h
            @Override // defpackage.jr5
            public Object get() {
                return ((qgb) this.receiver).f30582try;
            }

            @Override // defpackage.gr5
            public void set(Object obj) {
                qgb qgbVar2 = (qgb) this.receiver;
                mo5<? super Float, pl5> mo5Var = (mo5) obj;
                Objects.requireNonNull(qgbVar2);
                jp5.m8570try(mo5Var, "<set-?>");
                qgbVar2.f30582try = mo5Var;
            }
        };
        this.f37205break = new mp5(qgbVar) { // from class: tgb.g
            @Override // defpackage.jr5
            public Object get() {
                return ((qgb) this.receiver).f30572case;
            }

            @Override // defpackage.gr5
            public void set(Object obj) {
                qgb qgbVar2 = (qgb) this.receiver;
                qo5<? super T, ? super Boolean, pl5> qo5Var = (qo5) obj;
                Objects.requireNonNull(qgbVar2);
                jp5.m8570try(qo5Var, "<set-?>");
                qgbVar2.f30572case = qo5Var;
            }
        };
        this.f37208class = true;
        iz3 l3 = dn3.l3(igb.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        mr5<Object>[] mr5VarArr = f37203do;
        jp5.m8570try(mr5VarArr[3], "prop");
        this.f37228super = dn3.h1(cz3Var);
        iz3 l32 = dn3.l3(wga.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        bz3Var2.m2425do(l32);
        cz3 cz3Var2 = new cz3(l32);
        jp5.m8570try(cz3Var2, "provider");
        jp5.m8570try(mr5VarArr[4], "prop");
        this.f37231throw = dn3.h1(cz3Var2);
        this.f37235while = dn3.h1(c.f37236catch);
        iz3 l33 = dn3.l3(bhb.class);
        jp5.m8570try(l33, "typeSpec");
        bz3 bz3Var3 = bz3.f4526do;
        jp5.m8565for(bz3Var3);
        bz3Var3.m2425do(l33);
        cz3 cz3Var3 = new cz3(l33);
        jp5.m8570try(cz3Var3, "provider");
        jp5.m8570try(mr5VarArr[6], "prop");
        this.f37219import = dn3.h1(cz3Var3);
        iz3 l34 = dn3.l3(h8d.class);
        jp5.m8570try(l34, "typeSpec");
        bz3 bz3Var4 = bz3.f4526do;
        jp5.m8565for(bz3Var4);
        bz3Var4.m2425do(l34);
        cz3 cz3Var4 = new cz3(l34);
        jp5.m8570try(cz3Var4, "provider");
        jp5.m8570try(mr5VarArr[7], "prop");
        this.f37220native = dn3.h1(cz3Var4);
        iz3 l35 = dn3.l3(ogb.class);
        jp5.m8570try(l35, "typeSpec");
        bz3 bz3Var5 = bz3.f4526do;
        jp5.m8565for(bz3Var5);
        bz3Var5.m2425do(l35);
        cz3 cz3Var5 = new cz3(l35);
        jp5.m8570try(cz3Var5, "provider");
        jp5.m8570try(mr5VarArr[8], "prop");
        this.f37224public = dn3.h1(cz3Var5);
        this.f37225return = new Handler(Looper.getMainLooper());
        this.f37226static = new Runnable() { // from class: agb
            @Override // java.lang.Runnable
            public final void run() {
                tgb tgbVar = tgb.this;
                jp5.m8570try(tgbVar, "this$0");
                tgbVar.m14934break(tgb.a.ERROR);
            }
        };
        this.f37229switch = new Runnable() { // from class: zfb
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.lang.Runnable
            public final void run() {
                tgb tgbVar = tgb.this;
                jp5.m8570try(tgbVar, "this$0");
                Video video = tgbVar.f37212else;
                if (video == 0) {
                    return;
                }
                tgbVar.f37232throws = video;
                qgb<Video> qgbVar2 = tgbVar.f37216for;
                Objects.requireNonNull(qgbVar2);
                jp5.m8570try(video, "videoShotUrl");
                qgbVar2.f30572case.invoke(video, Boolean.TRUE);
            }
        };
        this.f37215finally = a.INVISIBLE;
        this.f37210continue = new d(this);
        this.f37234volatile = new i(this);
    }

    /* renamed from: break, reason: not valid java name */
    public final void m14934break(a aVar) {
        String str;
        k2f.c cVar = k2f.f19768new;
        cVar.mo8764do(jp5.m8559break("VideoShotCover: switchState ", aVar), new Object[0]);
        this.f37215finally = aVar;
        switch (aVar) {
            case INVISIBLE:
                m14942new();
                m14943this();
                this.f37216for.m12722for(false);
                m14941if();
                return;
            case EMPTY:
                this.f37216for.m12722for(true);
                this.f37216for.m12724new(new e(this));
                return;
            case LOADING:
                this.f37216for.m12722for(true);
                qgb.m12720try(this.f37216for, null, 1);
                Video video = this.f37212else;
                if (video == null || (str = video.mo7304do()) == null) {
                    str = null;
                } else {
                    m14939for(true);
                    if (this.f37222package) {
                        this.f37225return.removeCallbacks(this.f37229switch);
                        this.f37225return.postDelayed(this.f37229switch, 1000L);
                    } else {
                        m14937do();
                    }
                    cVar.mo8764do(jp5.m8559break("VideoShotCover: preparePlayer ", str), new Object[0]);
                    if (!jp5.m8563do(this.f37223private, str)) {
                        this.f37223private = str;
                        if (this.f37204abstract == null && this.f37227strictfp == null) {
                            iz3 l3 = dn3.l3(v14.class);
                            jp5.m8570try(l3, "typeSpec");
                            bz3 bz3Var = bz3.f4526do;
                            jp5.m8565for(bz3Var);
                            jp5.m8570try(l3, "typeSpec");
                            LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
                            boolean m13409else = ((ahb) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(ahb.class))).m13409else();
                            this.f37209const = m13409else;
                            cVar.mo8764do(jp5.m8559break("VideoShotCover: initializePlayer yandexPlayer: ", Boolean.valueOf(m13409else)), new Object[0]);
                            if (this.f37209const) {
                                bhb bhbVar = (bhb) this.f37219import.getValue();
                                ugb ugbVar = ugb.f38843catch;
                                Objects.requireNonNull(bhbVar);
                                jp5.m8570try(ugbVar, "mediaSourceModifier");
                                YandexPlayer<qo0> build = new YandexPlayerBuilder().context(bhbVar.f3603do).playerDelegateFactory(new ExoPlayerDelegateFactory(bhbVar.f3603do, null, new bhb.b(bhbVar.f3605if, ugbVar), null, null, null, null, null, false, false, 0, null, false, false, 15866, null)).playerStrategyFactory(bhbVar.f3604for).build();
                                build.setVolume(0.0f);
                                build.addObserver(this.f37234volatile);
                                this.f37227strictfp = build;
                            } else {
                                Context context = this.f37218if;
                                yo0 m17683do = new yo0.b(context, new un0(context), new ns0()).m17683do();
                                jp5.m8568new(m17683do, "Builder(context).build()");
                                m17683do.w(0.0f);
                                m17683do.mo12841public(this.f37210continue);
                                this.f37216for.m12723if(m17683do);
                                this.f37204abstract = m17683do;
                            }
                        }
                        if (this.f37209const) {
                            YandexPlayer<qo0> yandexPlayer = this.f37227strictfp;
                            if (yandexPlayer != null) {
                                yandexPlayer.prepare((VideoData) new VhVideoData(str, "", 0L, null, null, null, 60, null), (Long) null, false);
                            }
                        } else {
                            yo0 yo0Var = this.f37204abstract;
                            if (yo0Var != null) {
                                Context context2 = this.f37218if;
                                OkHttpClient okHttpClient = (OkHttpClient) this.f37235while.getValue();
                                wga wgaVar = (wga) this.f37231throw.getValue();
                                Uri parse = Uri.parse(str);
                                jp5.m8568new(parse, "parse(url)");
                                ja1 ja1Var = (ja1) ((igb) this.f37228super.getValue()).f16767if.getValue();
                                jp5.m8570try(context2, "context");
                                jp5.m8570try(okHttpClient, "okHttpClient");
                                jp5.m8570try(wgaVar, "connectivityBox");
                                jp5.m8570try(parse, "uri");
                                jp5.m8570try(ja1Var, "cache");
                                t11.b bVar = new t11.b(new ma1(ja1Var, new ejb(wgaVar, new r91(context2, new is0(okHttpClient))), 0));
                                bVar.f36462try = new gjb(null, 1);
                                jp5.m8568new(bVar, "when {\n            //DashMediaSource.Factory(dataSourceFactory)\n            //HlsMediaSource.Factory(dataSourceFactory)\n            else -> ProgressiveMediaSource.Factory(dataSourceFactory)\n        }\n            .setLoadErrorHandlingPolicy(ConnectivityBoxLoadErrorHandingPolicy())");
                                yo0Var.q(new h11(bVar.m14564try(parse)), true);
                            }
                        }
                    }
                }
                if (str == null) {
                    by.N("No playable to load", null, 2);
                    m14934break(a.EMPTY);
                    return;
                }
                return;
            case READY:
                m14936catch();
                m14942new();
                m14937do();
                this.f37225return.removeCallbacks(this.f37226static);
                if (!this.f37207catch && !this.f37222package) {
                    qgb.m12720try(this.f37216for, null, 1);
                    return;
                }
                qgb<Video> qgbVar = this.f37216for;
                sgb sgbVar = sgb.f35409catch;
                Objects.requireNonNull(qgbVar);
                jp5.m8570try(sgbVar, "listener");
                qgbVar.m12721do(1.0f, sgbVar);
                return;
            case BUFFERING:
                m14936catch();
                m14942new();
                this.f37225return.postDelayed(this.f37226static, 3000L);
                if (!this.f37207catch && !this.f37222package) {
                    qgb.m12720try(this.f37216for, null, 1);
                    return;
                }
                qgb<Video> qgbVar2 = this.f37216for;
                sgb sgbVar2 = sgb.f35409catch;
                Objects.requireNonNull(qgbVar2);
                jp5.m8570try(sgbVar2, "listener");
                qgbVar2.m12721do(1.0f, sgbVar2);
                return;
            case ERROR:
                m14942new();
                this.f37216for.m12722for(true);
                this.f37216for.m12724new(new f(this));
                return;
            case ERROR_INVISIBLE:
                this.f37216for.m12722for(false);
                m14941if();
                return;
            default:
                return;
        }
    }

    /* renamed from: case, reason: not valid java name */
    public final void m14935case(boolean z) {
        this.f37206case = z;
        k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: updatePlaybackStatus ", Boolean.valueOf(z)), new Object[0]);
        if (this.f37222package == z) {
            return;
        }
        this.f37222package = z;
        a aVar = this.f37215finally;
        if (aVar == a.READY || aVar == a.BUFFERING) {
            m14934break(aVar);
        }
    }

    /* renamed from: catch, reason: not valid java name */
    public final void m14936catch() {
        if (!this.f37209const) {
            yo0 yo0Var = this.f37204abstract;
            if (yo0Var != null) {
                yo0Var.mo12839package(this.f37222package);
            }
        } else if (this.f37222package) {
            YandexPlayer<qo0> yandexPlayer = this.f37227strictfp;
            if (yandexPlayer != null) {
                yandexPlayer.play();
            }
        } else {
            YandexPlayer<qo0> yandexPlayer2 = this.f37227strictfp;
            if (yandexPlayer2 != null) {
                yandexPlayer2.pause();
            }
        }
        boolean z = this.f37222package;
        if (this.f37208class) {
            this.f37216for.f30575do.setKeepScreenOn(z);
        }
    }

    /* renamed from: do, reason: not valid java name */
    public final void m14937do() {
        this.f37225return.removeCallbacks(this.f37229switch);
        Video video = this.f37232throws;
        if (video == null) {
            return;
        }
        qgb<Video> qgbVar = this.f37216for;
        Objects.requireNonNull(qgbVar);
        jp5.m8570try(video, "videoShotUrl");
        qgbVar.f30572case.invoke(video, Boolean.FALSE);
    }

    /* renamed from: else, reason: not valid java name */
    public final void m14938else(Video video) {
        if (jp5.m8563do(this.f37212else, video)) {
            return;
        }
        this.f37212else = video;
        k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: updateVideoShotUrl ", video), new Object[0]);
        a aVar = a.EMPTY;
        if (xl5.m17189strictfp(aVar, a.LOADING, a.READY, a.BUFFERING, a.ERROR).contains(this.f37215finally)) {
            m14934break(aVar);
        }
        if (this.f37215finally == a.ERROR_INVISIBLE) {
            m14934break(a.INVISIBLE);
        }
    }

    /* renamed from: for, reason: not valid java name */
    public final void m14939for(boolean z) {
        Video video = this.f37212else;
        if (video != null && this.f37214final) {
            this.f37221new.mo5200catch(video, z);
        }
    }

    /* renamed from: goto, reason: not valid java name */
    public final void m14940goto(boolean z) {
        this.f37233try = z;
        k2f.f19768new.mo8764do(jp5.m8559break("VideoShotCover: setVisible ", Boolean.valueOf(z)), new Object[0]);
        Video video = this.f37212else;
        if (video != null) {
            if (this.f37233try) {
                this.f37221new.mo5202throw(video);
            } else {
                this.f37221new.mo5201return(video);
            }
        }
        if (z && this.f37215finally == a.INVISIBLE) {
            m14934break(a.EMPTY);
            return;
        }
        if (z && this.f37215finally == a.ERROR_INVISIBLE) {
            m14934break(a.ERROR);
            return;
        }
        if (z) {
            return;
        }
        int ordinal = this.f37215finally.ordinal();
        a aVar = null;
        if (ordinal != 0) {
            if (ordinal == 5) {
                aVar = a.ERROR_INVISIBLE;
            } else if (ordinal != 6) {
                aVar = a.INVISIBLE;
            }
        }
        if (aVar == null) {
            return;
        }
        m14934break(aVar);
    }

    /* renamed from: if, reason: not valid java name */
    public final void m14941if() {
        k2f.f19768new.mo8764do("VideoShotCover: releasePlayer", new Object[0]);
        yo0 yo0Var = this.f37204abstract;
        if (yo0Var != null) {
            yo0Var.f45869const.mo12846throws(this.f37210continue);
        }
        yo0 yo0Var2 = this.f37204abstract;
        if (yo0Var2 != null) {
            yo0Var2.release();
        }
        this.f37204abstract = null;
        this.f37216for.m12723if(null);
        YandexPlayer<qo0> yandexPlayer = this.f37227strictfp;
        if (yandexPlayer != null) {
            yandexPlayer.removeObserver(this.f37234volatile);
        }
        YandexPlayer<qo0> yandexPlayer2 = this.f37227strictfp;
        if (yandexPlayer2 != null) {
            yandexPlayer2.release();
        }
        this.f37227strictfp = null;
    }

    /* renamed from: new, reason: not valid java name */
    public final void m14942new() {
        Long l;
        if (this.f37214final && this.f37222package && xl5.m17189strictfp(a.READY, a.BUFFERING).contains(this.f37215finally)) {
            Video video = this.f37212else;
            if (video != null) {
                this.f37221new.mo5204while(video);
                this.f37213extends = Long.valueOf(((h8d) this.f37220native.getValue()).currentTimeMillis());
            }
            this.f37211default = this.f37212else;
            return;
        }
        Video video2 = this.f37211default;
        if (video2 != null && (l = this.f37213extends) != null) {
            this.f37221new.mo5203try(video2, ((h8d) this.f37220native.getValue()).currentTimeMillis() - l.longValue());
        }
        this.f37211default = null;
        this.f37213extends = null;
    }

    /* renamed from: this, reason: not valid java name */
    public final void m14943this() {
        k2f.f19768new.mo8764do("VideoShotCover: stopPlayer", new Object[0]);
        m14937do();
        yo0 yo0Var = this.f37204abstract;
        if (yo0Var != null) {
            yo0Var.mo12832final(true);
        }
        YandexPlayer<qo0> yandexPlayer = this.f37227strictfp;
        if (yandexPlayer != null) {
            yandexPlayer.stop();
        }
        this.f37223private = null;
        this.f37225return.removeCallbacks(this.f37226static);
    }

    /* renamed from: try, reason: not valid java name */
    public final void m14944try(boolean z) {
        if (this.f37214final == z) {
            return;
        }
        this.f37214final = z;
        if (!z) {
            if (this.f37222package && xl5.m17189strictfp(a.READY, a.BUFFERING).contains(this.f37215finally)) {
                m14942new();
                return;
            }
            return;
        }
        a aVar = a.READY;
        a aVar2 = a.BUFFERING;
        if (xl5.m17189strictfp(a.EMPTY, a.LOADING, aVar, aVar2).contains(this.f37215finally)) {
            m14939for(((ogb) this.f37224public.getValue()).m11550do());
        }
        if (this.f37222package && xl5.m17189strictfp(aVar, aVar2).contains(this.f37215finally)) {
            m14942new();
        }
    }
}
