package defpackage;

import defpackage.f90;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

/* loaded from: classes.dex */
public class g90 implements f90.d {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ ArrayList f13253do;

    public g90(f90 f90Var, ArrayList arrayList) {
        this.f13253do = arrayList;
    }

    @Override // f90.d
    /* renamed from: do */
    public void mo5776do(String str, String str2) throws IOException {
        this.f13253do.add(String.format(Locale.US, "%s=%s", str, URLEncoder.encode(str2, "UTF-8")));
    }
}
