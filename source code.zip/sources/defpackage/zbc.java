package defpackage;

import defpackage.acc;

/* loaded from: classes2.dex */
public final class zbc implements acc.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ ybc f47015do;

    public zbc(ybc ybcVar) {
        this.f47015do = ybcVar;
    }

    @Override // acc.a
    /* renamed from: do */
    public void mo488do() {
        this.f47015do.m17561if();
    }
}
