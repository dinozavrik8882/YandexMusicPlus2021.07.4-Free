package defpackage;

/* loaded from: classes2.dex */
public abstract class z6e {

    /* renamed from: do, reason: not valid java name */
    public final String f46768do;

    /* loaded from: classes2.dex */
    public static final class a extends z6e {

        /* renamed from: case, reason: not valid java name */
        public final boolean f46769case;

        /* renamed from: else, reason: not valid java name */
        public final String f46770else;

        /* renamed from: for, reason: not valid java name */
        public final String f46771for;

        /* renamed from: if, reason: not valid java name */
        public final String f46772if;

        /* renamed from: new, reason: not valid java name */
        public final Boolean f46773new;

        /* renamed from: try, reason: not valid java name */
        public final boolean f46774try;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(String str, String str2, Boolean bool, boolean z, boolean z2, String str3) {
            super(str, null);
            jp5.m8570try(str2, "optionId");
            this.f46772if = str;
            this.f46771for = str2;
            this.f46773new = bool;
            this.f46774try = z;
            this.f46769case = z2;
            this.f46770else = str3;
        }

        @Override // defpackage.z6e
        /* renamed from: do */
        public String mo17869do() {
            return this.f46772if;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return jp5.m8563do(this.f46772if, aVar.f46772if) && jp5.m8563do(this.f46771for, aVar.f46771for) && jp5.m8563do(this.f46773new, aVar.f46773new) && this.f46774try == aVar.f46774try && this.f46769case == aVar.f46769case && jp5.m8563do(this.f46770else, aVar.f46770else);
        }

        /* JADX WARN: Multi-variable type inference failed */
        public int hashCode() {
            String str = this.f46772if;
            int hashCode = (str != null ? str.hashCode() : 0) * 31;
            String str2 = this.f46771for;
            int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
            Boolean bool = this.f46773new;
            int hashCode3 = (hashCode2 + (bool != null ? bool.hashCode() : 0)) * 31;
            boolean z = this.f46774try;
            int i = z;
            if (z != 0) {
                i = 1;
            }
            int i2 = (hashCode3 + i) * 31;
            boolean z2 = this.f46769case;
            int i3 = (i2 + (z2 ? 1 : z2 ? 1 : 0)) * 31;
            String str3 = this.f46770else;
            return i3 + (str3 != null ? str3.hashCode() : 0);
        }

        public String toString() {
            StringBuilder r = by.r("ChangeOptionStatusResponse(trackId=");
            r.append(this.f46772if);
            r.append(", optionId=");
            r.append(this.f46771for);
            r.append(", currentStatus=");
            r.append(this.f46773new);
            r.append(", disabled=");
            r.append(this.f46774try);
            r.append(", show=");
            r.append(this.f46769case);
            r.append(", errorMessage=");
            return by.e(r, this.f46770else, ")");
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends z6e {

        /* renamed from: case, reason: not valid java name */
        public final boolean f46775case;

        /* renamed from: for, reason: not valid java name */
        public final String f46776for;

        /* renamed from: if, reason: not valid java name */
        public final String f46777if;

        /* renamed from: new, reason: not valid java name */
        public final Boolean f46778new;

        /* renamed from: try, reason: not valid java name */
        public final boolean f46779try;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(String str, String str2, Boolean bool, boolean z, boolean z2) {
            super(str, null);
            jp5.m8570try(str2, "optionId");
            this.f46777if = str;
            this.f46776for = str2;
            this.f46778new = bool;
            this.f46779try = z;
            this.f46775case = z2;
        }

        @Override // defpackage.z6e
        /* renamed from: do */
        public String mo17869do() {
            return this.f46777if;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return jp5.m8563do(this.f46777if, bVar.f46777if) && jp5.m8563do(this.f46776for, bVar.f46776for) && jp5.m8563do(this.f46778new, bVar.f46778new) && this.f46779try == bVar.f46779try && this.f46775case == bVar.f46775case;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public int hashCode() {
            String str = this.f46777if;
            int hashCode = (str != null ? str.hashCode() : 0) * 31;
            String str2 = this.f46776for;
            int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
            Boolean bool = this.f46778new;
            int hashCode3 = (hashCode2 + (bool != null ? bool.hashCode() : 0)) * 31;
            boolean z = this.f46779try;
            int i = z;
            if (z != 0) {
                i = 1;
            }
            int i2 = (hashCode3 + i) * 31;
            boolean z2 = this.f46775case;
            return i2 + (z2 ? 1 : z2 ? 1 : 0);
        }

        public String toString() {
            StringBuilder r = by.r("OptionStatusResponse(trackId=");
            r.append(this.f46777if);
            r.append(", optionId=");
            r.append(this.f46776for);
            r.append(", currentStatus=");
            r.append(this.f46778new);
            r.append(", disabled=");
            r.append(this.f46779try);
            r.append(", show=");
            return by.k(r, this.f46775case, ")");
        }
    }

    public z6e(String str, ep5 ep5Var) {
        this.f46768do = str;
    }

    /* renamed from: do, reason: not valid java name */
    public String mo17869do() {
        return this.f46768do;
    }
}
