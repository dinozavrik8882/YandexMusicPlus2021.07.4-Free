package defpackage;

/* loaded from: classes2.dex */
public final class tbc {

    /* renamed from: do, reason: not valid java name */
    public ycc f36954do;

    /* renamed from: if, reason: not valid java name */
    public ycc f36956if = ycc.TRENDS;

    /* renamed from: for, reason: not valid java name */
    public zcc f36955for = zcc.KEYBOARD;

    /* renamed from: do, reason: not valid java name */
    public static final String m14844do(tbc tbcVar) {
        StringBuilder r = by.r("curr = ");
        r.append(tbcVar.f36956if);
        r.append(", prev = ");
        r.append(tbcVar.f36954do);
        return r.toString();
    }

    /* renamed from: for, reason: not valid java name */
    public final void m14845for(zcc zccVar) {
        jp5.m8570try(zccVar, "inputType");
        this.f36955for = zccVar;
        k2f.f19768new.mo8764do(jp5.m8559break("saveInputType ", zccVar), new Object[0]);
    }

    /* renamed from: if, reason: not valid java name */
    public final void m14846if(ycc yccVar) {
        jp5.m8570try(yccVar, "from");
        ycc yccVar2 = this.f36956if;
        if (yccVar2 == yccVar) {
            k2f.f19768new.mo8764do("skip save", new Object[0]);
        } else {
            this.f36954do = yccVar2;
            this.f36956if = yccVar;
            k2f.f19768new.mo8764do(jp5.m8559break("save ", m14844do(this)), new Object[0]);
        }
    }
}
