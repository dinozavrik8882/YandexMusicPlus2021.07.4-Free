package defpackage;

import android.content.Context;

/* loaded from: classes.dex */
public final class ix {

    /* renamed from: do, reason: not valid java name */
    public final Context f17493do;

    /* renamed from: if, reason: not valid java name */
    public final jx f17494if;

    public ix(Context context, sw swVar) {
        this.f17493do = context;
        this.f17494if = new jx(this, swVar, null);
    }

    /* renamed from: do, reason: not valid java name */
    public final void m7984do() {
        jx jxVar = this.f17494if;
        Context context = this.f17493do;
        if (!jxVar.f19461if) {
            ti2.m14992case("BillingBroadcastManager", "Receiver is not registered.");
        } else {
            context.unregisterReceiver(jxVar.f19460for.f17494if);
            jxVar.f19461if = false;
        }
    }
}
