package defpackage;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.media.MediaBrowserCompat;
import defpackage.tj;
import java.util.List;

/* loaded from: classes.dex */
public class vj extends tj.i<List<MediaBrowserCompat.MediaItem>> {

    /* renamed from: case, reason: not valid java name */
    public final /* synthetic */ f3 f40648case;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public vj(tj tjVar, Object obj, f3 f3Var) {
        super(obj);
        this.f40648case = f3Var;
    }

    @Override // tj.i
    /* renamed from: new */
    public void mo616new(List<MediaBrowserCompat.MediaItem> list) {
        List<MediaBrowserCompat.MediaItem> list2 = list;
        if ((this.f37333try & 4) != 0 || list2 == null) {
            this.f40648case.m5585for(-1, null);
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putParcelableArray("search_results", (Parcelable[]) list2.toArray(new MediaBrowserCompat.MediaItem[0]));
        this.f40648case.m5585for(0, bundle);
    }
}
