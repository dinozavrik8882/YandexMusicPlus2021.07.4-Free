package defpackage;

import android.support.v4.media.MediaBrowserCompat;

/* JADX INFO: Add missing generic type declarations: [T] */
/* loaded from: classes2.dex */
public final class nh8<T> extends kp5 implements mo5<T, hl5<? extends T, ? extends MediaBrowserCompat.MediaItem>> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ d f25506catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public nh8(d dVar) {
        super(1);
        this.f25506catch = dVar;
    }

    @Override // defpackage.mo5
    public Object invoke(Object obj) {
        jp5.m8570try(obj, "it");
        return new hl5(obj, this.f25506catch.f7726goto.mo7831do((l59) obj, "phonoteka"));
    }
}
