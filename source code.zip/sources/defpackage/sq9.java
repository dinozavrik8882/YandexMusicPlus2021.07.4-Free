package defpackage;

import android.content.Context;
import android.content.Intent;
import defpackage.bz3;
import defpackage.g2d;
import defpackage.j7d;
import defpackage.xq9;
import java.util.LinkedHashSet;
import ru.yandex.music.kids.KidsCatalogActivity;
import ru.yandex.music.main.MainScreenActivity;
import ru.yandex.music.url.ui.StubActivity;

/* loaded from: classes2.dex */
public final class sq9 implements e3d<tq9, pl5> {
    @Override // defpackage.e3d
    /* renamed from: do */
    public Intent mo234do(Context context, Intent intent, g2d<tq9, pl5> g2dVar) {
        jp5.m8570try(context, "context");
        jp5.m8570try(intent, "forRetain");
        jp5.m8570try(g2dVar, "validationResult");
        if (g2dVar.f12965for != g2d.a.SUCCESS) {
            Intent m16812for = wuc.m16812for(context, intent, g2dVar);
            if (m16812for != null) {
                return m16812for;
            }
            Intent m13790strictfp = StubActivity.m13790strictfp(context, j7d.a.NOT_FOUND);
            jp5.m8568new(m13790strictfp, "createForUrlGag(context, UrlGagFragment.Type.NOT_FOUND)");
            return m13790strictfp;
        }
        if (xq9.a.m17279do()) {
            iz3 l3 = dn3.l3(zoc.class);
            jp5.m8570try(l3, "typeSpec");
            bz3 bz3Var = bz3.f4526do;
            jp5.m8565for(bz3Var);
            jp5.m8570try(l3, "typeSpec");
            LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
            zoc zocVar = (zoc) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet);
            mg9 mo9658else = zocVar.f47641if.mo9658else();
            jp5.m8568new(mo9658else, "userCenter.latestSmallUser()");
            if (((Boolean) ((cpc) zocVar.m18191do(mo9658else)).m3738else(ooc.f27648case)).booleanValue()) {
                Intent m13664synchronized = MainScreenActivity.m13664synchronized(context, s9a.KIDS);
                jp5.m8568new(m13664synchronized, "{\n                MainScreenActivity.intent(context, BottomTab.KIDS)\n            }");
                return m13664synchronized;
            }
        }
        return KidsCatalogActivity.m13655implements(context);
    }
}
