package defpackage;

import ru.yandex.music.cover.upload.UploadCoverService;

/* loaded from: classes2.dex */
public final class b49 extends kp5 implements mo5<UploadCoverService, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ String f2905catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ String f2906class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ a49 f2907const;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b49(String str, String str2, a49 a49Var) {
        super(1);
        this.f2905catch = str;
        this.f2906class = str2;
        this.f2907const = a49Var;
    }

    @Override // defpackage.mo5
    public pl5 invoke(UploadCoverService uploadCoverService) {
        UploadCoverService uploadCoverService2 = uploadCoverService;
        jp5.m8570try(uploadCoverService2, "service");
        uploadCoverService2.m13604for(this.f2905catch, this.f2906class, this.f2907const.f219if);
        return pl5.f29126do;
    }
}
