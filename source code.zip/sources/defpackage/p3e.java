package defpackage;

/* loaded from: classes2.dex */
public final class p3e {

    /* renamed from: do, reason: not valid java name */
    public final f3e f28306do;

    /* renamed from: if, reason: not valid java name */
    public final o3e f28307if;

    public p3e(f3e f3eVar, o3e o3eVar) {
        jp5.m8570try(f3eVar, "sdkDataCache");
        jp5.m8570try(o3eVar, "counterPreferences");
        this.f28306do = f3eVar;
        this.f28307if = o3eVar;
    }
}
