package defpackage;

import android.view.View;
import android.view.ViewGroup;
import defpackage.bz6;
import defpackage.cz6;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public class dz6 extends vs7 {

    /* renamed from: class, reason: not valid java name */
    public final bz6 f9233class;

    /* renamed from: const, reason: not valid java name */
    public final cz6 f9234const;

    /* loaded from: classes2.dex */
    public class a implements View.OnAttachStateChangeListener {
        public a() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            dz6 dz6Var = dz6.this;
            bz6 bz6Var = dz6Var.f9233class;
            cz6 cz6Var = dz6Var.f9234const;
            bz6Var.f4543for = cz6Var;
            final zy6 zy6Var = new zy6(bz6Var);
            cz6Var.f7682do.setOnClickListener(new View.OnClickListener() { // from class: az6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    qdd qddVar;
                    bz6 bz6Var2 = ((zy6) cz6.a.this).f48010do;
                    bz6.b bVar = bz6Var2.f4544if;
                    if (bVar == null || (qddVar = bz6Var2.f4545new) == null) {
                        return;
                    }
                    ((yx6) ((mw6) bVar).f24673do).f46299do.mo13029import(qddVar);
                }
            });
            bz6Var.m2429do();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            bz6 bz6Var = dz6.this.f9233class;
            ce9.m2850if(bz6Var.f4542do, bz6Var.f4541case);
            bz6Var.f4543for = null;
        }
    }

    public dz6(ViewGroup viewGroup) {
        super(viewGroup, R.layout.view_video_preview);
        this.f9233class = new bz6(this.f41116catch);
        this.f9234const = new cz6(this.itemView);
        this.itemView.addOnAttachStateChangeListener(new a());
    }
}
