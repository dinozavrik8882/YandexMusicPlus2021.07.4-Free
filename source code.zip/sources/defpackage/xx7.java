package defpackage;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import defpackage.s49;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import ru.yandex.music.YMApplication;

/* loaded from: classes2.dex */
public final class xx7 {

    /* renamed from: do, reason: not valid java name */
    public final p8a f44692do;

    /* renamed from: if, reason: not valid java name */
    public final uc9 f44693if;

    public xx7(p8a p8aVar, uc9 uc9Var) {
        this.f44692do = p8aVar;
        this.f44693if = uc9Var;
    }

    /* renamed from: do, reason: not valid java name */
    public void m17370do(ox7<? extends d8a> ox7Var, Collection<e69> collection) {
        if (!(ox7Var.f28031if != 0)) {
            xab m17028if = xab.m17028if();
            ArrayList arrayList = new ArrayList();
            for (e69 e69Var : collection) {
                if (!e69Var.m4954break()) {
                    e69Var = m17028if.m17029do(e69Var);
                }
                if (e69Var != null) {
                    arrayList.add(e69Var);
                }
            }
            if (arrayList.isEmpty()) {
                return;
            }
            this.f44693if.m15492do(arrayList);
            rd9.m13223for().m13227try(arrayList);
            return;
        }
        p8a p8aVar = this.f44692do;
        Objects.requireNonNull(p8aVar);
        jp5.m8570try(ox7Var, "container");
        q8a q8aVar = p8aVar.f28596if;
        Objects.requireNonNull(q8aVar);
        e8d.m5046else();
        T t = ox7Var.f28031if;
        boolean m12555try = q8aVar.m12555try(t);
        p49<h59> g = t.g();
        g.mo11863new(ox7Var);
        if (m12555try) {
            oc9 oc9Var = q8aVar.f30287goto;
            String mo4957do = t.mo4957do();
            s49.a aVar = s49.a.LIKE;
            Uri m11481if = oc9.m11481if(g);
            ContentResolver contentResolver = oc9Var.f27025do;
            ContentValues contentValues = new ContentValues();
            contentValues.put("operation", Integer.valueOf(aVar.ordinal()));
            if (g == p49.f28338do) {
                contentValues.put("album_id", mo4957do);
            } else if (g == p49.f28340if) {
                contentValues.put("artist_id", mo4957do);
            } else {
                if (g != p49.f28339for) {
                    throw new IllegalStateException("unknown: " + g);
                }
                contentValues.put("playlist_id", mo4957do);
            }
            contentResolver.insert(m11481if, contentValues);
        }
        fy8.m6291do().m6293if(YMApplication.f33061catch);
    }
}
