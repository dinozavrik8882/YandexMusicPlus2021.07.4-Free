package defpackage;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes.dex */
public class bc {

    /* renamed from: break, reason: not valid java name */
    public int f3328break;

    /* renamed from: case, reason: not valid java name */
    public PendingIntent f3329case;

    /* renamed from: class, reason: not valid java name */
    public cc f3331class;

    /* renamed from: const, reason: not valid java name */
    public CharSequence f3332const;

    /* renamed from: default, reason: not valid java name */
    public String f3333default;

    /* renamed from: do, reason: not valid java name */
    public Context f3334do;

    /* renamed from: else, reason: not valid java name */
    public Bitmap f3335else;

    /* renamed from: extends, reason: not valid java name */
    public long f3336extends;

    /* renamed from: final, reason: not valid java name */
    public int f3337final;

    /* renamed from: finally, reason: not valid java name */
    public boolean f3338finally;

    /* renamed from: goto, reason: not valid java name */
    public CharSequence f3340goto;

    /* renamed from: import, reason: not valid java name */
    public boolean f3342import;

    /* renamed from: native, reason: not valid java name */
    public String f3343native;

    /* renamed from: new, reason: not valid java name */
    public CharSequence f3344new;

    /* renamed from: package, reason: not valid java name */
    public Notification f3345package;

    /* renamed from: private, reason: not valid java name */
    @Deprecated
    public ArrayList<String> f3346private;

    /* renamed from: return, reason: not valid java name */
    public String f3348return;

    /* renamed from: static, reason: not valid java name */
    public Bundle f3349static;

    /* renamed from: super, reason: not valid java name */
    public int f3350super;

    /* renamed from: this, reason: not valid java name */
    public int f3352this;

    /* renamed from: throw, reason: not valid java name */
    public boolean f3353throw;

    /* renamed from: try, reason: not valid java name */
    public CharSequence f3355try;

    /* renamed from: while, reason: not valid java name */
    public String f3356while;

    /* renamed from: if, reason: not valid java name */
    public ArrayList<yb> f3341if = new ArrayList<>();

    /* renamed from: for, reason: not valid java name */
    public ArrayList<yb> f3339for = new ArrayList<>();

    /* renamed from: catch, reason: not valid java name */
    public boolean f3330catch = true;

    /* renamed from: public, reason: not valid java name */
    public boolean f3347public = false;

    /* renamed from: switch, reason: not valid java name */
    public int f3351switch = 0;

    /* renamed from: throws, reason: not valid java name */
    public int f3354throws = 0;

    public bc(Context context, String str) {
        Notification notification = new Notification();
        this.f3345package = notification;
        this.f3334do = context;
        this.f3333default = str;
        notification.when = System.currentTimeMillis();
        this.f3345package.audioStreamType = -1;
        this.f3328break = 0;
        this.f3346private = new ArrayList<>();
        this.f3338finally = true;
    }

    /* renamed from: if, reason: not valid java name */
    public static CharSequence m1912if(CharSequence charSequence) {
        return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
    }

    /* renamed from: break, reason: not valid java name */
    public bc m1913break(Uri uri) {
        Notification notification = this.f3345package;
        notification.sound = uri;
        notification.audioStreamType = -1;
        notification.audioAttributes = new AudioAttributes.Builder().setContentType(4).setUsage(5).build();
        return this;
    }

    /* renamed from: case, reason: not valid java name */
    public final void m1914case(int i, boolean z) {
        if (z) {
            Notification notification = this.f3345package;
            notification.flags = i | notification.flags;
        } else {
            Notification notification2 = this.f3345package;
            notification2.flags = (~i) & notification2.flags;
        }
    }

    /* renamed from: catch, reason: not valid java name */
    public bc m1915catch(CharSequence charSequence) {
        this.f3345package.tickerText = m1912if(charSequence);
        return this;
    }

    /* renamed from: do, reason: not valid java name */
    public Notification m1916do() {
        RemoteViews mo2758if;
        dc dcVar = new dc(this);
        cc ccVar = dcVar.f8281if.f3331class;
        if (ccVar != null) {
            ccVar.mo457do(dcVar);
        }
        RemoteViews mo2757for = ccVar != null ? ccVar.mo2757for(dcVar) : null;
        Notification build = Build.VERSION.SDK_INT >= 26 ? dcVar.f8279do.build() : dcVar.f8279do.build();
        if (mo2757for != null) {
            build.contentView = mo2757for;
        } else {
            Objects.requireNonNull(dcVar.f8281if);
        }
        if (ccVar != null && (mo2758if = ccVar.mo2758if(dcVar)) != null) {
            build.bigContentView = mo2758if;
        }
        if (ccVar != null) {
            Objects.requireNonNull(dcVar.f8281if.f3331class);
        }
        if (ccVar != null) {
            Bundle bundle = build.extras;
        }
        return build;
    }

    /* renamed from: else, reason: not valid java name */
    public bc m1917else(Bitmap bitmap) {
        if (bitmap != null && Build.VERSION.SDK_INT < 27) {
            Resources resources = this.f3334do.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_width);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_height);
            if (bitmap.getWidth() > dimensionPixelSize || bitmap.getHeight() > dimensionPixelSize2) {
                double min = Math.min(dimensionPixelSize / Math.max(1, bitmap.getWidth()), dimensionPixelSize2 / Math.max(1, bitmap.getHeight()));
                bitmap = Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(bitmap.getWidth() * min), (int) Math.ceil(bitmap.getHeight() * min), true);
            }
        }
        this.f3335else = bitmap;
        return this;
    }

    /* renamed from: for, reason: not valid java name */
    public bc m1918for(CharSequence charSequence) {
        this.f3355try = m1912if(charSequence);
        return this;
    }

    /* renamed from: goto, reason: not valid java name */
    public bc m1919goto(int i, int i2, int i3) {
        Notification notification = this.f3345package;
        notification.ledARGB = i;
        notification.ledOnMS = i2;
        notification.ledOffMS = i3;
        notification.flags = ((i2 == 0 || i3 == 0) ? 0 : 1) | (notification.flags & (-2));
        return this;
    }

    /* renamed from: new, reason: not valid java name */
    public bc m1920new(CharSequence charSequence) {
        this.f3344new = m1912if(charSequence);
        return this;
    }

    /* renamed from: this, reason: not valid java name */
    public bc m1921this(int i, int i2, boolean z) {
        this.f3337final = i;
        this.f3350super = i2;
        this.f3353throw = z;
        return this;
    }

    /* renamed from: try, reason: not valid java name */
    public bc m1922try(int i) {
        Notification notification = this.f3345package;
        notification.defaults = i;
        if ((i & 4) != 0) {
            notification.flags |= 1;
        }
        return this;
    }
}
