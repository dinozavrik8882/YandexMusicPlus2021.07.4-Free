package defpackage;

/* loaded from: classes.dex */
public interface gs4 {
    /* renamed from: do, reason: not valid java name */
    void mo6815do(vn0 vn0Var);
}
