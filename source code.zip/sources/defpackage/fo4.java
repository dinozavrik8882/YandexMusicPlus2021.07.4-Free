package defpackage;

/* loaded from: classes.dex */
public final class fo4 extends en4<lm4> {
    @Override // defpackage.en4
    /* renamed from: do */
    public void mo5366do(lm4 lm4Var, xm4 xm4Var) {
        jp5.m8570try(lm4Var, "dto");
        jp5.m8570try(xm4Var, "writer");
        xm4Var.m17215new();
        xm4Var.m17217super("params");
        xm4Var.m17215new();
        xm4Var.m17217super("payload");
        xm4Var.m17213import();
        xm4Var.m17217super("xpay_system");
        xm4Var.b(null);
        xm4Var.m17217super("region_id");
        xm4Var.throwables(0);
        xm4Var.m17211goto();
        xm4Var.m17211goto();
    }
}
