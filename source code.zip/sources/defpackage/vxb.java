package defpackage;

/* loaded from: classes2.dex */
public abstract class vxb {
    /* renamed from: do */
    public abstract r5c mo1601do();

    /* renamed from: for */
    public abstract l4c mo1602for();

    /* renamed from: if */
    public abstract j4c mo1603if();
}
