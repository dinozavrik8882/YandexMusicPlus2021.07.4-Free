package defpackage;

/* loaded from: classes2.dex */
public interface mo5<P1, R> extends bl5<R> {
    R invoke(P1 p1);
}
