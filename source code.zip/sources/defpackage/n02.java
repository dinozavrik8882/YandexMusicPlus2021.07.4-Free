package defpackage;

import android.content.SharedPreferences;
import defpackage.z62;
import java.util.UUID;

/* loaded from: classes.dex */
public final class n02 {

    /* renamed from: do, reason: not valid java name */
    public final bi0<z62> f24831do;

    /* renamed from: for, reason: not valid java name */
    public final int f24832for;

    /* renamed from: if, reason: not valid java name */
    public final String f24833if;

    public n02(SharedPreferences sharedPreferences, bi0<z62> bi0Var, long j) {
        this.f24831do = bi0Var;
        String string = sharedPreferences.getString("client_sender_id", null);
        if (string == null) {
            string = UUID.randomUUID().toString();
            sharedPreferences.edit().putString("client_sender_id", string).apply();
        }
        this.f24833if = string;
        this.f24832for = j == 0 ? 1 : 2;
    }

    /* renamed from: do, reason: not valid java name */
    public final void m10691do(z62 z62Var, q32 q32Var) {
        z62.a m17852final = z62.m17852final(z62Var);
        String str = this.f24833if;
        if (m17852final.f46833const) {
            m17852final.m17885catch();
            m17852final.f46833const = false;
        }
        z62.m17853native((z62) m17852final.f46832class, str);
        z62 z62Var2 = (z62) ((z82) m17852final.m17887const());
        wh0 wh0Var = null;
        int i = q02.f29780do[this.f24832for - 1];
        if (i == 1) {
            wh0Var = new wh0(Integer.valueOf(q32Var.getNumber()), z62Var2, zh0.VERY_LOW);
        } else if (i == 2) {
            wh0Var = new wh0(Integer.valueOf(q32Var.getNumber()), z62Var2, zh0.DEFAULT);
        }
        this.f24831do.mo2044do(wh0Var);
    }
}
