package defpackage;

@ln5(c = "kotlinx.coroutines.flow.FlowKt__EmittersKt", f = "Emitters.kt", l = {216}, m = "invokeSafely$FlowKt__EmittersKt")
/* loaded from: classes2.dex */
public final class my5<T> extends jn5 {

    /* renamed from: final, reason: not valid java name */
    public Object f24719final;

    /* renamed from: super, reason: not valid java name */
    public /* synthetic */ Object f24720super;

    /* renamed from: throw, reason: not valid java name */
    public int f24721throw;

    public my5(wm5<? super my5> wm5Var) {
        super(wm5Var);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        this.f24720super = obj;
        this.f24721throw |= Integer.MIN_VALUE;
        return dn3.m4672while(null, null, null, this);
    }
}
