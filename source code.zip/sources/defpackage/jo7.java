package defpackage;

import android.content.Context;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class jo7 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f19036do;

    /* renamed from: break, reason: not valid java name */
    public a f19037break;

    /* renamed from: case, reason: not valid java name */
    public final zv4 f19038case;

    /* renamed from: else, reason: not valid java name */
    public oo7 f19039else;

    /* renamed from: for, reason: not valid java name */
    public b f19040for;

    /* renamed from: goto, reason: not valid java name */
    public j09<tp7> f19041goto;

    /* renamed from: if, reason: not valid java name */
    public final Context f19042if;

    /* renamed from: new, reason: not valid java name */
    public final el5 f19043new;

    /* renamed from: this, reason: not valid java name */
    public boolean f19044this;

    /* renamed from: try, reason: not valid java name */
    public final el5 f19045try;

    /* loaded from: classes2.dex */
    public enum a {
        Albums("albums"),
        Podcasts("podcasts");

        public static final C0191a Companion = new C0191a(null);
        private final String type;

        /* renamed from: jo7$a$a, reason: collision with other inner class name */
        /* loaded from: classes2.dex */
        public static final class C0191a {
            public C0191a(ep5 ep5Var) {
            }
        }

        a(String str) {
            this.type = str;
        }
    }

    /* loaded from: classes2.dex */
    public interface b {
        /* renamed from: do */
        void mo6731do(h59 h59Var);
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(jo7.class), "chartsCenter", "getChartsCenter()Lru/yandex/music/chart/catalog/ChartsCenter;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(jo7.class), "connectivityBox", "getConnectivityBox()Lru/yandex/music/network/connectivity/ConnectivityBox;");
        Objects.requireNonNull(eq5Var);
        f19036do = new mr5[]{wp5Var, wp5Var2};
    }

    public jo7(Context context) {
        jp5.m8570try(context, "context");
        this.f19042if = context;
        iz3 l3 = dn3.l3(qo7.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        mr5<Object>[] mr5VarArr = f19036do;
        jp5.m8570try(mr5VarArr[0], "prop");
        this.f19043new = dn3.h1(cz3Var);
        iz3 l32 = dn3.l3(wga.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        bz3Var2.m2425do(l32);
        cz3 cz3Var2 = new cz3(l32);
        jp5.m8570try(cz3Var2, "provider");
        jp5.m8570try(mr5VarArr[1], "prop");
        this.f19045try = dn3.h1(cz3Var2);
        this.f19038case = new cw4(false);
    }

    /* renamed from: do, reason: not valid java name */
    public final qo7 m8546do() {
        return (qo7) this.f19043new.getValue();
    }

    /* renamed from: if, reason: not valid java name */
    public final void m8547if(boolean z) {
        a aVar = this.f19037break;
        if (aVar == null) {
            jp5.m8562class("chartType");
            throw null;
        }
        int ordinal = aVar.ordinal();
        if (ordinal == 0) {
            qo7 m8546do = m8546do();
            m8546do.f31015for.mo3910switch();
            dn3.e1(dn3.m4644extends(m8546do.f31015for, kv4.m9275do()), null, null, new ro7(m8546do, z, null), 3, null);
        } else {
            if (ordinal != 1) {
                throw new gl5();
            }
            qo7 m8546do2 = m8546do();
            m8546do2.f31018try.mo3910switch();
            dn3.e1(dn3.m4644extends(m8546do2.f31018try, kv4.m9275do()), null, null, new so7(m8546do2, z, null), 3, null);
        }
    }
}
