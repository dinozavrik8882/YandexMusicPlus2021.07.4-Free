package defpackage;

import defpackage.h68;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* loaded from: classes2.dex */
public final class l68<LifecycleEvent> implements h68.a<LifecycleEvent> {

    /* renamed from: do, reason: not valid java name */
    public final f68<LifecycleEvent> f21648do;

    /* renamed from: for, reason: not valid java name */
    public LifecycleEvent f21649for;

    /* renamed from: if, reason: not valid java name */
    public final Map<LifecycleEvent, List<fqe>> f21650if = new HashMap();

    public l68(f68<LifecycleEvent> f68Var) {
        this.f21649for = f68Var.mo4241if();
        this.f21648do = f68Var;
    }

    @Override // h68.a
    /* renamed from: do */
    public void mo4953do(LifecycleEvent lifecycleevent) {
        this.f21649for = lifecycleevent;
        List<fqe> list = this.f21650if.get(lifecycleevent);
        if (list == null) {
            return;
        }
        Iterator<fqe> it = list.iterator();
        while (it.hasNext()) {
            it.next().unsubscribe();
        }
        list.clear();
    }

    /* renamed from: if, reason: not valid java name */
    public void m9458if(LifecycleEvent lifecycleevent, fqe fqeVar) {
        if (!this.f21648do.mo4240for(this.f21649for)) {
            List<fqe> list = this.f21650if.get(lifecycleevent);
            if (list == null) {
                list = new ArrayList<>(8);
                this.f21650if.put(lifecycleevent, list);
            }
            list.add(fqeVar);
            return;
        }
        String str = this.f21649for + " shows life is already finishing, skip awaiting " + lifecycleevent;
        int i = e8d.f9711do;
        jr3.m8593do(str);
        fqeVar.unsubscribe();
    }
}
