package defpackage;

/* loaded from: classes2.dex */
public class l75 implements f75 {

    /* renamed from: do, reason: not valid java name */
    public final int f21666do;

    /* renamed from: for, reason: not valid java name */
    public final int f21667for;

    /* renamed from: if, reason: not valid java name */
    public final long f21668if;

    /* renamed from: new, reason: not valid java name */
    public int f21669new;

    public l75(int i, long j, int i2, int i3) {
        this.f21666do = i;
        this.f21668if = j;
        this.f21667for = i3;
        this.f21669new = i2;
    }

    @Override // defpackage.f75
    /* renamed from: do */
    public boolean mo5725do() {
        return this.f21669new == 0;
    }

    @Override // defpackage.f75
    /* renamed from: for */
    public int mo5726for() {
        return this.f21666do;
    }

    @Override // defpackage.f75
    public int getCount() {
        return this.f21669new;
    }

    @Override // defpackage.f75
    /* renamed from: if */
    public int mo5727if() {
        return this.f21667for;
    }

    @Override // defpackage.f75
    /* renamed from: new */
    public boolean mo5728new() {
        return this.f21667for != Integer.MIN_VALUE;
    }

    @Override // defpackage.f75
    public void next() {
        this.f21669new = 0;
    }

    @Override // defpackage.f75
    /* renamed from: try */
    public long mo5729try() {
        return this.f21668if;
    }
}
