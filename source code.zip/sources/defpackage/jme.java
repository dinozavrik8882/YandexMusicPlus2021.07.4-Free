package defpackage;

import defpackage.yr0;
import java.util.UUID;

/* loaded from: classes2.dex */
public final class jme implements yr0.c {

    /* renamed from: do, reason: not valid java name */
    public final boolean f18978do;

    public jme(boolean z) {
        this.f18978do = z;
    }

    @Override // yr0.c
    /* renamed from: do, reason: not valid java name */
    public yr0 mo8522do(UUID uuid) {
        Object obj;
        jp5.m8560case(uuid, "uuid");
        try {
            as0 m1489class = as0.m1489class(uuid);
            jp5.m8567if(m1489class, "FrameworkMediaDrm.newInstance(uuid)");
            obj = m1489class;
            if (this.f18978do) {
                m1489class.f2445for.setPropertyString("securityLevel", "L3");
                obj = m1489class;
            }
        } catch (Throwable th) {
            obj = dn3.O(th);
        }
        Throwable m7873do = il5.m7873do(obj);
        Object obj2 = obj;
        if (m7873do != null) {
            obj2 = new gme(m7873do);
        }
        return (yr0) obj2;
    }
}
