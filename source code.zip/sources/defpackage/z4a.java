package defpackage;

import android.view.View;
import android.view.ViewGroup;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class z4a implements View.OnLayoutChangeListener {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ j f46695catch;

    public z4a(j jVar) {
        this.f46695catch = jVar;
    }

    @Override // android.view.View.OnLayoutChangeListener
    public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        jp5.m8560case(view, "view");
        view.removeOnLayoutChangeListener(this);
        View m8038this = this.f46695catch.m8038this();
        ViewGroup.LayoutParams layoutParams = m8038this.getLayoutParams();
        Objects.requireNonNull(layoutParams, "null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
        layoutParams.height = this.f46695catch.m8038this().getMeasuredHeight();
        m8038this.setLayoutParams(layoutParams);
    }
}
