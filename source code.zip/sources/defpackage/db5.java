package defpackage;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import defpackage.ub5;
import defpackage.wa5;
import java.lang.reflect.Constructor;

/* loaded from: classes2.dex */
public class db5 {

    /* renamed from: do, reason: not valid java name */
    public static db5 f8250do;

    /* renamed from: case, reason: not valid java name */
    public Class<?> f8251case;

    /* renamed from: else, reason: not valid java name */
    public Class<?> f8252else;

    /* renamed from: for, reason: not valid java name */
    public final Handler f8253for;

    /* renamed from: goto, reason: not valid java name */
    public Class<?> f8254goto;

    /* renamed from: new, reason: not valid java name */
    public boolean f8256new;

    /* renamed from: this, reason: not valid java name */
    public Class<?> f8257this;

    /* renamed from: if, reason: not valid java name */
    public Object f8255if = null;

    /* renamed from: try, reason: not valid java name */
    public boolean f8258try = false;

    /* loaded from: classes2.dex */
    public class a implements Runnable {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ c f8259catch;

        public a(db5 db5Var, c cVar) {
            this.f8259catch = cVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            wa5.a aVar = (wa5.a) this.f8259catch;
            wa5.this.f41930break.m4353this(ub5.b.STRONG_MATCH_PENDING_WAIT_LOCK);
            wa5.this.m16494while();
        }
    }

    /* loaded from: classes2.dex */
    public abstract class b implements ServiceConnection {
        public b() {
        }

        /* renamed from: do */
        public abstract void mo2744do(ComponentName componentName, Object obj);

        @Override // android.content.ServiceConnection
        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            try {
                db5 db5Var = db5.this;
                Constructor<?> declaredConstructor = db5Var.f8251case.getDeclaredConstructor(db5Var.f8257this, ComponentName.class);
                declaredConstructor.setAccessible(true);
                mo2744do(componentName, declaredConstructor.newInstance(Class.forName("z2$a").getMethod("asInterface", IBinder.class).invoke(null, iBinder), componentName));
            } catch (Throwable unused) {
                mo2744do(null, null);
            }
        }
    }

    /* loaded from: classes2.dex */
    public interface c {
    }

    public db5() {
        this.f8256new = true;
        try {
            this.f8251case = Class.forName("android.support.customtabs.CustomTabsClient");
            this.f8252else = Class.forName("android.support.customtabs.CustomTabsCallback");
            this.f8254goto = Class.forName("android.support.customtabs.CustomTabsSession");
            this.f8257this = Class.forName("z2");
        } catch (Throwable unused) {
            this.f8256new = false;
        }
        this.f8253for = new Handler();
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x00eb  */
    /* renamed from: do, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.net.Uri m4332do(java.lang.String r5, defpackage.nb5 r6, defpackage.tb5 r7, android.content.Context r8) {
        /*
            r4 = this;
            boolean r0 = android.text.TextUtils.isEmpty(r5)
            if (r0 != 0) goto L11c
            java.lang.String r0 = "https://"
            java.lang.String r1 = "/_strong_match?os="
            java.lang.StringBuilder r5 = defpackage.by.w(r0, r5, r1)
            android.content.Context r0 = r6.f25344for
            java.lang.String r0 = defpackage.jc5.m8277for(r0)
            r5.append(r0)
            java.lang.String r5 = r5.toString()
            java.lang.String r0 = "&"
            java.lang.StringBuilder r5 = defpackage.by.v(r5, r0)
            jb5 r1 = defpackage.jb5.HardwareID
            java.lang.String r1 = r1.getKey()
            r5.append(r1)
            java.lang.String r1 = "="
            r5.append(r1)
            jc5$b r2 = r6.m10890if()
            r5.append(r2)
            java.lang.String r5 = r5.toString()
            jc5$b r2 = r6.m10890if()
            boolean r2 = r2.f18365if
            if (r2 == 0) goto L45
            jb5 r2 = defpackage.jb5.HardwareIDTypeVendor
            goto L47
        L45:
            jb5 r2 = defpackage.jb5.HardwareIDTypeRandom
        L47:
            java.lang.String r2 = r2.getKey()
            java.lang.StringBuilder r5 = defpackage.by.v(r5, r0)
            jb5 r3 = defpackage.jb5.HardwareIDType
            java.lang.String r3 = r3.getKey()
            r5.append(r3)
            r5.append(r1)
            r5.append(r2)
            java.lang.String r5 = r5.toString()
            jc5 r2 = r6.f25345if
            java.lang.String r2 = r2.f18361do
            if (r2 == 0) goto L85
            boolean r8 = defpackage.eb5.m5090do(r8)
            if (r8 != 0) goto L85
            java.lang.StringBuilder r5 = defpackage.by.v(r5, r0)
            jb5 r8 = defpackage.jb5.GoogleAdvertisingID
            java.lang.String r8 = r8.getKey()
            r5.append(r8)
            r5.append(r1)
            r5.append(r2)
            java.lang.String r5 = r5.toString()
        L85:
            java.lang.String r8 = r7.m14812class()
            java.lang.String r2 = "bnc_no_value"
            boolean r8 = r8.equals(r2)
            if (r8 != 0) goto Lac
            java.lang.StringBuilder r5 = defpackage.by.v(r5, r0)
            jb5 r8 = defpackage.jb5.DeviceFingerprintID
            java.lang.String r8 = r8.getKey()
            r5.append(r8)
            r5.append(r1)
            java.lang.String r8 = r7.m14812class()
            r5.append(r8)
            java.lang.String r5 = r5.toString()
        Lac:
            java.lang.String r8 = r6.m10889do()
            boolean r8 = r8.equals(r2)
            if (r8 != 0) goto Ld1
            java.lang.StringBuilder r5 = defpackage.by.v(r5, r0)
            jb5 r8 = defpackage.jb5.AppVersion
            java.lang.String r8 = r8.getKey()
            r5.append(r8)
            r5.append(r1)
            java.lang.String r6 = r6.m10889do()
            r5.append(r6)
            java.lang.String r5 = r5.toString()
        Ld1:
            java.lang.String r6 = r7.m14821goto()
            if (r6 == 0) goto Le8
            boolean r8 = defpackage.eb5.f9829do
            if (r8 == 0) goto Lde
            java.lang.String r8 = "key_test_"
            goto Le0
        Lde:
            java.lang.String r8 = "key_"
        Le0:
            boolean r6 = r6.startsWith(r8)
            if (r6 == 0) goto Le8
            r6 = 1
            goto Le9
        Le8:
            r6 = 0
        Le9:
            if (r6 == 0) goto L106
            java.lang.StringBuilder r5 = defpackage.by.v(r5, r0)
            jb5 r6 = defpackage.jb5.BranchKey
            java.lang.String r6 = r6.getKey()
            r5.append(r6)
            r5.append(r1)
            java.lang.String r6 = r7.m14821goto()
            r5.append(r6)
            java.lang.String r5 = r5.toString()
        L106:
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            r6.append(r5)
            java.lang.String r5 = "&sdk=android4.3.2"
            r6.append(r5)
            java.lang.String r5 = r6.toString()
            android.net.Uri r5 = android.net.Uri.parse(r5)
            goto L11d
        L11c:
            r5 = 0
        L11d:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.db5.m4332do(java.lang.String, nb5, tb5, android.content.Context):android.net.Uri");
    }

    /* renamed from: if, reason: not valid java name */
    public final void m4333if(c cVar, boolean z) {
        if (cVar != null) {
            if (z) {
                new Handler().postDelayed(new a(this, cVar), 750);
                return;
            }
            wa5.a aVar = (wa5.a) cVar;
            wa5.this.f41930break.m4353this(ub5.b.STRONG_MATCH_PENDING_WAIT_LOCK);
            wa5.this.m16494while();
        }
    }
}
