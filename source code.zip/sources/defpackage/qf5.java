package defpackage;

/* loaded from: classes2.dex */
public interface qf5 {

    /* loaded from: classes2.dex */
    public interface a {
    }
}
