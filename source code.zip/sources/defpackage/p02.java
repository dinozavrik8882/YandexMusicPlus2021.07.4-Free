package defpackage;

/* loaded from: classes.dex */
public final class p02 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ int[] f28150do = {1, 2};
}
