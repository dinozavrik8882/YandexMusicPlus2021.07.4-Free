package defpackage;

import java.util.Collection;
import java.util.Map;

/* loaded from: classes.dex */
public interface j03<K, V> {
    /* renamed from: do */
    Map<K, Collection<V>> mo6319do();
}
