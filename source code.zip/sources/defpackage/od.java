package defpackage;

import android.os.CancellationSignal;

/* loaded from: classes.dex */
public final class od {

    /* renamed from: do, reason: not valid java name */
    public boolean f27029do;

    /* renamed from: for, reason: not valid java name */
    public Object f27030for;

    /* renamed from: if, reason: not valid java name */
    public a f27031if;

    /* renamed from: new, reason: not valid java name */
    public boolean f27032new;

    /* loaded from: classes.dex */
    public interface a {
        void onCancel();
    }

    /* renamed from: do, reason: not valid java name */
    public void m11483do() {
        synchronized (this) {
            if (this.f27029do) {
                return;
            }
            this.f27029do = true;
            this.f27032new = true;
            a aVar = this.f27031if;
            Object obj = this.f27030for;
            if (aVar != null) {
                try {
                    aVar.onCancel();
                } catch (Throwable th) {
                    synchronized (this) {
                        this.f27032new = false;
                        notifyAll();
                        throw th;
                    }
                }
            }
            if (obj != null) {
                ((CancellationSignal) obj).cancel();
            }
            synchronized (this) {
                this.f27032new = false;
                notifyAll();
            }
        }
    }

    /* renamed from: for, reason: not valid java name */
    public void m11484for() {
        boolean z;
        synchronized (this) {
            z = this.f27029do;
        }
        if (z) {
            throw new rd();
        }
    }

    /* renamed from: if, reason: not valid java name */
    public void m11485if(a aVar) {
        synchronized (this) {
            while (this.f27032new) {
                try {
                    wait();
                } catch (InterruptedException unused) {
                }
            }
            if (this.f27031if == aVar) {
                return;
            }
            this.f27031if = aVar;
            if (this.f27029do && aVar != null) {
                aVar.onCancel();
            }
        }
    }
}
