package defpackage;

/* loaded from: classes.dex */
public final class xz3 extends kp5 implements mo5<kx4, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ String f44755catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public xz3(String str) {
        super(1);
        this.f44755catch = str;
    }

    @Override // defpackage.mo5
    public pl5 invoke(kx4 kx4Var) {
        kx4 kx4Var2 = kx4Var;
        jp5.m8570try(kx4Var2, "$this$select");
        d04 d04Var = d04.f7778case;
        kx4Var2.m9290do(kx4Var2, d04Var.m3978this());
        kx4.m9289for(kx4Var2, kx4Var2, d04Var, null, 2);
        kx4Var2.m9292new(kx4Var2, new wz3(this.f44755catch));
        return pl5.f29126do;
    }
}
