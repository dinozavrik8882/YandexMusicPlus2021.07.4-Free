package defpackage;

/* loaded from: classes2.dex */
public class sj5 implements cj5 {
    @Override // defpackage.cj5
    /* renamed from: do */
    public bj5 mo2924do(int i) {
        return new rj5(new p96(), Math.min(1048576, Math.max(4096, i)));
    }
}
