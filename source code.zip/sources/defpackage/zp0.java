package defpackage;

/* loaded from: classes.dex */
public final class zp0 {

    /* renamed from: do, reason: not valid java name */
    public final int f47648do;

    /* renamed from: if, reason: not valid java name */
    public final float f47649if;

    public zp0(int i, float f) {
        this.f47648do = i;
        this.f47649if = f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || zp0.class != obj.getClass()) {
            return false;
        }
        zp0 zp0Var = (zp0) obj;
        return this.f47648do == zp0Var.f47648do && Float.compare(zp0Var.f47649if, this.f47649if) == 0;
    }

    public int hashCode() {
        return Float.floatToIntBits(this.f47649if) + ((527 + this.f47648do) * 31);
    }
}
