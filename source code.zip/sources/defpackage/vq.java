package defpackage;

import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class vq implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ wq f40992catch;

    public vq(wq wqVar) {
        this.f40992catch = wqVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.lang.Runnable
    public void run() {
        if (this.f40992catch.f42676try == null) {
            return;
        }
        uq<T> uqVar = this.f40992catch.f42676try;
        V v = uqVar.f39321do;
        if (v != 0) {
            wq wqVar = this.f40992catch;
            synchronized (wqVar) {
                Iterator it = new ArrayList(wqVar.f42674if).iterator();
                while (it.hasNext()) {
                    ((qq) it.next()).mo2999do(v);
                }
            }
            return;
        }
        wq wqVar2 = this.f40992catch;
        Throwable th = uqVar.f39322if;
        synchronized (wqVar2) {
            ArrayList arrayList = new ArrayList(wqVar2.f42673for);
            if (arrayList.isEmpty()) {
                bw.m2341for("Lottie encountered an error but no failure listener was added:", th);
                return;
            }
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                ((qq) it2.next()).mo2999do(th);
            }
        }
    }
}
