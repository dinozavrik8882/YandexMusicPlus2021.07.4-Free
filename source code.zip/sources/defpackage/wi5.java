package defpackage;

import java.io.InputStream;

/* loaded from: classes2.dex */
public interface wi5 {

    /* loaded from: classes2.dex */
    public interface a {
        InputStream next();
    }

    /* renamed from: do */
    void mo8434do(a aVar);

    /* renamed from: new */
    void mo8436new();
}
