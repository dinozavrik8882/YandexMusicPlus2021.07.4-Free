package defpackage;

import defpackage.li;

/* loaded from: classes.dex */
public abstract class mi implements gu5 {

    @ln5(c = "androidx.lifecycle.LifecycleCoroutineScope$launchWhenStarted$1", f = "Lifecycle.kt", l = {87}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class a extends pn5 implements qo5<gu5, wm5<? super pl5>, Object> {

        /* renamed from: super, reason: not valid java name */
        public int f24029super;

        /* renamed from: while, reason: not valid java name */
        public final /* synthetic */ qo5 f24031while;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(qo5 qo5Var, wm5 wm5Var) {
            super(2, wm5Var);
            this.f24031while = qo5Var;
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            jp5.m8570try(wm5Var, "completion");
            return new a(this.f24031while, wm5Var);
        }

        @Override // defpackage.qo5
        public final Object invoke(gu5 gu5Var, wm5<? super pl5> wm5Var) {
            wm5<? super pl5> wm5Var2 = wm5Var;
            jp5.m8570try(wm5Var2, "completion");
            return new a(this.f24031while, wm5Var2).mo76return(pl5.f29126do);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            int i = this.f24029super;
            if (i == 0) {
                dn3.N2(obj);
                li mo1034do = mi.this.mo1034do();
                qo5 qo5Var = this.f24031while;
                this.f24029super = 1;
                li.b bVar = li.b.STARTED;
                ru5 ru5Var = ru5.f34399do;
                if (dn3.F3(x16.f43160for.a0(), new aj(mo1034do, bVar, qo5Var, null), this) == cn5Var) {
                    return cn5Var;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                dn3.N2(obj);
            }
            return pl5.f29126do;
        }
    }

    /* renamed from: do */
    public abstract li mo1034do();

    /* renamed from: if, reason: not valid java name */
    public final nv5 m10455if(qo5<? super gu5, ? super wm5<? super pl5>, ? extends Object> qo5Var) {
        jp5.m8570try(qo5Var, "block");
        return dn3.e1(this, null, null, new a(qo5Var, null), 3, null);
    }
}
