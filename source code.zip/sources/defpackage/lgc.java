package defpackage;

import java.io.Serializable;

/* loaded from: classes2.dex */
public final class lgc implements Serializable {
    private static final long serialVersionUID = -6841695087305181591L;

    @qd3("query")
    public final String query;

    @qd3("time")
    public final Long time;

    public lgc(String str) {
        Long valueOf = Long.valueOf(System.currentTimeMillis());
        this.query = str;
        this.time = valueOf;
    }
}
