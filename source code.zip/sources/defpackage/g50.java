package defpackage;

import android.util.Log;
import java.io.File;
import java.io.IOException;

/* loaded from: classes.dex */
public class g50 implements pz<f50> {
    @Override // defpackage.az
    /* renamed from: do */
    public boolean mo1591do(Object obj, File file, mz mzVar) {
        try {
            a80.m299if(((f50) ((f10) obj).get()).f11179catch.f11189do.f17973do.mo13020try().asReadOnlyBuffer(), file);
            return true;
        } catch (IOException e) {
            if (Log.isLoggable("GifEncoder", 5)) {
                Log.w("GifEncoder", "Failed to encode GIF drawable data", e);
            }
            return false;
        }
    }

    @Override // defpackage.pz
    /* renamed from: if, reason: not valid java name */
    public zy mo6356if(mz mzVar) {
        return zy.SOURCE;
    }
}
