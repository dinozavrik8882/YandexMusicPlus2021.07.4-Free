package defpackage;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* loaded from: classes.dex */
public abstract class qxe<E> extends AbstractQueue<E> {

    /* renamed from: catch, reason: not valid java name */
    public final AtomicReferenceArray<E> f31477catch;

    /* renamed from: class, reason: not valid java name */
    public final int f31478class;

    public qxe(int i) {
        int m11016catch = nke.m11016catch(i);
        this.f31478class = m11016catch - 1;
        this.f31477catch = new AtomicReferenceArray<>(m11016catch);
    }

    @Override // java.util.AbstractQueue, java.util.AbstractCollection, java.util.Collection
    public void clear() {
        while (true) {
            if (poll() == null && isEmpty()) {
                return;
            }
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public Iterator<E> iterator() {
        throw new UnsupportedOperationException();
    }
}
