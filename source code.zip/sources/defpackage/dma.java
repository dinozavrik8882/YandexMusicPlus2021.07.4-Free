package defpackage;

/* loaded from: classes2.dex */
public enum dma {
    NON_MUSIC,
    KIDS
}
