package defpackage;

import defpackage.l56;
import okhttp3.OkHttpClient;
import ru.yandex.video.ott.data.net.impl.ExtFunctionsKt;

/* loaded from: classes2.dex */
public final class lne implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ mne f22458catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ Object f22459class;

    public lne(mne mneVar, Object obj) {
        this.f22458catch = mneVar;
        this.f22459class = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            String str = this.f22458catch.f24360new.to(this.f22459class);
            k2f.m8759if("StrmTrackingApi").mo8764do(str, new Object[0]);
            OkHttpClient okHttpClient = this.f22458catch.f24359if;
            l56.a aVar = new l56.a();
            aVar.m9435catch(this.f22458catch.f24357do);
            aVar.m9441new(ExtFunctionsKt.HEADER_USER_AGENT, this.f22458catch.f24361try.getUserAgent());
            aVar.m9437else(p56.m11871for(i56.m7618if("application/json"), str));
            r56 r56Var = ((r66) okHttpClient.mo9417do(aVar.m9440if())).execute().f30148import;
            if (r56Var != null) {
                r56Var.close();
            }
        } catch (Throwable th) {
            this.f22458catch.f24356case.error("StrmTrackingApi", "trackEvent", this.f22459class, th, new Object[0]);
        }
    }
}
