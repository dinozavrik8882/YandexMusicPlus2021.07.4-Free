package defpackage;

import defpackage.xb8;
import java.util.Iterator;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class tb8 {

    /* renamed from: do, reason: not valid java name */
    public final xb8 f36949do;

    public tb8(xb8 xb8Var) {
        jp5.m8570try(xb8Var, "playbackTimeTracker");
        this.f36949do = xb8Var;
    }

    /* renamed from: do, reason: not valid java name */
    public final boolean m14840do(q68 q68Var) {
        return !((utc) q68Var.mo285if(vtc.f41164do)).f39521new;
    }

    /* renamed from: for, reason: not valid java name */
    public final void m14841for(go8 go8Var, long j, long j2) {
        jp5.m8570try(go8Var, "queueEvent");
        q68 q68Var = go8Var.f13942case;
        if (m14840do(q68Var)) {
            return;
        }
        if (!jp5.m8563do(q68Var, this.f36949do.f43554if)) {
            xb8 xb8Var = this.f36949do;
            t78 t78Var = go8Var.f13948for;
            Objects.requireNonNull(xb8Var);
            k2f.f19768new.mo8774this("onPlaybackStart(): state = " + xb8Var.f43552do + ", playable = " + q68Var, new Object[0]);
            xb8.d dVar = xb8Var.f43552do;
            xb8.d dVar2 = xb8.d.STARTED;
            if (dVar == dVar2) {
                int i = e8d.f9711do;
                jr3.m8593do("onPlaybackStart(): incorrect usage");
            }
            xb8Var.m17047do();
            xb8Var.f43552do = dVar2;
            xb8Var.f43554if = q68Var;
            Iterator<xb8.b> it = xb8Var.f43551case.iterator();
            while (it.hasNext()) {
                it.next().mo5736new(t78Var, q68Var);
            }
            return;
        }
        xb8 xb8Var2 = this.f36949do;
        Objects.requireNonNull(xb8Var2);
        k2f.f19768new.mo8774this("onPlaybackResumed(): state = " + xb8Var2.f43552do + ", playable = " + q68Var + ", progress = " + j + ", duration = " + j2, new Object[0]);
        if (xb8Var2.f43552do != xb8.d.READY && q68Var.equals(xb8Var2.f43554if)) {
            for (xb8.b bVar : xb8Var2.f43551case) {
                if (bVar instanceof xb8.c) {
                    ((xb8.c) bVar).mo16538if(j, j2);
                }
            }
            return;
        }
        StringBuilder r = by.r("onPlaybackResumed(): incorrect usage. state = ");
        r.append(xb8Var2.f43552do);
        r.append(", tracking playable = ");
        r.append(xb8Var2.f43554if);
        String sb = r.toString();
        int i2 = e8d.f9711do;
        jr3.m8593do(sb);
    }

    /* renamed from: if, reason: not valid java name */
    public final void m14842if(go8 go8Var, long j, long j2) {
        jp5.m8570try(go8Var, "queueEvent");
        q68 q68Var = go8Var.f13942case;
        if (m14840do(q68Var)) {
            return;
        }
        xb8 xb8Var = this.f36949do;
        Objects.requireNonNull(xb8Var);
        k2f.f19768new.mo8774this("onPlaybackPause(): state = " + xb8Var.f43552do + ", playable = " + q68Var + ", progress = " + j + ", duration = " + j2, new Object[0]);
        if (xb8Var.f43552do != xb8.d.READY && q68Var.equals(xb8Var.f43554if)) {
            for (xb8.b bVar : xb8Var.f43551case) {
                if (bVar instanceof xb8.c) {
                    ((xb8.c) bVar).mo16537for(j, j2);
                } else {
                    bVar.mo5735case();
                }
            }
            return;
        }
        StringBuilder r = by.r("onPlaybackPause(): incorrect usage. state = ");
        r.append(xb8Var.f43552do);
        r.append(", tracking playable = ");
        r.append(xb8Var.f43554if);
        String sb = r.toString();
        int i = e8d.f9711do;
        jr3.m8593do(sb);
    }

    /* renamed from: new, reason: not valid java name */
    public final void m14843new(go8 go8Var, long j, boolean z) {
        jp5.m8570try(go8Var, "queueEvent");
        q68 q68Var = go8Var.f13942case;
        if (!m14840do(q68Var) && jp5.m8563do(q68Var, this.f36949do.f43554if)) {
            xb8 xb8Var = this.f36949do;
            Objects.requireNonNull(xb8Var);
            k2f.f19768new.mo8774this("onPlaybackStop(): state = " + xb8Var.f43552do + ", playable = " + q68Var, new Object[0]);
            e8d.m5048goto(j >= 0);
            if (xb8Var.f43552do == xb8.d.READY || !q68Var.equals(xb8Var.f43554if)) {
                StringBuilder r = by.r("onPlaybackStop(): incorrect usage. state = ");
                r.append(xb8Var.f43552do);
                r.append(", tracking playable = ");
                r.append(xb8Var.f43554if);
                jr3.m8593do(r.toString());
                return;
            }
            xb8Var.f43556try = j;
            long j2 = (j - xb8Var.f43553for) + xb8Var.f43555new;
            xb8Var.f43555new = j2;
            Iterator<xb8.b> it = xb8Var.f43551case.iterator();
            while (it.hasNext()) {
                it.next().mo5737try(j, j2, z);
            }
            xb8Var.m17047do();
            xb8Var.f43552do = xb8.d.READY;
            xb8Var.f43554if = null;
        }
    }
}
