package defpackage;

import defpackage.mxb;

/* loaded from: classes2.dex */
public final class gxb implements mxb.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ fxb f14340do;

    public gxb(fxb fxbVar) {
        this.f14340do = fxbVar;
    }

    @Override // mxb.a
    /* renamed from: do, reason: not valid java name */
    public void mo6900do() {
        fxb fxbVar = this.f14340do;
        q0a q0aVar = fxbVar.f12731catch;
        if (q0aVar == null) {
            return;
        }
        q0aVar.m12404throw();
        q0aVar.m12402super(new jxb(fxbVar));
    }
}
