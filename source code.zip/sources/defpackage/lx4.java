package defpackage;

/* loaded from: classes.dex */
public final class lx4 extends kp5 implements mo5<pw4, CharSequence> {

    /* renamed from: catch, reason: not valid java name */
    public static final lx4 f23010catch = new lx4();

    public lx4() {
        super(1);
    }

    @Override // defpackage.mo5
    public CharSequence invoke(pw4 pw4Var) {
        pw4 pw4Var2 = pw4Var;
        jp5.m8570try(pw4Var2, "it");
        return "    " + pw4Var2.f29650new + " AS " + pw4Var2.f29648for;
    }
}
