package defpackage;

import com.squareup.moshi.Json;
import com.yandex.auth.sync.AccountProvider;

/* loaded from: classes2.dex */
public final class t5c {

    @Json(name = AccountProvider.URI_FRAGMENT_ACCOUNT)
    private final v5c account = v5c.f40137do;

    @Json(name = "subscription")
    private final w5c subscription = w5c.f41709do;

    @Json(name = "skipsPerHour")
    private final Integer skipsPerHour = 6;

    /* renamed from: do, reason: not valid java name */
    public v5c m14664do() {
        return this.account;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || t5c.class != obj.getClass()) {
            return false;
        }
        t5c t5cVar = (t5c) obj;
        return this.account.equals(t5cVar.account) && this.subscription.equals(t5cVar.subscription) && this.skipsPerHour.equals(t5cVar.skipsPerHour);
    }

    public int hashCode() {
        return this.skipsPerHour.hashCode() + ((this.subscription.hashCode() + (this.account.hashCode() * 31)) * 31);
    }

    /* renamed from: if, reason: not valid java name */
    public int m14665if() {
        return this.skipsPerHour.intValue();
    }

    public String toString() {
        StringBuilder r = by.r("AccountInfo{account=");
        r.append(this.account);
        r.append(", subscription=");
        r.append(this.subscription);
        r.append(", skipsPerHour=");
        r.append(this.skipsPerHour);
        r.append('}');
        return r.toString();
    }
}
