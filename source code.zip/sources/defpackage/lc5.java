package defpackage;

import android.content.Context;
import android.net.TrafficStats;
import android.text.TextUtils;
import com.yandex.metrica.rtm.service.EventProcessor;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class lc5 {

    /* renamed from: do, reason: not valid java name */
    public static JSONObject f21935do;

    /* renamed from: if, reason: not valid java name */
    public static lc5 f21936if;

    /* renamed from: for, reason: not valid java name */
    public final ArrayList<String> f21937for;

    /* renamed from: new, reason: not valid java name */
    public final JSONObject f21938new;

    /* loaded from: classes2.dex */
    public static class b extends ya5<Void, Void, JSONObject> {

        /* renamed from: do, reason: not valid java name */
        public final tb5 f21939do;

        public b(Context context, a aVar) {
            this.f21939do = tb5.m14807throw(context);
        }

        @Override // android.os.AsyncTask
        public Object doInBackground(Object[] objArr) {
            HttpsURLConnection httpsURLConnection;
            TrafficStats.setThreadStatsTag(0);
            JSONObject jSONObject = new JSONObject();
            HttpsURLConnection httpsURLConnection2 = null;
            try {
                httpsURLConnection = (HttpsURLConnection) new URL("=".replace("%", !TextUtils.isEmpty(null) ? null : "=").replace("#", Integer.toString(lc5.f21935do.optInt(EventProcessor.KEY_VERSION) + 1))).openConnection();
            } catch (Throwable unused) {
            }
            try {
                httpsURLConnection.setConnectTimeout(1500);
                httpsURLConnection.setReadTimeout(1500);
                if (httpsURLConnection.getResponseCode() == 200 && httpsURLConnection.getInputStream() != null) {
                    jSONObject = new JSONObject(new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream())).readLine());
                }
                httpsURLConnection.disconnect();
            } catch (Throwable unused2) {
                httpsURLConnection2 = httpsURLConnection;
                if (httpsURLConnection2 != null) {
                    httpsURLConnection2.disconnect();
                }
                return jSONObject;
            }
            return jSONObject;
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Object obj) {
            JSONObject jSONObject = (JSONObject) obj;
            super.onPostExecute(jSONObject);
            if (jSONObject.optInt(EventProcessor.KEY_VERSION) > lc5.f21935do.optInt(EventProcessor.KEY_VERSION)) {
                lc5.f21935do = jSONObject;
                this.f21939do.m14828protected("skip_url_format_key", jSONObject.toString());
            }
        }
    }

    public lc5(Context context) {
        JSONObject jSONObject = new JSONObject();
        this.f21938new = jSONObject;
        try {
            jSONObject.putOpt(EventProcessor.KEY_VERSION, 0);
            JSONArray jSONArray = new JSONArray();
            jSONObject.putOpt("uri_skip_list", jSONArray);
            jSONArray.put("^fb\\d+:");
            jSONArray.put("^li\\d+:");
            jSONArray.put("^pdk\\d+:");
            jSONArray.put("^twitterkit-.*:");
            jSONArray.put("^com\\.googleusercontent\\.apps\\.\\d+-.*:\\/oauth");
            jSONArray.put("^(?i)(?!(http|https):).*(:|:.*\\b)(password|o?auth|o?auth.?token|access|access.?token)\\b");
            jSONArray.put("^(?i)((http|https):\\/\\/).*[\\/|?|#].*\\b(password|o?auth|o?auth.?token|access|access.?token)\\b");
        } catch (JSONException unused) {
        }
        tb5 m14807throw = tb5.m14807throw(context);
        JSONObject jSONObject2 = new JSONObject();
        String m14815default = m14807throw.m14815default("skip_url_format_key");
        if (TextUtils.isEmpty(m14815default) || "bnc_no_value".equals(m14815default)) {
            jSONObject2 = this.f21938new;
        } else {
            try {
                jSONObject2 = new JSONObject(m14815default);
            } catch (JSONException unused2) {
            }
        }
        f21935do = jSONObject2;
        this.f21937for = new ArrayList<>();
    }

    /* renamed from: do, reason: not valid java name */
    public static lc5 m9581do(Context context) {
        if (f21936if == null) {
            f21936if = new lc5(context);
        }
        return f21936if;
    }

    /* renamed from: if, reason: not valid java name */
    public String m9582if(String str) {
        String str2;
        try {
            JSONArray optJSONArray = f21935do.optJSONArray("uri_skip_list");
            if (optJSONArray != null) {
                for (int i = 0; i < optJSONArray.length(); i++) {
                    try {
                        str2 = optJSONArray.getString(i);
                    } catch (JSONException unused) {
                    }
                    if (Pattern.compile(str2).matcher(str).find()) {
                        break;
                    }
                }
            }
            str2 = null;
            if (str2 == null) {
                if (this.f21937for.size() <= 0) {
                    return str;
                }
                Iterator<String> it = this.f21937for.iterator();
                while (it.hasNext()) {
                    if (str.matches(it.next())) {
                        return str;
                    }
                }
            }
            return str2;
        } catch (Exception unused2) {
            return str;
        }
    }
}
