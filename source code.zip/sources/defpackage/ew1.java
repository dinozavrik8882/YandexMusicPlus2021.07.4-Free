package defpackage;

/* loaded from: classes.dex */
public final class ew1 {

    /* renamed from: do, reason: not valid java name */
    public final String f10782do;

    /* renamed from: if, reason: not valid java name */
    public final boolean f10783if;

    public ew1(String str, String str2, boolean z, int i, boolean z2) {
        this.f10782do = str2;
        this.f10783if = z2;
    }
}
