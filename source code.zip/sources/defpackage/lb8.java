package defpackage;

/* loaded from: classes2.dex */
public final /* synthetic */ class lb8 extends ip5 implements bo5<pl5> {
    public lb8(ya8 ya8Var) {
        super(0, ya8Var, ya8.class, "stop", "stop()V", 0);
    }

    @Override // defpackage.bo5
    public pl5 invoke() {
        ((ya8) this.receiver).stop();
        return pl5.f29126do;
    }
}
