package defpackage;

import defpackage.eh7;
import defpackage.ga9;

/* loaded from: classes2.dex */
public interface rg7 extends eh7 {

    /* loaded from: classes2.dex */
    public interface a extends eh7.a {
    }

    /* renamed from: extends */
    void mo10075extends(boolean z);

    /* renamed from: import */
    void mo10077import(String str);

    /* renamed from: new */
    void mo10079new(ae9 ae9Var);

    /* renamed from: static */
    void mo10081static(String str);

    /* renamed from: super */
    void mo10082super(a aVar);

    /* renamed from: throw */
    void mo10084throw(ga9.b bVar, int i);
}
