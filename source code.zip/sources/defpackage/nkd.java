package defpackage;

/* loaded from: classes2.dex */
public final class nkd implements y8e {
    @Override // defpackage.y8e
    /* renamed from: do, reason: not valid java name */
    public boolean mo11010do(String str) {
        jp5.m8570try(str, "settingId");
        return false;
    }

    @Override // defpackage.y8e
    /* renamed from: for, reason: not valid java name */
    public boolean mo11011for(String str) {
        jp5.m8570try(str, "settingId");
        return false;
    }

    @Override // defpackage.y8e
    /* renamed from: if, reason: not valid java name */
    public void mo11012if(String str, boolean z, z8e z8eVar) {
        jp5.m8570try(str, "settingId");
        jp5.m8570try(z8eVar, "callback");
    }

    @Override // defpackage.y8e
    /* renamed from: new, reason: not valid java name */
    public boolean mo11013new(String str) {
        jp5.m8570try(str, "settingId");
        return false;
    }
}
