package defpackage;

import android.util.Log;
import defpackage.k43;
import java.util.Date;

/* loaded from: classes.dex */
public class r33 implements k43.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ x33 f31802do;

    public r33(x33 x33Var) {
        this.f31802do = x33Var;
    }

    /* renamed from: do, reason: not valid java name */
    public void m13116do(g73 g73Var, Thread thread, Throwable th) {
        x33 x33Var = this.f31802do;
        synchronized (x33Var) {
            w23.f41542do.m16339if("Handling uncaught exception \"" + th + "\" from thread " + thread.getName());
            try {
                c53.m2610do(x33Var.f43205case.m9399for(new t33(x33Var, new Date(), th, thread, g73Var)));
            } catch (Exception e) {
                if (w23.f41542do.m16336do(6)) {
                    Log.e("FirebaseCrashlytics", "Error handling uncaught exception", e);
                }
            }
        }
    }
}
