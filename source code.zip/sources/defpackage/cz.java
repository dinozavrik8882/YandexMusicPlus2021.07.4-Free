package defpackage;

import com.bumptech.glide.load.ImageHeaderParser;
import java.io.IOException;
import java.io.InputStream;

/* loaded from: classes.dex */
public class cz implements iz {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ InputStream f7672do;

    public cz(InputStream inputStream) {
        this.f7672do = inputStream;
    }

    @Override // defpackage.iz
    /* renamed from: do, reason: not valid java name */
    public ImageHeaderParser.ImageType mo3931do(ImageHeaderParser imageHeaderParser) throws IOException {
        try {
            return imageHeaderParser.mo1697if(this.f7672do);
        } finally {
            this.f7672do.reset();
        }
    }
}
