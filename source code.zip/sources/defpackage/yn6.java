package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class yn6 extends kp5 implements mo5<bz3.a, xn6> {

    /* renamed from: catch, reason: not valid java name */
    public static final yn6 f45807catch = new yn6();

    public yn6() {
        super(1);
    }

    @Override // defpackage.mo5
    public xn6 invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        return new xn6((zs3) aVar2.m2427do(dn3.l3(zs3.class)));
    }
}
