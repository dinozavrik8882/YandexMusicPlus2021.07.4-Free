package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;

/* loaded from: classes2.dex */
public final class ka9 implements Serializable, Parcelable {
    public static final Parcelable.Creator<ka9> CREATOR = new a();
    private static final long serialVersionUID = 1;

    /* renamed from: catch, reason: not valid java name */
    public final pg9 f20131catch;

    /* renamed from: class, reason: not valid java name */
    public final ia9 f20132class;

    /* loaded from: classes2.dex */
    public static final class a implements Parcelable.Creator<ka9> {
        @Override // android.os.Parcelable.Creator
        public ka9 createFromParcel(Parcel parcel) {
            jp5.m8570try(parcel, "parcel");
            return new ka9(parcel.readInt() == 0 ? null : pg9.CREATOR.createFromParcel(parcel), parcel.readInt() != 0 ? ia9.CREATOR.createFromParcel(parcel) : null);
        }

        @Override // android.os.Parcelable.Creator
        public ka9[] newArray(int i) {
            return new ka9[i];
        }
    }

    public ka9(pg9 pg9Var, ia9 ia9Var) {
        this.f20131catch = pg9Var;
        this.f20132class = ia9Var;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ka9)) {
            return false;
        }
        ka9 ka9Var = (ka9) obj;
        return jp5.m8563do(this.f20131catch, ka9Var.f20131catch) && jp5.m8563do(this.f20132class, ka9Var.f20132class);
    }

    public int hashCode() {
        pg9 pg9Var = this.f20131catch;
        int hashCode = (pg9Var == null ? 0 : pg9Var.hashCode()) * 31;
        ia9 ia9Var = this.f20132class;
        return hashCode + (ia9Var != null ? ia9Var.hashCode() : 0);
    }

    public String toString() {
        StringBuilder r = by.r("MadeFor(userInfo=");
        r.append(this.f20131catch);
        r.append(", caseForms=");
        r.append(this.f20132class);
        r.append(')');
        return r.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        jp5.m8570try(parcel, "out");
        pg9 pg9Var = this.f20131catch;
        if (pg9Var == null) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(1);
            pg9Var.writeToParcel(parcel, i);
        }
        ia9 ia9Var = this.f20132class;
        if (ia9Var == null) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(1);
            ia9Var.writeToParcel(parcel, i);
        }
    }
}
