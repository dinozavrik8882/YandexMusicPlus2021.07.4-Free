package defpackage;

/* loaded from: classes2.dex */
public final class g07 extends mz6 {
    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public g07(defpackage.mo5 r16, int r17, boolean r18, int r19, boolean r20, int r21, defpackage.gz6 r22, int r23) {
        /*
            r15 = this;
            r0 = r23 & 2
            if (r0 == 0) goto L9
            r0 = 2131952426(0x7f13032a, float:1.9541294E38)
            r5 = r0
            goto Lb
        L9:
            r5 = r17
        Lb:
            r0 = r23 & 4
            r1 = 0
            if (r0 == 0) goto L12
            r7 = r1
            goto L14
        L12:
            r7 = r18
        L14:
            r0 = r23 & 8
            if (r0 == 0) goto L1d
            r0 = 2131231241(0x7f080209, float:1.8078557E38)
            r3 = r0
            goto L1f
        L1d:
            r3 = r19
        L1f:
            r0 = r23 & 16
            if (r0 == 0) goto L25
            r4 = r1
            goto L27
        L25:
            r4 = r20
        L27:
            r0 = r23 & 32
            if (r0 == 0) goto L2f
            r0 = 2131231240(0x7f080208, float:1.8078555E38)
            goto L31
        L2f:
            r0 = r21
        L31:
            r1 = r23 & 64
            if (r1 == 0) goto L38
            gz6 r1 = defpackage.gz6.DISLIKE
            goto L39
        L38:
            r1 = 0
        L39:
            r13 = r1
            java.lang.String r1 = "action"
            r2 = r16
            defpackage.jp5.m8570try(r2, r1)
            java.lang.String r1 = "type"
            defpackage.jp5.m8570try(r13, r1)
            w47 r14 = new w47
            java.lang.Integer r8 = java.lang.Integer.valueOf(r0)
            r0 = 2131952042(0x7f1301aa, float:1.9540516E38)
            java.lang.Integer r9 = java.lang.Integer.valueOf(r0)
            r6 = 0
            r10 = 0
            r11 = 0
            r12 = 768(0x300, float:1.076E-42)
            r1 = r14
            r1.<init>(r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r0 = r15
            r15.<init>(r14, r13)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.g07.<init>(mo5, int, boolean, int, boolean, int, gz6, int):void");
    }
}
