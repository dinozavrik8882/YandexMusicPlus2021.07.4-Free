package defpackage;

import android.system.ErrnoException;
import android.system.OsConstants;
import com.yandex.metrica.rtm.Constants;
import defpackage.n91;
import defpackage.x91;
import java.io.IOException;

/* loaded from: classes.dex */
public abstract class bs4 extends Exception {

    /* loaded from: classes.dex */
    public static abstract class a extends bs4 {

        /* renamed from: catch, reason: not valid java name */
        public final String f4228catch;

        /* renamed from: class, reason: not valid java name */
        public final String f4229class;

        /* renamed from: bs4$a$a, reason: collision with other inner class name */
        /* loaded from: classes.dex */
        public static final class C0023a extends a {

            /* renamed from: const, reason: not valid java name */
            public final int f4230const;

            /* renamed from: final, reason: not valid java name */
            public final String f4231final;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0023a(String str, String str2, Throwable th, int i) {
                super(str, str2, th, null);
                jp5.m8570try(str, "trackId");
                jp5.m8570try(str2, "downloadInfoUrl");
                this.f4230const = i;
                StringBuilder sb = new StringBuilder();
                sb.append("downloadInfoUrl=" + str2 + ' ');
                sb.append(jp5.m8559break("httpCode = ", Integer.valueOf(i)));
                if (super.getMessage() != null) {
                    sb.append(jp5.m8559break("; ", super.getMessage()));
                }
                String sb2 = sb.toString();
                jp5.m8568new(sb2, "StringBuilder().apply(builderAction).toString()");
                this.f4231final = sb2;
            }

            @Override // java.lang.Throwable
            public String getMessage() {
                return this.f4231final;
            }
        }

        /* loaded from: classes.dex */
        public static final class b extends a {

            /* renamed from: const, reason: not valid java name */
            public final String f4232const;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public b(String str, String str2) {
                super(str, str2, null, null);
                jp5.m8570try(str, "trackId");
                jp5.m8570try(str2, "downloadInfo");
                StringBuilder sb = new StringBuilder();
                sb.append(jp5.m8559break("downloadInfoUrl=", this.f4229class));
                if (super.getMessage() != null) {
                    sb.append(jp5.m8559break("; ", super.getMessage()));
                }
                String sb2 = sb.toString();
                jp5.m8568new(sb2, "StringBuilder().apply(builderAction).toString()");
                this.f4232const = sb2;
            }

            @Override // java.lang.Throwable
            public String getMessage() {
                return this.f4232const;
            }
        }

        /* loaded from: classes.dex */
        public static final class c extends a {

            /* renamed from: const, reason: not valid java name */
            public final String f4233const;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public c(String str, String str2, IOException iOException) {
                super(str, str2, iOException, null);
                jp5.m8570try(str, "trackId");
                jp5.m8570try(str2, "downloadInfoUrl");
                jp5.m8570try(iOException, Constants.KEY_EXCEPTION);
                StringBuilder sb = new StringBuilder();
                sb.append(jp5.m8559break("downloadInfoUrl=", str2));
                if (super.getMessage() != null) {
                    sb.append(jp5.m8559break("; ", super.getMessage()));
                }
                String sb2 = sb.toString();
                jp5.m8568new(sb2, "StringBuilder().apply(builderAction).toString()");
                this.f4233const = sb2;
            }

            @Override // java.lang.Throwable
            public String getMessage() {
                return this.f4233const;
            }
        }

        public a(String str, String str2, Throwable th, ep5 ep5Var) {
            super(th, null);
            this.f4228catch = str;
            this.f4229class = str2;
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends bs4 {

        /* renamed from: catch, reason: not valid java name */
        public final String f4234catch;

        /* renamed from: class, reason: not valid java name */
        public final as4 f4235class;

        /* renamed from: const, reason: not valid java name */
        public final Integer f4236const;

        /* renamed from: final, reason: not valid java name */
        public final IOException f4237final;

        /* renamed from: super, reason: not valid java name */
        public final String f4238super;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(String str, as4 as4Var, Integer num, IOException iOException) {
            super(iOException, null);
            jp5.m8570try(str, "trackId");
            jp5.m8570try(iOException, Constants.KEY_EXCEPTION);
            this.f4234catch = str;
            this.f4235class = as4Var;
            this.f4236const = num;
            this.f4237final = iOException;
            StringBuilder sb = new StringBuilder();
            sb.append(jp5.m8559break("contentUrl=", as4Var));
            if (super.getMessage() != null) {
                sb.append(jp5.m8559break("; ", super.getMessage()));
            }
            String sb2 = sb.toString();
            jp5.m8568new(sb2, "StringBuilder().apply(builderAction).toString()");
            this.f4238super = sb2;
        }

        @Override // java.lang.Throwable
        public String getMessage() {
            return this.f4238super;
        }
    }

    /* loaded from: classes.dex */
    public static final class c extends bs4 {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(ErrnoException errnoException) {
            super(errnoException, null);
            jp5.m8570try(errnoException, Constants.KEY_EXCEPTION);
        }
    }

    /* loaded from: classes.dex */
    public static final class d extends bs4 {

        /* renamed from: catch, reason: not valid java name */
        public final String f4239catch;

        /* renamed from: class, reason: not valid java name */
        public final String f4240class;

        /* renamed from: const, reason: not valid java name */
        public final String f4241const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(String str, String str2, IOException iOException) {
            super(iOException, null);
            jp5.m8570try(str, "trackId");
            jp5.m8570try(str2, "preGetUrl");
            jp5.m8570try(iOException, Constants.KEY_EXCEPTION);
            this.f4239catch = str;
            this.f4240class = str2;
            StringBuilder sb = new StringBuilder();
            sb.append(jp5.m8559break("preGetUrl=", str2));
            if (super.getMessage() != null) {
                sb.append(jp5.m8559break("; ", super.getMessage()));
            }
            String sb2 = sb.toString();
            jp5.m8568new(sb2, "StringBuilder().apply(builderAction).toString()");
            this.f4241const = sb2;
        }

        @Override // java.lang.Throwable
        public String getMessage() {
            return this.f4241const;
        }
    }

    /* loaded from: classes.dex */
    public static final class e extends bs4 {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(cu4 cu4Var) {
            super(cu4Var, null);
            jp5.m8570try(cu4Var, "cause");
        }
    }

    public bs4(Throwable th, ep5 ep5Var) {
        super(th);
    }

    /* renamed from: do, reason: not valid java name */
    public static final bs4 m2307do(String str, as4 as4Var, IOException iOException) {
        ErrnoException errnoException;
        jp5.m8570try(str, "trackId");
        jp5.m8570try(iOException, "ioException");
        dn3.s1(iOException);
        Throwable cause = iOException.getCause();
        while (true) {
            if (cause == null) {
                errnoException = null;
                break;
            }
            if (cause instanceof ErrnoException) {
                errnoException = (ErrnoException) cause;
                break;
            }
            cause = cause.getCause();
        }
        boolean z = false;
        if (errnoException != null && errnoException.errno == OsConstants.ENOSPC) {
            z = true;
        }
        if (z) {
            return new c(errnoException);
        }
        if (l91.m9532do(iOException)) {
            x91.e eVar = iOException instanceof x91.e ? (x91.e) iOException : null;
            if (eVar != null) {
                n91.b m10829do = eVar.f43433catch.m10829do();
                m10829do.f25253goto = null;
                String n91Var = m10829do.m10833do().toString();
                jp5.m8568new(n91Var, "invalid.dataSpec.buildUpon().setKey(null).build().toString()");
                return new b(str, as4Var, Integer.valueOf(eVar.f43434class), new IOException(jp5.m8559break("dataSpec = ", n91Var), iOException));
            }
        }
        x91.e eVar2 = iOException instanceof x91.e ? (x91.e) iOException : null;
        return new b(str, as4Var, eVar2 != null ? Integer.valueOf(eVar2.f43434class) : null, iOException);
    }
}
