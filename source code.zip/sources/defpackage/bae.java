package defpackage;

import defpackage.qie;

/* loaded from: classes2.dex */
public final /* synthetic */ class bae implements qie.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ dae f3279do;

    public /* synthetic */ bae(dae daeVar) {
        this.f3279do = daeVar;
    }
}
