package defpackage;

/* loaded from: classes2.dex */
public interface mg9 {
    /* renamed from: do */
    String mo8994do();

    /* renamed from: for */
    boolean mo8995for();

    String getId();
}
