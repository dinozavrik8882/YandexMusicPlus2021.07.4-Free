package defpackage;

import ru.yandex.speechkit.Error;
import ru.yandex.speechkit.SoundBuffer;

/* loaded from: classes2.dex */
public interface pod {
    /* renamed from: do, reason: not valid java name */
    void m12243do(ood oodVar, SoundBuffer soundBuffer);

    /* renamed from: for, reason: not valid java name */
    void m12244for(ood oodVar);

    /* renamed from: if, reason: not valid java name */
    void m12245if(ood oodVar);

    /* renamed from: new, reason: not valid java name */
    void m12246new(ood oodVar, Error error);

    /* renamed from: try, reason: not valid java name */
    void m12247try(ood oodVar);
}
