package defpackage;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import defpackage.yob;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.profile.PromoCodeActivity;
import ru.yandex.music.profile.RestorePurchasesActivity;

/* loaded from: classes2.dex */
public class dnb extends p58 implements r58 {

    /* renamed from: super, reason: not valid java name */
    public xob f8803super;

    @Override // defpackage.r58
    /* renamed from: break */
    public boolean mo2196break() {
        return false;
    }

    @Override // defpackage.r58
    /* renamed from: goto */
    public boolean mo2197goto() {
        return false;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_subscription_offer, viewGroup, false);
    }

    @Override // defpackage.p58, defpackage.j68, androidx.fragment.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        xob xobVar = this.f8803super;
        f9d.m5797for(xobVar, "arg is null");
        xobVar.f44203for.x();
    }

    @Override // defpackage.j68, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        xob xobVar = this.f8803super;
        f9d.m5797for(xobVar, "arg is null");
        xobVar.f44204if = null;
    }

    @Override // defpackage.j68, androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        view.findViewById(R.id.enter_promo_code).setOnClickListener(new View.OnClickListener() { // from class: mmb
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                dnb dnbVar = dnb.this;
                Objects.requireNonNull(dnbVar);
                pic.m12145new(new vuc("Profile_EnterPromocode_Tapped"));
                dnbVar.startActivity(PromoCodeActivity.m13715strictfp(dnbVar.getContext()));
            }
        });
        view.findViewById(R.id.restore_purchases).setOnClickListener(new View.OnClickListener() { // from class: nmb
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                dnb dnbVar = dnb.this;
                Objects.requireNonNull(dnbVar);
                pic.m12145new(new vuc("Profile_RestorePurchase_Tapped"));
                RestorePurchasesActivity.m13718strictfp(dnbVar.getContext());
            }
        });
        view.findViewById(R.id.profile_manage_userpic_text_view).setOnClickListener(new View.OnClickListener() { // from class: pmb
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                dnb dnbVar = dnb.this;
                Objects.requireNonNull(dnbVar);
                pic.m12145new(new vuc("Profile_SetUserpic_Tapped"));
                wuc.m16807class(dnbVar.getContext(), "https://passport.yandex.ru/profile/public?origin=music_mobile&mode=popup&retpath=yandexmusic://profile");
            }
        });
        view.findViewById(R.id.profile_open_wizard_text_view).setOnClickListener(new View.OnClickListener() { // from class: omb
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                dnb dnbVar = dnb.this;
                Objects.requireNonNull(dnbVar);
                pic.m12145new(new vuc("Profile_OpenWizard_Tapped"));
                whd.f42365do.m16687if(dnbVar.getContext(), cid.USER_PROFILE_PAGE);
            }
        });
        yob yobVar = new yob(view);
        yobVar.f45950for = new yob.a() { // from class: lmb
            @Override // yob.a
            /* renamed from: do */
            public final void mo7913do() {
                dnb dnbVar = dnb.this;
                Objects.requireNonNull(dnbVar);
                pic.m12145new(new vuc("Profile_PurchaseAlert_Tapped"));
                Context context = dnbVar.getContext();
                jp5.m8570try(context, "context");
                qsa.m12934try(context, null, 2);
            }
        };
        xob xobVar = this.f8803super;
        f9d.m5797for(xobVar, "arg is null");
        xobVar.m17231do(yobVar);
    }

    @Override // defpackage.p58
    /* renamed from: private */
    public void mo2063private(Context context) {
        this.f28384const = true;
        this.f8803super = new xob();
    }

    @Override // defpackage.r58
    /* renamed from: throws */
    public List<cbd> mo2198throws() {
        return Collections.emptyList();
    }

    @Override // defpackage.s58
    /* renamed from: try */
    public int mo2199try() {
        return -1;
    }
}
