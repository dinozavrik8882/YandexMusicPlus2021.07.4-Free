package defpackage;

/* loaded from: classes.dex */
public final class r8<V> extends m8<V> {
    @Override // defpackage.m8
    /* renamed from: break */
    public boolean mo10213break(Throwable th) {
        return super.mo10213break(th);
    }

    @Override // defpackage.m8
    /* renamed from: this */
    public boolean mo10218this(V v) {
        return super.mo10218this(v);
    }
}
