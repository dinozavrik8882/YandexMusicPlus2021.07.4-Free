package defpackage;

/* loaded from: classes.dex */
public final class tm4 {

    /* renamed from: do, reason: not valid java name */
    public final String f37470do;

    /* renamed from: for, reason: not valid java name */
    public final String f37471for;

    /* renamed from: if, reason: not valid java name */
    public final String f37472if;

    /* renamed from: new, reason: not valid java name */
    public final Integer f37473new;

    /* renamed from: try, reason: not valid java name */
    public final String f37474try;

    public tm4(String str, String str2, String str3, Integer num, String str4) {
        this.f37470do = str;
        this.f37472if = str2;
        this.f37471for = str3;
        this.f37473new = num;
        this.f37474try = str4;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof tm4)) {
            return false;
        }
        tm4 tm4Var = (tm4) obj;
        return jp5.m8563do(this.f37470do, tm4Var.f37470do) && jp5.m8563do(this.f37472if, tm4Var.f37472if) && jp5.m8563do(this.f37471for, tm4Var.f37471for) && jp5.m8563do(this.f37473new, tm4Var.f37473new) && jp5.m8563do(this.f37474try, tm4Var.f37474try);
    }

    public int hashCode() {
        String str = this.f37470do;
        int hashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.f37472if;
        int hashCode2 = (hashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.f37471for;
        int hashCode3 = (hashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        Integer num = this.f37473new;
        int hashCode4 = (hashCode3 + (num == null ? 0 : num.hashCode())) * 31;
        String str4 = this.f37474try;
        return hashCode4 + (str4 != null ? str4.hashCode() : 0);
    }

    public String toString() {
        StringBuilder r = by.r("UserPaymentMethodDto(paymentMethodId=");
        r.append((Object) this.f37470do);
        r.append(", type=");
        r.append((Object) this.f37472if);
        r.append(", number=");
        r.append((Object) this.f37471for);
        r.append(", regionId=");
        r.append(this.f37473new);
        r.append(", system=");
        return by.b(r, this.f37474try, ')');
    }
}
