package defpackage;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class q03<T> extends l03<T> implements Serializable {
    private static final long serialVersionUID = 0;

    /* renamed from: catch, reason: not valid java name */
    public final l03<? super T> f29781catch;

    public q03(l03<? super T> l03Var) {
        this.f29781catch = l03Var;
    }

    @Override // defpackage.l03, java.util.Comparator
    public int compare(T t, T t2) {
        return this.f29781catch.compare(t2, t);
    }

    @Override // java.util.Comparator
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof q03) {
            return this.f29781catch.equals(((q03) obj).f29781catch);
        }
        return false;
    }

    public int hashCode() {
        return -this.f29781catch.hashCode();
    }

    @Override // defpackage.l03
    /* renamed from: if */
    public <S extends T> l03<S> mo8713if() {
        return this.f29781catch;
    }

    public String toString() {
        String valueOf = String.valueOf(this.f29781catch);
        return by.m2410throw(valueOf.length() + 10, valueOf, ".reverse()");
    }
}
