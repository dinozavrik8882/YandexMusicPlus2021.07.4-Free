package defpackage;

/* loaded from: classes.dex */
public final class e14 extends vx3 {

    /* loaded from: classes.dex */
    public static final class a extends kp5 implements mo5<fw4, pl5> {

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ yn f9322class;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(yn ynVar) {
            super(1);
            this.f9322class = ynVar;
        }

        @Override // defpackage.mo5
        public pl5 invoke(fw4 fw4Var) {
            fw4 fw4Var2 = fw4Var;
            jp5.m8570try(fw4Var2, "$this$migrate");
            fw4Var2.m6267do(7, new d14(e14.this, this.f9322class));
            return pl5.f29126do;
        }
    }

    @Override // defpackage.ex3
    /* renamed from: do */
    public void mo2512do(yn ynVar) {
        jp5.m8570try(ynVar, "db");
        dn3.L(ynVar, d04.f7778case);
    }

    @Override // defpackage.ex3
    /* renamed from: for */
    public void mo2513for(yn ynVar, int i, int i2) {
        jp5.m8570try(ynVar, "db");
        dn3.t1(i, i2, new a(ynVar));
    }

    @Override // defpackage.ex3
    /* renamed from: if */
    public String mo2514if() {
        return "AlbumTrackOrderSqliteContributor";
    }
}
