package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class a2d extends kp5 implements bo5<lh6> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ bz3.a f131catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a2d(bz3.a aVar) {
        super(0);
        this.f131catch = aVar;
    }

    @Override // defpackage.bo5
    public lh6 invoke() {
        return (lh6) this.f131catch.m2427do(dn3.l3(lh6.class));
    }
}
