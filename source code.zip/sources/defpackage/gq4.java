package defpackage;

import com.yandex.metrica.rtm.Constants;
import com.yandex.metrica.rtm.service.EventProcessor;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes.dex */
public final class gq4 extends nq4<fq4> {

    /* renamed from: do, reason: not valid java name */
    public static final gq4 f14023do = new gq4();

    @Override // defpackage.nq4
    /* renamed from: do, reason: not valid java name */
    public fq4 mo6760do(oq4 oq4Var) {
        kq4 kq4Var;
        jp5.m8570try(oq4Var, "reader");
        if (!oq4Var.mo9874class()) {
            return null;
        }
        fq4 fq4Var = new fq4(null, null, null, 7);
        while (oq4Var.hasNext()) {
            String nextName = oq4Var.nextName();
            int hashCode = nextName.hashCode();
            if (hashCode != -891990144) {
                if (hashCode != 3076010) {
                    if (hashCode == 351608024 && nextName.equals(EventProcessor.KEY_VERSION)) {
                        fq4Var.f12411do = oq4Var.nextString();
                    }
                    oq4Var.skipValue();
                } else if (nextName.equals(Constants.KEY_DATA)) {
                    fq4Var.f12412for = iq4.f17171do.mo6760do(oq4Var);
                } else {
                    oq4Var.skipValue();
                }
            } else if (nextName.equals("stream")) {
                jp5.m8570try(oq4Var, "reader");
                if (oq4Var.mo9874class()) {
                    kq4Var = new kq4(null, null, 3);
                    while (oq4Var.hasNext()) {
                        String nextName2 = oq4Var.nextName();
                        if (jp5.m8563do(nextName2, DatabaseHelper.OttTrackingTable.COLUMN_ID)) {
                            kq4Var.f20867do = oq4Var.nextString();
                        } else if (jp5.m8563do(nextName2, "url")) {
                            kq4Var.f20868if = oq4Var.nextString();
                        } else {
                            oq4Var.skipValue();
                        }
                    }
                    oq4Var.endObject();
                } else {
                    kq4Var = null;
                }
                fq4Var.f12413if = kq4Var;
            } else {
                oq4Var.skipValue();
            }
        }
        oq4Var.endObject();
        return fq4Var;
    }
}
