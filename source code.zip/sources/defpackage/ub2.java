package defpackage;

import java.util.Iterator;

/* loaded from: classes.dex */
public final class ub2 implements Iterator<String> {

    /* renamed from: catch, reason: not valid java name */
    public Iterator<String> f38678catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ sb2 f38679class;

    public ub2(sb2 sb2Var) {
        this.f38679class = sb2Var;
        this.f38678catch = sb2Var.f35218catch.iterator();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f38678catch.hasNext();
    }

    @Override // java.util.Iterator
    public final /* synthetic */ String next() {
        return this.f38678catch.next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
