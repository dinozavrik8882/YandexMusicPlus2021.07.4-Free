package defpackage;

/* loaded from: classes.dex */
public final class nh2 {
    /* JADX WARN: Multi-variable type inference failed */
    /* renamed from: do, reason: not valid java name */
    public final boolean m10927do(byte[] bArr, int i, int i2) {
        int i3;
        while (i < i2 && bArr[i] >= 0) {
            i++;
        }
        if (i < i2) {
            while (i < i2) {
                int i4 = i + 1;
                i3 = bArr[i];
                if (i3 < 0) {
                    if (i3 >= -32) {
                        if (i3 >= -16) {
                            if (i4 < i2 - 2) {
                                int i5 = i4 + 1;
                                int i6 = bArr[i4];
                                if (i6 <= -65) {
                                    if ((((i6 + 112) + (i3 << 28)) >> 30) == 0) {
                                        int i7 = i5 + 1;
                                        if (bArr[i5] <= -65) {
                                            i4 = i7 + 1;
                                            if (bArr[i7] > -65) {
                                            }
                                        }
                                    }
                                }
                                i3 = -1;
                                break;
                            }
                            i3 = mh2.m10431for(bArr, i4, i2);
                            break;
                        }
                        if (i4 < i2 - 1) {
                            int i8 = i4 + 1;
                            char c = bArr[i4];
                            if (c <= -65 && ((i3 != -32 || c >= -96) && (i3 != -19 || c < -96))) {
                                i = i8 + 1;
                                if (bArr[i8] > -65) {
                                }
                            }
                            i3 = -1;
                            break;
                        }
                        i3 = mh2.m10431for(bArr, i4, i2);
                        break;
                    }
                    if (i4 >= i2) {
                        break;
                    }
                    if (i3 >= -62) {
                        i = i4 + 1;
                        if (bArr[i4] > -65) {
                        }
                    }
                    i3 = -1;
                    break;
                }
                i = i4;
            }
        }
        i3 = 0;
        return i3 == 0;
    }
}
