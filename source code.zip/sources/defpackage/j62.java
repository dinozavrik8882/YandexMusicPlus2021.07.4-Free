package defpackage;

import defpackage.z82;

/* loaded from: classes.dex */
public final class j62 extends z82<j62, a> implements la2 {
    private static volatile sa2<j62> zzafw;
    private static final j62 zzbhp;
    private int zzafi;
    private j92<n62> zzbhm;
    private j92<b72> zzbhn;
    private m62 zzbho;

    /* loaded from: classes.dex */
    public static final class a extends z82.a<j62, a> implements la2 {
        public a(r72 r72Var) {
            super(j62.zzbhp);
        }
    }

    static {
        j62 j62Var = new j62();
        zzbhp = j62Var;
        z82.m17881catch(j62.class, j62Var);
    }

    public j62() {
        wa2<Object> wa2Var = wa2.f41917class;
        this.zzbhm = wa2Var;
        this.zzbhn = wa2Var;
    }

    /* JADX WARN: Type inference failed for: r2v13, types: [z82$c, sa2<j62>] */
    @Override // defpackage.z82
    /* renamed from: this */
    public final Object mo270this(z82.d dVar, Object obj, Object obj2) {
        sa2<j62> sa2Var;
        switch (r72.f31978do[dVar.ordinal()]) {
            case 1:
                return new j62();
            case 2:
                return new a(null);
            case 3:
                return new za2(zzbhp, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0002\u0000\u0001\u001b\u0002\u001b\u0003\t\u0000", new Object[]{"zzafi", "zzbhm", n62.class, "zzbhn", b72.class, "zzbho"});
            case 4:
                return zzbhp;
            case 5:
                sa2<j62> sa2Var2 = zzafw;
                sa2<j62> sa2Var3 = sa2Var2;
                if (sa2Var2 == null) {
                    synchronized (j62.class) {
                        sa2<j62> sa2Var4 = zzafw;
                        sa2Var = sa2Var4;
                        if (sa2Var4 == null) {
                            ?? cVar = new z82.c(zzbhp);
                            zzafw = cVar;
                            sa2Var = cVar;
                        }
                    }
                    sa2Var3 = sa2Var;
                }
                return sa2Var3;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
