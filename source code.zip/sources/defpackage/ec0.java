package defpackage;

/* loaded from: classes.dex */
public class ec0 {

    /* renamed from: do, reason: not valid java name */
    public float[] f9841do;

    /* renamed from: for, reason: not valid java name */
    public int f9842for;

    /* renamed from: if, reason: not valid java name */
    public int[] f9843if;

    public ec0(int[] iArr) {
        this.f9843if = iArr;
        int i = 1;
        for (int i2 : iArr) {
            i *= i2;
        }
        this.f9842for = i;
        this.f9841do = new float[i];
    }
}
