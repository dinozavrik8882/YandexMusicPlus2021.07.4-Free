package defpackage;

/* loaded from: classes2.dex */
public final class xr8 {

    /* renamed from: do, reason: not valid java name */
    public final rfc f44375do;

    /* renamed from: if, reason: not valid java name */
    public final yr8 f44376if;

    /* loaded from: classes2.dex */
    public enum a {
        ARTIST,
        ALBUM
    }

    /* loaded from: classes2.dex */
    public static final class b {

        /* renamed from: do, reason: not valid java name */
        public final String f44377do;

        /* renamed from: for, reason: not valid java name */
        public final String f44378for;

        /* renamed from: if, reason: not valid java name */
        public final String f44379if;

        /* renamed from: new, reason: not valid java name */
        public final String f44380new;

        public b(String str, String str2, String str3, String str4) {
            this.f44377do = str;
            this.f44379if = str2;
            this.f44378for = str3;
            this.f44380new = str4;
        }

        /* renamed from: do, reason: not valid java name */
        public final String m17285do() {
            String str = this.f44379if;
            if (str == null || str.length() == 0) {
                String str2 = this.f44378for;
                if (str2 == null || str2.length() == 0) {
                    String str3 = this.f44380new;
                    if (str3 == null || str3.length() == 0) {
                        String str4 = this.f44377do;
                        return str4 != null ? str4 : "";
                    }
                }
            }
            StringBuilder sb = new StringBuilder();
            String str5 = this.f44379if;
            if (str5 == null) {
                str5 = "";
            }
            sb.append(str5);
            sb.append(' ');
            String str6 = this.f44378for;
            if (str6 == null) {
                str6 = "";
            }
            sb.append(str6);
            sb.append(' ');
            String str7 = this.f44380new;
            sb.append(str7 != null ? str7 : "");
            return sb.toString();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return jp5.m8563do(this.f44377do, bVar.f44377do) && jp5.m8563do(this.f44379if, bVar.f44379if) && jp5.m8563do(this.f44378for, bVar.f44378for) && jp5.m8563do(this.f44380new, bVar.f44380new);
        }

        public int hashCode() {
            String str = this.f44377do;
            int hashCode = (str == null ? 0 : str.hashCode()) * 31;
            String str2 = this.f44379if;
            int hashCode2 = (hashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
            String str3 = this.f44378for;
            int hashCode3 = (hashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
            String str4 = this.f44380new;
            return hashCode3 + (str4 != null ? str4.hashCode() : 0);
        }

        public String toString() {
            StringBuilder r = by.r("SearchRequest(rawInput=");
            r.append((Object) this.f44377do);
            r.append(", artist=");
            r.append((Object) this.f44379if);
            r.append(", album=");
            r.append((Object) this.f44378for);
            r.append(", title=");
            return by.b(r, this.f44380new, ')');
        }
    }

    /* loaded from: classes2.dex */
    public static final class c {

        /* renamed from: do, reason: not valid java name */
        public static final a f44381do = new a(null);

        /* renamed from: if, reason: not valid java name */
        public static final c f44382if = new c(null);

        /* renamed from: for, reason: not valid java name */
        public final w68 f44383for;

        /* loaded from: classes2.dex */
        public static final class a {
            public a(ep5 ep5Var) {
            }
        }

        public c(w68 w68Var) {
            this.f44383for = w68Var;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof c) && jp5.m8563do(this.f44383for, ((c) obj).f44383for);
        }

        public int hashCode() {
            w68 w68Var = this.f44383for;
            if (w68Var == null) {
                return 0;
            }
            return w68Var.hashCode();
        }

        public String toString() {
            StringBuilder r = by.r("SearchResult(queueDescriptor=");
            r.append(this.f44383for);
            r.append(')');
            return r.toString();
        }
    }

    /* loaded from: classes2.dex */
    public /* synthetic */ class d {

        /* renamed from: do, reason: not valid java name */
        public static final /* synthetic */ int[] f44384do;

        static {
            a.values();
            int[] iArr = new int[2];
            iArr[a.ALBUM.ordinal()] = 1;
            iArr[a.ARTIST.ordinal()] = 2;
            f44384do = iArr;
        }
    }

    public xr8(rfc rfcVar, yr8 yr8Var) {
        jp5.m8570try(rfcVar, "onlineSearchHelper");
        jp5.m8570try(yr8Var, "queueRepository");
        this.f44375do = rfcVar;
        this.f44376if = yr8Var;
    }
}
