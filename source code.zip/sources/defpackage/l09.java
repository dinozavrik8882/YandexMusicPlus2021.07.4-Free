package defpackage;

import java.util.List;

/* loaded from: classes2.dex */
public interface l09<T> {

    /* loaded from: classes2.dex */
    public static final class a<T> {

        /* renamed from: do, reason: not valid java name */
        public final ria f21346do;

        /* renamed from: if, reason: not valid java name */
        public final List<T> f21347if;

        public a(ria riaVar, List<T> list) {
            this.f21346do = riaVar;
            this.f21347if = list;
        }
    }

    /* loaded from: classes2.dex */
    public interface b<T> {
    }
}
