package defpackage;

import java.util.List;

/* loaded from: classes2.dex */
public final class qvd {

    @qd3("geo_state")
    private final zwd geoState;

    @qd3("include")
    private final List<String> includeFields;

    @qd3("shown_plaques")
    private final List<jxd> shownPlaques;

    @qd3("supported_features")
    private final List<tvd> supportedFeatures;

    public qvd(List<String> list, List<tvd> list2, zwd zwdVar, List<jxd> list3) {
        jp5.m8570try(list2, "supportedFeatures");
        this.includeFields = list;
        this.supportedFeatures = list2;
        this.geoState = null;
        this.shownPlaques = list3;
    }
}
