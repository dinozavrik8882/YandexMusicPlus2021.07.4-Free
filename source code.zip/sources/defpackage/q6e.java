package defpackage;

import defpackage.dvd;
import defpackage.srd;
import defpackage.t9e;
import defpackage.trd;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import okhttp3.OkHttpClient;
import ru.yandex.taxi.common_models.net.GeoPoint;

/* loaded from: classes2.dex */
public final class q6e implements bsd {

    /* renamed from: do, reason: not valid java name */
    public final cvd f30215do;

    /* renamed from: for, reason: not valid java name */
    public final OkHttpClient f30216for;

    /* renamed from: if, reason: not valid java name */
    public final x0e f30217if;

    /* renamed from: new, reason: not valid java name */
    public final i46 f30218new;

    /* loaded from: classes2.dex */
    public static final class a<I, O> implements mhe<trd, asd> {

        /* renamed from: do, reason: not valid java name */
        public static final a f30219do = new a();

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r2v2, types: [r6e] */
        @Override // defpackage.mhe
        /* renamed from: do */
        public asd mo1620do(trd trdVar) {
            List list;
            trd trdVar2 = trdVar;
            if (trdVar2 == null) {
                throw new IllegalArgumentException("communications response is null");
            }
            List<trd.a> m15151do = trdVar2.m15151do();
            kr5 kr5Var = p6e.f28456catch;
            if (kr5Var != null) {
                kr5Var = new r6e(kr5Var);
            }
            wfe wfeVar = (wfe) kr5Var;
            Iterator it = m15151do.iterator();
            if (it.hasNext()) {
                ArrayList arrayList = new ArrayList();
                do {
                    Object next = it.next();
                    if (t9e.a.STORY == ((trd.a) next).m15153do()) {
                        arrayList.add(wfeVar.apply(next));
                    }
                } while (it.hasNext());
                list = arrayList;
            } else {
                list = Collections.emptyList();
            }
            jp5.m8568new(list, "CollectionUtils.filterAn…onse.Item::id\n          )");
            return new asd(trdVar2.m15152if(), list);
        }
    }

    public q6e(cvd cvdVar, x0e x0eVar, OkHttpClient okHttpClient, i46 i46Var) {
        jp5.m8570try(cvdVar, "communicationsApi");
        jp5.m8570try(x0eVar, "callAdapter");
        jp5.m8570try(okHttpClient, "okHttpClient");
        this.f30215do = cvdVar;
        this.f30217if = x0eVar;
        this.f30216for = okHttpClient;
        this.f30218new = i46Var;
    }

    @Override // defpackage.bsd
    /* renamed from: do */
    public a13<t9e> mo2310do(xrd xrdVar, Executor executor) {
        jp5.m8570try(xrdVar, "param");
        jp5.m8570try(executor, "executor");
        a13<t9e> m9389try = l2e.m9389try(new UnsupportedOperationException("getPromotion is not supported"));
        jp5.m8568new(m9389try, "Futures.error(Unsupporte…otion is not supported\"))");
        return m9389try;
    }

    @Override // defpackage.bsd
    /* renamed from: for */
    public a13<InputStream> mo2311for(String str, Executor executor) {
        jp5.m8570try(str, "url");
        jp5.m8570try(executor, "executor");
        a13<InputStream> m9377class = l2e.m9377class(new o6e(this, str), executor);
        jp5.m8568new(m9377class, "Futures.submitAsync(\n   …},\n        executor\n    )");
        return m9377class;
    }

    @Override // defpackage.bsd
    /* renamed from: if */
    public boolean mo2312if(String str) throws IOException {
        jp5.m8570try(str, "url");
        i46 i46Var = this.f30218new;
        if (i46Var == null) {
            return false;
        }
        j46 j46Var = new j46(i46Var);
        while (j46Var.hasNext()) {
            if (ts5.m15203try((CharSequence) j46Var.next(), str, false, 2)) {
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.bsd
    /* renamed from: new */
    public a13<asd> mo2313new(List<String> list, String str, Double d, Double d2, Integer num, String str2, Executor executor) {
        jp5.m8570try(list, "existingStoryIds");
        jp5.m8570try(executor, "executor");
        a13<asd> m9381final = l2e.m9381final(this.f30217if.m16884do(this.f30215do.m3895do(new srd(list, new ard(bge.f3583for, bge.f3584if, bge.f3582do), new srd.a(num, (d == null || d2 == null) ? null : new GeoPoint(d.doubleValue(), d2.doubleValue()), null, null, null, null, null, str2, null, null, jp5.m8563do("#none#", str) ^ true ? str : null), dn3.i1("screen"), em5.f10300catch)), new dvd.a(), new c1e()), a.f30219do, dhe.INSTANCE);
        jp5.m8568new(m9381final, "Futures.transform(\n     …ctExecutor.INSTANCE\n    )");
        return m9381final;
    }
}
