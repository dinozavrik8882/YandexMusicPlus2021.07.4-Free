package defpackage;

import android.graphics.Bitmap;

/* loaded from: classes2.dex */
public final /* synthetic */ class lie extends ip5 implements mo5<Bitmap, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ kie f22247catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public lie(kie kieVar) {
        super(1, null, "updateImage", "invoke(Landroid/graphics/Bitmap;)V", 0);
        this.f22247catch = kieVar;
    }

    @Override // defpackage.mo5
    public pl5 invoke(Bitmap bitmap) {
        this.f22247catch.m9047do(bitmap);
        return pl5.f29126do;
    }
}
