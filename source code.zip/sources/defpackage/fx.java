package defpackage;

import defpackage.pw;

/* loaded from: classes.dex */
public final class fx {

    /* renamed from: break, reason: not valid java name */
    public static final pw f12678break;

    /* renamed from: case, reason: not valid java name */
    public static final pw f12679case;

    /* renamed from: catch, reason: not valid java name */
    public static final pw f12680catch;

    /* renamed from: class, reason: not valid java name */
    public static final pw f12681class;

    /* renamed from: const, reason: not valid java name */
    public static final pw f12682const;

    /* renamed from: do, reason: not valid java name */
    public static final pw f12683do;

    /* renamed from: else, reason: not valid java name */
    public static final pw f12684else;

    /* renamed from: final, reason: not valid java name */
    public static final pw f12685final;

    /* renamed from: for, reason: not valid java name */
    public static final pw f12686for;

    /* renamed from: goto, reason: not valid java name */
    public static final pw f12687goto;

    /* renamed from: if, reason: not valid java name */
    public static final pw f12688if;

    /* renamed from: new, reason: not valid java name */
    public static final pw f12689new;

    /* renamed from: super, reason: not valid java name */
    public static final pw f12690super;

    /* renamed from: this, reason: not valid java name */
    public static final pw f12691this;

    /* renamed from: throw, reason: not valid java name */
    public static final pw f12692throw;

    /* renamed from: try, reason: not valid java name */
    public static final pw f12693try;

    static {
        pw.a m12328do = pw.m12328do();
        m12328do.f29637do = 3;
        m12328do.f29638if = "Google Play In-app Billing API version is less than 3";
        f12683do = m12328do.m12329do();
        pw.a m12328do2 = pw.m12328do();
        m12328do2.f29637do = 3;
        m12328do2.f29638if = "Google Play In-app Billing API version is less than 9";
        f12688if = m12328do2.m12329do();
        pw.a m12328do3 = pw.m12328do();
        m12328do3.f29637do = 3;
        m12328do3.f29638if = "Billing service unavailable on device.";
        f12686for = m12328do3.m12329do();
        pw.a m12328do4 = pw.m12328do();
        m12328do4.f29637do = 5;
        m12328do4.f29638if = "Client is already in the process of connecting to billing service.";
        f12689new = m12328do4.m12329do();
        pw.a m12328do5 = pw.m12328do();
        m12328do5.f29637do = 3;
        m12328do5.f29638if = "Play Store version installed does not support cross selling products.";
        f12693try = m12328do5.m12329do();
        pw.a m12328do6 = pw.m12328do();
        m12328do6.f29637do = 5;
        m12328do6.f29638if = "The list of SKUs can't be empty.";
        f12679case = m12328do6.m12329do();
        pw.a m12328do7 = pw.m12328do();
        m12328do7.f29637do = 5;
        m12328do7.f29638if = "SKU type can't be empty.";
        f12684else = m12328do7.m12329do();
        pw.a m12328do8 = pw.m12328do();
        m12328do8.f29637do = -2;
        m12328do8.f29638if = "Client does not support extra params.";
        f12687goto = m12328do8.m12329do();
        pw.a m12328do9 = pw.m12328do();
        m12328do9.f29637do = -2;
        m12328do9.f29638if = "Client does not support the feature.";
        m12328do9.m12329do();
        pw.a m12328do10 = pw.m12328do();
        m12328do10.f29637do = -2;
        m12328do10.f29638if = "Client does not support get purchase history.";
        f12691this = m12328do10.m12329do();
        pw.a m12328do11 = pw.m12328do();
        m12328do11.f29637do = 5;
        m12328do11.f29638if = "Invalid purchase token.";
        f12678break = m12328do11.m12329do();
        pw.a m12328do12 = pw.m12328do();
        m12328do12.f29637do = 6;
        m12328do12.f29638if = "An internal error occurred.";
        f12680catch = m12328do12.m12329do();
        pw.a m12328do13 = pw.m12328do();
        m12328do13.f29637do = 4;
        m12328do13.f29638if = "Item is unavailable for purchase.";
        m12328do13.m12329do();
        pw.a m12328do14 = pw.m12328do();
        m12328do14.f29637do = 5;
        m12328do14.f29638if = "SKU can't be null.";
        m12328do14.m12329do();
        pw.a m12328do15 = pw.m12328do();
        m12328do15.f29637do = 5;
        m12328do15.f29638if = "SKU type can't be null.";
        m12328do15.m12329do();
        pw.a m12328do16 = pw.m12328do();
        m12328do16.f29637do = 0;
        f12681class = m12328do16.m12329do();
        pw.a m12328do17 = pw.m12328do();
        m12328do17.f29637do = -1;
        m12328do17.f29638if = "Service connection is disconnected.";
        f12682const = m12328do17.m12329do();
        pw.a m12328do18 = pw.m12328do();
        m12328do18.f29637do = -3;
        m12328do18.f29638if = "Timeout communicating with service.";
        f12685final = m12328do18.m12329do();
        pw.a m12328do19 = pw.m12328do();
        m12328do19.f29637do = -2;
        m12328do19.f29638if = "Client doesn't support subscriptions.";
        f12690super = m12328do19.m12329do();
        pw.a m12328do20 = pw.m12328do();
        m12328do20.f29637do = -2;
        m12328do20.f29638if = "Client doesn't support subscriptions update.";
        f12692throw = m12328do20.m12329do();
        pw.a m12328do21 = pw.m12328do();
        m12328do21.f29637do = 5;
        m12328do21.f29638if = "Unknown feature";
        m12328do21.m12329do();
    }
}
