package defpackage;

/* loaded from: classes2.dex */
public final class zk5 {
    public zk5(String str, long j) {
    }
}
