package defpackage;

import java.util.List;

/* loaded from: classes2.dex */
public class jid {

    @qd3("genres")
    private iid mGenres;

    public jid(List<String> list, List<String> list2) {
        this.mGenres = new iid(list, list2);
    }
}
