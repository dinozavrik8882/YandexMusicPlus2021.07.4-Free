package defpackage;

/* loaded from: classes.dex */
public final class nb2 extends RuntimeException {
    public nb2() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
