package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import defpackage.ce9;
import j$.time.ZonedDateTime;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ru.yandex.music.data.stores.CoverPath;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes2.dex */
public final class j19 implements Parcelable, Serializable, ae9 {
    public static final Parcelable.Creator<j19> CREATOR = new a();
    private static final long serialVersionUID = 124;

    /* renamed from: catch, reason: not valid java name */
    public final String f17752catch;

    /* renamed from: class, reason: not valid java name */
    public final List<p19> f17753class;

    /* renamed from: const, reason: not valid java name */
    public final String f17754const;

    /* renamed from: final, reason: not valid java name */
    public final List<CoverPath> f17755final;

    /* renamed from: import, reason: not valid java name */
    public final String f17756import;

    /* renamed from: native, reason: not valid java name */
    public final List<j19> f17757native;

    /* renamed from: public, reason: not valid java name */
    public final String f17758public;

    /* renamed from: return, reason: not valid java name */
    public final String f17759return;

    /* renamed from: static, reason: not valid java name */
    public final String f17760static;

    /* renamed from: super, reason: not valid java name */
    public final ZonedDateTime f17761super;

    /* renamed from: switch, reason: not valid java name */
    public final String f17762switch;

    /* renamed from: throw, reason: not valid java name */
    public final String f17763throw;

    /* renamed from: throws, reason: not valid java name */
    public final String f17764throws;

    /* renamed from: while, reason: not valid java name */
    public final String f17765while;

    /* loaded from: classes2.dex */
    public static final class a implements Parcelable.Creator<j19> {
        @Override // android.os.Parcelable.Creator
        public j19 createFromParcel(Parcel parcel) {
            jp5.m8570try(parcel, "parcel");
            String readString = parcel.readString();
            int readInt = parcel.readInt();
            ArrayList arrayList = new ArrayList(readInt);
            int i = 0;
            int i2 = 0;
            while (i2 != readInt) {
                i2 = by.f(p19.CREATOR, parcel, arrayList, i2, 1);
            }
            String readString2 = parcel.readString();
            int readInt2 = parcel.readInt();
            ArrayList arrayList2 = new ArrayList(readInt2);
            for (int i3 = 0; i3 != readInt2; i3++) {
                arrayList2.add(parcel.readParcelable(j19.class.getClassLoader()));
            }
            ZonedDateTime zonedDateTime = (ZonedDateTime) parcel.readSerializable();
            String readString3 = parcel.readString();
            String readString4 = parcel.readString();
            String readString5 = parcel.readString();
            int readInt3 = parcel.readInt();
            ArrayList arrayList3 = new ArrayList(readInt3);
            while (i != readInt3) {
                i = by.f(j19.CREATOR, parcel, arrayList3, i, 1);
            }
            return new j19(readString, arrayList, readString2, arrayList2, zonedDateTime, readString3, readString4, readString5, arrayList3, parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString());
        }

        @Override // android.os.Parcelable.Creator
        public j19[] newArray(int i) {
            return new j19[i];
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public j19(String str, List<p19> list, String str2, List<? extends CoverPath> list2, ZonedDateTime zonedDateTime, String str3, String str4, String str5, List<j19> list3, String str6, String str7, String str8, String str9, String str10) {
        jp5.m8570try(str, DatabaseHelper.OttTrackingTable.COLUMN_ID);
        jp5.m8570try(list, "metroStations");
        jp5.m8570try(str2, "title");
        jp5.m8570try(list2, "images");
        jp5.m8570try(zonedDateTime, "date");
        jp5.m8570try(str3, "city");
        jp5.m8570try(list3, "popularConcerts");
        this.f17752catch = str;
        this.f17753class = list;
        this.f17754const = str2;
        this.f17755final = list2;
        this.f17761super = zonedDateTime;
        this.f17763throw = str3;
        this.f17765while = str4;
        this.f17756import = str5;
        this.f17757native = list3;
        this.f17758public = str6;
        this.f17759return = str7;
        this.f17760static = str8;
        this.f17762switch = str9;
        this.f17764throws = str10;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j19)) {
            return false;
        }
        j19 j19Var = (j19) obj;
        return jp5.m8563do(this.f17752catch, j19Var.f17752catch) && jp5.m8563do(this.f17753class, j19Var.f17753class) && jp5.m8563do(this.f17754const, j19Var.f17754const) && jp5.m8563do(this.f17755final, j19Var.f17755final) && jp5.m8563do(this.f17761super, j19Var.f17761super) && jp5.m8563do(this.f17763throw, j19Var.f17763throw) && jp5.m8563do(this.f17765while, j19Var.f17765while) && jp5.m8563do(this.f17756import, j19Var.f17756import) && jp5.m8563do(this.f17757native, j19Var.f17757native) && jp5.m8563do(this.f17758public, j19Var.f17758public) && jp5.m8563do(this.f17759return, j19Var.f17759return) && jp5.m8563do(this.f17760static, j19Var.f17760static) && jp5.m8563do(this.f17762switch, j19Var.f17762switch) && jp5.m8563do(this.f17764throws, j19Var.f17764throws);
    }

    @Override // defpackage.ae9
    /* renamed from: for */
    public CoverPath mo513for() {
        CoverPath coverPath = (CoverPath) xl5.m17186public(this.f17755final);
        if (coverPath != null) {
            return coverPath;
        }
        CoverPath none = CoverPath.none();
        jp5.m8568new(none, "none()");
        return none;
    }

    public int hashCode() {
        int A = by.A(this.f17763throw, (this.f17761super.hashCode() + by.L(this.f17755final, by.A(this.f17754const, by.L(this.f17753class, this.f17752catch.hashCode() * 31, 31), 31), 31)) * 31, 31);
        String str = this.f17765while;
        int hashCode = (A + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.f17756import;
        int L = by.L(this.f17757native, (hashCode + (str2 == null ? 0 : str2.hashCode())) * 31, 31);
        String str3 = this.f17758public;
        int hashCode2 = (L + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.f17759return;
        int hashCode3 = (hashCode2 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.f17760static;
        int hashCode4 = (hashCode3 + (str5 == null ? 0 : str5.hashCode())) * 31;
        String str6 = this.f17762switch;
        int hashCode5 = (hashCode4 + (str6 == null ? 0 : str6.hashCode())) * 31;
        String str7 = this.f17764throws;
        return hashCode5 + (str7 != null ? str7.hashCode() : 0);
    }

    @Override // defpackage.ae9
    /* renamed from: new */
    public ce9.a mo514new() {
        return ce9.a.CONCERT;
    }

    public String toString() {
        StringBuilder r = by.r("Concert(id=");
        r.append(this.f17752catch);
        r.append(", metroStations=");
        r.append(this.f17753class);
        r.append(", title=");
        r.append(this.f17754const);
        r.append(", images=");
        r.append(this.f17755final);
        r.append(", date=");
        r.append(this.f17761super);
        r.append(", city=");
        r.append(this.f17763throw);
        r.append(", place=");
        r.append((Object) this.f17765while);
        r.append(", address=");
        r.append((Object) this.f17756import);
        r.append(", popularConcerts=");
        r.append(this.f17757native);
        r.append(", afishaUrl=");
        r.append((Object) this.f17758public);
        r.append(", dataSessionId=");
        r.append((Object) this.f17759return);
        r.append(", afishaHash=");
        r.append((Object) this.f17760static);
        r.append(", mapCoverUrl=");
        r.append((Object) this.f17762switch);
        r.append(", mapUrl=");
        return by.b(r, this.f17764throws, ')');
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        jp5.m8570try(parcel, "out");
        parcel.writeString(this.f17752catch);
        Iterator B = by.B(this.f17753class, parcel);
        while (B.hasNext()) {
            ((p19) B.next()).writeToParcel(parcel, i);
        }
        parcel.writeString(this.f17754const);
        Iterator B2 = by.B(this.f17755final, parcel);
        while (B2.hasNext()) {
            parcel.writeParcelable((Parcelable) B2.next(), i);
        }
        parcel.writeSerializable(this.f17761super);
        parcel.writeString(this.f17763throw);
        parcel.writeString(this.f17765while);
        parcel.writeString(this.f17756import);
        Iterator B3 = by.B(this.f17757native, parcel);
        while (B3.hasNext()) {
            ((j19) B3.next()).writeToParcel(parcel, i);
        }
        parcel.writeString(this.f17758public);
        parcel.writeString(this.f17759return);
        parcel.writeString(this.f17760static);
        parcel.writeString(this.f17762switch);
        parcel.writeString(this.f17764throws);
    }
}
