package defpackage;

import android.graphics.Paint;

/* loaded from: classes2.dex */
public class cyd {

    /* renamed from: do, reason: not valid java name */
    public static final char[] f7666do = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

    /* renamed from: case, reason: not valid java name */
    public int f7667case;

    /* renamed from: for, reason: not valid java name */
    public final int f7668for;

    /* renamed from: if, reason: not valid java name */
    public final Paint f7669if;

    /* renamed from: new, reason: not valid java name */
    public final int f7670new;

    /* renamed from: try, reason: not valid java name */
    public final int f7671try;

    /* loaded from: classes2.dex */
    public enum a {
        NUMERIC,
        CURRENCY,
        SPACE,
        MINUS
    }

    public cyd(Paint paint) {
        int i = 0;
        for (char c : f7666do) {
            int m3929do = m3929do(c, paint);
            if (m3929do > i) {
                i = m3929do;
            }
        }
        this.f7668for = i;
        this.f7670new = m3929do((char) 8198, paint);
        this.f7671try = m3929do('-', paint);
        this.f7669if = paint;
    }

    /* renamed from: do, reason: not valid java name */
    public final int m3929do(char c, Paint paint) {
        return m3930if(Character.toString(c), paint);
    }

    /* renamed from: if, reason: not valid java name */
    public final int m3930if(String str, Paint paint) {
        if (str.isEmpty() || str.equals(Character.toString(' '))) {
            return 0;
        }
        return (int) paint.measureText(str);
    }
}
