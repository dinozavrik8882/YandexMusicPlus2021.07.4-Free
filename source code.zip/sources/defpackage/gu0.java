package defpackage;

import defpackage.at0;

/* loaded from: classes.dex */
public interface gu0 extends at0 {

    /* loaded from: classes.dex */
    public static class a extends at0.b implements gu0 {
        public a() {
            super(-9223372036854775807L, 0L);
        }

        @Override // defpackage.gu0
        /* renamed from: do */
        public long mo3842do(long j) {
            return 0L;
        }

        @Override // defpackage.gu0
        /* renamed from: if */
        public long mo3843if() {
            return -1L;
        }
    }

    /* renamed from: do */
    long mo3842do(long j);

    /* renamed from: if */
    long mo3843if();
}
