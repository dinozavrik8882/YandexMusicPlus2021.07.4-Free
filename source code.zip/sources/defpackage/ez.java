package defpackage;

import com.bumptech.glide.load.ImageHeaderParser;
import com.bumptech.glide.load.data.ParcelFileDescriptorRewinder;
import java.io.FileInputStream;
import java.io.IOException;

/* loaded from: classes.dex */
public class ez implements iz {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ ParcelFileDescriptorRewinder f10907do;

    /* renamed from: if, reason: not valid java name */
    public final /* synthetic */ m10 f10908if;

    public ez(ParcelFileDescriptorRewinder parcelFileDescriptorRewinder, m10 m10Var) {
        this.f10907do = parcelFileDescriptorRewinder;
        this.f10908if = m10Var;
    }

    @Override // defpackage.iz
    /* renamed from: do */
    public ImageHeaderParser.ImageType mo3931do(ImageHeaderParser imageHeaderParser) throws IOException {
        n40 n40Var = null;
        try {
            n40 n40Var2 = new n40(new FileInputStream(this.f10907do.mo1605do().getFileDescriptor()), this.f10908if);
            try {
                ImageHeaderParser.ImageType mo1697if = imageHeaderParser.mo1697if(n40Var2);
                try {
                    n40Var2.close();
                } catch (IOException unused) {
                }
                this.f10907do.mo1605do();
                return mo1697if;
            } catch (Throwable th) {
                th = th;
                n40Var = n40Var2;
                if (n40Var != null) {
                    try {
                        n40Var.close();
                    } catch (IOException unused2) {
                    }
                }
                this.f10907do.mo1605do();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
