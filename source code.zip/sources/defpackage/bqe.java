package defpackage;

/* JADX INFO: Add missing generic type declarations: [R] */
/* loaded from: classes.dex */
public final class bqe<R> implements ere<R> {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ cre f4179do;

    public bqe(cre creVar) {
        this.f4179do = creVar;
    }

    @Override // defpackage.ere
    /* renamed from: do */
    public R mo1445do(Object... objArr) {
        return (R) this.f4179do.mo3824do(objArr[0], objArr[1], objArr[2], objArr[3], objArr[4], objArr[5]);
    }
}
