package defpackage;

/* loaded from: classes.dex */
public final class gh3 implements sg3 {

    /* renamed from: do, reason: not valid java name */
    public final ug3 f13610do;

    /* renamed from: for, reason: not valid java name */
    public final Object[] f13611for;

    /* renamed from: if, reason: not valid java name */
    public final String f13612if;

    /* renamed from: new, reason: not valid java name */
    public final int f13613new;

    public gh3(ug3 ug3Var, String str, Object[] objArr) {
        String str2;
        Throwable e;
        char charAt;
        this.f13610do = ug3Var;
        this.f13612if = str;
        this.f13611for = objArr;
        int i = 1;
        try {
            charAt = str.charAt(0);
        } catch (StringIndexOutOfBoundsException unused) {
            char[] charArray = str.toCharArray();
            String str3 = new String(charArray);
            try {
                try {
                    charAt = str3.charAt(0);
                    str = str3;
                } catch (StringIndexOutOfBoundsException unused2) {
                    char[] cArr = new char[str3.length()];
                    str3.getChars(0, str3.length(), cArr, 0);
                    str2 = new String(cArr);
                    try {
                        charAt = str2.charAt(0);
                        str = str2;
                    } catch (ArrayIndexOutOfBoundsException e2) {
                        e = e2;
                        throw new IllegalStateException(String.format("Failed parsing '%s' with charArray.length of %d", str2, Integer.valueOf(charArray.length)), e);
                    } catch (StringIndexOutOfBoundsException e3) {
                        e = e3;
                        throw new IllegalStateException(String.format("Failed parsing '%s' with charArray.length of %d", str2, Integer.valueOf(charArray.length)), e);
                    }
                }
            } catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e4) {
                str2 = str3;
                e = e4;
                throw new IllegalStateException(String.format("Failed parsing '%s' with charArray.length of %d", str2, Integer.valueOf(charArray.length)), e);
            }
        }
        if (charAt < 55296) {
            this.f13613new = charAt;
            return;
        }
        int i2 = charAt & 8191;
        int i3 = 13;
        while (true) {
            int i4 = i + 1;
            char charAt2 = str.charAt(i);
            if (charAt2 < 55296) {
                this.f13613new = (charAt2 << i3) | i2;
                return;
            } else {
                i2 |= (charAt2 & 8191) << i3;
                i3 += 13;
                i = i4;
            }
        }
    }

    @Override // defpackage.sg3
    /* renamed from: do, reason: not valid java name */
    public boolean mo6636do() {
        return (this.f13613new & 2) == 2;
    }

    @Override // defpackage.sg3
    /* renamed from: for, reason: not valid java name */
    public dh3 mo6637for() {
        return (this.f13613new & 1) == 1 ? dh3.PROTO2 : dh3.PROTO3;
    }

    @Override // defpackage.sg3
    /* renamed from: if, reason: not valid java name */
    public ug3 mo6638if() {
        return this.f13610do;
    }
}
