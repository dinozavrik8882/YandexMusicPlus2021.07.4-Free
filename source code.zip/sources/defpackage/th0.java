package defpackage;

import android.os.IBinder;
import android.os.IInterface;

/* loaded from: classes.dex */
public class th0 implements IInterface {

    /* renamed from: do, reason: not valid java name */
    public final IBinder f37251do;

    public th0(IBinder iBinder) {
        this.f37251do = iBinder;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f37251do;
    }
}
