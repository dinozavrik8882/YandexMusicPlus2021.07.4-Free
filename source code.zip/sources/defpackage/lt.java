package defpackage;

import android.graphics.PointF;

/* loaded from: classes.dex */
public class lt implements mt {

    /* renamed from: do, reason: not valid java name */
    public final String f22745do;

    /* renamed from: for, reason: not valid java name */
    public final ct f22746for;

    /* renamed from: if, reason: not valid java name */
    public final jt<PointF, PointF> f22747if;

    /* renamed from: new, reason: not valid java name */
    public final boolean f22748new;

    /* renamed from: try, reason: not valid java name */
    public final boolean f22749try;

    public lt(String str, jt<PointF, PointF> jtVar, ct ctVar, boolean z, boolean z2) {
        this.f22745do = str;
        this.f22747if = jtVar;
        this.f22746for = ctVar;
        this.f22748new = z;
        this.f22749try = z2;
    }

    @Override // defpackage.mt
    /* renamed from: do */
    public fr mo1514do(oq oqVar, du duVar) {
        return new ir(oqVar, duVar, this);
    }
}
