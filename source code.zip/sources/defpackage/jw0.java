package defpackage;

import com.google.android.exoplayer2.util.Util;
import com.yandex.metrica.YandexMetricaDefaultValues;
import defpackage.js0;
import java.io.IOException;

/* loaded from: classes.dex */
public final class jw0 extends js0 {

    /* loaded from: classes.dex */
    public static final class b implements js0.f {

        /* renamed from: do, reason: not valid java name */
        public final hc1 f19407do;

        /* renamed from: if, reason: not valid java name */
        public final wb1 f19408if = new wb1();

        public b(hc1 hc1Var, a aVar) {
            this.f19407do = hc1Var;
        }

        @Override // js0.f
        /* renamed from: do */
        public void mo8611do() {
            this.f19408if.m16508default(Util.EMPTY_BYTE_ARRAY);
        }

        @Override // js0.f
        /* renamed from: if */
        public js0.e mo8612if(qs0 qs0Var, long j) throws IOException {
            int m8654else;
            long position = qs0Var.getPosition();
            int min = (int) Math.min(20000L, qs0Var.mo10570do() - position);
            this.f19408if.m16529throws(min);
            qs0Var.mo10572final(this.f19408if.f41978do, 0, min);
            wb1 wb1Var = this.f19408if;
            int i = -1;
            int i2 = -1;
            long j2 = -9223372036854775807L;
            while (wb1Var.m16509do() >= 4) {
                if (jw0.m8654else(wb1Var.f41978do, wb1Var.f41980if) != 442) {
                    wb1Var.m16521private(1);
                } else {
                    wb1Var.m16521private(4);
                    long m9277for = kw0.m9277for(wb1Var);
                    if (m9277for != -9223372036854775807L) {
                        long m7134if = this.f19407do.m7134if(m9277for);
                        if (m7134if > j) {
                            return j2 == -9223372036854775807L ? js0.e.m8608do(m7134if, position) : js0.e.m8610if(position + i2);
                        }
                        if (100000 + m7134if > j) {
                            return js0.e.m8610if(position + wb1Var.f41980if);
                        }
                        i2 = wb1Var.f41980if;
                        j2 = m7134if;
                    }
                    int i3 = wb1Var.f41979for;
                    if (wb1Var.m16509do() >= 10) {
                        wb1Var.m16521private(9);
                        int m16531while = wb1Var.m16531while() & 7;
                        if (wb1Var.m16509do() >= m16531while) {
                            wb1Var.m16521private(m16531while);
                            if (wb1Var.m16509do() >= 4) {
                                if (jw0.m8654else(wb1Var.f41978do, wb1Var.f41980if) == 443) {
                                    wb1Var.m16521private(4);
                                    int m16524static = wb1Var.m16524static();
                                    if (wb1Var.m16509do() < m16524static) {
                                        wb1Var.m16520package(i3);
                                    } else {
                                        wb1Var.m16521private(m16524static);
                                    }
                                }
                                while (true) {
                                    if (wb1Var.m16509do() < 4 || (m8654else = jw0.m8654else(wb1Var.f41978do, wb1Var.f41980if)) == 442 || m8654else == 441 || (m8654else >>> 8) != 1) {
                                        break;
                                    }
                                    wb1Var.m16521private(4);
                                    if (wb1Var.m16509do() < 2) {
                                        wb1Var.m16520package(i3);
                                        break;
                                    }
                                    wb1Var.m16520package(Math.min(wb1Var.f41979for, wb1Var.f41980if + wb1Var.m16524static()));
                                }
                            } else {
                                wb1Var.m16520package(i3);
                            }
                        } else {
                            wb1Var.m16520package(i3);
                        }
                    } else {
                        wb1Var.m16520package(i3);
                    }
                    i = wb1Var.f41980if;
                }
            }
            return j2 != -9223372036854775807L ? js0.e.m8609for(j2, position + i) : js0.e.f19207do;
        }
    }

    public jw0(hc1 hc1Var, long j, long j2) {
        super(new js0.b(), new b(hc1Var, null), j, 0L, j + 1, 0L, j2, 188L, YandexMetricaDefaultValues.DEFAULT_MAX_REPORTS_IN_DATABASE_COUNT);
    }

    /* renamed from: else, reason: not valid java name */
    public static int m8654else(byte[] bArr, int i) {
        return (bArr[i + 3] & 255) | ((bArr[i] & 255) << 24) | ((bArr[i + 1] & 255) << 16) | ((bArr[i + 2] & 255) << 8);
    }
}
