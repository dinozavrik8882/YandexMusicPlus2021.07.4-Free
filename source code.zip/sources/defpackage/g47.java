package defpackage;

import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class g47 extends qad {

    /* renamed from: final, reason: not valid java name */
    public final /* synthetic */ z37 f13053final;

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ e69 f13054super;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g47(z37 z37Var, e69 e69Var, qg9 qg9Var, a48 a48Var) {
        super(qg9Var, a48Var);
        this.f13053final = z37Var;
        this.f13054super = e69Var;
    }

    @Override // defpackage.wad, java.lang.Runnable
    public void run() {
        z37 z37Var = this.f13053final;
        g8d.T(z37Var.f46621for, z37Var.m17831class().mo9664try(), R.string.track_was_removed_from_dislikes);
        this.f13053final.m17833this().m11945while(this.f13054super);
    }
}
