package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class lx2 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ int f23006do = 0;

    static {
        lx2.class.getClassLoader();
    }

    /* renamed from: do, reason: not valid java name */
    public static <T extends Parcelable> T m10054do(Parcel parcel, Parcelable.Creator<T> creator) {
        if (parcel.readInt() == 0) {
            return null;
        }
        return creator.createFromParcel(parcel);
    }
}
