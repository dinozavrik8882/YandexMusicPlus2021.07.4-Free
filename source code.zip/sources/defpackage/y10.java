package defpackage;

import java.io.File;

/* loaded from: classes.dex */
public interface y10 {

    /* loaded from: classes.dex */
    public interface a {
    }

    /* loaded from: classes.dex */
    public interface b {
    }

    void clear();

    /* renamed from: do */
    void mo2524do(jz jzVar, b bVar);

    /* renamed from: if */
    File mo2526if(jz jzVar);
}
