package defpackage;

/* loaded from: classes.dex */
public interface p00 {

    /* loaded from: classes.dex */
    public interface a {
        /* renamed from: case */
        void mo8721case(jz jzVar, Object obj, uz<?> uzVar, xy xyVar, jz jzVar2);

        /* renamed from: if */
        void mo8722if(jz jzVar, Exception exc, uz<?> uzVar, xy xyVar);

        /* renamed from: try */
        void mo8723try();
    }

    void cancel();

    /* renamed from: do */
    boolean mo6323do();
}
