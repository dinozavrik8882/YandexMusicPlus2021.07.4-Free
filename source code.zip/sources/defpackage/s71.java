package defpackage;

import java.util.List;

/* loaded from: classes.dex */
public interface s71 {

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: do, reason: not valid java name */
        public final b21 f35021do;

        /* renamed from: for, reason: not valid java name */
        public final int f35022for;

        /* renamed from: if, reason: not valid java name */
        public final int[] f35023if;

        /* renamed from: new, reason: not valid java name */
        public final Object f35024new;

        public a(b21 b21Var, int... iArr) {
            this.f35021do = b21Var;
            this.f35023if = iArr;
            this.f35022for = 0;
            this.f35024new = null;
        }

        public a(b21 b21Var, int[] iArr, int i, Object obj) {
            this.f35021do = b21Var;
            this.f35023if = iArr;
            this.f35022for = i;
            this.f35024new = obj;
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        /* renamed from: do */
        s71[] mo10800do(a[] aVarArr, e91 e91Var);
    }

    /* renamed from: break */
    int mo11388break(bo0 bo0Var);

    /* renamed from: case */
    void mo10795case();

    /* renamed from: catch */
    void mo5593catch(long j, long j2, long j3, List<? extends t21> list, u21[] u21VarArr);

    /* renamed from: class */
    int mo11389class();

    /* renamed from: const */
    bo0 mo11390const();

    /* renamed from: do */
    b21 mo11391do();

    /* renamed from: else */
    void mo10796else();

    /* renamed from: final */
    int mo5594final();

    /* renamed from: for */
    boolean mo11392for(int i, long j);

    /* renamed from: goto */
    int mo11393goto(int i);

    /* renamed from: if */
    int mo5595if();

    /* renamed from: import */
    int mo11394import(int i);

    int length();

    /* renamed from: new, reason: not valid java name */
    default boolean m14127new(long j, l21 l21Var, List<? extends t21> list) {
        return false;
    }

    /* renamed from: super */
    void mo10798super(float f);

    /* renamed from: this */
    int mo10799this(long j, List<? extends t21> list);

    /* renamed from: throw */
    Object mo5596throw();

    /* renamed from: try */
    bo0 mo11396try(int i);

    /* renamed from: while, reason: not valid java name */
    default void m14128while() {
    }
}
