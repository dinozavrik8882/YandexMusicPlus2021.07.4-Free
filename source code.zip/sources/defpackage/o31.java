package defpackage;

import com.google.android.exoplayer2.util.Util;

/* loaded from: classes.dex */
public class o31 {

    /* renamed from: do, reason: not valid java name */
    public final String f26580do;

    /* renamed from: for, reason: not valid java name */
    public final String f26581for;

    /* renamed from: if, reason: not valid java name */
    public final String f26582if;

    /* renamed from: new, reason: not valid java name */
    public final String f26583new;

    /* renamed from: try, reason: not valid java name */
    public final String f26584try;

    public o31(String str, String str2, String str3, String str4, String str5) {
        this.f26580do = str;
        this.f26582if = str2;
        this.f26581for = str3;
        this.f26583new = str4;
        this.f26584try = str5;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || o31.class != obj.getClass()) {
            return false;
        }
        o31 o31Var = (o31) obj;
        return Util.areEqual(this.f26580do, o31Var.f26580do) && Util.areEqual(this.f26582if, o31Var.f26582if) && Util.areEqual(this.f26581for, o31Var.f26581for) && Util.areEqual(this.f26583new, o31Var.f26583new) && Util.areEqual(this.f26584try, o31Var.f26584try);
    }

    public int hashCode() {
        String str = this.f26580do;
        int hashCode = (527 + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f26582if;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.f26581for;
        int hashCode3 = (hashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31;
        String str4 = this.f26583new;
        int hashCode4 = (hashCode3 + (str4 != null ? str4.hashCode() : 0)) * 31;
        String str5 = this.f26584try;
        return hashCode4 + (str5 != null ? str5.hashCode() : 0);
    }
}
