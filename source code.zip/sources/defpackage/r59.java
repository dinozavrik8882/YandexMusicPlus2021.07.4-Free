package defpackage;

/* loaded from: classes2.dex */
public enum r59 {
    MP3("mp3", 1),
    AAC("aac", 2),
    UNKNOWN("unknown", 0);

    public final String value;
    public final int weight;

    r59(String str, int i) {
        this.value = str;
        this.weight = i;
    }

    public static r59 fromValue(String str) {
        r59[] values = values();
        for (int i = 0; i < 3; i++) {
            r59 r59Var = values[i];
            if (r59Var.value.equalsIgnoreCase(str)) {
                return r59Var;
            }
        }
        return UNKNOWN;
    }
}
