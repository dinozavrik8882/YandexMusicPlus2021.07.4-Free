package defpackage;

import android.view.View;
import defpackage.ze;

/* loaded from: classes.dex */
public class cf extends ze.b<Boolean> {
    public cf(int i, Class cls, int i2) {
        super(i, cls, i2);
    }

    @Override // ze.b
    /* renamed from: if */
    public Boolean mo516if(View view) {
        return Boolean.valueOf(view.isAccessibilityHeading());
    }

    /* renamed from: new, reason: not valid java name */
    public void m2860new(View view, Object obj) {
        view.setAccessibilityHeading(((Boolean) obj).booleanValue());
    }

    /* renamed from: try, reason: not valid java name */
    public boolean m2861try(Object obj, Object obj2) {
        return !m18005do((Boolean) obj, (Boolean) obj2);
    }
}
