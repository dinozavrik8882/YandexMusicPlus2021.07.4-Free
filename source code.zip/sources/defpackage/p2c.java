package defpackage;

import com.squareup.moshi.Json;
import com.yandex.auth.sync.AccountProvider;

/* loaded from: classes2.dex */
public class p2c {

    @Json(name = "liked")
    public boolean liked;

    @Json(name = "track")
    public d3c track;

    @Json(name = "trackParameters")
    public e3c trackParameters;

    @Json(name = AccountProvider.TYPE)
    public String type;
}
