package defpackage;

/* loaded from: classes2.dex */
public final class tnb extends kp5 implements mo5<Throwable, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ bo5<pl5> f37534catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public tnb(bo5<pl5> bo5Var) {
        super(1);
        this.f37534catch = bo5Var;
    }

    @Override // defpackage.mo5
    public pl5 invoke(Throwable th) {
        jp5.m8570try(th, "it");
        this.f37534catch.invoke();
        return pl5.f29126do;
    }
}
