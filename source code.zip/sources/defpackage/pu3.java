package defpackage;

import com.yandex.metrica.rtm.Constants;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.Charset;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.ReentrantLock;

/* loaded from: classes.dex */
public final class pu3 {

    /* renamed from: do, reason: not valid java name */
    public final qu3 f29569do;

    /* renamed from: for, reason: not valid java name */
    public Thread f29570for;

    /* renamed from: if, reason: not valid java name */
    public final ReentrantLock f29571if;

    /* renamed from: new, reason: not valid java name */
    public final LinkedBlockingQueue<Object> f29572new;

    /* loaded from: classes.dex */
    public static final class a extends kp5 implements mo5<mu3, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ String f29573catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(String str) {
            super(1);
            this.f29573catch = str;
        }

        /* JADX WARN: Finally extract failed */
        @Override // defpackage.mo5
        public pl5 invoke(mu3 mu3Var) {
            boolean m10621if;
            mu3 mu3Var2 = mu3Var;
            jp5.m8570try(mu3Var2, "activeFile");
            String str = this.f29573catch;
            jp5.m8570try(str, Constants.KEY_MESSAGE);
            if (mu3Var2.f24593if) {
                m10621if = true;
            } else {
                m10621if = mu3Var2.m10621if();
                mu3Var2.f24593if = m10621if;
            }
            if (m10621if) {
                FileOutputStream fileOutputStream = mu3Var2.f24592for;
                jp5.m8565for(fileOutputStream);
                FileChannel channel = fileOutputStream.getChannel();
                OutputStream outputStream = mu3Var2.f24594new;
                jp5.m8565for(outputStream);
                Charset charset = ns5.f26008do;
                byte[] bytes = str.getBytes(charset);
                jp5.m8568new(bytes, "(this as java.lang.String).getBytes(charset)");
                try {
                    jp5.m8568new(channel, "channel");
                    FileLock lock = channel.lock();
                    try {
                        outputStream.write(bytes);
                        byte[] bytes2 = "\n".getBytes(charset);
                        jp5.m8568new(bytes2, "(this as java.lang.String).getBytes(charset)");
                        outputStream.write(bytes2);
                        outputStream.flush();
                        if (lock != null && lock.isValid()) {
                            lock.release();
                        }
                    } catch (Throwable th) {
                        if (lock != null && lock.isValid()) {
                            lock.release();
                        }
                        throw th;
                    }
                } catch (IOException unused) {
                    mu3Var2.f24593if = false;
                }
            }
            return pl5.f29126do;
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends kp5 implements bo5<pl5> {
        public b() {
            super(0);
        }

        @Override // defpackage.bo5
        public pl5 invoke() {
            while (!Thread.currentThread().isInterrupted()) {
                pu3 pu3Var = pu3.this;
                Object take = pu3Var.f29572new.take();
                jp5.m8568new(take, "messageQueue.take()");
                if (take instanceof String) {
                    pu3Var.m12319do((String) take);
                } else {
                    if (!(take instanceof Runnable)) {
                        throw new IllegalStateException(jp5.m8559break("Invalid message ", take).toString());
                    }
                    ((Runnable) take).run();
                }
            }
            return pl5.f29126do;
        }
    }

    public pu3(long j, int i, File file) {
        jp5.m8570try(file, "filesDir");
        this.f29569do = new qu3(j, i, file);
        this.f29571if = new ReentrantLock();
        this.f29572new = new LinkedBlockingQueue<>();
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x0081 A[Catch: all -> 0x0188, TRY_LEAVE, TryCatch #5 {all -> 0x0188, blocks: (B:28:0x006d, B:30:0x0075, B:35:0x0081, B:90:0x0089, B:91:0x009f, B:94:0x00a7, B:96:0x008f), top: B:27:0x006d, outer: #3, inners: #6 }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x010e A[Catch: all -> 0x0174, TryCatch #2 {all -> 0x0174, blocks: (B:47:0x00f9, B:50:0x0109, B:52:0x010e, B:54:0x0135, B:55:0x0151, B:56:0x0155, B:58:0x015b, B:60:0x0138, B:67:0x0107), top: B:46:0x00f9, outer: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0107 A[Catch: all -> 0x0174, TryCatch #2 {all -> 0x0174, blocks: (B:47:0x00f9, B:50:0x0109, B:52:0x010e, B:54:0x0135, B:55:0x0151, B:56:0x0155, B:58:0x015b, B:60:0x0138, B:67:0x0107), top: B:46:0x00f9, outer: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0089 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* renamed from: do, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void m12319do(java.lang.String r13) {
        /*
            Method dump skipped, instructions count: 421
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.pu3.m12319do(java.lang.String):void");
    }

    /* renamed from: if, reason: not valid java name */
    public final void m12320if() {
        ReentrantLock reentrantLock = this.f29571if;
        reentrantLock.lock();
        try {
            if (this.f29570for != null) {
                return;
            }
            b bVar = new b();
            jp5.m8570try(bVar, "block");
            sm5 sm5Var = new sm5(bVar);
            sm5Var.setDaemon(true);
            sm5Var.setPriority(1);
            sm5Var.start();
            this.f29570for = sm5Var;
        } finally {
            reentrantLock.unlock();
        }
    }
}
