package defpackage;

import android.view.View;
import android.widget.TextView;
import defpackage.a2;
import ru.yandex.music.R;

@ln5(c = "ru.yandex.music.profile.PromoCodeView$observePresenter$$inlined$collectWhenStarted$2", f = "PromoCodeView.kt", l = {42}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class knb extends pn5 implements qo5<gu5, wm5<? super pl5>, Object> {

    /* renamed from: super, reason: not valid java name */
    public int f20679super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ ey5 f20680throw;

    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ a2 f20681while;

    /* loaded from: classes2.dex */
    public static final class a implements fy5<Boolean> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ a2 f20682catch;

        public a(a2 a2Var) {
            this.f20682catch = a2Var;
        }

        @Override // defpackage.fy5
        /* renamed from: if */
        public Object mo600if(Boolean bool, wm5 wm5Var) {
            boolean booleanValue = bool.booleanValue();
            final a2 a2Var = this.f20682catch;
            if (booleanValue) {
                ((TextView) a2Var.f85for.m5520do(a2.f82do[0])).setText(R.string.subscription_promo_code_subscribed);
                a2Var.m63if().setOnClickListener(new View.OnClickListener() { // from class: qmb
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        a2 a2Var2 = a2.this;
                        jp5.m8570try(a2Var2, "this$0");
                        a2.c cVar = a2Var2.f89this;
                        if (cVar == null) {
                            return;
                        }
                        cVar.mo64do();
                    }
                });
                a2Var.m61do().setOnClickListener(new View.OnClickListener() { // from class: smb
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        a2 a2Var2 = a2.this;
                        jp5.m8570try(a2Var2, "this$0");
                        a2.c cVar = a2Var2.f89this;
                        if (cVar == null) {
                            return;
                        }
                        cVar.mo65for();
                    }
                });
                a2Var.m63if().setText(R.string.share_with_friend);
                a2Var.m61do().setText(R.string.promo_code_button_text);
            } else {
                ((TextView) a2Var.f85for.m5520do(a2.f82do[0])).setText(R.string.subscription_promo_code);
                a2Var.m63if().setOnClickListener(new View.OnClickListener() { // from class: tmb
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        a2 a2Var2 = a2.this;
                        jp5.m8570try(a2Var2, "this$0");
                        a2.c cVar = a2Var2.f89this;
                        if (cVar == null) {
                            return;
                        }
                        cVar.mo65for();
                    }
                });
                a2Var.m61do().setOnClickListener(new View.OnClickListener() { // from class: rmb
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        a2 a2Var2 = a2.this;
                        jp5.m8570try(a2Var2, "this$0");
                        a2.c cVar = a2Var2.f89this;
                        if (cVar == null) {
                            return;
                        }
                        cVar.mo64do();
                    }
                });
                a2Var.m63if().setText(R.string.promo_code_button_text);
                a2Var.m61do().setText(R.string.share_with_friend);
                a2Var.m61do().setVisibility(8);
            }
            return pl5.f29126do;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public knb(ey5 ey5Var, wm5 wm5Var, a2 a2Var) {
        super(2, wm5Var);
        this.f20680throw = ey5Var;
        this.f20681while = a2Var;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        return new knb(this.f20680throw, wm5Var, this.f20681while);
    }

    @Override // defpackage.qo5
    public Object invoke(gu5 gu5Var, wm5<? super pl5> wm5Var) {
        return new knb(this.f20680throw, wm5Var, this.f20681while).mo76return(pl5.f29126do);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        int i = this.f20679super;
        if (i == 0) {
            dn3.N2(obj);
            ey5 ey5Var = this.f20680throw;
            a aVar = new a(this.f20681while);
            this.f20679super = 1;
            if (ey5Var.mo1466do(aVar, this) == cn5Var) {
                return cn5Var;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            dn3.N2(obj);
        }
        return pl5.f29126do;
    }
}
