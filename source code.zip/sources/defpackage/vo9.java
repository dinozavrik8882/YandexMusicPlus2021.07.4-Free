package defpackage;

import com.yandex.auth.sync.AccountProvider;
import com.yandex.metrica.rtm.Constants;
import defpackage.bz3;
import defpackage.po9;
import java.util.LinkedHashSet;
import java.util.Objects;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes2.dex */
public abstract class vo9 {

    /* renamed from: do, reason: not valid java name */
    public static final a f40937do = new a(null);

    /* loaded from: classes2.dex */
    public static final class a {

        /* renamed from: do, reason: not valid java name */
        public static final /* synthetic */ mr5<Object>[] f40938do;

        static {
            up5 up5Var = new up5(dq5.m4763do(a.class), "trackTarget", "<v#0>");
            eq5 eq5Var = dq5.f8909do;
            Objects.requireNonNull(eq5Var);
            up5 up5Var2 = new up5(dq5.m4763do(a.class), "trackFallbackTarget", "<v#1>");
            Objects.requireNonNull(eq5Var);
            f40938do = new mr5[]{up5Var, up5Var2};
        }

        public a() {
        }

        public a(ep5 ep5Var) {
        }

        /* renamed from: for, reason: not valid java name */
        public static /* synthetic */ double m16181for(a aVar, xo9 xo9Var, boolean z, double d, int i) {
            if ((i & 2) != 0) {
                z = false;
            }
            if ((i & 4) != 0) {
                d = 0.0d;
            }
            return aVar.m16183if(xo9Var, z, d);
        }

        /* renamed from: do, reason: not valid java name */
        public final vo9 m16182do(b.a aVar, on8 on8Var, xo9 xo9Var, String str, boolean z) {
            xo9 xo9Var2;
            xo9 xo9Var3;
            jp5.m8570try(aVar, AccountProvider.TYPE);
            jp5.m8570try(on8Var, "queue");
            if (xo9Var == null) {
                jp5.m8570try(on8Var, "queue");
                e69 e69Var = on8Var.f27580break;
                if (e69Var == null) {
                    xo9Var3 = null;
                } else {
                    Integer valueOf = Integer.valueOf(on8Var.f27582catch);
                    jp5.m8570try(e69Var, "track");
                    xo9Var3 = new xo9(e69Var.f9541catch, e69Var.f9547final, valueOf);
                }
                xo9Var2 = xo9Var3;
            } else {
                xo9Var2 = xo9Var;
            }
            Double valueOf2 = xo9Var == null ? null : Double.valueOf(0.0d);
            double m16184new = valueOf2 == null ? m16184new(on8Var.f27583class) : valueOf2.doubleValue();
            t78 t78Var = on8Var.f41757for;
            jp5.m8568new(t78Var, "queue.playbackContext()");
            if (str != null || (str = t78Var.m14691else()) != null) {
                return new b(aVar, str, t78Var, xo9Var2, xo9Var2 != null ? Double.valueOf(vo9.f40937do.m16183if(xo9Var2, z, m16184new)) : null);
            }
            if (xo9Var2 == null) {
                StringBuilder r = by.r("queue(type=");
                r.append(t78Var.m14690catch());
                r.append(", id=null) without track");
                return new c(r.toString());
            }
            double m16183if = m16183if(xo9Var2, z, m16184new);
            String m14695new = t78Var.m14695new();
            jp5.m8568new(m14695new, "playbackContext.generateFrom()");
            return new f(xo9Var2, m16183if, m14695new);
        }

        /* renamed from: if, reason: not valid java name */
        public final double m16183if(xo9 xo9Var, boolean z, double d) {
            iz3 l3 = dn3.l3(oa8.class);
            jp5.m8570try(l3, "typeSpec");
            bz3 bz3Var = bz3.f4526do;
            jp5.m8565for(bz3Var);
            jp5.m8570try(l3, "typeSpec");
            LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
            oa8 oa8Var = (oa8) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet);
            String str = xo9Var.f44200if;
            e69 mo286new = oa8Var.mo10269finally().mo2230const().f13942case.mo286new();
            Double valueOf = !jp5.m8563do(str, mo286new == null ? null : mo286new.f9541catch) ? null : Double.valueOf(m16184new(oa8Var.mo10265do()));
            if (z) {
                return valueOf == null ? d : valueOf.doubleValue();
            }
            iz3 l32 = dn3.l3(xl8.class);
            jp5.m8570try(l32, "typeSpec");
            bz3 bz3Var2 = bz3.f4526do;
            jp5.m8565for(bz3Var2);
            jp5.m8570try(l32, "typeSpec");
            LinkedHashSet linkedHashSet2 = bz3Var2.f4528if ? new LinkedHashSet() : null;
            xl8 xl8Var = (xl8) bz3Var2.m2426new(l32, linkedHashSet2 != null ? new bz3.a(bz3Var2, linkedHashSet2) : bz3Var2.f4529new, linkedHashSet2);
            Long m17203for = xl8Var.m17203for(xo9Var.f44200if);
            if (m17203for == null || xl8Var.m17208try(m17203for.longValue(), xo9Var.f44199for)) {
                m17203for = null;
            }
            Double valueOf2 = m17203for != null ? Double.valueOf(m16184new(m17203for.longValue())) : null;
            return valueOf2 == null ? valueOf == null ? d : valueOf.doubleValue() : valueOf2.doubleValue();
        }

        /* renamed from: new, reason: not valid java name */
        public final double m16184new(long j) {
            return j / 1000;
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends vo9 {

        /* renamed from: case, reason: not valid java name */
        public final Double f40939case;

        /* renamed from: else, reason: not valid java name */
        public final po9 f40940else;

        /* renamed from: for, reason: not valid java name */
        public final String f40941for;

        /* renamed from: if, reason: not valid java name */
        public final a f40942if;

        /* renamed from: new, reason: not valid java name */
        public final t78 f40943new;

        /* renamed from: try, reason: not valid java name */
        public final xo9 f40944try;

        /* loaded from: classes2.dex */
        public enum a {
            RADIO(po9.a.RADIO),
            ALBUM(po9.a.ALBUM),
            ARTIST(po9.a.ARTIST),
            PLAYLIST(po9.a.PLAYLIST);

            public static final C0320a Companion = new C0320a(null);
            private final po9.a glagolType;

            /* renamed from: vo9$b$a$a, reason: collision with other inner class name */
            /* loaded from: classes2.dex */
            public static final class C0320a {
                public C0320a(ep5 ep5Var) {
                }
            }

            a(po9.a aVar) {
                this.glagolType = aVar;
            }

            public final po9.a getGlagolType$yandexmusic_gplayProdRelease() {
                return this.glagolType;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(a aVar, String str, t78 t78Var, xo9 xo9Var, Double d) {
            super(null);
            xo9 xo9Var2;
            jp5.m8570try(aVar, "entityType");
            jp5.m8570try(str, "entityId");
            jp5.m8570try(t78Var, "playbackContext");
            this.f40942if = aVar;
            this.f40941for = str;
            this.f40943new = t78Var;
            this.f40944try = xo9Var;
            this.f40939case = d;
            po9.a glagolType$yandexmusic_gplayProdRelease = aVar.getGlagolType$yandexmusic_gplayProdRelease();
            String m14695new = t78Var.m14695new();
            if (xo9Var == null) {
                xo9Var2 = null;
            } else {
                String str2 = xo9Var.f44200if;
                long j = xo9Var.f44199for;
                jp5.m8570try(str2, DatabaseHelper.OttTrackingTable.COLUMN_ID);
                xo9Var2 = new xo9(str2, j, null);
            }
            this.f40940else = new po9(glagolType$yandexmusic_gplayProdRelease, null, str, xo9Var2, d, m14695new, 2);
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        public /* synthetic */ b(a aVar, String str, t78 t78Var, xo9 xo9Var, Double d, int i) {
            this(aVar, str, t78Var, null, null);
            int i2 = i & 8;
            int i3 = i & 16;
        }

        public String toString() {
            return this.f40942if + "(id=" + this.f40941for + ", start=" + this.f40944try + ", offset=" + this.f40939case + ", context=" + this.f40943new + ')';
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends vo9 {

        /* renamed from: if, reason: not valid java name */
        public final IllegalStateException f40945if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(String str) {
            super(null);
            jp5.m8570try(str, Constants.KEY_MESSAGE);
            this.f40945if = new IllegalStateException(str);
        }

        public String toString() {
            StringBuilder r = by.r("Illegal(");
            r.append((Object) this.f40945if.getMessage());
            r.append(')');
            return r.toString();
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends vo9 {

        /* renamed from: if, reason: not valid java name */
        public static final d f40946if = new d();

        public d() {
            super(null);
        }

        public String toString() {
            return "Play";
        }
    }

    /* loaded from: classes2.dex */
    public static final class e extends vo9 {

        /* renamed from: if, reason: not valid java name */
        public final po9 f40947if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(po9 po9Var) {
            super(null);
            jp5.m8570try(po9Var, "castEntity");
            this.f40947if = po9Var;
        }

        public String toString() {
            StringBuilder r = by.r("Special(type=");
            r.append((Object) this.f40947if.f29270if);
            r.append(", id=");
            return by.c(r, this.f40947if.f29269for, ')');
        }
    }

    /* loaded from: classes2.dex */
    public static final class f extends vo9 {

        /* renamed from: for, reason: not valid java name */
        public final double f40948for;

        /* renamed from: if, reason: not valid java name */
        public final xo9 f40949if;

        /* renamed from: new, reason: not valid java name */
        public final String f40950new;

        /* renamed from: try, reason: not valid java name */
        public final po9 f40951try;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(xo9 xo9Var, double d, String str) {
            super(null);
            jp5.m8570try(xo9Var, "descriptor");
            jp5.m8570try(str, "from");
            this.f40949if = xo9Var;
            this.f40948for = d;
            this.f40950new = str;
            this.f40951try = new po9(po9.a.TRACK, null, xo9Var.f44200if, xo9Var, Double.valueOf(d), str, 2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof f)) {
                return false;
            }
            f fVar = (f) obj;
            return jp5.m8563do(this.f40949if, fVar.f40949if) && jp5.m8563do(Double.valueOf(this.f40948for), Double.valueOf(fVar.f40948for)) && jp5.m8563do(this.f40950new, fVar.f40950new);
        }

        public int hashCode() {
            return this.f40950new.hashCode() + ((Double.hashCode(this.f40948for) + (this.f40949if.hashCode() * 31)) * 31);
        }

        public String toString() {
            StringBuilder r = by.r("Track(id=");
            r.append(this.f40949if.f44200if);
            r.append(", progress=");
            r.append(this.f40948for);
            r.append("s, from=");
            return by.c(r, this.f40950new, ')');
        }
    }

    /* loaded from: classes2.dex */
    public static final class g extends vo9 {

        /* renamed from: if, reason: not valid java name */
        public final qo5<qo5<? super xo9, ? super wm5<? super Double>, ? extends Object>, wm5<? super po9>, Object> f40952if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        public g(qo5<? super qo5<? super xo9, ? super wm5<? super Double>, ? extends Object>, ? super wm5<? super po9>, ? extends Object> qo5Var) {
            super(null);
            jp5.m8570try(qo5Var, "constructCastEntity");
            this.f40952if = qo5Var;
        }

        public String toString() {
            return "TrackList(async)";
        }
    }

    public vo9() {
    }

    public vo9(ep5 ep5Var) {
    }
}
