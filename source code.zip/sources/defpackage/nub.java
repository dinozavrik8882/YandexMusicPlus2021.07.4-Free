package defpackage;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class nub {

    /* renamed from: do, reason: not valid java name */
    public final fub f26119do;

    /* renamed from: for, reason: not valid java name */
    public volatile t4c f26120for;

    /* renamed from: if, reason: not valid java name */
    public volatile boolean f26121if;

    /* loaded from: classes2.dex */
    public static final class a extends Exception {
    }

    @ln5(c = "ru.yandex.music.radio.store.RadioCatalogCenter", f = "RadioCatalogCenter.kt", l = {33}, m = "recommendations")
    /* loaded from: classes2.dex */
    public static final class b extends jn5 {

        /* renamed from: final, reason: not valid java name */
        public Object f26122final;

        /* renamed from: super, reason: not valid java name */
        public /* synthetic */ Object f26123super;

        /* renamed from: while, reason: not valid java name */
        public int f26125while;

        public b(wm5<? super b> wm5Var) {
            super(wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            this.f26123super = obj;
            this.f26125while |= Integer.MIN_VALUE;
            return nub.this.m11225for(false, null, this);
        }
    }

    public nub(fub fubVar) {
        jp5.m8570try(fubVar, "radioCatalogApi");
        this.f26119do = fubVar;
    }

    /* renamed from: if, reason: not valid java name */
    public static Object m11223if(nub nubVar, boolean z, List list, wm5 wm5Var, int i) throws IOException, zv3, c74, a {
        if ((i & 1) != 0) {
            z = false;
        }
        Objects.requireNonNull(nubVar);
        return dn3.F3(kv4.f21091if, new oub(nubVar, z, list, null), wm5Var);
    }

    /* renamed from: do, reason: not valid java name */
    public final void m11224do() {
        k2f.f19768new.mo8764do("invalidateRecommendations", new Object[0]);
        this.f26121if = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x009a A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* renamed from: for, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m11225for(boolean r6, java.util.List<? extends qub.a> r7, defpackage.wm5<? super defpackage.q4c> r8) throws java.io.IOException, defpackage.zv3, defpackage.c74, nub.a {
        /*
            r5 = this;
            boolean r0 = r8 instanceof nub.b
            if (r0 == 0) goto L13
            r0 = r8
            nub$b r0 = (nub.b) r0
            int r1 = r0.f26125while
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f26125while = r1
            goto L18
        L13:
            nub$b r0 = new nub$b
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f26123super
            cn5 r1 = defpackage.cn5.COROUTINE_SUSPENDED
            int r2 = r0.f26125while
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L34
            if (r2 != r4) goto L2c
            java.lang.Object r6 = r0.f26122final
            nub r6 = (defpackage.nub) r6
            defpackage.dn3.N2(r8)
            goto L4f
        L2c:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L34:
            defpackage.dn3.N2(r8)
            fub r8 = r5.f26119do
            if (r6 != 0) goto L42
            boolean r6 = r5.f26121if
            if (r6 == 0) goto L40
            goto L42
        L40:
            r6 = r3
            goto L43
        L42:
            r6 = r4
        L43:
            r0.f26122final = r5
            r0.f26125while = r4
            java.lang.Object r8 = r8.mo6227for(r6, r7, r0)
            if (r8 != r1) goto L4e
            return r1
        L4e:
            r6 = r5
        L4f:
            yub r8 = (defpackage.yub) r8
            java.lang.String r7 = "<this>"
            defpackage.jp5.m8570try(r8, r7)
            java.lang.String r7 = r8.m17758do()
            r0 = 0
            if (r7 == 0) goto L91
            java.util.List r7 = r8.m17759if()
            if (r7 != 0) goto L64
            goto L91
        L64:
            java.lang.String r7 = r8.m17758do()
            java.util.List r8 = r8.m17759if()
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Iterator r8 = r8.iterator()
        L75:
            boolean r2 = r8.hasNext()
            if (r2 == 0) goto L8b
            java.lang.Object r2 = r8.next()
            vub r2 = (defpackage.vub) r2
            t4c r2 = defpackage.qd9.F(r2)
            if (r2 == 0) goto L75
            r1.add(r2)
            goto L75
        L8b:
            q4c r8 = new q4c
            r8.<init>(r7, r1)
            goto L92
        L91:
            r8 = r0
        L92:
            if (r8 != 0) goto L95
            goto L98
        L95:
            r6.f26121if = r3
            r0 = r8
        L98:
            if (r0 == 0) goto L9b
            return r0
        L9b:
            nub$a r6 = new nub$a
            r6.<init>()
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.nub.m11225for(boolean, java.util.List, wm5):java.lang.Object");
    }
}
