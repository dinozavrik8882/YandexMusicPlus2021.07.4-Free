package defpackage;

import android.content.Context;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import defpackage.ps1;
import defpackage.rt1;
import defpackage.wo1;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;

@Deprecated
/* loaded from: classes.dex */
public abstract class zo1 {

    /* renamed from: do, reason: not valid java name */
    public static final Set<zo1> f47577do = Collections.newSetFromMap(new WeakHashMap());

    @Deprecated
    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: break, reason: not valid java name */
        public c f47578break;

        /* renamed from: case, reason: not valid java name */
        public final Context f47579case;

        /* renamed from: catch, reason: not valid java name */
        public Looper f47580catch;

        /* renamed from: class, reason: not valid java name */
        public qo1 f47581class;

        /* renamed from: const, reason: not valid java name */
        public wo1.a<? extends tj2, aj2> f47582const;

        /* renamed from: final, reason: not valid java name */
        public final ArrayList<b> f47585final;

        /* renamed from: for, reason: not valid java name */
        public String f47586for;

        /* renamed from: goto, reason: not valid java name */
        public pp1 f47587goto;

        /* renamed from: new, reason: not valid java name */
        public String f47589new;

        /* renamed from: super, reason: not valid java name */
        public final ArrayList<c> f47590super;

        /* renamed from: do, reason: not valid java name */
        public final Set<Scope> f47583do = new HashSet();

        /* renamed from: if, reason: not valid java name */
        public final Set<Scope> f47588if = new HashSet();

        /* renamed from: try, reason: not valid java name */
        public final Map<wo1<?>, rt1.b> f47592try = new d8();

        /* renamed from: else, reason: not valid java name */
        public final Map<wo1<?>, wo1.d> f47584else = new d8();

        /* renamed from: this, reason: not valid java name */
        public int f47591this = -1;

        public a(@RecentlyNonNull Context context) {
            Object obj = qo1.f30995if;
            this.f47581class = qo1.f30994for;
            this.f47582const = qj2.f30794for;
            this.f47585final = new ArrayList<>();
            this.f47590super = new ArrayList<>();
            this.f47579case = context;
            this.f47580catch = context.getMainLooper();
            this.f47586for = context.getPackageName();
            this.f47589new = context.getClass().getName();
        }

        @RecentlyNonNull
        /* renamed from: do, reason: not valid java name */
        public final a m18174do(@RecentlyNonNull wo1<?> wo1Var) {
            hg1.m7291this(wo1Var, "Api must not be null");
            this.f47584else.put(wo1Var, null);
            wo1.a<?, ?> aVar = wo1Var.f42600do;
            hg1.m7291this(aVar, "Base client builder must not be null");
            List<Scope> mo8395do = aVar.mo8395do(null);
            this.f47588if.addAll(mo8395do);
            this.f47583do.addAll(mo8395do);
            return this;
        }

        @RecentlyNonNull
        /* renamed from: for, reason: not valid java name */
        public final a m18175for(@RecentlyNonNull b bVar) {
            hg1.m7291this(bVar, "Listener must not be null");
            this.f47585final.add(bVar);
            return this;
        }

        @RecentlyNonNull
        /* renamed from: if, reason: not valid java name */
        public final <O extends wo1.d.c> a m18176if(@RecentlyNonNull wo1<O> wo1Var, @RecentlyNonNull O o) {
            hg1.m7291this(wo1Var, "Api must not be null");
            hg1.m7291this(o, "Null options are not permitted for this Api");
            this.f47584else.put(wo1Var, o);
            wo1.a<?, O> aVar = wo1Var.f42600do;
            hg1.m7291this(aVar, "Base client builder must not be null");
            List<Scope> mo8395do = aVar.mo8395do(o);
            this.f47588if.addAll(mo8395do);
            this.f47583do.addAll(mo8395do);
            return this;
        }

        /* JADX WARN: Type inference failed for: r3v20, types: [java.lang.Object, wo1$f] */
        @RecentlyNonNull
        /* renamed from: new, reason: not valid java name */
        public final zo1 m18177new() {
            boolean z;
            boolean z2;
            boolean z3 = true;
            hg1.m7274if(!this.f47584else.isEmpty(), "must call addApi() to add at least one API");
            aj2 aj2Var = aj2.f918catch;
            Map<wo1<?>, wo1.d> map = this.f47584else;
            wo1<aj2> wo1Var = qj2.f30797try;
            if (map.containsKey(wo1Var)) {
                aj2Var = (aj2) this.f47584else.get(wo1Var);
            }
            rt1 rt1Var = new rt1(null, this.f47583do, this.f47592try, 0, null, this.f47586for, this.f47589new, aj2Var);
            Map<wo1<?>, rt1.b> map2 = rt1Var.f33032new;
            d8 d8Var = new d8();
            d8 d8Var2 = new d8();
            ArrayList arrayList = new ArrayList();
            Iterator<wo1<?>> it = this.f47584else.keySet().iterator();
            wo1<?> wo1Var2 = null;
            while (true) {
                if (!it.hasNext()) {
                    if (wo1Var2 != null) {
                        boolean equals = this.f47583do.equals(this.f47588if);
                        z = true;
                        Object[] objArr = {wo1Var2.f42601for};
                        if (!equals) {
                            throw new IllegalStateException(String.format("Must not set scopes in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead.", objArr));
                        }
                    } else {
                        z = true;
                    }
                    sq1 sq1Var = new sq1(this.f47579case, new ReentrantLock(), this.f47580catch, rt1Var, this.f47581class, this.f47582const, d8Var, this.f47585final, this.f47590super, d8Var2, this.f47591this, sq1.m14405public(d8Var2.values(), z), arrayList);
                    Set<zo1> set = zo1.f47577do;
                    synchronized (set) {
                        set.add(sq1Var);
                    }
                    if (this.f47591this >= 0) {
                        ps1 m12284final = ps1.m12284final(this.f47587goto);
                        int i = this.f47591this;
                        c cVar = this.f47578break;
                        hg1.m7291this(sq1Var, "GoogleApiClient instance cannot be null");
                        z2 = m12284final.f29410throw.indexOfKey(i) < 0 ? z : false;
                        StringBuilder sb = new StringBuilder(54);
                        sb.append("Already managing a GoogleApiClient with id ");
                        sb.append(i);
                        hg1.m7262catch(z2, sb.toString());
                        rs1 rs1Var = m12284final.f35942const.get();
                        boolean z4 = m12284final.f35941class;
                        String valueOf = String.valueOf(rs1Var);
                        StringBuilder sb2 = new StringBuilder(valueOf.length() + 49);
                        sb2.append("starting AutoManage for client ");
                        sb2.append(i);
                        sb2.append(" ");
                        sb2.append(z4);
                        sb2.append(" ");
                        sb2.append(valueOf);
                        Log.d("AutoManageHelper", sb2.toString());
                        ps1.a aVar = new ps1.a(i, sq1Var, cVar);
                        sq1Var.f35847for.m6850if(aVar);
                        m12284final.f29410throw.put(i, aVar);
                        if (m12284final.f35941class && rs1Var == null) {
                            String valueOf2 = String.valueOf(sq1Var);
                            StringBuilder sb3 = new StringBuilder(valueOf2.length() + 11);
                            sb3.append("connecting ");
                            sb3.append(valueOf2);
                            Log.d("AutoManageHelper", sb3.toString());
                            sq1Var.mo4759new();
                        }
                    }
                    return sq1Var;
                }
                wo1<?> next = it.next();
                wo1.d dVar = this.f47584else.get(next);
                z2 = map2.get(next) != null ? z3 : false;
                d8Var.put(next, Boolean.valueOf(z2));
                xs1 xs1Var = new xs1(next, z2);
                arrayList.add(xs1Var);
                wo1.a<?, ?> aVar2 = next.f42600do;
                Objects.requireNonNull(aVar2, "null reference");
                ?? mo2187if = aVar2.mo2187if(this.f47579case, this.f47580catch, rt1Var, dVar, xs1Var, xs1Var);
                d8Var2.put(next.f42602if, mo2187if);
                if (mo2187if.mo15135try()) {
                    if (wo1Var2 != null) {
                        String str = next.f42601for;
                        String str2 = wo1Var2.f42601for;
                        StringBuilder sb4 = new StringBuilder(String.valueOf(str2).length() + String.valueOf(str).length() + 21);
                        sb4.append(str);
                        sb4.append(" cannot be used with ");
                        sb4.append(str2);
                        throw new IllegalStateException(sb4.toString());
                    }
                    wo1Var2 = next;
                }
                z3 = true;
            }
        }
    }

    @Deprecated
    /* loaded from: classes.dex */
    public interface b extends mp1 {
    }

    @Deprecated
    /* loaded from: classes.dex */
    public interface c extends up1 {
    }

    @RecentlyNonNull
    /* renamed from: break */
    public Context mo11150break() {
        throw new UnsupportedOperationException();
    }

    /* renamed from: case */
    public abstract void mo4756case(@RecentlyNonNull String str, @RecentlyNonNull FileDescriptor fileDescriptor, @RecentlyNonNull PrintWriter printWriter, @RecentlyNonNull String[] strArr);

    @RecentlyNonNull
    /* renamed from: catch */
    public Looper mo11151catch() {
        throw new UnsupportedOperationException();
    }

    /* renamed from: class */
    public boolean mo14408class(@RecentlyNonNull yp1 yp1Var) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: const */
    public void mo14409const() {
        throw new UnsupportedOperationException();
    }

    @RecentlyNonNull
    /* renamed from: else */
    public <A extends wo1.b, R extends ep1, T extends kp1<R, A>> T mo11152else(@RecentlyNonNull T t) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: final */
    public abstract void mo4757final(@RecentlyNonNull mg mgVar);

    @RecentlyNonNull
    /* renamed from: for */
    public abstract ap1<Status> mo4758for();

    @RecentlyNonNull
    /* renamed from: goto */
    public <A extends wo1.b, T extends kp1<? extends ep1, A>> T mo11153goto(@RecentlyNonNull T t) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: new */
    public abstract void mo4759new();

    /* renamed from: this */
    public <C extends wo1.f> C mo14414this(@RecentlyNonNull wo1.c<C> cVar) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: throw */
    public abstract void mo4760throw(@RecentlyNonNull b bVar);

    /* renamed from: try */
    public abstract void mo4761try();

    /* renamed from: while */
    public abstract void mo4762while(@RecentlyNonNull c cVar);
}
