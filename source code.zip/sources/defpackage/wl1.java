package defpackage;

import android.content.Context;
import android.os.Looper;
import defpackage.pf1;
import defpackage.wo1;
import defpackage.zo1;

/* loaded from: classes.dex */
public final class wl1 extends wo1.a<cl1, pf1.c> {
    @Override // wo1.a
    /* renamed from: if */
    public final /* synthetic */ cl1 mo2187if(Context context, Looper looper, rt1 rt1Var, pf1.c cVar, zo1.b bVar, zo1.c cVar2) {
        pf1.c cVar3 = cVar;
        hg1.m7291this(cVar3, "Setting the API options is required.");
        return new cl1(context, looper, rt1Var, cVar3.f28887catch, 0, cVar3.f28889const, cVar3.f28890final, bVar, cVar2);
    }
}
