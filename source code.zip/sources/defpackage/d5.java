package defpackage;

import android.widget.ListView;

/* loaded from: classes.dex */
public interface d5 {
    /* renamed from: break, reason: not valid java name */
    ListView mo4101break();

    void dismiss();

    /* renamed from: do, reason: not valid java name */
    void mo4102do();

    /* renamed from: if, reason: not valid java name */
    boolean mo4103if();
}
