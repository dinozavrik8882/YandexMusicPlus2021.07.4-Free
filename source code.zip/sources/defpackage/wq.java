package defpackage;

import android.os.Handler;
import android.os.Looper;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

/* loaded from: classes.dex */
public class wq<T> {

    /* renamed from: do, reason: not valid java name */
    public static Executor f42672do = Executors.newCachedThreadPool();

    /* renamed from: if, reason: not valid java name */
    public final Set<qq<T>> f42674if = new LinkedHashSet(1);

    /* renamed from: for, reason: not valid java name */
    public final Set<qq<Throwable>> f42673for = new LinkedHashSet(1);

    /* renamed from: new, reason: not valid java name */
    public final Handler f42675new = new Handler(Looper.getMainLooper());

    /* renamed from: try, reason: not valid java name */
    public volatile uq<T> f42676try = null;

    /* loaded from: classes.dex */
    public class a extends FutureTask<uq<T>> {
        public a(Callable<uq<T>> callable) {
            super(callable);
        }

        @Override // java.util.concurrent.FutureTask
        public void done() {
            if (isCancelled()) {
                return;
            }
            try {
                wq.this.m16767for(get());
            } catch (InterruptedException | ExecutionException e) {
                wq.this.m16767for(new uq<>(e));
            }
        }
    }

    public wq(Callable<uq<T>> callable) {
        f42672do.execute(new a(callable));
    }

    /* renamed from: do, reason: not valid java name */
    public synchronized wq<T> m16766do(qq<Throwable> qqVar) {
        if (this.f42676try != null && this.f42676try.f39322if != null) {
            qqVar.mo2999do(this.f42676try.f39322if);
        }
        this.f42673for.add(qqVar);
        return this;
    }

    /* renamed from: for, reason: not valid java name */
    public final void m16767for(uq<T> uqVar) {
        if (this.f42676try != null) {
            throw new IllegalStateException("A task may only be set once.");
        }
        this.f42676try = uqVar;
        this.f42675new.post(new vq(this));
    }

    /* renamed from: if, reason: not valid java name */
    public synchronized wq<T> m16768if(qq<T> qqVar) {
        if (this.f42676try != null && this.f42676try.f39321do != null) {
            qqVar.mo2999do(this.f42676try.f39321do);
        }
        this.f42674if.add(qqVar);
        return this;
    }
}
