package defpackage;

import android.content.SharedPreferences;
import defpackage.bz3;
import defpackage.q8a;
import defpackage.t54;
import defpackage.xab;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/* loaded from: classes2.dex */
public final class p8a {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f28591do;

    /* renamed from: case, reason: not valid java name */
    public final k0f<a> f28592case;

    /* renamed from: else, reason: not valid java name */
    public final spe<a> f28593else;

    /* renamed from: for, reason: not valid java name */
    public final t54 f28594for;

    /* renamed from: goto, reason: not valid java name */
    public final el5 f28595goto;

    /* renamed from: if, reason: not valid java name */
    public final q8a f28596if;

    /* renamed from: new, reason: not valid java name */
    public final lj9 f28597new;

    /* renamed from: try, reason: not valid java name */
    public final qg9 f28598try;

    /* loaded from: classes2.dex */
    public static final class a {
    }

    /* loaded from: classes2.dex */
    public static final class b implements u68 {
        public b() {
        }

        @Override // defpackage.u68
        /* renamed from: case */
        public void mo4252case(a78 a78Var) {
            jp5.m8570try(a78Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: do */
        public void mo4253do(ip9 ip9Var) {
            jp5.m8570try(ip9Var, "playable");
            e69 e69Var = ip9Var.f17153for;
            if (e69Var == null) {
                return;
            }
            p8a.this.m11936for(e69Var);
        }

        @Override // defpackage.u68
        /* renamed from: else */
        public void mo4254else(kl8 kl8Var) {
            jp5.m8570try(kl8Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: for */
        public void mo4255for(z68 z68Var) {
            jp5.m8570try(z68Var, "playable");
            p8a p8aVar = p8a.this;
            e69 e69Var = z68Var.f46759if;
            jp5.m8568new(e69Var, "playable.track");
            p8aVar.m11936for(e69Var);
        }

        @Override // defpackage.u68
        /* renamed from: if */
        public void mo4256if(h78 h78Var) {
            jp5.m8570try(h78Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: new */
        public void mo4257new(dr8 dr8Var) {
            jp5.m8570try(dr8Var, "playable");
            p8a.this.m11933do(dr8Var.f8963if);
        }

        @Override // defpackage.u68
        /* renamed from: try */
        public void mo4258try(mj9 mj9Var) {
            jp5.m8570try(mj9Var, "playable");
            lj9 lj9Var = p8a.this.f28597new;
            Objects.requireNonNull(lj9Var);
            jp5.m8570try(mj9Var, "playable");
            m8a m8aVar = m8a.DISLIKED;
            lj9Var.m9784if(mj9Var, m8aVar);
            lj9Var.m9783for(mj9Var, m8aVar, m8a.NEUTRAL);
        }
    }

    /* loaded from: classes2.dex */
    public static final class c implements u68 {
        public c() {
        }

        @Override // defpackage.u68
        /* renamed from: case */
        public void mo4252case(a78 a78Var) {
            jp5.m8570try(a78Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: do */
        public void mo4253do(ip9 ip9Var) {
            jp5.m8570try(ip9Var, "playable");
            e69 e69Var = ip9Var.f17153for;
            if (e69Var == null) {
                return;
            }
            p8a.this.m11928break(e69Var);
        }

        @Override // defpackage.u68
        /* renamed from: else */
        public void mo4254else(kl8 kl8Var) {
            jp5.m8570try(kl8Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: for */
        public void mo4255for(z68 z68Var) {
            jp5.m8570try(z68Var, "playable");
            p8a p8aVar = p8a.this;
            e69 e69Var = z68Var.f46759if;
            jp5.m8568new(e69Var, "playable.track");
            p8aVar.m11928break(e69Var);
        }

        @Override // defpackage.u68
        /* renamed from: if */
        public void mo4256if(h78 h78Var) {
            jp5.m8570try(h78Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: new */
        public void mo4257new(dr8 dr8Var) {
            jp5.m8570try(dr8Var, "playable");
            p8a.this.m11937goto(dr8Var.f8963if);
        }

        @Override // defpackage.u68
        /* renamed from: try */
        public void mo4258try(mj9 mj9Var) {
            jp5.m8570try(mj9Var, "playable");
            p8a.this.m11940new();
            lj9 lj9Var = p8a.this.f28597new;
            Objects.requireNonNull(lj9Var);
            jp5.m8570try(mj9Var, "playable");
            m8a m8aVar = m8a.LIKED;
            lj9Var.m9784if(mj9Var, m8aVar);
            lj9Var.m9783for(mj9Var, m8aVar, m8a.NEUTRAL);
        }
    }

    /* loaded from: classes2.dex */
    public static final class d implements t68<spe<m8a>> {
        public d() {
        }

        @Override // defpackage.t68
        /* renamed from: case */
        public spe<m8a> mo190case(a78 a78Var) {
            jp5.m8570try(a78Var, "playable");
            ixe ixeVar = new ixe(m8a.NEUTRAL);
            jp5.m8568new(ixeVar, "just(LikeState.NEUTRAL)");
            return ixeVar;
        }

        @Override // defpackage.t68
        /* renamed from: do */
        public spe<m8a> mo191do(ip9 ip9Var) {
            jp5.m8570try(ip9Var, "playable");
            e69 e69Var = ip9Var.f17153for;
            if (e69Var != null) {
                return p8a.this.m11932const(e69Var);
            }
            ixe ixeVar = new ixe(m8a.NEUTRAL);
            jp5.m8568new(ixeVar, "just(LikeState.NEUTRAL)");
            return ixeVar;
        }

        @Override // defpackage.t68
        /* renamed from: else */
        public spe<m8a> mo192else(kl8 kl8Var) {
            jp5.m8570try(kl8Var, "playable");
            ixe ixeVar = new ixe(m8a.NEUTRAL);
            jp5.m8568new(ixeVar, "just(LikeState.NEUTRAL)");
            return ixeVar;
        }

        @Override // defpackage.t68
        /* renamed from: for */
        public spe<m8a> mo193for(z68 z68Var) {
            jp5.m8570try(z68Var, "playable");
            p8a p8aVar = p8a.this;
            e69 e69Var = z68Var.f46759if;
            jp5.m8568new(e69Var, "playable.track");
            return p8aVar.m11932const(e69Var);
        }

        @Override // defpackage.t68
        /* renamed from: if */
        public spe<m8a> mo195if(h78 h78Var) {
            jp5.m8570try(h78Var, "playable");
            ixe ixeVar = new ixe(m8a.NEUTRAL);
            jp5.m8568new(ixeVar, "just(LikeState.NEUTRAL)");
            return ixeVar;
        }

        @Override // defpackage.t68
        /* renamed from: new */
        public spe<m8a> mo196new(dr8 dr8Var) {
            jp5.m8570try(dr8Var, "playable");
            return p8a.this.m11930catch(dr8Var.f8963if);
        }

        @Override // defpackage.t68
        /* renamed from: try */
        public spe<m8a> mo197try(mj9 mj9Var) {
            jp5.m8570try(mj9Var, "playable");
            return p8a.this.f28597new.m9782do(mj9Var);
        }
    }

    /* loaded from: classes2.dex */
    public static final class e implements u68 {
        public e() {
        }

        @Override // defpackage.u68
        /* renamed from: case */
        public void mo4252case(a78 a78Var) {
            jp5.m8570try(a78Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: do */
        public void mo4253do(ip9 ip9Var) {
            jp5.m8570try(ip9Var, "playable");
            e69 e69Var = ip9Var.f17153for;
            if (e69Var == null) {
                return;
            }
            p8a.this.m11945while(e69Var);
        }

        @Override // defpackage.u68
        /* renamed from: else */
        public void mo4254else(kl8 kl8Var) {
            jp5.m8570try(kl8Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: for */
        public void mo4255for(z68 z68Var) {
            jp5.m8570try(z68Var, "playable");
            p8a p8aVar = p8a.this;
            e69 e69Var = z68Var.f46759if;
            jp5.m8568new(e69Var, "playable.track");
            p8aVar.m11945while(e69Var);
        }

        @Override // defpackage.u68
        /* renamed from: if */
        public void mo4256if(h78 h78Var) {
            jp5.m8570try(h78Var, "playable");
        }

        @Override // defpackage.u68
        /* renamed from: new */
        public void mo4257new(dr8 dr8Var) {
            jp5.m8570try(dr8Var, "playable");
            p8a.this.m11941super(dr8Var.f8963if);
        }

        @Override // defpackage.u68
        /* renamed from: try */
        public void mo4258try(mj9 mj9Var) {
            jp5.m8570try(mj9Var, "playable");
            Objects.requireNonNull(p8a.this.f28597new);
            jp5.m8570try(mj9Var, "playable");
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(p8a.class), "likeDialogShowController", "getLikeDialogShowController()Lru/yandex/music/likes/LikeDialogShowController;");
        Objects.requireNonNull(dq5.f8909do);
        f28591do = new mr5[]{wp5Var};
    }

    public p8a(q8a q8aVar, t54 t54Var, lj9 lj9Var, qg9 qg9Var) {
        jp5.m8570try(q8aVar, "likesDealer");
        jp5.m8570try(t54Var, "shotLikesManager");
        jp5.m8570try(lj9Var, "generativeLikesManager");
        jp5.m8570try(qg9Var, "userCenter");
        this.f28596if = q8aVar;
        this.f28594for = t54Var;
        this.f28597new = lj9Var;
        this.f28598try = qg9Var;
        k0f<a> s = k0f.s();
        jp5.m8568new(s, "create()");
        this.f28592case = s;
        this.f28593else = s.m14382catch(zbd.m17943if("LikesCenter", true));
        iz3 l3 = dn3.l3(h8a.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        jp5.m8570try(f28591do[0], "prop");
        this.f28595goto = dn3.h1(cz3Var);
    }

    /* renamed from: break, reason: not valid java name */
    public final void m11928break(e69 e69Var) {
        jp5.m8570try(e69Var, "track");
        m11940new();
        if (!this.f28596if.m12553if(e69Var)) {
            k2f.f19768new.mo8764do("Can not call LIKE for track because storage type is %s", e69Var.f9559super);
        } else {
            xab m17028if = xab.m17028if();
            m17028if.f43527new.execute(new xab.c(e69Var, null));
        }
    }

    /* renamed from: case, reason: not valid java name */
    public final boolean m11929case(h59 h59Var) {
        jp5.m8570try(h59Var, "album");
        return this.f28596if.m12551for(h59Var);
    }

    /* renamed from: catch, reason: not valid java name */
    public final spe<m8a> m11930catch(final m64 m64Var) {
        jp5.m8570try(m64Var, "shot");
        t54 t54Var = this.f28594for;
        Objects.requireNonNull(t54Var);
        jp5.m8570try(m64Var, "shot");
        final t54.a aVar = t54Var.f36601if;
        Objects.requireNonNull(aVar);
        jp5.m8570try(m64Var, "shot");
        spe<R> m14390interface = aVar.f36603if.m14397switch(new sqe() { // from class: q54
            @Override // defpackage.sqe
            public final void call() {
                t54.a aVar2 = t54.a.this;
                m64 m64Var2 = m64Var;
                jp5.m8570try(aVar2, "this$0");
                jp5.m8570try(m64Var2, "$shot");
                aVar2.f36603if.mo1523case(new hl5<>(m64Var2.f23471if, aVar2.m14659if(m64Var2)));
            }
        }).m14384extends(new yqe() { // from class: s54
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                m64 m64Var2 = m64.this;
                jp5.m8570try(m64Var2, "$shot");
                return Boolean.valueOf(jp5.m8563do(((hl5) obj).f15273catch, m64Var2.f23471if));
            }
        }).m14390interface(new yqe() { // from class: r54
            /* JADX WARN: Multi-variable type inference failed */
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                return (l64) ((hl5) obj).f15274class;
            }
        });
        jp5.m8568new(m14390interface, "states\n                    .doOnSubscribe { states.onNext(Pair(shot.shotId, getLikeStatus(shot))) }\n                    .filter { it.first == shot.shotId }\n                    .map { it.second }");
        spe m14387implements = m14390interface.m14387implements(jqe.m8590do());
        jp5.m8568new(m14387implements, "shotLikeStatusHelper\n                .getLikeStatusesUpdates(shot)\n                .observeOn(AndroidSchedulers.mainThread())");
        spe<m8a> m14390interface2 = m14387implements.m14390interface(new yqe() { // from class: s7a
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                l64 l64Var = (l64) obj;
                jp5.m8570try(p8a.this, "this$0");
                jp5.m8568new(l64Var, "it");
                int ordinal = l64Var.ordinal();
                if (ordinal == 0) {
                    return m8a.LIKED;
                }
                if (ordinal == 1) {
                    return m8a.DISLIKED;
                }
                if (ordinal == 2) {
                    return m8a.NEUTRAL;
                }
                throw new gl5();
            }
        });
        jp5.m8568new(m14390interface2, "shotLikesManager.likeState(shot).map { it.toLikeState() }");
        return m14390interface2;
    }

    /* renamed from: class, reason: not valid java name */
    public final spe<m8a> m11931class(q68 q68Var) {
        jp5.m8570try(q68Var, "playable");
        if (jp5.m8563do(q68Var, q68.f30204do)) {
            ixe ixeVar = new ixe(m8a.NEUTRAL);
            jp5.m8568new(ixeVar, "just(LikeState.NEUTRAL)");
            return ixeVar;
        }
        Object mo285if = q68Var.mo285if(new d());
        jp5.m8568new(mo285if, "fun likeState(playable: Playable): Observable<LikeState> {\n        if (playable == Playable.NONE) {\n            return Observable.just(LikeState.NEUTRAL)\n        }\n\n        return playable.accept(\n            object : PlayableVisitor<Observable<LikeState>> {\n                override fun visit(playable: TrackPlayable): Observable<LikeState> = likeState(playable.track)\n\n                override fun visit(playable: UriPlayable): Observable<LikeState> = Observable.just(LikeState.NEUTRAL)\n\n                override fun visit(playable: AdvertPlayable): Observable<LikeState> = Observable.just(LikeState.NEUTRAL)\n\n                override fun visit(playable: ShotPlayable): Observable<LikeState> = likeState(playable.shot)\n\n                override fun visit(playable: PrerollPlayable): Observable<LikeState> = Observable.just(LikeState.NEUTRAL)\n\n                override fun visit(playable: GenerativePlayable): Observable<LikeState> {\n                    return generativeLikesManager.likeState(playable)\n                }\n\n                override fun visit(playable: GlagolRemotePlayable): Observable<LikeState> {\n                    return when (val track = playable.musicTrack) {\n                        null -> Observable.just(LikeState.NEUTRAL)\n                        else -> likeState(track)\n                    }\n                }\n            }\n        )\n    }");
        return (spe) mo285if;
    }

    /* renamed from: const, reason: not valid java name */
    public final spe<m8a> m11932const(e69 e69Var) {
        jp5.m8570try(e69Var, "track");
        spe<m8a> m12552goto = this.f28596if.m12552goto(e69Var);
        jp5.m8568new(m12552goto, "likesDealer.trackLikeStates(track)");
        return m12552goto;
    }

    /* renamed from: do, reason: not valid java name */
    public final void m11933do(m64 m64Var) {
        jp5.m8570try(m64Var, "shot");
        dn3.e0(qfb.f30537for.m17714static(), "Alice_Shot_Dislike", null, 2);
        t54 t54Var = this.f28594for;
        String id = this.f28598try.mo9658else().getId();
        Objects.requireNonNull(t54Var);
        jp5.m8570try(m64Var, "shot");
        jp5.m8570try(id, "latestUserId");
        l64 m14659if = t54Var.f36601if.m14659if(m64Var);
        l64 l64Var = l64.DISLIKED;
        if (m14659if == l64Var) {
            return;
        }
        t54Var.m14657do(m64Var, new u54(t54Var, m64Var, id, null));
        t54Var.f36601if.m14658do(m64Var, l64Var);
    }

    /* renamed from: else, reason: not valid java name */
    public final boolean m11934else(oa9 oa9Var) {
        jp5.m8570try(oa9Var, "playlistHeader");
        return this.f28596if.m12551for(oa9Var);
    }

    /* renamed from: final, reason: not valid java name */
    public final <Entity extends d8a<Entity>> boolean m11935final(Entity entity, yg9 yg9Var, q8a.a aVar) {
        q8a.a aVar2;
        jp5.m8570try(entity, "entity");
        jp5.m8570try(yg9Var, "userData");
        q8a q8aVar = this.f28596if;
        if (q8aVar.m12551for(entity)) {
            return false;
        }
        if (aVar != null) {
            return q8aVar.m12550else(aVar, yg9Var);
        }
        p49<h59> g = entity.g();
        if (g == p49.f28338do) {
            aVar2 = q8a.a.ALBUM;
        } else if (g == p49.f28340if) {
            aVar2 = q8a.a.ARTIST;
        } else {
            if (g != p49.f28339for) {
                int i = e8d.f9711do;
                jr3.m8593do("Invalid attractive type " + g);
                return false;
            }
            aVar2 = q8a.a.PLAYLIST;
        }
        return q8aVar.m12550else(aVar2, yg9Var);
    }

    /* renamed from: for, reason: not valid java name */
    public final void m11936for(e69 e69Var) {
        jp5.m8570try(e69Var, "track");
        if (!this.f28596if.m12553if(e69Var)) {
            k2f.f19768new.mo8764do("Can not call DISLIKE for track because storage type is %s", e69Var.f9559super);
        } else {
            xab m17028if = xab.m17028if();
            m17028if.f43527new.execute(new xab.b(e69Var, null));
        }
    }

    /* renamed from: goto, reason: not valid java name */
    public final void m11937goto(m64 m64Var) {
        jp5.m8570try(m64Var, "shot");
        m11940new();
        dn3.e0(qfb.f30537for.m17714static(), "Alice_Shot_Like", null, 2);
        t54 t54Var = this.f28594for;
        String id = this.f28598try.mo9658else().getId();
        Objects.requireNonNull(t54Var);
        jp5.m8570try(m64Var, "shot");
        jp5.m8570try(id, "latestUserId");
        l64 m14659if = t54Var.f36601if.m14659if(m64Var);
        l64 l64Var = l64.LIKED;
        if (m14659if == l64Var) {
            return;
        }
        t54Var.m14657do(m64Var, new v54(t54Var, m64Var, id, null));
        t54Var.f36601if.m14658do(m64Var, l64Var);
    }

    /* renamed from: if, reason: not valid java name */
    public final void m11938if(q68 q68Var) {
        jp5.m8570try(q68Var, "playable");
        if (jp5.m8563do(q68Var, q68.f30204do)) {
            return;
        }
        q68Var.m12508try(new b());
    }

    /* renamed from: import, reason: not valid java name */
    public final void m11939import(p49<?> p49Var, Collection<String> collection) {
        Set<String> m12548case = this.f28596if.m12548case(p49Var);
        if (m12548case.size() == collection.size() && m12548case.containsAll(collection)) {
            return;
        }
        g8d.J(m12548case, collection);
        o8a.m11424do();
    }

    /* renamed from: new, reason: not valid java name */
    public final void m11940new() {
        iz3 l3 = dn3.l3(v14.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        if (((iu9) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(iu9.class))).m13409else()) {
            this.f28592case.mo1523case(new a());
            h8a h8aVar = (h8a) this.f28595goto.getValue();
            Objects.requireNonNull(h8aVar);
            iz3 l32 = dn3.l3(v14.class);
            jp5.m8570try(l32, "typeSpec");
            bz3 bz3Var2 = bz3.f4526do;
            jp5.m8565for(bz3Var2);
            jp5.m8570try(l32, "typeSpec");
            LinkedHashSet linkedHashSet2 = bz3Var2.f4528if ? new LinkedHashSet() : null;
            if (((iu9) ((v14) bz3Var2.m2426new(l32, linkedHashSet2 != null ? new bz3.a(bz3Var2, linkedHashSet2) : bz3Var2.f4529new, linkedHashSet2)).m15853do(dq5.m4763do(iu9.class))).m13409else()) {
                synchronized (h8aVar) {
                    int i = h8aVar.f14847try;
                    if (i < 2) {
                        int i2 = i + 1;
                        h8aVar.f14847try = i2;
                        if (i2 <= 1) {
                            SharedPreferences.Editor edit = h8aVar.f14844for.edit();
                            jp5.m8567if(edit, "editor");
                            edit.putInt("user_has_some_like", h8aVar.f14847try);
                            edit.apply();
                        }
                    }
                }
            }
        }
    }

    /* renamed from: super, reason: not valid java name */
    public final void m11941super(m64 m64Var) {
        jp5.m8570try(m64Var, "shot");
        t54 t54Var = this.f28594for;
        String id = this.f28598try.mo9658else().getId();
        Objects.requireNonNull(t54Var);
        jp5.m8570try(m64Var, "shot");
        jp5.m8570try(id, "latestUserId");
        l64 m14659if = t54Var.f36601if.m14659if(m64Var);
        l64 l64Var = l64.NEUTRAL;
        if (m14659if == l64Var) {
            return;
        }
        t54Var.m14657do(m64Var, new w54(t54Var, m64Var, id, m14659if, null));
        t54Var.f36601if.m14658do(m64Var, l64Var);
    }

    /* renamed from: this, reason: not valid java name */
    public final void m11942this(q68 q68Var) {
        jp5.m8570try(q68Var, "playable");
        if (jp5.m8563do(q68Var, q68.f30204do)) {
            return;
        }
        q68Var.m12508try(new c());
    }

    /* renamed from: throw, reason: not valid java name */
    public final void m11943throw(q68 q68Var) {
        jp5.m8570try(q68Var, "playable");
        if (jp5.m8563do(q68Var, q68.f30204do)) {
            return;
        }
        q68Var.m12508try(new e());
    }

    /* renamed from: try, reason: not valid java name */
    public final <T extends d8a<T>> boolean m11944try(T t) {
        jp5.m8570try(t, "entity");
        return this.f28596if.m12551for(t);
    }

    /* renamed from: while, reason: not valid java name */
    public final void m11945while(e69 e69Var) {
        jp5.m8570try(e69Var, "track");
        if (!this.f28596if.m12553if(e69Var)) {
            k2f.f19768new.mo8764do("Can not call NEUTRAL for track because storage type is %s", e69Var.f9559super);
        } else {
            xab m17028if = xab.m17028if();
            m17028if.f43527new.execute(new xab.d(e69Var, null));
        }
    }
}
