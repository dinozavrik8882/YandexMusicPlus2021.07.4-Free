package defpackage;

import defpackage.qk0;
import java.util.Set;

/* loaded from: classes.dex */
public final class nk0 extends qk0.a {

    /* renamed from: do, reason: not valid java name */
    public final long f25598do;

    /* renamed from: for, reason: not valid java name */
    public final Set<qk0.b> f25599for;

    /* renamed from: if, reason: not valid java name */
    public final long f25600if;

    /* loaded from: classes.dex */
    public static final class b extends qk0.a.AbstractC0260a {

        /* renamed from: do, reason: not valid java name */
        public Long f25601do;

        /* renamed from: for, reason: not valid java name */
        public Set<qk0.b> f25602for;

        /* renamed from: if, reason: not valid java name */
        public Long f25603if;

        @Override // qk0.a.AbstractC0260a
        /* renamed from: do, reason: not valid java name */
        public qk0.a mo10985do() {
            String str = this.f25601do == null ? " delta" : "";
            if (this.f25603if == null) {
                str = by.m2405strictfp(str, " maxAllowedDelay");
            }
            if (this.f25602for == null) {
                str = by.m2405strictfp(str, " flags");
            }
            if (str.isEmpty()) {
                return new nk0(this.f25601do.longValue(), this.f25603if.longValue(), this.f25602for, null);
            }
            throw new IllegalStateException(by.m2405strictfp("Missing required properties:", str));
        }

        @Override // qk0.a.AbstractC0260a
        /* renamed from: for, reason: not valid java name */
        public qk0.a.AbstractC0260a mo10986for(long j) {
            this.f25603if = Long.valueOf(j);
            return this;
        }

        @Override // qk0.a.AbstractC0260a
        /* renamed from: if, reason: not valid java name */
        public qk0.a.AbstractC0260a mo10987if(long j) {
            this.f25601do = Long.valueOf(j);
            return this;
        }
    }

    public nk0(long j, long j2, Set set, a aVar) {
        this.f25598do = j;
        this.f25600if = j2;
        this.f25599for = set;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof qk0.a)) {
            return false;
        }
        qk0.a aVar = (qk0.a) obj;
        return this.f25598do == aVar.mo10983if() && this.f25600if == aVar.mo10984new() && this.f25599for.equals(aVar.mo10982for());
    }

    @Override // qk0.a
    /* renamed from: for, reason: not valid java name */
    public Set<qk0.b> mo10982for() {
        return this.f25599for;
    }

    public int hashCode() {
        long j = this.f25598do;
        int i = (((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003;
        long j2 = this.f25600if;
        return ((i ^ ((int) ((j2 >>> 32) ^ j2))) * 1000003) ^ this.f25599for.hashCode();
    }

    @Override // qk0.a
    /* renamed from: if, reason: not valid java name */
    public long mo10983if() {
        return this.f25598do;
    }

    @Override // qk0.a
    /* renamed from: new, reason: not valid java name */
    public long mo10984new() {
        return this.f25600if;
    }

    public String toString() {
        StringBuilder r = by.r("ConfigValue{delta=");
        r.append(this.f25598do);
        r.append(", maxAllowedDelay=");
        r.append(this.f25600if);
        r.append(", flags=");
        r.append(this.f25599for);
        r.append("}");
        return r.toString();
    }
}
