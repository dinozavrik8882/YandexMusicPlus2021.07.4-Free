package defpackage;

/* loaded from: classes.dex */
public final /* synthetic */ class xr1 implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public static final Runnable f44364catch = new xr1();

    @Override // java.lang.Runnable
    public final void run() {
    }
}
