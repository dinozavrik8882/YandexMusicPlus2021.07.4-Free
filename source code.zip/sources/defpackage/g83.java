package defpackage;

import java.io.IOException;

/* loaded from: classes.dex */
public interface g83 {
    /* renamed from: case, reason: not valid java name */
    g83 mo6458case(boolean z) throws IOException;

    /* renamed from: try, reason: not valid java name */
    g83 mo6459try(String str) throws IOException;
}
