package defpackage;

import defpackage.vz;
import java.io.IOException;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public class u40 implements vz<ByteBuffer> {

    /* renamed from: do, reason: not valid java name */
    public final ByteBuffer f38358do;

    /* loaded from: classes.dex */
    public static class a implements vz.a<ByteBuffer> {
        @Override // vz.a
        /* renamed from: do */
        public Class<ByteBuffer> mo1608do() {
            return ByteBuffer.class;
        }

        @Override // vz.a
        /* renamed from: if */
        public vz<ByteBuffer> mo1609if(ByteBuffer byteBuffer) {
            return new u40(byteBuffer);
        }
    }

    public u40(ByteBuffer byteBuffer) {
        this.f38358do = byteBuffer;
    }

    @Override // defpackage.vz
    /* renamed from: do */
    public ByteBuffer mo1605do() throws IOException {
        this.f38358do.position(0);
        return this.f38358do;
    }

    @Override // defpackage.vz
    /* renamed from: if */
    public void mo1607if() {
    }
}
