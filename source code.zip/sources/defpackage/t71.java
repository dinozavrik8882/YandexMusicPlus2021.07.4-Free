package defpackage;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class t71 {

    /* renamed from: do, reason: not valid java name */
    public final int f36709do;

    /* renamed from: for, reason: not valid java name */
    public int f36710for;

    /* renamed from: if, reason: not valid java name */
    public final s71[] f36711if;

    public t71(s71... s71VarArr) {
        this.f36711if = s71VarArr;
        this.f36709do = s71VarArr.length;
    }

    /* renamed from: do, reason: not valid java name */
    public s71[] m14683do() {
        return (s71[]) this.f36711if.clone();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || t71.class != obj.getClass()) {
            return false;
        }
        return Arrays.equals(this.f36711if, ((t71) obj).f36711if);
    }

    public int hashCode() {
        if (this.f36710for == 0) {
            this.f36710for = 527 + Arrays.hashCode(this.f36711if);
        }
        return this.f36710for;
    }
}
