package defpackage;

import android.system.ErrnoException;
import android.system.OsConstants;
import android.util.LruCache;
import com.yandex.metrica.rtm.Constants;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes2.dex */
public final class fz7 implements zy7 {

    /* renamed from: case, reason: not valid java name */
    public int f12799case;

    /* renamed from: do, reason: not valid java name */
    public final e69 f12800do;

    /* renamed from: else, reason: not valid java name */
    public volatile boolean f12801else;

    /* renamed from: for, reason: not valid java name */
    public final int f12802for;

    /* renamed from: goto, reason: not valid java name */
    public AtomicBoolean f12803goto;

    /* renamed from: if, reason: not valid java name */
    public final wga f12804if;

    /* renamed from: new, reason: not valid java name */
    public final long f12805new;

    /* renamed from: try, reason: not valid java name */
    public final zy7 f12806try;

    public fz7(e69 e69Var, wga wgaVar, int i, long j, zy7 zy7Var) {
        jp5.m8570try(e69Var, "track");
        jp5.m8570try(wgaVar, "connectivityBox");
        jp5.m8570try(zy7Var, "wrappedDownloader");
        this.f12800do = e69Var;
        this.f12804if = wgaVar;
        this.f12802for = i;
        this.f12805new = j;
        this.f12806try = zy7Var;
        this.f12803goto = new AtomicBoolean(false);
    }

    /* renamed from: for, reason: not valid java name */
    public static yy7 m6301for(fz7 fz7Var, e69 e69Var, Exception exc, jx7 jx7Var, int i) {
        int i2 = i & 4;
        String str = e69Var.f9541catch;
        jx7 fromException = jx7.fromException(exc, fz7Var.f12804if);
        jp5.m8568new(fromException, "fromException(exc, connectivityBox)");
        return new yy7(str, fromException, exc);
    }

    /* renamed from: if, reason: not valid java name */
    public static final String m6302if(fz7 fz7Var) {
        return fz7Var + " attempt=" + fz7Var.f12799case + ", retryCount=" + fz7Var.f12802for + ", track=" + fz7Var.f12800do;
    }

    @Override // defpackage.zy7
    public void cancel() {
        k2f.f19768new.mo8764do(this + " downloading has been cancelled for track=" + this.f12800do, new Object[0]);
        this.f12801else = true;
        this.f12806try.cancel();
    }

    @Override // defpackage.zy7
    /* renamed from: do, reason: not valid java name */
    public void mo6303do() throws yy7 {
        if (!this.f12803goto.compareAndSet(false, true)) {
            jr3.m8596new(new lr3(jp5.m8559break("Downloading by the same Downloader has started in second time, something went wrong ", m6302if(this)), new IllegalStateException()), null, 2);
            return;
        }
        boolean z = false;
        while (!z && this.f12799case < this.f12802for && !this.f12801else) {
            try {
                this.f12799case++;
                k2f.f19768new.mo8764do(this + " downloading attempt has started " + m6302if(this), new Object[0]);
                this.f12806try.mo6303do();
                z = true;
            } catch (IOException e) {
                m6304new(e);
            } catch (yfa e2) {
                Throwable cause = e2.getCause();
                if (!(cause instanceof IOException)) {
                    k2f.f19768new.mo8761case(e2, this + " attempt was failed with RetrofitError", new Object[0]);
                    throw m6301for(this, this.f12800do, e2, null, 4);
                }
                m6304new((IOException) cause);
            }
        }
        k2f.f19768new.mo8764do(this + " downloading finished for track=" + this.f12800do + ", isCancelled=" + this.f12801else, new Object[0]);
    }

    /* renamed from: new, reason: not valid java name */
    public final void m6304new(IOException iOException) {
        Throwable cause = iOException.getCause();
        if ((cause instanceof ErrnoException) && ((ErrnoException) cause).errno == OsConstants.ENOSPC) {
            e69 e69Var = this.f12800do;
            jx7 jx7Var = jx7.FAIL_NOT_ENOUGH_SPACE;
            String str = e69Var.f9541catch;
            if (jx7Var == null) {
                jx7Var = jx7.fromException(iOException, this.f12804if);
                jp5.m8568new(jx7Var, "fromException(exc, connectivityBox)");
            }
            yy7 yy7Var = new yy7(str, jx7Var, iOException);
            LruCache<String, Long> lruCache = m8d.f23599if;
            jp5.m8570try(yy7Var, Constants.KEY_EXCEPTION);
            k2f.f19768new.mo8771return(yy7Var);
            throw yy7Var;
        }
        if (this.f12801else) {
            k2f.f19768new.mo8764do(this + " downloading has failed, but has been already cancelled " + m6302if(this), new Object[0]);
            return;
        }
        if (this.f12799case >= this.f12802for) {
            throw m6301for(this, this.f12800do, iOException, null, 4);
        }
        k2f.f19768new.mo8761case(iOException, this + " awaiting retry because of error " + m6302if(this), new Object[0]);
        try {
            Thread.sleep(this.f12805new);
        } catch (InterruptedException unused) {
            k2f.f19768new.mo8764do(this + " interrupted " + m6302if(this), new Object[0]);
            cancel();
        }
    }
}
