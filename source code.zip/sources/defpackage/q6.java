package defpackage;

import android.view.MenuItem;

/* loaded from: classes.dex */
public interface q6 {
    /* renamed from: else, reason: not valid java name */
    void mo12502else(u4 u4Var, MenuItem menuItem);

    /* renamed from: new, reason: not valid java name */
    void mo12503new(u4 u4Var, MenuItem menuItem);
}
