package defpackage;

/* loaded from: classes.dex */
public class gl3 extends sl3 {
    private static final long serialVersionUID = 5365883691014039322L;

    public gl3() {
        super("Network is not available");
    }
}
