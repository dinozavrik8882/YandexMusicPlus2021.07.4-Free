package defpackage;

import com.yandex.metrica.rtm.Constants;

/* loaded from: classes2.dex */
public final class lo9 extends Exception {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public lo9(String str) {
        super(str);
        jp5.m8570try(str, Constants.KEY_MESSAGE);
    }
}
