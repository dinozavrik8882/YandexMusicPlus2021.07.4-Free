package defpackage;

import java.util.Iterator;

/* loaded from: classes.dex */
public interface by3<T> extends Iterable<T>, iq5 {
    T get(int i);

    int getSize();

    @Override // java.lang.Iterable
    Iterator<T> iterator();
}
