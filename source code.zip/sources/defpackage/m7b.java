package defpackage;

/* loaded from: classes2.dex */
public final /* synthetic */ class m7b implements tqe {

    /* renamed from: catch, reason: not valid java name */
    public static final /* synthetic */ m7b f23531catch = new m7b();

    @Override // defpackage.tqe
    public final void call(Object obj) {
        jr3.m8595if((Throwable) obj);
    }
}
