package defpackage;

import defpackage.z1;

@ln5(c = "com.yandex.music.model.payment.Billing$updateAccountEmail$2", f = "Billing.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes.dex */
public final class n84 extends pn5 implements qo5<gu5, wm5<? super pl5>, Object> {

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ z1 f25214super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ String f25215throw;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n84(z1 z1Var, String str, wm5<? super n84> wm5Var) {
        super(2, wm5Var);
        this.f25214super = z1Var;
        this.f25215throw = str;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        return new n84(this.f25214super, this.f25215throw, wm5Var);
    }

    @Override // defpackage.qo5
    public Object invoke(gu5 gu5Var, wm5<? super pl5> wm5Var) {
        wm5<? super pl5> wm5Var2 = wm5Var;
        z1 z1Var = this.f25214super;
        String str = this.f25215throw;
        if (wm5Var2 != null) {
            wm5Var2.getContext();
        }
        pl5 pl5Var = pl5.f29126do;
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(pl5Var);
        z1.b bVar = z1.f46453do;
        z1Var.m17807try().mo8314if(str);
        z1Var.f46457else.f28582if = str;
        return pl5Var;
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(obj);
        z1 z1Var = this.f25214super;
        z1.b bVar = z1.f46453do;
        z1Var.m17807try().mo8314if(this.f25215throw);
        this.f25214super.f46457else.f28582if = this.f25215throw;
        return pl5.f29126do;
    }
}
