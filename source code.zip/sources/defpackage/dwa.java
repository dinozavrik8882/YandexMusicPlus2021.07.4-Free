package defpackage;

import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;

/* loaded from: classes2.dex */
public class dwa implements TextWatcher, InputFilter {

    /* renamed from: catch, reason: not valid java name */
    public String f9128catch;

    @Override // android.text.TextWatcher
    public void afterTextChanged(Editable editable) {
        this.f9128catch = editable.toString();
    }

    @Override // android.text.TextWatcher
    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    /* renamed from: do, reason: not valid java name */
    public boolean m4826do() {
        String str = this.f9128catch;
        return str != null && str.length() == 3;
    }

    @Override // android.text.InputFilter
    public CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        if (i2 <= 0 || ((spanned.length() + i4) - i3) + i2 <= 3) {
            return null;
        }
        return "";
    }

    @Override // android.text.TextWatcher
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }
}
