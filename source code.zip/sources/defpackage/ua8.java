package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class ua8 extends kp5 implements bo5<qg9> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ bz3.a f38648catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ua8(bz3.a aVar) {
        super(0);
        this.f38648catch = aVar;
    }

    @Override // defpackage.bo5
    public qg9 invoke() {
        return (qg9) this.f38648catch.m2427do(dn3.l3(qg9.class));
    }
}
