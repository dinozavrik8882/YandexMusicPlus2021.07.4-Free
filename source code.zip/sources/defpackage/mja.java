package defpackage;

import java.io.Serializable;
import java.util.List;

/* loaded from: classes2.dex */
public class mja<T> implements kja, tcc<T>, Serializable {
    private static final long serialVersionUID = 1;

    /* renamed from: catch, reason: not valid java name */
    public final ria f24140catch;

    /* renamed from: class, reason: not valid java name */
    public final List<T> f24141class;

    /* JADX WARN: Multi-variable type inference failed */
    public mja(ria riaVar, List<? extends T> list) {
        jp5.m8570try(riaVar, "pager");
        jp5.m8570try(list, "results");
        this.f24140catch = riaVar;
        this.f24141class = list;
    }

    @Override // defpackage.kja
    /* renamed from: for */
    public ria mo8471for() {
        return this.f24140catch;
    }

    @Override // defpackage.tcc
    /* renamed from: new */
    public List<T> mo4493new() {
        return this.f24141class;
    }
}
