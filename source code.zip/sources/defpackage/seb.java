package defpackage;

/* loaded from: classes2.dex */
public class seb {

    /* renamed from: do, reason: not valid java name */
    public static final String f35344do;

    /* renamed from: for, reason: not valid java name */
    public static final String f35345for;

    /* renamed from: if, reason: not valid java name */
    public static final String f35346if;

    /* renamed from: new, reason: not valid java name */
    public yjb f35348new;

    /* renamed from: try, reason: not valid java name */
    public boolean f35349try = false;

    /* renamed from: case, reason: not valid java name */
    public boolean f35347case = false;

    static {
        String simpleName = seb.class.getSimpleName();
        f35344do = by.m2405strictfp(simpleName, ".state.current");
        f35346if = by.m2405strictfp(simpleName, ".state.forcedInvisible");
        f35345for = by.m2405strictfp(simpleName, ".state.shotDisplayed");
    }

    /* renamed from: do, reason: not valid java name */
    public yjb m14230do() {
        return this.f35349try ? yjb.HIDDEN : this.f35348new;
    }
}
