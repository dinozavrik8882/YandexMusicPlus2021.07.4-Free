package defpackage;

import java.io.IOException;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class dv0 {

    /* renamed from: new, reason: not valid java name */
    public int f9089new;

    /* renamed from: try, reason: not valid java name */
    public boolean f9090try;

    /* renamed from: do, reason: not valid java name */
    public final ev0 f9086do = new ev0();

    /* renamed from: if, reason: not valid java name */
    public final wb1 f9088if = new wb1(new byte[65025], 0);

    /* renamed from: for, reason: not valid java name */
    public int f9087for = -1;

    /* renamed from: do, reason: not valid java name */
    public final int m4818do(int i) {
        int i2;
        int i3 = 0;
        this.f9089new = 0;
        do {
            int i4 = this.f9089new;
            int i5 = i + i4;
            ev0 ev0Var = this.f9086do;
            if (i5 >= ev0Var.f10726new) {
                break;
            }
            int[] iArr = ev0Var.f10722else;
            this.f9089new = i4 + 1;
            i2 = iArr[i4 + i];
            i3 += i2;
        } while (i2 == 255);
        return i3;
    }

    /* renamed from: if, reason: not valid java name */
    public boolean m4819if(qs0 qs0Var) throws IOException {
        int i;
        h81.m7061else(qs0Var != null);
        if (this.f9090try) {
            this.f9090try = false;
            this.f9088if.m16529throws(0);
        }
        while (!this.f9090try) {
            if (this.f9087for < 0) {
                if (!this.f9086do.m5467for(qs0Var, -1L) || !this.f9086do.m5466do(qs0Var, true)) {
                    return false;
                }
                ev0 ev0Var = this.f9086do;
                int i2 = ev0Var.f10727try;
                if ((ev0Var.f10725if & 1) == 1 && this.f9088if.f41979for == 0) {
                    i2 += m4818do(0);
                    i = this.f9089new + 0;
                } else {
                    i = 0;
                }
                qs0Var.mo10569class(i2);
                this.f9087for = i;
            }
            int m4818do = m4818do(this.f9087for);
            int i3 = this.f9087for + this.f9089new;
            if (m4818do > 0) {
                wb1 wb1Var = this.f9088if;
                byte[] bArr = wb1Var.f41978do;
                int length = bArr.length;
                int i4 = wb1Var.f41979for;
                if (length < i4 + m4818do) {
                    wb1Var.m16511extends(Arrays.copyOf(bArr, i4 + m4818do), this.f9088if.f41979for);
                }
                wb1 wb1Var2 = this.f9088if;
                qs0Var.readFully(wb1Var2.f41978do, wb1Var2.f41979for, m4818do);
                wb1 wb1Var3 = this.f9088if;
                wb1Var3.m16513finally(wb1Var3.f41979for + m4818do);
                this.f9090try = this.f9086do.f10722else[i3 + (-1)] != 255;
            }
            if (i3 == this.f9086do.f10726new) {
                i3 = -1;
            }
            this.f9087for = i3;
        }
        return true;
    }
}
