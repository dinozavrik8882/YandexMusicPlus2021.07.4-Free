package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class sw7 {

    /* renamed from: do, reason: not valid java name */
    public static final sw7 f36132do = null;

    /* renamed from: if, reason: not valid java name */
    public static final bz3.b f36133if = new bz3.b(a.f36134catch);

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<az3, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public static final a f36134catch = new a();

        public a() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(az3 az3Var) {
            az3 az3Var2 = az3Var;
            jp5.m8570try(az3Var2, "$this$$receiver");
            az3Var2.m1595if(dn3.l3(tx7.class)).m1597if(gw7.f14277catch);
            az3Var2.m1595if(dn3.l3(ww7.class)).m1597if(kw7.f21132catch);
            az3Var2.m1595if(dn3.l3(uw7.class)).m1597if(lw7.f22991catch);
            az3Var2.m1595if(dn3.l3(az7.class)).m1597if(mw7.f24674catch);
            az3Var2.m1595if(dn3.l3(ny7.class)).m1597if(nw7.f26189catch);
            az3Var2.m1595if(dn3.l3(xw7.class)).m1597if(ow7.f27963catch);
            az3Var2.m1595if(dn3.l3(vx7.class)).m1597if(pw7.f29653catch);
            az3Var2.m1595if(dn3.l3(xy7.class)).m1597if(qw7.f31443catch);
            az3Var2.m1595if(dn3.l3(bk8.class)).m1597if(rw7.f34508catch);
            az3Var2.m1595if(dn3.l3(o47.class)).m1596do(fw7.f12664catch);
            return pl5.f29126do;
        }
    }
}
