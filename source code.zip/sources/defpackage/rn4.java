package defpackage;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class rn4 extends cn4<ul4> {
    @Override // defpackage.cn4
    /* renamed from: do */
    public ul4 mo683do(dn4 dn4Var) {
        jp5.m8570try(dn4Var, "reader");
        dn4Var.mo4673class();
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        vl4 vl4Var = null;
        Boolean bool = null;
        Boolean bool2 = null;
        ArrayList arrayList = null;
        while (dn4Var.hasNext()) {
            String nextName = dn4Var.nextName();
            switch (nextName.hashCode()) {
                case -2060497896:
                    if (!nextName.equals("subtitle")) {
                        break;
                    } else {
                        str3 = dn4Var.nextString();
                        break;
                    }
                case -1051830678:
                    if (!nextName.equals("productId")) {
                        break;
                    } else {
                        str = dn4Var.nextString();
                        break;
                    }
                case -891774750:
                    if (!nextName.equals("styles")) {
                        break;
                    } else {
                        vl4Var = new sn4().mo683do(dn4Var);
                        break;
                    }
                case -199047237:
                    if (!nextName.equals("vendorTrialAvailable")) {
                        break;
                    } else {
                        bool = Boolean.valueOf(dn4Var.mo4675final());
                        break;
                    }
                case 3444122:
                    if (!nextName.equals("plus")) {
                        break;
                    } else {
                        bool2 = Boolean.valueOf(dn4Var.mo4675final());
                        break;
                    }
                case 110371416:
                    if (!nextName.equals("title")) {
                        break;
                    } else {
                        str2 = dn4Var.nextString();
                        break;
                    }
                case 358545279:
                    if (!nextName.equals("buttonText")) {
                        break;
                    } else {
                        str5 = dn4Var.nextString();
                        break;
                    }
                case 1557721666:
                    if (!nextName.equals("details")) {
                        break;
                    } else {
                        str4 = dn4Var.nextString();
                        break;
                    }
                case 2041217302:
                    if (!nextName.equals("activation")) {
                        break;
                    } else {
                        nn4 nn4Var = new nn4();
                        jp5.m8570try(nn4Var, "childParser");
                        jp5.m8570try(dn4Var, "reader");
                        arrayList = new ArrayList();
                        dn4Var.mo4674const();
                        while (dn4Var.hasNext()) {
                            arrayList.add(nn4Var.mo683do(dn4Var));
                        }
                        dn4Var.endArray();
                        break;
                    }
            }
            dn4Var.skipValue();
        }
        dn4Var.endObject();
        return new ul4(str, str2, str3, str4, str5, vl4Var, bool, bool2, arrayList);
    }
}
