package defpackage;

import android.support.v4.media.MediaBrowserCompat;
import defpackage.d;
import java.util.List;

/* loaded from: classes2.dex */
public final class ih8 implements hh8, th8 {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ hh8 f16854do;

    /* renamed from: if, reason: not valid java name */
    public final /* synthetic */ th8 f16855if;

    public ih8(hh8 hh8Var, th8 th8Var) {
        jp5.m8570try(hh8Var, "browsableConverter");
        jp5.m8570try(th8Var, "playableConverter");
        this.f16854do = hh8Var;
        this.f16855if = th8Var;
    }

    @Override // defpackage.th8
    /* renamed from: break, reason: not valid java name */
    public MediaBrowserCompat.MediaItem mo7830break(t4c t4cVar) {
        jp5.m8570try(t4cVar, "station");
        return this.f16855if.mo7830break(t4cVar);
    }

    @Override // defpackage.hh8
    /* renamed from: case */
    public List<MediaBrowserCompat.MediaItem> mo7355case(MediaBrowserCompat.MediaItem mediaItem) {
        return this.f16854do.mo7355case(mediaItem);
    }

    @Override // defpackage.hh8
    /* renamed from: catch */
    public MediaBrowserCompat.MediaItem mo7356catch() {
        return this.f16854do.mo7356catch();
    }

    @Override // defpackage.hh8
    /* renamed from: class */
    public MediaBrowserCompat.MediaItem mo7357class(h59 h59Var) {
        jp5.m8570try(h59Var, "album");
        return this.f16854do.mo7357class(h59Var);
    }

    @Override // defpackage.th8
    /* renamed from: do, reason: not valid java name */
    public MediaBrowserCompat.MediaItem mo7831do(l59 l59Var, String str) {
        jp5.m8570try(l59Var, "artist");
        return this.f16855if.mo7831do(l59Var, str);
    }

    @Override // defpackage.hh8
    /* renamed from: else */
    public List<MediaBrowserCompat.MediaItem> mo7358else(MediaBrowserCompat.MediaItem mediaItem, boolean z) {
        return this.f16854do.mo7358else(mediaItem, z);
    }

    @Override // defpackage.hh8
    /* renamed from: for */
    public MediaBrowserCompat.MediaItem mo7359for(d.c cVar) {
        jp5.m8570try(cVar, "stationMeta");
        return this.f16854do.mo7359for(cVar);
    }

    @Override // defpackage.th8
    /* renamed from: goto, reason: not valid java name */
    public MediaBrowserCompat.MediaItem mo7832goto(h59 h59Var) {
        jp5.m8570try(h59Var, "album");
        return this.f16855if.mo7832goto(h59Var);
    }

    @Override // defpackage.th8
    /* renamed from: if, reason: not valid java name */
    public MediaBrowserCompat.MediaItem mo7833if(oa9 oa9Var, boolean z) {
        jp5.m8570try(oa9Var, "playlistHeader");
        return this.f16855if.mo7833if(oa9Var, z);
    }

    @Override // defpackage.th8
    /* renamed from: new, reason: not valid java name */
    public MediaBrowserCompat.MediaItem mo7834new(e69 e69Var) {
        jp5.m8570try(e69Var, "track");
        return this.f16855if.mo7834new(e69Var);
    }

    @Override // defpackage.hh8
    /* renamed from: this */
    public List<MediaBrowserCompat.MediaItem> mo7360this(List<gl7> list, List<? extends buc<?>> list2, List<? extends MediaBrowserCompat.MediaItem> list3, List<? extends MediaBrowserCompat.MediaItem> list4, List<? extends MediaBrowserCompat.MediaItem> list5) {
        jp5.m8570try(list, "personalPlaylists");
        jp5.m8570try(list2, "playHistoryItems");
        jp5.m8570try(list3, "phonotekaPlaylists");
        jp5.m8570try(list4, "phonotekaArtists");
        jp5.m8570try(list5, "stationTypes");
        return this.f16854do.mo7360this(list, list2, list3, list4, list5);
    }

    @Override // defpackage.th8
    /* renamed from: try, reason: not valid java name */
    public MediaBrowserCompat.MediaItem mo7835try(d8a<?> d8aVar) {
        jp5.m8570try(d8aVar, "historyItemEntity");
        return this.f16855if.mo7835try(d8aVar);
    }
}
