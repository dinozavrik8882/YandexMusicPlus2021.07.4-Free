package defpackage;

/* loaded from: classes2.dex */
public final class ar6 implements ey5<Boolean> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ ey5 f2431catch;

    /* loaded from: classes2.dex */
    public static final class a implements fy5<uq7> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ fy5 f2432catch;

        @ln5(c = "ru.yandex.music.cast.ui.PultPicker$selectCastProgress$$inlined$map$1$2", f = "PultPicker.kt", l = {137}, m = "emit")
        /* renamed from: ar6$a$a, reason: collision with other inner class name */
        /* loaded from: classes2.dex */
        public static final class C0014a extends jn5 {

            /* renamed from: final, reason: not valid java name */
            public /* synthetic */ Object f2433final;

            /* renamed from: super, reason: not valid java name */
            public int f2434super;

            public C0014a(wm5 wm5Var) {
                super(wm5Var);
            }

            @Override // defpackage.hn5
            /* renamed from: return */
            public final Object mo76return(Object obj) {
                this.f2433final = obj;
                this.f2434super |= Integer.MIN_VALUE;
                return a.this.mo600if(null, this);
            }
        }

        public a(fy5 fy5Var) {
            this.f2432catch = fy5Var;
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x002f  */
        /* JADX WARN: Removed duplicated region for block: B:31:0x0065 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
        @Override // defpackage.fy5
        /* renamed from: if */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object mo600if(defpackage.uq7 r5, defpackage.wm5 r6) {
            /*
                r4 = this;
                boolean r0 = r6 instanceof ar6.a.C0014a
                if (r0 == 0) goto L13
                r0 = r6
                ar6$a$a r0 = (ar6.a.C0014a) r0
                int r1 = r0.f2434super
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f2434super = r1
                goto L18
            L13:
                ar6$a$a r0 = new ar6$a$a
                r0.<init>(r6)
            L18:
                java.lang.Object r6 = r0.f2433final
                cn5 r1 = defpackage.cn5.COROUTINE_SUSPENDED
                int r2 = r0.f2434super
                r3 = 1
                if (r2 == 0) goto L2f
                if (r2 != r3) goto L27
                defpackage.dn3.N2(r6)
                goto L66
            L27:
                java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                r5.<init>(r6)
                throw r5
            L2f:
                defpackage.dn3.N2(r6)
                fy5 r6 = r4.f2432catch
                uq7 r5 = (defpackage.uq7) r5
                java.lang.String r2 = "it"
                defpackage.jp5.m8568new(r5, r2)
                int r5 = r5.ordinal()
                if (r5 == 0) goto L58
                if (r5 == r3) goto L56
                r2 = 2
                if (r5 == r2) goto L58
                r2 = 3
                if (r5 == r2) goto L56
                r2 = 4
                if (r5 == r2) goto L58
                r2 = 5
                if (r5 != r2) goto L50
                goto L56
            L50:
                gl5 r5 = new gl5
                r5.<init>()
                throw r5
            L56:
                r5 = 0
                goto L59
            L58:
                r5 = r3
            L59:
                java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)
                r0.f2434super = r3
                java.lang.Object r5 = r6.mo600if(r5, r0)
                if (r5 != r1) goto L66
                return r1
            L66:
                pl5 r5 = defpackage.pl5.f29126do
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: ar6.a.mo600if(java.lang.Object, wm5):java.lang.Object");
        }
    }

    public ar6(ey5 ey5Var) {
        this.f2431catch = ey5Var;
    }

    @Override // defpackage.ey5
    /* renamed from: do, reason: not valid java name */
    public Object mo1466do(fy5<? super Boolean> fy5Var, wm5 wm5Var) {
        Object mo1466do = this.f2431catch.mo1466do(new a(fy5Var), wm5Var);
        return mo1466do == cn5.COROUTINE_SUSPENDED ? mo1466do : pl5.f29126do;
    }
}
