package defpackage;

import defpackage.bz3;
import java.util.LinkedHashSet;
import okhttp3.OkHttpClient;

/* loaded from: classes2.dex */
public final class fj9 extends kp5 implements mo5<bz3.a, up4> {

    /* renamed from: catch, reason: not valid java name */
    public static final fj9 f12050catch = new fj9();

    public fj9() {
        super(1);
    }

    @Override // defpackage.mo5
    public up4 invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        OkHttpClient okHttpClient = (OkHttpClient) aVar2.m2427do(dn3.l3(OkHttpClient.class));
        iz3 l3 = dn3.l3(zs3.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        String m18233do = ((zs3) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m18233do(a74.class);
        if (m18233do == null) {
            m18233do = a74.PROD.getUrl();
        }
        return new up4(okHttpClient, m18233do);
    }
}
