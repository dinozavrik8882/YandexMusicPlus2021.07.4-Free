package defpackage;

import android.content.Context;
import android.os.Bundle;
import defpackage.lsa;
import java.util.UUID;

/* loaded from: classes2.dex */
public class isa {

    /* renamed from: do, reason: not valid java name */
    public static final lsa.a f17234do = (lsa.a) a9d.m371do(lsa.a.class);

    /* renamed from: if, reason: not valid java name */
    public static final lsa.b f17235if = (lsa.b) a9d.m371do(lsa.b.class);

    /* renamed from: case, reason: not valid java name */
    public final jsa f17237case;

    /* renamed from: catch, reason: not valid java name */
    public lsa f17238catch;

    /* renamed from: else, reason: not valid java name */
    public final c f17241else;

    /* renamed from: final, reason: not valid java name */
    public d f17242final;

    /* renamed from: for, reason: not valid java name */
    public final b f17243for;

    /* renamed from: goto, reason: not valid java name */
    public final Context f17244goto;

    /* renamed from: new, reason: not valid java name */
    public final k09 f17245new;

    /* renamed from: this, reason: not valid java name */
    public final wga f17246this;

    /* renamed from: try, reason: not valid java name */
    public final String f17247try;

    /* renamed from: break, reason: not valid java name */
    public final t0f f17236break = new t0f();

    /* renamed from: class, reason: not valid java name */
    public lsa.a f17239class = f17234do;

    /* renamed from: const, reason: not valid java name */
    public lsa.b f17240const = f17235if;

    /* loaded from: classes2.dex */
    public class a implements lsa.b.a {
        public a() {
        }
    }

    /* loaded from: classes2.dex */
    public interface b {
    }

    /* loaded from: classes2.dex */
    public enum c {
        REGISTER_PHONE,
        PICK_PHONE
    }

    /* loaded from: classes2.dex */
    public enum d {
        CHOOSING_PHONE,
        CONFIRMING_PHONE
    }

    public isa(Context context, b bVar, final lh6 lh6Var, final qg9 qg9Var, wga wgaVar, c cVar, Bundle bundle) {
        k09 k09Var = (k09) dz3.m4865do(k09.class);
        this.f17245new = k09Var;
        this.f17244goto = context;
        this.f17243for = bVar;
        this.f17246this = wgaVar;
        this.f17241else = cVar;
        String string = bundle != null ? bundle.getString("state.cache.key", null) : null;
        string = string == null ? UUID.randomUUID().toString() : string;
        this.f17247try = string;
        this.f17237case = (jsa) k09Var.m8714do(string, jsa.class, new xqe() { // from class: kra
            @Override // defpackage.xqe, java.util.concurrent.Callable
            public final Object call() {
                return new jsa(lh6.this, qg9Var);
            }
        });
    }

    /* renamed from: do, reason: not valid java name */
    public final void m7948do(d dVar, cra craVar) {
        if (this.f17238catch == null || this.f17242final == dVar) {
            return;
        }
        this.f17242final = dVar;
        int ordinal = dVar.ordinal();
        if (ordinal == 0) {
            this.f17239class = this.f17238catch.mo9929final(new jra(this));
        } else {
            if (ordinal != 1) {
                return;
            }
            lsa lsaVar = this.f17238catch;
            f9d.m5797for(craVar, "arg is null");
            this.f17240const = lsaVar.mo9930for(craVar, new a());
        }
    }
}
