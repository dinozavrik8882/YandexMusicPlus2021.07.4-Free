package defpackage;

import defpackage.bz3;

/* loaded from: classes.dex */
public final class q94 {

    /* renamed from: do, reason: not valid java name */
    public static final q94 f30334do = null;

    /* renamed from: if, reason: not valid java name */
    public static final bz3.b f30335if = new bz3.b(a.f30336catch);

    /* loaded from: classes.dex */
    public static final class a extends kp5 implements mo5<az3, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public static final a f30336catch = new a();

        public a() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(az3 az3Var) {
            az3 az3Var2 = az3Var;
            jp5.m8570try(az3Var2, "$this$$receiver");
            az3Var2.m1595if(dn3.l3(va4.class)).m1597if(p94.f28675catch);
            return pl5.f29126do;
        }
    }
}
