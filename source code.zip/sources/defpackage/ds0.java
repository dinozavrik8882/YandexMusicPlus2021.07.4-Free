package defpackage;

import defpackage.yr0;
import java.util.UUID;

/* loaded from: classes.dex */
public interface ds0 {
    /* renamed from: do */
    byte[] mo2290do(UUID uuid, yr0.a aVar) throws es0;

    /* renamed from: if */
    byte[] mo2291if(UUID uuid, yr0.d dVar) throws es0;
}
