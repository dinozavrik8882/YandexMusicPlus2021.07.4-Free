package defpackage;

import java.util.Iterator;

/* loaded from: classes2.dex */
public final class ls5<T, R> implements wr5<R> {

    /* renamed from: do, reason: not valid java name */
    public final wr5<T> f22708do;

    /* renamed from: if, reason: not valid java name */
    public final qo5<Integer, T, R> f22709if;

    /* loaded from: classes2.dex */
    public static final class a implements Iterator<R>, iq5 {

        /* renamed from: catch, reason: not valid java name */
        public final Iterator<T> f22710catch;

        /* renamed from: class, reason: not valid java name */
        public int f22711class;

        public a() {
            this.f22710catch = ls5.this.f22708do.iterator();
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f22710catch.hasNext();
        }

        @Override // java.util.Iterator
        public R next() {
            qo5<Integer, T, R> qo5Var = ls5.this.f22709if;
            int i = this.f22711class;
            this.f22711class = i + 1;
            if (i >= 0) {
                return (R) qo5Var.invoke(Integer.valueOf(i), this.f22710catch.next());
            }
            xl5.t();
            throw null;
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public ls5(wr5<? extends T> wr5Var, qo5<? super Integer, ? super T, ? extends R> qo5Var) {
        jp5.m8570try(wr5Var, "sequence");
        jp5.m8570try(qo5Var, "transformer");
        this.f22708do = wr5Var;
        this.f22709if = qo5Var;
    }

    @Override // defpackage.wr5
    public Iterator<R> iterator() {
        return new a();
    }
}
