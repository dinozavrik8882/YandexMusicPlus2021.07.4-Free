package defpackage;

/* loaded from: classes2.dex */
public final class a26 {

    /* renamed from: do, reason: not valid java name */
    public final t16 f120do;

    public a26(t16 t16Var) {
        this.f120do = t16Var;
    }

    public String toString() {
        StringBuilder r = by.r("Removed[");
        r.append(this.f120do);
        r.append(']');
        return r.toString();
    }
}
