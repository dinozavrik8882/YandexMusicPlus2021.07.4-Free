package defpackage;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.yandex.metrica.rtm.Constants;
import defpackage.q1;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class m0 extends q1 {

    /* renamed from: catch, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f23146catch;

    /* renamed from: class, reason: not valid java name */
    public final ey3 f23147class;

    /* renamed from: const, reason: not valid java name */
    public final ey3 f23148const;

    /* renamed from: final, reason: not valid java name */
    public final ey3 f23149final;

    /* renamed from: super, reason: not valid java name */
    public final ey3 f23150super;

    /* renamed from: throw, reason: not valid java name */
    public final ey3 f23151throw;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<mr5<?>, TextView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f23152catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ int f23153class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ Object f23154const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(int i, int i2, Object obj) {
            super(1);
            this.f23152catch = i;
            this.f23153class = i2;
            this.f23154const = obj;
        }

        @Override // defpackage.mo5
        public final TextView invoke(mr5<?> mr5Var) {
            int i = this.f23152catch;
            if (i == 0) {
                mr5<?> mr5Var2 = mr5Var;
                jp5.m8570try(mr5Var2, "property");
                try {
                    View findViewById = ((View) this.f23154const).findViewById(R.id.copyright_info);
                    if (findViewById != null) {
                        return (TextView) findViewById;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
                }
            }
            if (i == 1) {
                mr5<?> mr5Var3 = mr5Var;
                jp5.m8570try(mr5Var3, "property");
                try {
                    View findViewById2 = ((View) this.f23154const).findViewById(R.id.promo_title);
                    if (findViewById2 != null) {
                        return (TextView) findViewById2;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e2) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var3).toString(), e2);
                }
            }
            if (i == 2) {
                mr5<?> mr5Var4 = mr5Var;
                jp5.m8570try(mr5Var4, "property");
                try {
                    View findViewById3 = ((View) this.f23154const).findViewById(R.id.promo_subtitle);
                    if (findViewById3 != null) {
                        return (TextView) findViewById3;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e3) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var4).toString(), e3);
                }
            }
            if (i == 3) {
                mr5<?> mr5Var5 = mr5Var;
                jp5.m8570try(mr5Var5, "property");
                try {
                    View findViewById4 = ((View) this.f23154const).findViewById(R.id.promo_info);
                    if (findViewById4 != null) {
                        return (TextView) findViewById4;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e4) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var5).toString(), e4);
                }
            }
            if (i != 4) {
                throw null;
            }
            mr5<?> mr5Var6 = mr5Var;
            jp5.m8570try(mr5Var6, "property");
            try {
                View findViewById5 = ((View) this.f23154const).findViewById(R.id.promo_description);
                if (findViewById5 != null) {
                    return (TextView) findViewById5;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            } catch (ClassCastException e5) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var6).toString(), e5);
            }
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(m0.class), "copyrightInfo", "getCopyrightInfo()Landroid/widget/TextView;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(m0.class), "title", "getTitle()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var3 = new wp5(dq5.m4763do(m0.class), "subtitle", "getSubtitle()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var4 = new wp5(dq5.m4763do(m0.class), "info", "getInfo()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var5 = new wp5(dq5.m4763do(m0.class), "description", "getDescription()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        f23146catch = new mr5[]{wp5Var, wp5Var2, wp5Var3, wp5Var4, wp5Var5};
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m0(Context context, View view) {
        super(context, view);
        jp5.m8570try(context, "context");
        jp5.m8570try(view, "view");
        this.f23147class = new ey3(new a(0, R.id.copyright_info, view));
        this.f23148const = new ey3(new a(1, R.id.promo_title, view));
        this.f23149final = new ey3(new a(2, R.id.promo_subtitle, view));
        this.f23150super = new ey3(new a(3, R.id.promo_info, view));
        this.f23151throw = new ey3(new a(4, R.id.promo_description, view));
    }

    @Override // defpackage.q1
    /* renamed from: if, reason: not valid java name */
    public void mo10086if(h67 h67Var) {
        String str;
        jp5.m8570try(h67Var, Constants.KEY_DATA);
        super.mo10086if(h67Var);
        zd9 copyrightInfo = h67Var.f14767const.getCopyrightInfo();
        if (copyrightInfo != null) {
            TextView textView = (TextView) this.f23147class.m5520do(f23146catch[0]);
            String str2 = copyrightInfo.f47070catch;
            t2.m14618synchronized(textView, (str2 == null || (str = copyrightInfo.f47071class) == null) ? str2 != null ? h9d.m7090else(R.string.photo_copyright_format_short, str2) : null : h9d.m7090else(R.string.photo_copyright_format, str, str2));
        }
        ey3 ey3Var = this.f23148const;
        mr5<Object>[] mr5VarArr = f23146catch;
        t2.m14618synchronized((TextView) ey3Var.m5520do(mr5VarArr[1]), h67Var.f14774while);
        t2.m14618synchronized((TextView) this.f23149final.m5520do(mr5VarArr[2]), h67Var.f14769import);
        t2.m14618synchronized((TextView) this.f23150super.m5520do(mr5VarArr[3]), h67Var.f14770native);
        t2.m14618synchronized((TextView) this.f23151throw.m5520do(mr5VarArr[4]), h67Var.f14771public);
        m12408for().setOnClickListener(new View.OnClickListener() { // from class: d67
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                m0 m0Var = m0.this;
                jp5.m8570try(m0Var, "this$0");
                q1.b bVar = m0Var.f29861break;
                if (bVar == null) {
                    return;
                }
                bVar.mo8836for();
            }
        });
    }
}
