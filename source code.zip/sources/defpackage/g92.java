package defpackage;

/* loaded from: classes.dex */
public interface g92 extends j92<Long> {
}
