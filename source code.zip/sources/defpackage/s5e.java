package defpackage;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import defpackage.bde;
import defpackage.h5e;
import defpackage.vde;
import defpackage.w6e;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class s5e implements vde.b {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ t5e f34971do;

    /* renamed from: if, reason: not valid java name */
    public final /* synthetic */ h5e.d f34972if;

    public s5e(t5e t5eVar, h5e.d dVar) {
        this.f34971do = t5eVar;
        this.f34972if = dVar;
    }

    @Override // vde.b
    /* renamed from: do */
    public final void mo10911do(List<String> list, String str) {
        jp5.m8570try(list, "ids");
        jp5.m8570try(str, "clickedId");
        ViewGroup viewGroup = this.f34971do.f36637final.f43317else.get();
        if (viewGroup != null) {
            t5e t5eVar = this.f34971do;
            w6e w6eVar = t5eVar.f36637final.f43316do;
            String str2 = this.f34972if.f14741do;
            View view = t5eVar.itemView;
            jp5.m8568new(view, "itemView");
            Context context = view.getContext();
            jp5.m8568new(context, "itemView.context");
            float dimension = context.getResources().getDimension(R.dimen.mu_1);
            Runnable runnable = this.f34971do.f36637final.f43322this;
            Objects.requireNonNull(w6eVar);
            jp5.m8570try(str2, "screenName");
            jp5.m8570try(list, "storyIds");
            jp5.m8570try(str, "selectedStoryId");
            jp5.m8570try(viewGroup, "container");
            bde.b bVar = new bde.b();
            bVar.f3466for = bde.c.STORIES_FOR_SCREEN;
            bVar.f3468new = Collections.unmodifiableList(list);
            bVar.f3467if = str;
            bVar.f3465do = str2;
            bVar.f3469try = Float.valueOf(dimension);
            bVar.f3464case = false;
            l2e.m9390while(bVar.f3465do, "screenName is null");
            l2e.m9390while(bVar.f3466for, "mode is null");
            List<String> list2 = bVar.f3468new;
            l2e.m9390while(list2, "storyIds is empty");
            if (apd.m1395const(list2)) {
                k2f.f19768new.mo8772static(new IllegalStateException(), "storyIds is empty", new Object[0]);
            }
            l2e.m9390while(bVar.f3469try, "previewCornersRadius is null");
            bde bdeVar = new bde(bVar, null);
            jp5.m8568new(bdeVar, "Builder()\n      .setMode…wed(false)\n      .build()");
            Context context2 = w6eVar.f41763do;
            wud wudVar = w6eVar.f41767if;
            dae daeVar = w6eVar.f41765for;
            lrd lrdVar = w6eVar.f41768new;
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context2, R.style.Component_Light);
            kae kaeVar = daeVar.f8222do.f5062class;
            qie m4301do = daeVar.m4301do();
            cae caeVar = daeVar.f8222do;
            fae faeVar = new fae(kaeVar, new hfe(kaeVar, m4301do, caeVar.f5068goto, caeVar.f5065else), daeVar.f8224if, daeVar.m4302if(), bdeVar);
            cae caeVar2 = daeVar.f8222do;
            nrd nrdVar = caeVar2.f5070new;
            qae m2714do = caeVar2.m2714do();
            ffe m4302if = daeVar.m4302if();
            cae caeVar3 = daeVar.f8222do;
            pae paeVar = caeVar3.f5060case;
            ypd ypdVar = caeVar3.f5068goto;
            fde fdeVar = new fde(bdeVar, kaeVar, faeVar, nrdVar, m2714do, m4302if, paeVar, lrdVar, ypdVar, new jie(caeVar3.f5063const, caeVar3.f5061catch, ypdVar, contextThemeWrapper, caeVar3.f5071this, caeVar3.f5059break));
            oie oieVar = daeVar.f8222do.f5063const;
            qie m4301do2 = daeVar.m4301do();
            cae caeVar4 = daeVar.f8222do;
            dde ddeVar = new dde(contextThemeWrapper, wudVar, fdeVar, oieVar, m4301do2, caeVar4.f5068goto, caeVar4.f5070new, new gde(caeVar4.m2714do(), faeVar, daeVar.f8222do.f5069if, bdeVar));
            jp5.m8568new(ddeVar, "component.newStoryModalView()");
            ddeVar.setZ(2);
            if (runnable != null) {
                ddeVar.setOnAppearingListener(new w6e.a(runnable));
            }
            viewGroup.addView(ddeVar);
            this.f34971do.f36635class.f36693package.mo147do(new d8e(ddeVar));
        }
    }
}
