package defpackage;

import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class p48 extends kp5 implements mo5<r, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ int f28336catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ boolean f28337class;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p48(int i, boolean z) {
        super(1);
        this.f28336catch = i;
        this.f28337class = z;
    }

    @Override // defpackage.mo5
    public pl5 invoke(r rVar) {
        r rVar2 = rVar;
        jp5.m8570try(rVar2, "$this$null");
        int i = this.f28336catch;
        boolean z = this.f28337class;
        String m7093new = h9d.m7093new(R.plurals.plural_n_days, i, Integer.valueOf(i));
        rVar2.m13039for().setText(z ? rVar2.f31567for.getString(R.string.promo_code_success_delayed, m7093new) : rVar2.f31567for.getString(R.string.promo_code_success, m7093new));
        return pl5.f29126do;
    }
}
