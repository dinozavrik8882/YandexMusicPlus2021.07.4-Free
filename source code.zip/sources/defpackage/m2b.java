package defpackage;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.DrawableWrapper;

/* loaded from: classes2.dex */
public final class m2b extends DrawableWrapper {

    /* renamed from: catch, reason: not valid java name */
    public final int f23296catch;

    /* renamed from: class, reason: not valid java name */
    public final Paint f23297class;

    /* renamed from: const, reason: not valid java name */
    public boolean f23298const;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public m2b(android.content.Context r2, int r3, int r4) {
        /*
            r1 = this;
            java.lang.String r0 = "context"
            defpackage.jp5.m8570try(r2, r0)
            android.graphics.drawable.Drawable r2 = r2.getDrawable(r3)
            defpackage.jp5.m8565for(r2)
            java.lang.String r3 = "context.getDrawable(resId)!!"
            defpackage.jp5.m8568new(r2, r3)
            java.lang.String r3 = "base"
            defpackage.jp5.m8570try(r2, r3)
            r1.<init>(r2)
            r1.f23296catch = r4
            android.graphics.Paint r2 = new android.graphics.Paint
            r2.<init>()
            r3 = 436207616(0x1a000000, float:2.646978E-23)
            r2.setColor(r3)
            r1.f23297class = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.m2b.<init>(android.content.Context, int, int):void");
    }

    @Override // android.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        jp5.m8570try(canvas, "canvas");
        float width = getBounds().width();
        float height = getBounds().height();
        canvas.save();
        float f = 2;
        canvas.scale(this.f23296catch / getBounds().width(), this.f23296catch / getBounds().width(), width / f, height / f);
        super.draw(canvas);
        canvas.restore();
        if (this.f23298const) {
            canvas.drawOval(0.0f, 0.0f, width, height, this.f23297class);
        }
    }
}
