package defpackage;

import ru.yandex.video.ott.data.local.PictureInPictureProvider;
import ru.yandex.video.ott.data.local.SubProfileProvider;
import ru.yandex.video.player.impl.utils.TimeProvider;
import ru.yandex.video.player.utils.ResourceProvider;

/* loaded from: classes2.dex */
public final class vke {

    /* renamed from: do, reason: not valid java name */
    public final TimeProvider f40730do;

    /* renamed from: for, reason: not valid java name */
    public final ske f40731for;

    /* renamed from: if, reason: not valid java name */
    public final ResourceProvider f40732if;

    /* renamed from: new, reason: not valid java name */
    public final SubProfileProvider f40733new;

    /* renamed from: try, reason: not valid java name */
    public final PictureInPictureProvider f40734try;

    public vke(TimeProvider timeProvider, ResourceProvider resourceProvider, ske skeVar, SubProfileProvider subProfileProvider, PictureInPictureProvider pictureInPictureProvider) {
        jp5.m8560case(timeProvider, "timeProvider");
        jp5.m8560case(resourceProvider, "resourceProvider");
        jp5.m8560case(skeVar, "connectionChecker");
        jp5.m8560case(subProfileProvider, "subProfileProvider");
        jp5.m8560case(pictureInPictureProvider, "pictureInPictureProvider");
        this.f40730do = timeProvider;
        this.f40732if = resourceProvider;
        this.f40731for = skeVar;
        this.f40733new = subProfileProvider;
        this.f40734try = pictureInPictureProvider;
    }
}
