package defpackage;

import android.content.Context;
import defpackage.b20;
import java.io.File;

/* loaded from: classes.dex */
public final class d20 extends b20 {

    /* loaded from: classes.dex */
    public class a implements b20.a {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ Context f7876do;

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ String f7877if;

        public a(Context context, String str) {
            this.f7876do = context;
            this.f7877if = str;
        }

        @Override // b20.a
        /* renamed from: do */
        public File mo1641do() {
            File externalCacheDir;
            File cacheDir = this.f7876do.getCacheDir();
            if (cacheDir == null) {
                cacheDir = null;
            } else if (this.f7877if != null) {
                cacheDir = new File(cacheDir, this.f7877if);
            }
            return ((cacheDir == null || !cacheDir.exists()) && (externalCacheDir = this.f7876do.getExternalCacheDir()) != null && externalCacheDir.canWrite()) ? this.f7877if != null ? new File(externalCacheDir, this.f7877if) : externalCacheDir : cacheDir;
        }
    }

    public d20(Context context, String str, long j) {
        super(new a(context, str), j);
    }
}
