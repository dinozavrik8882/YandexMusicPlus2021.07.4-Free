package defpackage;

import android.content.Context;
import android.view.View;
import defpackage.vn8;
import java.util.Objects;
import ru.yandex.music.search.SearchFeedbackRequest;

/* loaded from: classes2.dex */
public final class y37 extends z37 {

    /* renamed from: public, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f44945public;

    /* renamed from: return, reason: not valid java name */
    public final el5 f44946return;

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(y37.class), "searchFeedbackReporter", "getSearchFeedbackReporter()Lru/yandex/music/search/SearchFeedbackReporter;");
        Objects.requireNonNull(dq5.f8909do);
        f44945public = new mr5[]{wp5Var};
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y37(c37 c37Var, Context context, t78 t78Var, cd9 cd9Var, xab xabVar, kz6 kz6Var, vn8.a aVar) {
        super(c37Var, context, t78Var, cd9Var, xabVar, kz6Var, aVar);
        jp5.m8570try(c37Var, "navigation");
        jp5.m8570try(context, "context");
        jp5.m8570try(t78Var, "playbackContext");
        jp5.m8570try(cd9Var, "trackDataSource");
        jp5.m8570try(xabVar, "phonotekaHelper");
        iz3 l3 = dn3.l3(obc.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        jp5.m8570try(f44945public[0], "prop");
        this.f44946return = dn3.h1(cz3Var);
    }

    @Override // defpackage.z37
    /* renamed from: const */
    public void mo16358const(View view, e69 e69Var) {
        jp5.m8570try(view, "view");
        jp5.m8570try(e69Var, "track");
        super.mo16358const(view, e69Var);
        ((obc) this.f44946return.getValue()).m11472if(SearchFeedbackRequest.ClickType.LIKE);
    }
}
