package defpackage;

import java.util.HashMap;

/* loaded from: classes2.dex */
public class lt7 {

    /* renamed from: do, reason: not valid java name */
    public final HashMap<String, Long> f22779do = new HashMap<>();

    /* renamed from: if, reason: not valid java name */
    public long f22780if = 1;

    /* renamed from: do, reason: not valid java name */
    public long m9977do(String str) {
        Long l = this.f22779do.get(str);
        if (l == null) {
            long j = this.f22780if;
            this.f22780if = 1 + j;
            l = Long.valueOf(j);
            this.f22779do.put(str, l);
        }
        return l.longValue();
    }
}
