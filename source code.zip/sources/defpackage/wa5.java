package defpackage;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import defpackage.db5;
import defpackage.fb5;
import defpackage.jc5;
import defpackage.sb5;
import defpackage.ub5;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class wa5 implements fb5.c, jc5.a, sb5.a {

    /* renamed from: do, reason: not valid java name */
    public static wa5 f41926do;

    /* renamed from: for, reason: not valid java name */
    public static boolean f41927for;

    /* renamed from: if, reason: not valid java name */
    public static boolean f41928if;

    /* renamed from: new, reason: not valid java name */
    public static final String[] f41929new = {"extra_launch_uri", "branch_intent"};

    /* renamed from: break, reason: not valid java name */
    public final dc5 f41930break;

    /* renamed from: case, reason: not valid java name */
    public tb5 f41931case;

    /* renamed from: catch, reason: not valid java name */
    public int f41932catch;

    /* renamed from: class, reason: not valid java name */
    public boolean f41933class;

    /* renamed from: const, reason: not valid java name */
    public Map<?, String> f41934const;

    /* renamed from: else, reason: not valid java name */
    public final nb5 f41935else;

    /* renamed from: goto, reason: not valid java name */
    public Context f41937goto;

    /* renamed from: import, reason: not valid java name */
    public boolean f41938import;

    /* renamed from: return, reason: not valid java name */
    public xa5 f41941return;

    /* renamed from: static, reason: not valid java name */
    public final kc5 f41942static;

    /* renamed from: this, reason: not valid java name */
    public Semaphore f41944this;

    /* renamed from: throw, reason: not valid java name */
    public WeakReference<Activity> f41945throw;

    /* renamed from: try, reason: not valid java name */
    public mc5 f41946try;

    /* renamed from: while, reason: not valid java name */
    public final ConcurrentHashMap<String, String> f41947while;

    /* renamed from: final, reason: not valid java name */
    public e f41936final = e.PENDING;

    /* renamed from: super, reason: not valid java name */
    public f f41943super = f.UNINITIALISED;

    /* renamed from: native, reason: not valid java name */
    public boolean f41939native = false;

    /* renamed from: public, reason: not valid java name */
    public boolean f41940public = false;

    /* loaded from: classes2.dex */
    public class a implements db5.c {
        public a() {
        }
    }

    /* loaded from: classes2.dex */
    public class b extends ya5<Void, Void, ic5> {

        /* renamed from: do, reason: not valid java name */
        public ub5 f41949do;

        public b(ub5 ub5Var) {
            this.f41949do = ub5Var;
        }

        /* JADX WARN: Finally extract failed */
        /* JADX WARN: Removed duplicated region for block: B:48:0x01b8  */
        /* JADX WARN: Removed duplicated region for block: B:49:0x01b9 A[Catch: JSONException -> 0x01cd, TRY_LEAVE, TryCatch #10 {JSONException -> 0x01cd, blocks: (B:42:0x0116, B:44:0x011a, B:46:0x012b, B:49:0x01b9, B:51:0x0148, B:53:0x0150, B:55:0x015e, B:57:0x0168, B:59:0x0176, B:61:0x0185, B:62:0x019c, B:64:0x01a2, B:66:0x01ae), top: B:41:0x0116 }] */
        @Override // android.os.AsyncTask
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object doInBackground(java.lang.Object[] r15) {
            /*
                Method dump skipped, instructions count: 1190
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: wa5.b.doInBackground(java.lang.Object[]):java.lang.Object");
        }

        @Override // android.os.AsyncTask
        public void onPostExecute(Object obj) {
            boolean z;
            ic5 ic5Var = (ic5) obj;
            super.onPostExecute(ic5Var);
            if (ic5Var != null) {
                try {
                    int i = ic5Var.f16614do;
                    wa5 wa5Var = wa5.this;
                    boolean z2 = true;
                    wa5Var.f41933class = true;
                    if (i == -117) {
                        this.f41949do.m15468final();
                        wa5.this.f41930break.m4350goto(this.f41949do);
                    } else if (i != 200) {
                        ub5 ub5Var = this.f41949do;
                        if (ub5Var instanceof bc5) {
                            wa5Var.f41943super = f.UNINITIALISED;
                        }
                        if (i != 400 && i != 409) {
                            wa5Var.f41933class = false;
                            ArrayList arrayList = new ArrayList();
                            for (int i2 = 0; i2 < wa5.this.f41930break.m4349for(); i2++) {
                                arrayList.add(wa5.this.f41930break.m4346case(i2));
                            }
                            Iterator it = arrayList.iterator();
                            while (it.hasNext()) {
                                ub5 ub5Var2 = (ub5) it.next();
                                if (ub5Var2 == null || !ub5Var2.mo476throw()) {
                                    wa5.this.f41930break.m4350goto(ub5Var2);
                                }
                            }
                            wa5.this.f41932catch = 0;
                            Iterator it2 = arrayList.iterator();
                            while (it2.hasNext()) {
                                ub5 ub5Var3 = (ub5) it2.next();
                                if (ub5Var3 != null) {
                                    ub5Var3.mo473else(i, ic5Var.m7736do());
                                    if (ub5Var3.mo476throw()) {
                                        ub5Var3.mo475if();
                                    }
                                }
                            }
                        }
                        wa5Var.f41930break.m4350goto(ub5Var);
                        ub5 ub5Var4 = this.f41949do;
                        if (ub5Var4 instanceof wb5) {
                            Objects.requireNonNull((wb5) ub5Var4);
                        } else {
                            if (!TextUtils.isEmpty("Branch API Error: Conflicting resource error code from API")) {
                                Log.i("BranchSDK", "Branch API Error: Conflicting resource error code from API");
                            }
                            wa5.this.m16480break(0, i);
                        }
                    } else {
                        wa5Var.f41933class = true;
                        ub5 ub5Var5 = this.f41949do;
                        if (ub5Var5 instanceof wb5) {
                            if (ic5Var.m7737if() != null) {
                                String string = ic5Var.m7737if().getString("url");
                                Map<?, String> map = wa5.this.f41934const;
                                Objects.requireNonNull((wb5) this.f41949do);
                                map.put(null, string);
                            }
                        } else if (ub5Var5 instanceof cc5) {
                            wa5Var.f41934const.clear();
                            wa5.this.f41930break.m4347do();
                        }
                        wa5.this.f41930break.m4351if();
                        ub5 ub5Var6 = this.f41949do;
                        if (!(ub5Var6 instanceof bc5) && !(ub5Var6 instanceof ac5)) {
                            ub5Var6.mo472catch(ic5Var, wa5.f41926do);
                        }
                        JSONObject m7737if = ic5Var.m7737if();
                        if (m7737if != null) {
                            if (wa5.this.f41942static.f20223do) {
                                z2 = false;
                            } else {
                                jb5 jb5Var = jb5.SessionID;
                                if (m7737if.has(jb5Var.getKey())) {
                                    wa5.this.f41931case.m14828protected("bnc_session_id", m7737if.getString(jb5Var.getKey()));
                                    z = true;
                                } else {
                                    z = false;
                                }
                                jb5 jb5Var2 = jb5.IdentityID;
                                if (m7737if.has(jb5Var2.getKey())) {
                                    if (!wa5.this.f41931case.m14818final().equals(m7737if.getString(jb5Var2.getKey()))) {
                                        wa5.this.f41934const.clear();
                                        wa5.this.f41931case.m14828protected("bnc_identity_id", m7737if.getString(jb5Var2.getKey()));
                                        z = true;
                                    }
                                }
                                jb5 jb5Var3 = jb5.DeviceFingerprintID;
                                if (m7737if.has(jb5Var3.getKey())) {
                                    wa5.this.f41931case.m14828protected("bnc_device_fingerprint_id", m7737if.getString(jb5Var3.getKey()));
                                } else {
                                    z2 = z;
                                }
                            }
                            if (z2) {
                                wa5.m16478do(wa5.this);
                            }
                            ub5 ub5Var7 = this.f41949do;
                            if (ub5Var7 instanceof bc5) {
                                wa5.this.f41943super = f.INITIALISED;
                                ub5Var7.mo472catch(ic5Var, wa5.f41926do);
                                if (!((bc5) this.f41949do).m1940native(ic5Var)) {
                                    wa5.this.m16487if();
                                }
                                Objects.requireNonNull(wa5.this);
                                Objects.requireNonNull(wa5.this);
                            } else {
                                ub5Var7.mo472catch(ic5Var, wa5.f41926do);
                            }
                        }
                    }
                    wa5 wa5Var2 = wa5.this;
                    wa5Var2.f41932catch = 0;
                    if (!wa5Var2.f41933class || wa5Var2.f41943super == f.UNINITIALISED) {
                        return;
                    }
                    wa5Var2.m16494while();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override // android.os.AsyncTask
        public void onPreExecute() {
            boolean m14810case;
            super.onPreExecute();
            this.f41949do.mo1937break();
            ub5 ub5Var = this.f41949do;
            Objects.requireNonNull(ub5Var);
            try {
                JSONObject jSONObject = new JSONObject();
                Iterator<String> keys = ub5Var.f38687new.f36940case.keys();
                while (keys.hasNext()) {
                    String next = keys.next();
                    jSONObject.put(next, ub5Var.f38687new.f36940case.get(next));
                }
                JSONObject optJSONObject = ub5Var.f38686if.optJSONObject(jb5.Metadata.getKey());
                if (optJSONObject != null) {
                    Iterator<String> keys2 = optJSONObject.keys();
                    while (keys2.hasNext()) {
                        String next2 = keys2.next();
                        jSONObject.put(next2, optJSONObject.get(next2));
                    }
                }
                if ((ub5Var instanceof gc5) && ub5Var.f38687new.f36941else.length() > 0) {
                    Iterator<String> keys3 = ub5Var.f38687new.f36941else.keys();
                    while (keys3.hasNext()) {
                        String next3 = keys3.next();
                        ub5Var.f38686if.putOpt(next3, ub5Var.f38687new.f36941else.get(next3));
                    }
                }
                ub5Var.f38686if.put(jb5.Metadata.getKey(), jSONObject);
            } catch (JSONException unused) {
                tb5.m14805do("Could not merge metadata, ignoring user metadata.");
            }
            if (ub5Var.mo1943while()) {
                JSONObject optJSONObject2 = ub5Var.mo15469new() == ub5.a.V1 ? ub5Var.f38686if : ub5Var.f38686if.optJSONObject(jb5.UserData.getKey());
                if (optJSONObject2 == null || !(m14810case = ub5Var.f38687new.m14810case("bnc_limit_facebook_tracking"))) {
                    return;
                }
                try {
                    optJSONObject2.putOpt(jb5.limitFacebookTracking.getKey(), Boolean.valueOf(m14810case));
                } catch (JSONException unused2) {
                }
            }
        }
    }

    /* loaded from: classes2.dex */
    public interface c {
        /* renamed from: do */
        void mo7594do(JSONObject jSONObject, za5 za5Var);
    }

    /* loaded from: classes2.dex */
    public interface d {
        /* renamed from: do, reason: not valid java name */
        boolean m16495do();
    }

    /* loaded from: classes2.dex */
    public enum e {
        PENDING,
        READY
    }

    /* loaded from: classes2.dex */
    public enum f {
        INITIALISED,
        INITIALISING,
        UNINITIALISED
    }

    public wa5(Context context) {
        this.f41938import = false;
        this.f41931case = tb5.m14807throw(context);
        kc5 kc5Var = new kc5(context);
        this.f41942static = kc5Var;
        this.f41946try = new nc5(context);
        if (nb5.f25343do == null) {
            nb5.f25343do = new nb5(context);
        }
        nb5 nb5Var = nb5.f25343do;
        this.f41935else = nb5Var;
        if (dc5.f8292do == null) {
            synchronized (dc5.class) {
                if (dc5.f8292do == null) {
                    dc5.f8292do = new dc5(context);
                }
            }
        }
        this.f41930break = dc5.f8292do;
        this.f41944this = new Semaphore(1);
        this.f41932catch = 0;
        this.f41933class = true;
        this.f41934const = new HashMap();
        this.f41947while = new ConcurrentHashMap<>();
        if (kc5Var.f20223do) {
            return;
        }
        this.f41938import = nb5Var.f25345if.m8281case(context, this);
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x005c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* renamed from: case, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static defpackage.wa5 m16477case(android.content.Context r8) {
        /*
            Method dump skipped, instructions count: 281
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.wa5.m16477case(android.content.Context):wa5");
    }

    /* renamed from: do, reason: not valid java name */
    public static void m16478do(wa5 wa5Var) {
        JSONObject jSONObject;
        Objects.requireNonNull(wa5Var);
        for (int i = 0; i < wa5Var.f41930break.m4349for(); i++) {
            try {
                ub5 m4346case = wa5Var.f41930break.m4346case(i);
                if (m4346case != null && (jSONObject = m4346case.f38686if) != null) {
                    jb5 jb5Var = jb5.SessionID;
                    if (jSONObject.has(jb5Var.getKey())) {
                        m4346case.f38686if.put(jb5Var.getKey(), wa5Var.f41931case.m14836throws());
                    }
                    jb5 jb5Var2 = jb5.IdentityID;
                    if (jSONObject.has(jb5Var2.getKey())) {
                        m4346case.f38686if.put(jb5Var2.getKey(), wa5Var.f41931case.m14818final());
                    }
                    jb5 jb5Var3 = jb5.DeviceFingerprintID;
                    if (jSONObject.has(jb5Var3.getKey())) {
                        m4346case.f38686if.put(jb5Var3.getKey(), wa5Var.f41931case.m14812class());
                    }
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
                return;
            }
        }
    }

    /* renamed from: else, reason: not valid java name */
    public static wa5 m16479else() {
        if (f41926do == null) {
            tb5.m14805do("Branch instance is not created yet. Make sure you have initialised Branch. [Consider Calling getInstance(Context ctx) if you still have issue.]");
        } else if (f41928if && !f41927for) {
            tb5.m14805do("Branch instance is not properly initialised. Make sure your Application class is extending BranchApp class. If you are not extending BranchApp class make sure you are initialising Branch in your Applications onCreate()");
        }
        return f41926do;
    }

    /* renamed from: break, reason: not valid java name */
    public final void m16480break(int i, int i2) {
        ub5 m4346case;
        if (i >= this.f41930break.m4349for()) {
            m4346case = this.f41930break.m4346case(r2.m4349for() - 1);
        } else {
            m4346case = this.f41930break.m4346case(i);
        }
        if (m4346case == null) {
            return;
        }
        m4346case.mo473else(i2, "");
    }

    /* renamed from: catch, reason: not valid java name */
    public final void m16481catch(c cVar, Activity activity) {
    }

    /* renamed from: class, reason: not valid java name */
    public final boolean m16482class(Activity activity) {
        return (activity == null || activity.getIntent() == null || !activity.getIntent().getBooleanExtra(jb5.BranchLinkUsed.getKey(), false)) ? false : true;
    }

    /* renamed from: const, reason: not valid java name */
    public boolean m16483const(Intent intent) {
        if (intent != null) {
            return intent.getBooleanExtra(jb5.ForceNewBranchSession.getKey(), false) || !(intent.getStringExtra(jb5.AndroidPushNotificationKey.getKey()) == null || intent.getBooleanExtra(jb5.BranchLinkUsed.getKey(), false));
        }
        return false;
    }

    /* renamed from: final, reason: not valid java name */
    public void m16484final() {
        this.f41938import = false;
        this.f41930break.m4353this(ub5.b.GAID_FETCH_WAIT_LOCK);
        if (!this.f41939native) {
            m16494while();
        } else {
            m16492throw();
            this.f41939native = false;
        }
    }

    /* renamed from: for, reason: not valid java name */
    public final boolean m16485for(JSONObject jSONObject, ActivityInfo activityInfo) {
        if (activityInfo.metaData.getString("io.branch.sdk.auto_link_keys") != null) {
            for (String str : activityInfo.metaData.getString("io.branch.sdk.auto_link_keys").split(",")) {
                if (jSONObject.has(str)) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: goto, reason: not valid java name */
    public JSONObject m16486goto() {
        return m16493try(this.f41931case.m14815default("bnc_session_params"));
    }

    /* renamed from: if, reason: not valid java name */
    public final void m16487if() {
        WeakReference<Activity> weakReference;
        Bundle bundle;
        JSONObject m16486goto = m16486goto();
        String str = null;
        try {
            jb5 jb5Var = jb5.Clicked_Branch_Link;
            if (m16486goto.has(jb5Var.getKey()) && m16486goto.getBoolean(jb5Var.getKey()) && m16486goto.length() > 0) {
                Bundle bundle2 = this.f41937goto.getPackageManager().getApplicationInfo(this.f41937goto.getPackageName(), 128).metaData;
                if (bundle2 == null || !bundle2.getBoolean("io.branch.sdk.auto_link_disable", false)) {
                    ActivityInfo[] activityInfoArr = this.f41937goto.getPackageManager().getPackageInfo(this.f41937goto.getPackageName(), 129).activities;
                    int i = 1501;
                    if (activityInfoArr != null) {
                        for (ActivityInfo activityInfo : activityInfoArr) {
                            if (activityInfo != null && (bundle = activityInfo.metaData) != null && ((bundle.getString("io.branch.sdk.auto_link_keys") != null || activityInfo.metaData.getString("io.branch.sdk.auto_link_path") != null) && (m16485for(m16486goto, activityInfo) || m16489new(m16486goto, activityInfo)))) {
                                str = activityInfo.name;
                                i = activityInfo.metaData.getInt("io.branch.sdk.auto_link_request_code", 1501);
                                break;
                            }
                        }
                    }
                    if (str == null || (weakReference = this.f41945throw) == null) {
                        return;
                    }
                    Activity activity = weakReference.get();
                    if (activity == null) {
                        tb5.m14805do("No activity reference to launch deep linked activity");
                        return;
                    }
                    Intent intent = new Intent(activity, Class.forName(str));
                    intent.putExtra("io.branch.sdk.auto_linked", "true");
                    intent.putExtra(jb5.ReferringData.getKey(), m16486goto.toString());
                    Iterator<String> keys = m16486goto.keys();
                    while (keys.hasNext()) {
                        String next = keys.next();
                        intent.putExtra(next, m16486goto.getString(next));
                    }
                    activity.startActivityForResult(intent, i);
                }
            }
        } catch (PackageManager.NameNotFoundException unused) {
            tb5.m14805do("Warning: Please make sure Activity names set for auto deep link are correct!");
        } catch (ClassNotFoundException unused2) {
            tb5.m14805do("Warning: Please make sure Activity names set for auto deep link are correct! Error while looking for activity " + ((String) null));
        } catch (Exception unused3) {
        }
    }

    /* renamed from: import, reason: not valid java name */
    public boolean m16488import(Uri uri, Activity activity) {
        String str;
        if (this.f41936final == e.READY) {
            if (uri != null) {
                try {
                    if (!m16482class(activity)) {
                        String m9582if = lc5.m9581do(this.f41937goto).m9582if(uri.toString());
                        this.f41931case.m14828protected("bnc_external_intent_uri", m9582if);
                        if (m9582if != null && m9582if.equals(uri.toString()) && activity != null && activity.getIntent() != null && activity.getIntent().getExtras() != null) {
                            Bundle extras = activity.getIntent().getExtras();
                            Set<String> keySet = extras.keySet();
                            if (keySet.size() > 0) {
                                JSONObject jSONObject = new JSONObject();
                                for (String str2 : f41929new) {
                                    if (keySet.contains(str2)) {
                                        jSONObject.put(str2, extras.get(str2));
                                    }
                                }
                                if (jSONObject.length() > 0) {
                                    this.f41931case.m14828protected("bnc_external_intent_extra", jSONObject.toString());
                                }
                            }
                        }
                    }
                } catch (Exception unused) {
                }
            }
            if (activity != null) {
                try {
                    if (activity.getIntent() != null && activity.getIntent().getExtras() != null && !m16482class(activity)) {
                        Object obj = activity.getIntent().getExtras().get(jb5.AndroidPushNotificationKey.getKey());
                        String uri2 = obj instanceof String ? (String) obj : obj instanceof Uri ? ((Uri) obj).toString() : null;
                        if (!TextUtils.isEmpty(uri2)) {
                            this.f41931case.m14828protected("bnc_push_identifier", uri2);
                            Intent intent = activity.getIntent();
                            intent.putExtra(jb5.BranchLinkUsed.getKey(), true);
                            activity.setIntent(intent);
                            return false;
                        }
                    }
                } catch (Exception unused2) {
                }
            }
            if (uri != null && uri.isHierarchical() && activity != null) {
                if (!((activity.getIntent() == null || (activity.getIntent().getFlags() & 1048576) == 0) ? false : true)) {
                    try {
                        jb5 jb5Var = jb5.LinkClickID;
                        if (uri.getQueryParameter(jb5Var.getKey()) != null) {
                            this.f41931case.m14828protected("bnc_link_click_identifier", uri.getQueryParameter(jb5Var.getKey()));
                            String str3 = "link_click_id=" + uri.getQueryParameter(jb5Var.getKey());
                            String dataString = activity.getIntent() != null ? activity.getIntent().getDataString() : null;
                            if (uri.getQuery().length() == str3.length()) {
                                str = "\\?" + str3;
                            } else if (dataString == null || dataString.length() - str3.length() != dataString.indexOf(str3)) {
                                str = str3 + "&";
                            } else {
                                str = "&" + str3;
                            }
                            if (dataString != null) {
                                activity.getIntent().setData(Uri.parse(dataString.replaceFirst(str, "")));
                                activity.getIntent().putExtra(jb5.BranchLinkUsed.getKey(), true);
                            } else {
                                tb5.m14805do("Warning: URI for the launcher activity is null. Please make sure that intent data is not set to null before calling Branch#InitSession ");
                            }
                            return true;
                        }
                        String scheme = uri.getScheme();
                        Intent intent2 = activity.getIntent();
                        if (scheme != null && intent2 != null && ((scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https")) && uri.getHost() != null && uri.getHost().length() > 0 && !m16482class(activity))) {
                            if (uri.toString().equalsIgnoreCase(lc5.m9581do(this.f41937goto).m9582if(uri.toString()))) {
                                this.f41931case.m14828protected("bnc_app_link", uri.toString());
                            }
                            intent2.putExtra(jb5.BranchLinkUsed.getKey(), true);
                            activity.setIntent(intent2);
                        }
                    } catch (Exception unused3) {
                    }
                }
            }
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:40:0x002b, code lost:
    
        r10 = null;
     */
    /* JADX WARN: Removed duplicated region for block: B:28:0x008e A[LOOP:0: B:9:0x0046->B:28:0x008e, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x008d A[SYNTHETIC] */
    /* renamed from: new, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean m16489new(org.json.JSONObject r10, android.content.pm.ActivityInfo r11) {
        /*
            r9 = this;
            jb5 r0 = defpackage.jb5.AndroidDeepLinkPath     // Catch: org.json.JSONException -> L2a
            java.lang.String r1 = r0.getKey()     // Catch: org.json.JSONException -> L2a
            boolean r1 = r10.has(r1)     // Catch: org.json.JSONException -> L2a
            if (r1 == 0) goto L15
            java.lang.String r0 = r0.getKey()     // Catch: org.json.JSONException -> L2a
            java.lang.String r10 = r10.getString(r0)     // Catch: org.json.JSONException -> L2a
            goto L2b
        L15:
            jb5 r0 = defpackage.jb5.DeepLinkPath     // Catch: org.json.JSONException -> L2a
            java.lang.String r1 = r0.getKey()     // Catch: org.json.JSONException -> L2a
            boolean r1 = r10.has(r1)     // Catch: org.json.JSONException -> L2a
            if (r1 == 0) goto L2a
            java.lang.String r0 = r0.getKey()     // Catch: org.json.JSONException -> L2a
            java.lang.String r10 = r10.getString(r0)     // Catch: org.json.JSONException -> L2a
            goto L2b
        L2a:
            r10 = 0
        L2b:
            android.os.Bundle r0 = r11.metaData
            java.lang.String r1 = "io.branch.sdk.auto_link_path"
            java.lang.String r0 = r0.getString(r1)
            r2 = 0
            if (r0 == 0) goto L91
            if (r10 == 0) goto L91
            android.os.Bundle r11 = r11.metaData
            java.lang.String r11 = r11.getString(r1)
            java.lang.String r0 = ","
            java.lang.String[] r11 = r11.split(r0)
            int r0 = r11.length
            r1 = r2
        L46:
            if (r1 >= r0) goto L91
            r3 = r11[r1]
            java.lang.String r3 = r3.trim()
            java.lang.String r4 = "\\?"
            java.lang.String[] r3 = r3.split(r4)
            r3 = r3[r2]
            java.lang.String r5 = "/"
            java.lang.String[] r3 = r3.split(r5)
            java.lang.String[] r4 = r10.split(r4)
            r4 = r4[r2]
            java.lang.String[] r4 = r4.split(r5)
            int r5 = r3.length
            int r6 = r4.length
            r7 = 1
            if (r5 == r6) goto L6c
            goto L85
        L6c:
            r5 = r2
        L6d:
            int r6 = r3.length
            if (r5 >= r6) goto L8a
            int r6 = r4.length
            if (r5 >= r6) goto L8a
            r6 = r3[r5]
            r8 = r4[r5]
            boolean r8 = r6.equals(r8)
            if (r8 != 0) goto L87
            java.lang.String r8 = "*"
            boolean r6 = r6.contains(r8)
            if (r6 != 0) goto L87
        L85:
            r3 = r2
            goto L8b
        L87:
            int r5 = r5 + 1
            goto L6d
        L8a:
            r3 = r7
        L8b:
            if (r3 == 0) goto L8e
            return r7
        L8e:
            int r1 = r1 + 1
            goto L46
        L91:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.wa5.m16489new(org.json.JSONObject, android.content.pm.ActivityInfo):boolean");
    }

    /* renamed from: super, reason: not valid java name */
    public void m16490super(int i, String str, String str2) {
        if (bc5.m1936public(str2)) {
            m16487if();
        }
    }

    /* renamed from: this, reason: not valid java name */
    public String m16491this() {
        String m14813const = this.f41931case.m14813const();
        if (m14813const.equals("bnc_no_value")) {
            return null;
        }
        return m14813const;
    }

    /* renamed from: throw, reason: not valid java name */
    public final void m16492throw() {
        if (this.f41942static.f20223do) {
            return;
        }
        WeakReference<Activity> weakReference = this.f41945throw;
        Activity activity = weakReference != null ? weakReference.get() : null;
        Context applicationContext = activity != null ? activity.getApplicationContext() : null;
        if (applicationContext != null) {
            dc5 dc5Var = this.f41930break;
            Objects.requireNonNull(dc5Var);
            synchronized (dc5.f8293if) {
                for (ub5 ub5Var : dc5Var.f8296try) {
                    if (ub5Var != null && (ub5Var instanceof bc5)) {
                        ub5Var.m15467do(ub5.b.STRONG_MATCH_PENDING_WAIT_LOCK);
                    }
                }
            }
            if (db5.f8250do == null) {
                db5.f8250do = new db5();
            }
            db5 db5Var = db5.f8250do;
            nb5 nb5Var = this.f41935else;
            tb5 tb5Var = this.f41931case;
            a aVar = new a();
            db5Var.f8258try = false;
            if (System.currentTimeMillis() - tb5Var.m14829public("bnc_branch_strong_match_time") < 2592000000L) {
                db5Var.m4333if(aVar, db5Var.f8258try);
                return;
            }
            if (!db5Var.f8256new) {
                db5Var.m4333if(aVar, db5Var.f8258try);
                return;
            }
            try {
                nb5Var.m10890if();
                Uri m4332do = db5Var.m4332do("app.link", nb5Var, tb5Var, applicationContext);
                if (m4332do != null) {
                    db5Var.f8253for.postDelayed(new bb5(db5Var, aVar), 500L);
                    Method method = db5Var.f8251case.getMethod("warmup", Long.TYPE);
                    Method method2 = db5Var.f8251case.getMethod("newSession", db5Var.f8252else);
                    Method method3 = db5Var.f8254goto.getMethod("mayLaunchUrl", Uri.class, Bundle.class, List.class);
                    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
                    intent.setPackage("com.android.chrome");
                    applicationContext.bindService(intent, new cb5(db5Var, method, method2, m4332do, method3, tb5Var, aVar), 33);
                } else {
                    db5Var.m4333if(aVar, db5Var.f8258try);
                }
            } catch (Throwable unused) {
                db5Var.m4333if(aVar, db5Var.f8258try);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x00fb, code lost:
    
        if (r8 != 4) goto L63;
     */
    /* JADX WARN: Removed duplicated region for block: B:27:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0139  */
    /* renamed from: try, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final org.json.JSONObject m16493try(java.lang.String r17) {
        /*
            Method dump skipped, instructions count: 321
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.wa5.m16493try(java.lang.String):org.json.JSONObject");
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x0064 A[Catch: Exception -> 0x00ab, TryCatch #0 {Exception -> 0x00ab, blocks: (B:2:0x0000, B:4:0x0009, B:6:0x0011, B:8:0x0021, B:12:0x002f, B:15:0x0037, B:17:0x0044, B:20:0x0056, B:25:0x0064, B:27:0x0071, B:31:0x0083, B:34:0x0090, B:36:0x005b, B:39:0x009b, B:42:0x009e, B:44:0x00a5), top: B:1:0x0000 }] */
    /* renamed from: while, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void m16494while() {
        /*
            r6 = this;
            java.util.concurrent.Semaphore r0 = r6.f41944this     // Catch: java.lang.Exception -> Lab
            r0.acquire()     // Catch: java.lang.Exception -> Lab
            int r0 = r6.f41932catch     // Catch: java.lang.Exception -> Lab
            if (r0 != 0) goto La5
            dc5 r0 = r6.f41930break     // Catch: java.lang.Exception -> Lab
            int r0 = r0.m4349for()     // Catch: java.lang.Exception -> Lab
            if (r0 <= 0) goto La5
            r0 = 1
            r6.f41932catch = r0     // Catch: java.lang.Exception -> Lab
            dc5 r1 = r6.f41930break     // Catch: java.lang.Exception -> Lab
            ub5 r1 = r1.m4354try()     // Catch: java.lang.Exception -> Lab
            java.util.concurrent.Semaphore r2 = r6.f41944this     // Catch: java.lang.Exception -> Lab
            r2.release()     // Catch: java.lang.Exception -> Lab
            if (r1 == 0) goto L9e
            java.util.Set<ub5$b> r2 = r1.f38684else     // Catch: java.lang.Exception -> Lab
            int r2 = r2.size()     // Catch: java.lang.Exception -> Lab
            r3 = 0
            if (r2 <= 0) goto L2c
            r2 = r0
            goto L2d
        L2c:
            r2 = r3
        L2d:
            if (r2 != 0) goto L9b
            boolean r2 = r1 instanceof defpackage.gc5     // Catch: java.lang.Exception -> Lab
            r4 = -101(0xffffffffffffff9b, float:NaN)
            java.lang.String r5 = "bnc_no_value"
            if (r2 != 0) goto L56
            tb5 r2 = r6.f41931case     // Catch: java.lang.Exception -> Lab
            java.lang.String r2 = r2.m14818final()     // Catch: java.lang.Exception -> Lab
            boolean r2 = r2.equals(r5)     // Catch: java.lang.Exception -> Lab
            r2 = r2 ^ r0
            if (r2 != 0) goto L56
            java.lang.String r1 = "Branch Error: User session has not been initialized!"
            defpackage.tb5.m14805do(r1)     // Catch: java.lang.Exception -> Lab
            r6.f41932catch = r3     // Catch: java.lang.Exception -> Lab
            dc5 r1 = r6.f41930break     // Catch: java.lang.Exception -> Lab
            int r1 = r1.m4349for()     // Catch: java.lang.Exception -> Lab
            int r1 = r1 - r0
            r6.m16480break(r1, r4)     // Catch: java.lang.Exception -> Lab
            goto Laf
        L56:
            boolean r2 = r1 instanceof defpackage.bc5     // Catch: java.lang.Exception -> Lab
            if (r2 == 0) goto L5b
            goto L5f
        L5b:
            boolean r2 = r1 instanceof defpackage.wb5     // Catch: java.lang.Exception -> Lab
            if (r2 == 0) goto L61
        L5f:
            r2 = r3
            goto L62
        L61:
            r2 = r0
        L62:
            if (r2 == 0) goto L90
            tb5 r2 = r6.f41931case     // Catch: java.lang.Exception -> Lab
            java.lang.String r2 = r2.m14836throws()     // Catch: java.lang.Exception -> Lab
            boolean r2 = r2.equals(r5)     // Catch: java.lang.Exception -> Lab
            r2 = r2 ^ r0
            if (r2 == 0) goto L80
            tb5 r2 = r6.f41931case     // Catch: java.lang.Exception -> Lab
            java.lang.String r2 = r2.m14812class()     // Catch: java.lang.Exception -> Lab
            boolean r2 = r2.equals(r5)     // Catch: java.lang.Exception -> Lab
            r2 = r2 ^ r0
            if (r2 == 0) goto L80
            r2 = r0
            goto L81
        L80:
            r2 = r3
        L81:
            if (r2 != 0) goto L90
            r6.f41932catch = r3     // Catch: java.lang.Exception -> Lab
            dc5 r1 = r6.f41930break     // Catch: java.lang.Exception -> Lab
            int r1 = r1.m4349for()     // Catch: java.lang.Exception -> Lab
            int r1 = r1 - r0
            r6.m16480break(r1, r4)     // Catch: java.lang.Exception -> Lab
            goto Laf
        L90:
            wa5$b r0 = new wa5$b     // Catch: java.lang.Exception -> Lab
            r0.<init>(r1)     // Catch: java.lang.Exception -> Lab
            java.lang.Void[] r1 = new java.lang.Void[r3]     // Catch: java.lang.Exception -> Lab
            r0.m17535do(r1)     // Catch: java.lang.Exception -> Lab
            goto Laf
        L9b:
            r6.f41932catch = r3     // Catch: java.lang.Exception -> Lab
            goto Laf
        L9e:
            dc5 r0 = r6.f41930break     // Catch: java.lang.Exception -> Lab
            r1 = 0
            r0.m4350goto(r1)     // Catch: java.lang.Exception -> Lab
            goto Laf
        La5:
            java.util.concurrent.Semaphore r0 = r6.f41944this     // Catch: java.lang.Exception -> Lab
            r0.release()     // Catch: java.lang.Exception -> Lab
            goto Laf
        Lab:
            r0 = move-exception
            r0.printStackTrace()
        Laf:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.wa5.m16494while():void");
    }
}
