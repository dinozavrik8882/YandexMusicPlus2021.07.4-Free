package defpackage;

/* loaded from: classes.dex */
public class ff0 {

    /* renamed from: do, reason: not valid java name */
    public static ff0 f11783do;
}
