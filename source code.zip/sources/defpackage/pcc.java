package defpackage;

import java.util.List;
import ru.yandex.music.search.center.remote.data.SuggestDto;

/* loaded from: classes2.dex */
public class pcc extends gka<List<SuggestDto>> {
    private static final long serialVersionUID = 1;
}
