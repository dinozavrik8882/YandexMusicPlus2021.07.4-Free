package defpackage;

import ru.yandex.music.R;

/* loaded from: classes2.dex */
public enum t1b {
    PLAYLISTS(R.drawable.ic_playlist, R.string.playlists, 20),
    TRACKS(R.drawable.ic_track, R.string.tracks, 20),
    ALBUMS(R.drawable.ic_album, R.string.albums, 20),
    ARTISTS(R.drawable.ic_artist, R.string.artists, 20),
    PODCASTS(R.drawable.ic_podcast, R.string.my_music_podcasts, 24),
    CACHED_TRACKS(R.drawable.ic_download, R.string.cached_tracks, 20),
    LOCAL_TRACKS(R.drawable.ic_local, R.string.local_tracks, 20),
    KIDS(R.drawable.ic_kid, R.string.kids_tab, 20);

    public final int iconRes;
    public final int sizeInDp;
    public final int titleRes;

    t1b(int i, int i2, int i3) {
        this.iconRes = i;
        this.titleRes = i2;
        this.sizeInDp = i3;
    }
}
