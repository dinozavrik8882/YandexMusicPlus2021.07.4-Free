package defpackage;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public class vm extends rn {

    /* renamed from: goto, reason: not valid java name */
    public static TimeInterpolator f40765goto;

    /* renamed from: this, reason: not valid java name */
    public ArrayList<RecyclerView.b0> f40774this = new ArrayList<>();

    /* renamed from: break, reason: not valid java name */
    public ArrayList<RecyclerView.b0> f40766break = new ArrayList<>();

    /* renamed from: catch, reason: not valid java name */
    public ArrayList<e> f40767catch = new ArrayList<>();

    /* renamed from: class, reason: not valid java name */
    public ArrayList<d> f40768class = new ArrayList<>();

    /* renamed from: const, reason: not valid java name */
    public ArrayList<ArrayList<RecyclerView.b0>> f40769const = new ArrayList<>();

    /* renamed from: final, reason: not valid java name */
    public ArrayList<ArrayList<e>> f40770final = new ArrayList<>();

    /* renamed from: super, reason: not valid java name */
    public ArrayList<ArrayList<d>> f40773super = new ArrayList<>();

    /* renamed from: throw, reason: not valid java name */
    public ArrayList<RecyclerView.b0> f40775throw = new ArrayList<>();

    /* renamed from: while, reason: not valid java name */
    public ArrayList<RecyclerView.b0> f40776while = new ArrayList<>();

    /* renamed from: import, reason: not valid java name */
    public ArrayList<RecyclerView.b0> f40771import = new ArrayList<>();

    /* renamed from: native, reason: not valid java name */
    public ArrayList<RecyclerView.b0> f40772native = new ArrayList<>();

    /* loaded from: classes.dex */
    public class a implements Runnable {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ ArrayList f40777catch;

        public a(ArrayList arrayList) {
            this.f40777catch = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f40777catch.iterator();
            while (it.hasNext()) {
                e eVar = (e) it.next();
                vm vmVar = vm.this;
                RecyclerView.b0 b0Var = eVar.f40789do;
                int i = eVar.f40791if;
                int i2 = eVar.f40790for;
                int i3 = eVar.f40792new;
                int i4 = eVar.f40793try;
                Objects.requireNonNull(vmVar);
                View view = b0Var.itemView;
                int i5 = i3 - i;
                int i6 = i4 - i2;
                if (i5 != 0) {
                    view.animate().translationX(0.0f);
                }
                if (i6 != 0) {
                    view.animate().translationY(0.0f);
                }
                ViewPropertyAnimator animate = view.animate();
                vmVar.f40776while.add(b0Var);
                animate.setDuration(vmVar.f1932try).setListener(new ym(vmVar, b0Var, i5, view, i6, animate)).start();
            }
            this.f40777catch.clear();
            vm.this.f40770final.remove(this.f40777catch);
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ ArrayList f40779catch;

        public b(ArrayList arrayList) {
            this.f40779catch = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f40779catch.iterator();
            while (it.hasNext()) {
                d dVar = (d) it.next();
                vm vmVar = vm.this;
                Objects.requireNonNull(vmVar);
                RecyclerView.b0 b0Var = dVar.f40784do;
                View view = b0Var == null ? null : b0Var.itemView;
                RecyclerView.b0 b0Var2 = dVar.f40786if;
                View view2 = b0Var2 != null ? b0Var2.itemView : null;
                if (view != null) {
                    ViewPropertyAnimator duration = view.animate().setDuration(vmVar.f1927case);
                    vmVar.f40772native.add(dVar.f40784do);
                    duration.translationX(dVar.f40788try - dVar.f40785for);
                    duration.translationY(dVar.f40783case - dVar.f40787new);
                    duration.alpha(0.0f).setListener(new zm(vmVar, dVar, duration, view)).start();
                }
                if (view2 != null) {
                    ViewPropertyAnimator animate = view2.animate();
                    vmVar.f40772native.add(dVar.f40786if);
                    animate.translationX(0.0f).translationY(0.0f).setDuration(vmVar.f1927case).alpha(1.0f).setListener(new an(vmVar, dVar, animate, view2)).start();
                }
            }
            this.f40779catch.clear();
            vm.this.f40773super.remove(this.f40779catch);
        }
    }

    /* loaded from: classes.dex */
    public class c implements Runnable {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ ArrayList f40781catch;

        public c(ArrayList arrayList) {
            this.f40781catch = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f40781catch.iterator();
            while (it.hasNext()) {
                RecyclerView.b0 b0Var = (RecyclerView.b0) it.next();
                vm vmVar = vm.this;
                Objects.requireNonNull(vmVar);
                View view = b0Var.itemView;
                ViewPropertyAnimator animate = view.animate();
                vmVar.f40775throw.add(b0Var);
                animate.alpha(1.0f).setDuration(vmVar.f1929for).setListener(new xm(vmVar, b0Var, view, animate)).start();
            }
            this.f40781catch.clear();
            vm.this.f40769const.remove(this.f40781catch);
        }
    }

    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: case, reason: not valid java name */
        public int f40783case;

        /* renamed from: do, reason: not valid java name */
        public RecyclerView.b0 f40784do;

        /* renamed from: for, reason: not valid java name */
        public int f40785for;

        /* renamed from: if, reason: not valid java name */
        public RecyclerView.b0 f40786if;

        /* renamed from: new, reason: not valid java name */
        public int f40787new;

        /* renamed from: try, reason: not valid java name */
        public int f40788try;

        public d(RecyclerView.b0 b0Var, RecyclerView.b0 b0Var2, int i, int i2, int i3, int i4) {
            this.f40784do = b0Var;
            this.f40786if = b0Var2;
            this.f40785for = i;
            this.f40787new = i2;
            this.f40788try = i3;
            this.f40783case = i4;
        }

        public String toString() {
            StringBuilder r = by.r("ChangeInfo{oldHolder=");
            r.append(this.f40784do);
            r.append(", newHolder=");
            r.append(this.f40786if);
            r.append(", fromX=");
            r.append(this.f40785for);
            r.append(", fromY=");
            r.append(this.f40787new);
            r.append(", toX=");
            r.append(this.f40788try);
            r.append(", toY=");
            return by.m2395instanceof(r, this.f40783case, '}');
        }
    }

    /* loaded from: classes.dex */
    public static class e {

        /* renamed from: do, reason: not valid java name */
        public RecyclerView.b0 f40789do;

        /* renamed from: for, reason: not valid java name */
        public int f40790for;

        /* renamed from: if, reason: not valid java name */
        public int f40791if;

        /* renamed from: new, reason: not valid java name */
        public int f40792new;

        /* renamed from: try, reason: not valid java name */
        public int f40793try;

        public e(RecyclerView.b0 b0Var, int i, int i2, int i3, int i4) {
            this.f40789do = b0Var;
            this.f40791if = i;
            this.f40790for = i2;
            this.f40792new = i3;
            this.f40793try = i4;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.j
    /* renamed from: break */
    public void mo1147break(RecyclerView.b0 b0Var) {
        View view = b0Var.itemView;
        view.animate().cancel();
        int size = this.f40767catch.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            if (this.f40767catch.get(size).f40789do == b0Var) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                mo13382return(b0Var);
                m1156goto(b0Var);
                this.f40767catch.remove(size);
            }
        }
        m16133default(this.f40768class, b0Var);
        if (this.f40774this.remove(b0Var)) {
            view.setAlpha(1.0f);
            m1156goto(b0Var);
        }
        if (this.f40766break.remove(b0Var)) {
            view.setAlpha(1.0f);
            m1156goto(b0Var);
        }
        int size2 = this.f40773super.size();
        while (true) {
            size2--;
            if (size2 < 0) {
                break;
            }
            ArrayList<d> arrayList = this.f40773super.get(size2);
            m16133default(arrayList, b0Var);
            if (arrayList.isEmpty()) {
                this.f40773super.remove(size2);
            }
        }
        int size3 = this.f40770final.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            ArrayList<e> arrayList2 = this.f40770final.get(size3);
            int size4 = arrayList2.size();
            while (true) {
                size4--;
                if (size4 < 0) {
                    break;
                }
                if (arrayList2.get(size4).f40789do == b0Var) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    mo13382return(b0Var);
                    m1156goto(b0Var);
                    arrayList2.remove(size4);
                    if (arrayList2.isEmpty()) {
                        this.f40770final.remove(size3);
                    }
                }
            }
        }
        int size5 = this.f40769const.size();
        while (true) {
            size5--;
            if (size5 < 0) {
                this.f40771import.remove(b0Var);
                this.f40775throw.remove(b0Var);
                this.f40772native.remove(b0Var);
                this.f40776while.remove(b0Var);
                m16137throws();
                return;
            }
            ArrayList<RecyclerView.b0> arrayList3 = this.f40769const.get(size5);
            if (arrayList3.remove(b0Var)) {
                view.setAlpha(1.0f);
                m1156goto(b0Var);
                if (arrayList3.isEmpty()) {
                    this.f40769const.remove(size5);
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.j
    /* renamed from: catch */
    public void mo1149catch() {
        int size = this.f40767catch.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            e eVar = this.f40767catch.get(size);
            View view = eVar.f40789do.itemView;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            RecyclerView.b0 b0Var = eVar.f40789do;
            mo13382return(b0Var);
            m1156goto(b0Var);
            this.f40767catch.remove(size);
        }
        int size2 = this.f40774this.size();
        while (true) {
            size2--;
            if (size2 < 0) {
                break;
            }
            m1156goto(this.f40774this.get(size2));
            this.f40774this.remove(size2);
        }
        int size3 = this.f40766break.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            RecyclerView.b0 b0Var2 = this.f40766break.get(size3);
            b0Var2.itemView.setAlpha(1.0f);
            m1156goto(b0Var2);
            this.f40766break.remove(size3);
        }
        int size4 = this.f40768class.size();
        while (true) {
            size4--;
            if (size4 < 0) {
                break;
            }
            d dVar = this.f40768class.get(size4);
            RecyclerView.b0 b0Var3 = dVar.f40784do;
            if (b0Var3 != null) {
                m16134extends(dVar, b0Var3);
            }
            RecyclerView.b0 b0Var4 = dVar.f40786if;
            if (b0Var4 != null) {
                m16134extends(dVar, b0Var4);
            }
        }
        this.f40768class.clear();
        if (!mo1150class()) {
            return;
        }
        int size5 = this.f40770final.size();
        while (true) {
            size5--;
            if (size5 < 0) {
                break;
            }
            ArrayList<e> arrayList = this.f40770final.get(size5);
            int size6 = arrayList.size();
            while (true) {
                size6--;
                if (size6 >= 0) {
                    e eVar2 = arrayList.get(size6);
                    View view2 = eVar2.f40789do.itemView;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    RecyclerView.b0 b0Var5 = eVar2.f40789do;
                    mo13382return(b0Var5);
                    m1156goto(b0Var5);
                    arrayList.remove(size6);
                    if (arrayList.isEmpty()) {
                        this.f40770final.remove(arrayList);
                    }
                }
            }
        }
        int size7 = this.f40769const.size();
        while (true) {
            size7--;
            if (size7 < 0) {
                break;
            }
            ArrayList<RecyclerView.b0> arrayList2 = this.f40769const.get(size7);
            int size8 = arrayList2.size();
            while (true) {
                size8--;
                if (size8 >= 0) {
                    RecyclerView.b0 b0Var6 = arrayList2.get(size8);
                    b0Var6.itemView.setAlpha(1.0f);
                    m1156goto(b0Var6);
                    arrayList2.remove(size8);
                    if (arrayList2.isEmpty()) {
                        this.f40769const.remove(arrayList2);
                    }
                }
            }
        }
        int size9 = this.f40773super.size();
        while (true) {
            size9--;
            if (size9 < 0) {
                m16136switch(this.f40771import);
                m16136switch(this.f40776while);
                m16136switch(this.f40775throw);
                m16136switch(this.f40772native);
                m1160this();
                return;
            }
            ArrayList<d> arrayList3 = this.f40773super.get(size9);
            int size10 = arrayList3.size();
            while (true) {
                size10--;
                if (size10 >= 0) {
                    d dVar2 = arrayList3.get(size10);
                    RecyclerView.b0 b0Var7 = dVar2.f40784do;
                    if (b0Var7 != null) {
                        m16134extends(dVar2, b0Var7);
                    }
                    RecyclerView.b0 b0Var8 = dVar2.f40786if;
                    if (b0Var8 != null) {
                        m16134extends(dVar2, b0Var8);
                    }
                    if (arrayList3.isEmpty()) {
                        this.f40773super.remove(arrayList3);
                    }
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.j
    /* renamed from: class */
    public boolean mo1150class() {
        return (this.f40766break.isEmpty() && this.f40768class.isEmpty() && this.f40767catch.isEmpty() && this.f40774this.isEmpty() && this.f40776while.isEmpty() && this.f40771import.isEmpty() && this.f40775throw.isEmpty() && this.f40772native.isEmpty() && this.f40770final.isEmpty() && this.f40769const.isEmpty() && this.f40773super.isEmpty()) ? false : true;
    }

    /* renamed from: default, reason: not valid java name */
    public final void m16133default(List<d> list, RecyclerView.b0 b0Var) {
        int size = list.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            }
            d dVar = list.get(size);
            if (m16134extends(dVar, b0Var) && dVar.f40784do == null && dVar.f40786if == null) {
                list.remove(dVar);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.j
    /* renamed from: else */
    public boolean mo1153else(RecyclerView.b0 b0Var, List<Object> list) {
        return !list.isEmpty() || mo1148case(b0Var);
    }

    /* renamed from: extends, reason: not valid java name */
    public final boolean m16134extends(d dVar, RecyclerView.b0 b0Var) {
        if (dVar.f40786if == b0Var) {
            dVar.f40786if = null;
        } else {
            if (dVar.f40784do != b0Var) {
                return false;
            }
            dVar.f40784do = null;
        }
        b0Var.itemView.setAlpha(1.0f);
        b0Var.itemView.setTranslationX(0.0f);
        b0Var.itemView.setTranslationY(0.0f);
        m1156goto(b0Var);
        return true;
    }

    /* renamed from: finally, reason: not valid java name */
    public final void m16135finally(RecyclerView.b0 b0Var) {
        if (f40765goto == null) {
            f40765goto = new ValueAnimator().getInterpolator();
        }
        b0Var.itemView.animate().setInterpolator(f40765goto);
        mo1147break(b0Var);
    }

    @Override // defpackage.rn
    /* renamed from: import */
    public boolean mo13379import(RecyclerView.b0 b0Var, int i, int i2, int i3, int i4) {
        View view = b0Var.itemView;
        int translationX = i + ((int) view.getTranslationX());
        int translationY = i2 + ((int) b0Var.itemView.getTranslationY());
        m16135finally(b0Var);
        int i5 = i3 - translationX;
        int i6 = i4 - translationY;
        if (i5 == 0 && i6 == 0) {
            mo13382return(b0Var);
            m1156goto(b0Var);
            return false;
        }
        if (i5 != 0) {
            view.setTranslationX(-i5);
        }
        if (i6 != 0) {
            view.setTranslationY(-i6);
        }
        this.f40767catch.add(new e(b0Var, translationX, translationY, i3, i4));
        return true;
    }

    @Override // defpackage.rn
    /* renamed from: native */
    public boolean mo13380native(RecyclerView.b0 b0Var) {
        m16135finally(b0Var);
        this.f40774this.add(b0Var);
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.j
    /* renamed from: super */
    public void mo1159super() {
        boolean z = !this.f40774this.isEmpty();
        boolean z2 = !this.f40767catch.isEmpty();
        boolean z3 = !this.f40768class.isEmpty();
        boolean z4 = !this.f40766break.isEmpty();
        if (z || z2 || z4 || z3) {
            Iterator<RecyclerView.b0> it = this.f40774this.iterator();
            while (it.hasNext()) {
                RecyclerView.b0 next = it.next();
                View view = next.itemView;
                ViewPropertyAnimator animate = view.animate();
                this.f40771import.add(next);
                animate.setDuration(this.f1931new).alpha(0.0f).setListener(new wm(this, next, animate, view)).start();
            }
            this.f40774this.clear();
            if (z2) {
                ArrayList<e> arrayList = new ArrayList<>();
                arrayList.addAll(this.f40767catch);
                this.f40770final.add(arrayList);
                this.f40767catch.clear();
                a aVar = new a(arrayList);
                if (z) {
                    View view2 = arrayList.get(0).f40789do.itemView;
                    long j = this.f1931new;
                    AtomicInteger atomicInteger = ze.f47083do;
                    view2.postOnAnimationDelayed(aVar, j);
                } else {
                    aVar.run();
                }
            }
            if (z3) {
                ArrayList<d> arrayList2 = new ArrayList<>();
                arrayList2.addAll(this.f40768class);
                this.f40773super.add(arrayList2);
                this.f40768class.clear();
                b bVar = new b(arrayList2);
                if (z) {
                    View view3 = arrayList2.get(0).f40784do.itemView;
                    long j2 = this.f1931new;
                    AtomicInteger atomicInteger2 = ze.f47083do;
                    view3.postOnAnimationDelayed(bVar, j2);
                } else {
                    bVar.run();
                }
            }
            if (z4) {
                ArrayList<RecyclerView.b0> arrayList3 = new ArrayList<>();
                arrayList3.addAll(this.f40766break);
                this.f40769const.add(arrayList3);
                this.f40766break.clear();
                c cVar = new c(arrayList3);
                if (!z && !z2 && !z3) {
                    cVar.run();
                    return;
                }
                long max = Math.max(z2 ? this.f1932try : 0L, z3 ? this.f1927case : 0L) + (z ? this.f1931new : 0L);
                View view4 = arrayList3.get(0).itemView;
                AtomicInteger atomicInteger3 = ze.f47083do;
                view4.postOnAnimationDelayed(cVar, max);
            }
        }
    }

    /* renamed from: switch, reason: not valid java name */
    public void m16136switch(List<RecyclerView.b0> list) {
        int size = list.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            } else {
                list.get(size).itemView.animate().cancel();
            }
        }
    }

    @Override // defpackage.rn
    /* renamed from: throw */
    public boolean mo13384throw(RecyclerView.b0 b0Var) {
        m16135finally(b0Var);
        b0Var.itemView.setAlpha(0.0f);
        this.f40766break.add(b0Var);
        return true;
    }

    /* renamed from: throws, reason: not valid java name */
    public void m16137throws() {
        if (mo1150class()) {
            return;
        }
        m1160this();
    }

    @Override // defpackage.rn
    /* renamed from: while */
    public boolean mo13385while(RecyclerView.b0 b0Var, RecyclerView.b0 b0Var2, int i, int i2, int i3, int i4) {
        if (b0Var == b0Var2) {
            return mo13379import(b0Var, i, i2, i3, i4);
        }
        float translationX = b0Var.itemView.getTranslationX();
        float translationY = b0Var.itemView.getTranslationY();
        float alpha = b0Var.itemView.getAlpha();
        m16135finally(b0Var);
        b0Var.itemView.setTranslationX(translationX);
        b0Var.itemView.setTranslationY(translationY);
        b0Var.itemView.setAlpha(alpha);
        m16135finally(b0Var2);
        b0Var2.itemView.setTranslationX(-((int) ((i3 - i) - translationX)));
        b0Var2.itemView.setTranslationY(-((int) ((i4 - i2) - translationY)));
        b0Var2.itemView.setAlpha(0.0f);
        this.f40768class.add(new d(b0Var, b0Var2, i, i2, i3, i4));
        return true;
    }
}
