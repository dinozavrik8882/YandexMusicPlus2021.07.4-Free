package defpackage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/* loaded from: classes2.dex */
public class p95 {

    /* renamed from: do, reason: not valid java name */
    public static final File f28676do = new File("/proc");

    /* renamed from: if, reason: not valid java name */
    public File f28677if;

    public p95(int i) {
        this.f28677if = new File(f28676do, Integer.toString(i));
    }

    /* renamed from: do, reason: not valid java name */
    public final String m11971do(String str) {
        try {
            FileReader fileReader = new FileReader(new File(this.f28677if, str));
            try {
                String readLine = new BufferedReader(fileReader).readLine();
                fileReader.close();
                return readLine;
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }
}
