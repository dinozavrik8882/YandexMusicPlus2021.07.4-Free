package defpackage;

/* loaded from: classes.dex */
public interface ph0 {
    /* renamed from: do, reason: not valid java name */
    void m12096do(float f, float f2);
}
