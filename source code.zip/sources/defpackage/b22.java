package defpackage;

/* loaded from: classes.dex */
public final class b22 implements f92 {

    /* renamed from: do, reason: not valid java name */
    public static final f92 f2811do = new b22();
}
