package defpackage;

import android.content.Context;
import defpackage.bz3;
import defpackage.n8a;
import defpackage.rfb;
import defpackage.y0d;
import java.util.LinkedHashSet;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.likes.CustomizableDislikeView;
import ru.yandex.music.likes.CustomizableLikeView;
import ru.yandex.music.player.view.RoundPlayButtonWithProgress;

/* loaded from: classes2.dex */
public final class rfb {

    /* renamed from: break, reason: not valid java name */
    public final y0d.a f32307break;

    /* renamed from: case, reason: not valid java name */
    public final oa8 f32308case;

    /* renamed from: catch, reason: not valid java name */
    public final vpe f32309catch;

    /* renamed from: do, reason: not valid java name */
    public final Context f32310do;

    /* renamed from: else, reason: not valid java name */
    public final t0f f32311else;

    /* renamed from: for, reason: not valid java name */
    public a f32312for;

    /* renamed from: goto, reason: not valid java name */
    public final t0f f32313goto;

    /* renamed from: if, reason: not valid java name */
    public u2 f32314if;

    /* renamed from: new, reason: not valid java name */
    public final v8a f32315new;

    /* renamed from: this, reason: not valid java name */
    public b f32316this;

    /* renamed from: try, reason: not valid java name */
    public final x0d f32317try;

    /* loaded from: classes2.dex */
    public interface a {
        void close();

        /* renamed from: do */
        void mo12062do();
    }

    /* loaded from: classes2.dex */
    public static abstract class b {

        /* loaded from: classes2.dex */
        public static final class a extends b {

            /* renamed from: do, reason: not valid java name */
            public final m64 f32318do;

            /* renamed from: if, reason: not valid java name */
            public final e69 f32319if;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public a(m64 m64Var, e69 e69Var) {
                super(null);
                jp5.m8570try(m64Var, "shot");
                jp5.m8570try(e69Var, "track");
                this.f32318do = m64Var;
                this.f32319if = e69Var;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof a)) {
                    return false;
                }
                a aVar = (a) obj;
                return jp5.m8563do(this.f32318do, aVar.f32318do) && jp5.m8563do(this.f32319if, aVar.f32319if);
            }

            public int hashCode() {
                return this.f32319if.hashCode() + (this.f32318do.hashCode() * 31);
            }

            public String toString() {
                StringBuilder r = by.r("ShotInfo(shot=");
                r.append(this.f32318do);
                r.append(", track=");
                r.append(this.f32319if);
                r.append(')');
                return r.toString();
            }
        }

        /* renamed from: rfb$b$b, reason: collision with other inner class name */
        /* loaded from: classes2.dex */
        public static final class C0265b extends b {

            /* renamed from: do, reason: not valid java name */
            public final m64 f32320do;

            /* renamed from: if, reason: not valid java name */
            public final e69 f32321if;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0265b(m64 m64Var, e69 e69Var) {
                super(null);
                jp5.m8570try(m64Var, "shot");
                jp5.m8570try(e69Var, "track");
                this.f32320do = m64Var;
                this.f32321if = e69Var;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof C0265b)) {
                    return false;
                }
                C0265b c0265b = (C0265b) obj;
                return jp5.m8563do(this.f32320do, c0265b.f32320do) && jp5.m8563do(this.f32321if, c0265b.f32321if);
            }

            public int hashCode() {
                return this.f32321if.hashCode() + (this.f32320do.hashCode() * 31);
            }

            public String toString() {
                StringBuilder r = by.r("ShotPlaying(shot=");
                r.append(this.f32320do);
                r.append(", track=");
                r.append(this.f32321if);
                r.append(')');
                return r.toString();
            }
        }

        /* loaded from: classes2.dex */
        public static final class c extends b {

            /* renamed from: do, reason: not valid java name */
            public final m64 f32322do;

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return (obj instanceof c) && jp5.m8563do(this.f32322do, ((c) obj).f32322do);
            }

            public int hashCode() {
                return this.f32322do.hashCode();
            }

            public String toString() {
                StringBuilder r = by.r("ShotPlayingWithoutAnyTrack(shot=");
                r.append(this.f32322do);
                r.append(')');
                return r.toString();
            }
        }

        /* loaded from: classes2.dex */
        public static final class d extends b {

            /* renamed from: do, reason: not valid java name */
            public static final d f32323do = new d();

            public d() {
                super(null);
            }
        }

        public b(ep5 ep5Var) {
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements mo5<n8a, pl5> {
        public c() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(n8a n8aVar) {
            n8a n8aVar2 = n8aVar;
            jp5.m8570try(n8aVar2, "it");
            v8a v8aVar = rfb.this.f32315new;
            Objects.requireNonNull(v8aVar);
            jp5.m8570try(n8aVar2, "view");
            v8aVar.f40272if = n8aVar2;
            n8aVar2.mo1783else(v8aVar.f40273new);
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends kp5 implements mo5<n8a, pl5> {
        public d() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(n8a n8aVar) {
            n8a n8aVar2 = n8aVar;
            jp5.m8570try(n8aVar2, "it");
            v8a v8aVar = rfb.this.f32315new;
            Objects.requireNonNull(v8aVar);
            jp5.m8570try(n8aVar2, "view");
            v8aVar.f40270for = n8aVar2;
            n8aVar2.mo1783else(v8aVar.f40274try);
            final rfb rfbVar = rfb.this;
            n8aVar2.mo1783else(new n8a.a() { // from class: lfb
                @Override // n8a.a
                /* renamed from: if, reason: not valid java name */
                public final void mo9644if() {
                    rfb rfbVar2 = rfb.this;
                    jp5.m8570try(rfbVar2, "this$0");
                    rfb.a aVar = rfbVar2.f32312for;
                    if (aVar == null) {
                        return;
                    }
                    aVar.mo12062do();
                }
            });
            return pl5.f29126do;
        }
    }

    /* loaded from: classes2.dex */
    public static final class e extends kp5 implements mo5<RoundPlayButtonWithProgress, pl5> {
        public e() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(RoundPlayButtonWithProgress roundPlayButtonWithProgress) {
            RoundPlayButtonWithProgress roundPlayButtonWithProgress2 = roundPlayButtonWithProgress;
            jp5.m8570try(roundPlayButtonWithProgress2, "button");
            y0d.a aVar = rfb.this.f32307break;
            jp5.m8570try(aVar, "listener");
            if (!roundPlayButtonWithProgress2.f33584while.contains(aVar)) {
                roundPlayButtonWithProgress2.f33584while.add(aVar);
            }
            rfb.this.f32317try.m16879do(roundPlayButtonWithProgress2);
            return pl5.f29126do;
        }
    }

    public rfb(Context context) {
        jp5.m8570try(context, "context");
        this.f32310do = context;
        this.f32315new = new v8a(null, 1);
        this.f32317try = new x0d(context);
        iz3 l3 = dn3.l3(oa8.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        this.f32308case = (oa8) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet);
        this.f32311else = new t0f();
        this.f32313goto = new t0f();
        this.f32316this = b.d.f32323do;
        this.f32307break = new y0d.a() { // from class: jfb
            @Override // y0d.a
            /* renamed from: if, reason: not valid java name */
            public final void mo8415if() {
                rfb rfbVar = rfb.this;
                jp5.m8570try(rfbVar, "this$0");
                if (rfbVar.f32308case.isPlaying()) {
                    return;
                }
                dn3.e0(qfb.f30537for.m17714static(), "Alice_Shot_Pause", null, 2);
            }
        };
        this.f32309catch = h0f.m6948do();
    }

    /* renamed from: do, reason: not valid java name */
    public final void m13260do(u2 u2Var) {
        jp5.m8570try(u2Var, "view");
        this.f32314if = u2Var;
        c cVar = new c();
        jp5.m8570try(cVar, "setUp");
        ey3 ey3Var = u2Var.f38250case;
        mr5<Object>[] mr5VarArr = u2.f38248do;
        cVar.invoke((CustomizableLikeView) ey3Var.m5520do(mr5VarArr[2]));
        d dVar = new d();
        jp5.m8570try(dVar, "setUp");
        dVar.invoke((CustomizableDislikeView) u2Var.f38251else.m5520do(mr5VarArr[3]));
        u2Var.m15341this(new e());
    }

    /* renamed from: if, reason: not valid java name */
    public final void m13261if(go8 go8Var) {
        b bVar;
        z68 z68Var;
        m64 m64Var;
        jp5.m8570try(go8Var, "queueEvent");
        q68 q68Var = go8Var.f13942case;
        q68 q68Var2 = go8Var.f13946else;
        boolean z = q68Var instanceof dr8;
        if (z && (q68Var2 instanceof z68)) {
            m64 m64Var2 = ((dr8) q68Var).f8963if;
            e69 e69Var = ((z68) q68Var2).f46759if;
            jp5.m8568new(e69Var, "pending.track");
            bVar = new b.C0265b(m64Var2, e69Var);
        } else if (!(q68Var instanceof z68) || (m64Var = (z68Var = (z68) q68Var).f46761try) == null) {
            by.N("ShotPresenter: shot's insertion conditions is violated", null, 2);
            if (z) {
                jp5.m8570try(((dr8) q68Var).f8963if, "shot");
            }
            bVar = b.d.f32323do;
        } else {
            jp5.m8565for(m64Var);
            jp5.m8568new(m64Var, "current.shot!!");
            e69 e69Var2 = z68Var.f46759if;
            jp5.m8568new(e69Var2, "current.track");
            bVar = new b.a(m64Var, e69Var2);
        }
        this.f32316this = bVar;
        if (bVar instanceof b.C0265b) {
            b.C0265b c0265b = (b.C0265b) bVar;
            m64 m64Var3 = c0265b.f32320do;
            e69 e69Var3 = c0265b.f32321if;
            u2 u2Var = this.f32314if;
            if (u2Var != null) {
                u2Var.m15342try(true);
            }
            u2 u2Var2 = this.f32314if;
            if (u2Var2 != null) {
                u2Var2.m15334break(true);
            }
            u2 u2Var3 = this.f32314if;
            if (u2Var3 != null) {
                String string = this.f32310do.getString(R.string.shot_screen_next);
                jp5.m8568new(string, "context.getString(tanker.R.string.shot_screen_next)");
                u2Var3.m15338goto(string);
            }
            u2 u2Var4 = this.f32314if;
            if (u2Var4 != null) {
                u2Var4.m15337for(m64Var3);
            }
            u2 u2Var5 = this.f32314if;
            if (u2Var5 != null) {
                u2Var5.m15340new(e69Var3);
            }
            u2 u2Var6 = this.f32314if;
            if (u2Var6 != null) {
                u2Var6.m15341this(new tfb(this));
            }
            u2 u2Var7 = this.f32314if;
            if (u2Var7 != null) {
                u2Var7.m15339if(new ufb(this));
            }
            this.f32315new.m15980do(c0265b.f32320do);
            return;
        }
        if (!(bVar instanceof b.a)) {
            if (!(bVar instanceof b.c)) {
                boolean z2 = bVar instanceof b.d;
                return;
            }
            b.c cVar = (b.c) bVar;
            m64 m64Var4 = cVar.f32322do;
            by.N("ShotPresenter: shot playing without next track is unsupported by UI", null, 2);
            u2 u2Var8 = this.f32314if;
            if (u2Var8 != null) {
                u2Var8.m15342try(true);
            }
            u2 u2Var9 = this.f32314if;
            if (u2Var9 != null) {
                u2Var9.m15334break(false);
            }
            u2 u2Var10 = this.f32314if;
            if (u2Var10 != null) {
                u2Var10.m15337for(m64Var4);
            }
            this.f32315new.m15980do(cVar.f32322do);
            return;
        }
        b.a aVar = (b.a) bVar;
        m64 m64Var5 = aVar.f32318do;
        e69 e69Var4 = aVar.f32319if;
        u2 u2Var11 = this.f32314if;
        if (u2Var11 != null) {
            u2Var11.m15342try(false);
        }
        u2 u2Var12 = this.f32314if;
        if (u2Var12 != null) {
            u2Var12.m15334break(false);
        }
        u2 u2Var13 = this.f32314if;
        if (u2Var13 != null) {
            String string2 = this.f32310do.getString(R.string.shot_screen_now_playing);
            jp5.m8568new(string2, "context.getString(tanker.R.string.shot_screen_now_playing)");
            u2Var13.m15338goto(string2);
        }
        u2 u2Var14 = this.f32314if;
        if (u2Var14 != null) {
            u2Var14.m15337for(m64Var5);
        }
        u2 u2Var15 = this.f32314if;
        if (u2Var15 != null) {
            u2Var15.m15340new(e69Var4);
        }
        final u2 u2Var16 = this.f32314if;
        if (u2Var16 != null) {
            this.f32313goto.m14551if(this.f32308case.mo10261catch().c(1).m14387implements(jqe.m8590do()).h(new tqe() { // from class: mfb
                @Override // defpackage.tqe
                public final void call(Object obj) {
                    u2 u2Var17 = u2.this;
                    jp5.m8570try(u2Var17, "$view");
                    e69 mo286new = ((go8) obj).f13942case.mo286new();
                    if (mo286new == null) {
                        return;
                    }
                    u2Var17.m15340new(mo286new);
                }
            }, ifb.f16727catch));
        }
        u2 u2Var17 = this.f32314if;
        if (u2Var17 != null) {
            u2Var17.m15339if(new sfb(this));
        }
        this.f32315new.m15980do(aVar.f32318do);
    }
}
