package defpackage;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

/* loaded from: classes.dex */
public class mc {

    /* renamed from: do, reason: not valid java name */
    public static final Object f23742do = new Object();

    /* loaded from: classes.dex */
    public static class a implements Executor {

        /* renamed from: catch, reason: not valid java name */
        public final Handler f23743catch;

        public a(Handler handler) {
            this.f23743catch = handler;
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            if (this.f23743catch.post(runnable)) {
                return;
            }
            throw new RejectedExecutionException(this.f23743catch + " is shutting down");
        }
    }

    /* renamed from: do, reason: not valid java name */
    public static int m10312do(Context context, String str) {
        if (str != null) {
            return context.checkPermission(str, Process.myPid(), Process.myUid());
        }
        throw new IllegalArgumentException("permission is null");
    }

    /* renamed from: if, reason: not valid java name */
    public static Executor m10313if(Context context) {
        return Build.VERSION.SDK_INT >= 28 ? context.getMainExecutor() : new a(new Handler(context.getMainLooper()));
    }
}
