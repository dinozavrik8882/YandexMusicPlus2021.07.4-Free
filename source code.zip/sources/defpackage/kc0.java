package defpackage;

/* loaded from: classes.dex */
public final class kc0 {
    /* renamed from: break, reason: not valid java name */
    public static void m8915break(ec0 ec0Var) {
        if (se0.m14224if(kc0.class)) {
            return;
        }
        try {
            int[] iArr = ec0Var.f9843if;
            int i = iArr[0];
            int i2 = iArr[1];
            float[] fArr = ec0Var.f9841do;
            for (int i3 = 0; i3 < i; i3++) {
                int i4 = i3 * i2;
                int i5 = i4 + i2;
                float f = Float.MIN_VALUE;
                float f2 = 0.0f;
                for (int i6 = i4; i6 < i5; i6++) {
                    if (fArr[i6] > f) {
                        f = fArr[i6];
                    }
                }
                for (int i7 = i4; i7 < i5; i7++) {
                    fArr[i7] = (float) Math.exp(fArr[i7] - f);
                }
                for (int i8 = i4; i8 < i5; i8++) {
                    f2 += fArr[i8];
                }
                while (i4 < i5) {
                    fArr[i4] = fArr[i4] / f2;
                    i4++;
                }
            }
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
        }
    }

    /* renamed from: case, reason: not valid java name */
    public static void m8916case(ec0 ec0Var, int i) {
        if (se0.m14224if(kc0.class)) {
            return;
        }
        try {
            if (i >= ec0Var.f9843if.length) {
                return;
            }
            int i2 = 1;
            int i3 = i;
            int i4 = 1;
            while (true) {
                int[] iArr = ec0Var.f9843if;
                if (i3 >= iArr.length) {
                    break;
                }
                i4 *= iArr[i3];
                i3++;
            }
            int i5 = i + 1;
            int[] iArr2 = new int[i5];
            for (int i6 = 0; i6 < i; i6++) {
                iArr2[i6] = ec0Var.f9843if[i6];
            }
            iArr2[i] = i4;
            ec0Var.f9843if = iArr2;
            for (int i7 = 0; i7 < i5; i7++) {
                i2 *= iArr2[i7];
            }
            float[] fArr = new float[i2];
            System.arraycopy(ec0Var.f9841do, 0, fArr, 0, Math.min(ec0Var.f9842for, i2));
            ec0Var.f9841do = fArr;
            ec0Var.f9842for = i2;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
        }
    }

    /* renamed from: catch, reason: not valid java name */
    public static ec0 m8917catch(ec0 ec0Var) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int[] iArr = ec0Var.f9843if;
            int i = iArr[0];
            int i2 = iArr[1];
            ec0 ec0Var2 = new ec0(new int[]{i2, i});
            float[] fArr = ec0Var.f9841do;
            float[] fArr2 = ec0Var2.f9841do;
            for (int i3 = 0; i3 < i; i3++) {
                for (int i4 = 0; i4 < i2; i4++) {
                    fArr2[(i4 * i) + i3] = fArr[(i3 * i2) + i4];
                }
            }
            return ec0Var2;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: class, reason: not valid java name */
    public static ec0 m8918class(ec0 ec0Var) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int[] iArr = ec0Var.f9843if;
            int i = iArr[0];
            int i2 = iArr[1];
            int i3 = iArr[2];
            ec0 ec0Var2 = new ec0(new int[]{i3, i2, i});
            float[] fArr = ec0Var.f9841do;
            float[] fArr2 = ec0Var2.f9841do;
            for (int i4 = 0; i4 < i; i4++) {
                for (int i5 = 0; i5 < i2; i5++) {
                    for (int i6 = 0; i6 < i3; i6++) {
                        fArr2[(i5 * i) + (i6 * i * i2) + i4] = fArr[(i5 * i3) + (i4 * i2 * i3) + i6];
                    }
                }
            }
            return ec0Var2;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public static void m8919do(ec0 ec0Var, ec0 ec0Var2) {
        if (se0.m14224if(kc0.class)) {
            return;
        }
        try {
            int[] iArr = ec0Var.f9843if;
            int i = iArr[0];
            int i2 = iArr[1];
            int i3 = iArr[2];
            float[] fArr = ec0Var.f9841do;
            float[] fArr2 = ec0Var2.f9841do;
            for (int i4 = 0; i4 < i; i4++) {
                for (int i5 = 0; i5 < i2; i5++) {
                    for (int i6 = 0; i6 < i3; i6++) {
                        int i7 = (i5 * i3) + (i4 * i2 * i3) + i6;
                        fArr[i7] = fArr[i7] + fArr2[i6];
                    }
                }
            }
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
        }
    }

    /* renamed from: else, reason: not valid java name */
    public static ec0 m8920else(ec0 ec0Var, int i) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int[] iArr = ec0Var.f9843if;
            int i2 = 0;
            int i3 = iArr[0];
            int i4 = iArr[1];
            int i5 = iArr[2];
            int i6 = (i4 - i) + 1;
            ec0 ec0Var2 = new ec0(new int[]{i3, i6, i5});
            float[] fArr = ec0Var.f9841do;
            float[] fArr2 = ec0Var2.f9841do;
            int i7 = 0;
            while (i7 < i3) {
                int i8 = i2;
                while (i8 < i5) {
                    int i9 = i2;
                    while (i9 < i6) {
                        int i10 = i9 * i5;
                        int i11 = (i7 * i6 * i5) + i10 + i8;
                        int i12 = (i7 * i4 * i5) + i10 + i8;
                        fArr2[i11] = Float.MIN_VALUE;
                        for (int i13 = i2; i13 < i; i13++) {
                            fArr2[i11] = Math.max(fArr2[i11], fArr[(i13 * i5) + i12]);
                        }
                        i9++;
                        i2 = 0;
                    }
                    i8++;
                    i2 = 0;
                }
                i7++;
                i2 = 0;
            }
            return ec0Var2;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: for, reason: not valid java name */
    public static ec0 m8921for(ec0 ec0Var, ec0 ec0Var2) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int[] iArr = ec0Var.f9843if;
            int i = 0;
            int i2 = iArr[0];
            int i3 = iArr[1];
            int i4 = iArr[2];
            int[] iArr2 = ec0Var2.f9843if;
            int i5 = iArr2[0];
            int i6 = (i3 - i5) + 1;
            int i7 = iArr2[2];
            ec0 ec0Var3 = new ec0(new int[]{i2, i6, i7});
            float[] fArr = ec0Var.f9841do;
            float[] fArr2 = ec0Var3.f9841do;
            float[] fArr3 = ec0Var2.f9841do;
            int i8 = 0;
            while (i8 < i2) {
                int i9 = i;
                while (i9 < i7) {
                    int i10 = i;
                    while (i10 < i6) {
                        float f = 0.0f;
                        while (i < i5) {
                            for (int i11 = 0; i11 < i4; i11++) {
                                f = (fArr[((i + i10) * i4) + (i3 * i4 * i8) + i11] * fArr3[(((i * i4) + i11) * i7) + i9]) + f;
                            }
                            i++;
                        }
                        fArr2[(i10 * i7) + (i6 * i7 * i8) + i9] = f;
                        i10++;
                        i = 0;
                    }
                    i9++;
                    i = 0;
                }
                i8++;
                i = 0;
            }
            return ec0Var3;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: goto, reason: not valid java name */
    public static ec0 m8922goto(ec0 ec0Var, ec0 ec0Var2) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int i = ec0Var.f9843if[0];
            int[] iArr = ec0Var2.f9843if;
            int i2 = iArr[0];
            int i3 = iArr[1];
            ec0 ec0Var3 = new ec0(new int[]{i, i3});
            float[] fArr = ec0Var.f9841do;
            float[] fArr2 = ec0Var2.f9841do;
            float[] fArr3 = ec0Var3.f9841do;
            for (int i4 = 0; i4 < i; i4++) {
                for (int i5 = 0; i5 < i3; i5++) {
                    int i6 = (i4 * i3) + i5;
                    fArr3[i6] = 0.0f;
                    for (int i7 = 0; i7 < i2; i7++) {
                        fArr3[i6] = (fArr[(i4 * i2) + i7] * fArr2[(i7 * i3) + i5]) + fArr3[i6];
                    }
                }
            }
            return ec0Var3;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: if, reason: not valid java name */
    public static ec0 m8923if(ec0[] ec0VarArr) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int i = ec0VarArr[0].f9843if[0];
            int i2 = 0;
            for (ec0 ec0Var : ec0VarArr) {
                i2 += ec0Var.f9843if[1];
            }
            ec0 ec0Var2 = new ec0(new int[]{i, i2});
            float[] fArr = ec0Var2.f9841do;
            for (int i3 = 0; i3 < i; i3++) {
                int i4 = i3 * i2;
                for (int i5 = 0; i5 < ec0VarArr.length; i5++) {
                    float[] fArr2 = ec0VarArr[i5].f9841do;
                    int i6 = ec0VarArr[i5].f9843if[1];
                    System.arraycopy(fArr2, i3 * i6, fArr, i4, i6);
                    i4 += i6;
                }
            }
            return ec0Var2;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: new, reason: not valid java name */
    public static ec0 m8924new(ec0 ec0Var, ec0 ec0Var2, ec0 ec0Var3) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int i = ec0Var.f9843if[0];
            int i2 = ec0Var3.f9843if[0];
            ec0 m8922goto = m8922goto(ec0Var, ec0Var2);
            float[] fArr = ec0Var3.f9841do;
            float[] fArr2 = m8922goto.f9841do;
            for (int i3 = 0; i3 < i; i3++) {
                for (int i4 = 0; i4 < i2; i4++) {
                    int i5 = (i3 * i2) + i4;
                    fArr2[i5] = fArr2[i5] + fArr[i4];
                }
            }
            return m8922goto;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }

    /* renamed from: this, reason: not valid java name */
    public static void m8925this(ec0 ec0Var) {
        if (se0.m14224if(kc0.class)) {
            return;
        }
        try {
            float[] fArr = ec0Var.f9841do;
            for (int i = 0; i < fArr.length; i++) {
                if (fArr[i] < 0.0f) {
                    fArr[i] = 0.0f;
                }
            }
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
        }
    }

    /* renamed from: try, reason: not valid java name */
    public static ec0 m8926try(String[] strArr, int i, ec0 ec0Var) {
        if (se0.m14224if(kc0.class)) {
            return null;
        }
        try {
            int length = strArr.length;
            int i2 = ec0Var.f9843if[1];
            ec0 ec0Var2 = new ec0(new int[]{length, i, i2});
            float[] fArr = ec0Var2.f9841do;
            float[] fArr2 = ec0Var.f9841do;
            for (int i3 = 0; i3 < length; i3++) {
                int[] m9567if = lc0.m9567if(strArr[i3], i);
                for (int i4 = 0; i4 < i; i4++) {
                    System.arraycopy(fArr2, m9567if[i4] * i2, fArr, (i2 * i4) + (i2 * i * i3), i2);
                }
            }
            return ec0Var2;
        } catch (Throwable th) {
            se0.m14223do(th, kc0.class);
            return null;
        }
    }
}
