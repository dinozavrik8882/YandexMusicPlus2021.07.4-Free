package defpackage;

/* loaded from: classes.dex */
public interface my2<ResultT> {
    /* renamed from: do */
    void mo2625do(dz2<ResultT> dz2Var);
}
