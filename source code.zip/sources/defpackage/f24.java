package defpackage;

import java.util.concurrent.TimeUnit;
import ru.yandex.video.player.impl.utils.LoadErrorHandlingPolicyImpl;

/* loaded from: classes.dex */
public final class f24 extends e04 {

    /* renamed from: for, reason: not valid java name */
    public static boolean f11037for;

    /* renamed from: if, reason: not valid java name */
    public static final f24 f11038if = new f24();

    /* loaded from: classes.dex */
    public enum a implements gvc {
        TotalDuration(35000),
        InitialRendering(1000),
        DataReceiving(30000),
        ViewModelConstruction(500),
        FinalRendering(LoadErrorHandlingPolicyImpl.DEFAULT_MAX_RETRY_DELAY_MS);

        private final long maxDuration;

        a(long j) {
            this.maxDuration = j;
        }

        @Override // defpackage.gvc
        public String getHistogramName() {
            return jp5.m8559break("Content.landing.", name());
        }

        @Override // defpackage.gvc
        public long getMaxDuration() {
            return this.maxDuration;
        }

        @Override // defpackage.gvc
        public long getMinDuration() {
            wuc.m16821try(this);
            return 0L;
        }

        @Override // defpackage.gvc
        public int getNumberOfBuckets() {
            wuc.m16805case(this);
            return 50;
        }

        @Override // defpackage.gvc
        public TimeUnit getTimeUnit() {
            wuc.m16810else(this);
            return TimeUnit.MILLISECONDS;
        }
    }

    /* renamed from: break, reason: not valid java name */
    public static final void m5571break() {
        f11038if.mo4479case(a.ViewModelConstruction);
    }

    /* renamed from: this, reason: not valid java name */
    public static final void m5572this() {
        f11038if.mo4873else(a.ViewModelConstruction);
    }

    @Override // defpackage.e04
    /* renamed from: goto */
    public boolean mo4874goto() {
        return !f11037for;
    }
}
