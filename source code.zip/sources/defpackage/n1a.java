package defpackage;

import java.util.Objects;

/* loaded from: classes2.dex */
public final class n1a {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f24889do;

    /* renamed from: case, reason: not valid java name */
    public final spe<ll5<qb8, ia8, ia8>> f24890case;

    /* renamed from: for, reason: not valid java name */
    public final el5 f24891for;

    /* renamed from: if, reason: not valid java name */
    public final mq5 f24892if = new a(null, null, this);

    /* renamed from: new, reason: not valid java name */
    public final t1a f24893new;

    /* renamed from: try, reason: not valid java name */
    public final k0f<ia8> f24894try;

    /* loaded from: classes2.dex */
    public static final class a extends lq5<w68> {

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ n1a f24895if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(Object obj, Object obj2, n1a n1aVar) {
            super(null);
            this.f24895if = n1aVar;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, w68 w68Var, w68 w68Var2) {
            jp5.m8570try(mr5Var, "property");
            this.f24895if.f24894try.mo1523case(new ia8(w68Var2));
        }
    }

    static {
        op5 op5Var = new op5(dq5.m4763do(n1a.class), "playbackQueue", "getPlaybackQueue()Lru/yandex/music/common/media/QueueDescriptor;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var = new wp5(dq5.m4763do(n1a.class), "playbackControl", "getPlaybackControl()Lru/yandex/music/common/media/control/PlaybackControl;");
        Objects.requireNonNull(eq5Var);
        f24889do = new mr5[]{op5Var, wp5Var};
    }

    public n1a() {
        iz3 l3 = dn3.l3(oa8.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        this.f24891for = new ez3(new cz3(l3)).m5533do(f24889do[1]);
        this.f24893new = new t1a();
        k0f<ia8> t = k0f.t(ia8.f16532do);
        this.f24894try = t;
        this.f24890case = spe.m14380this(m10705do().mo10262class(), m10705do().mo10281switch(), t, new are() { // from class: pz9
            @Override // defpackage.are
            /* renamed from: do */
            public final Object mo233do(Object obj, Object obj2, Object obj3) {
                return new ll5((qb8) obj, (ia8) obj2, (ia8) obj3);
            }
        });
    }

    /* renamed from: do, reason: not valid java name */
    public final oa8 m10705do() {
        return (oa8) this.f24891for.getValue();
    }

    /* renamed from: for, reason: not valid java name */
    public final boolean m10706for(w68 w68Var, w68 w68Var2) {
        if (w68Var != null) {
            w68 w68Var3 = sn8.f35685if;
            if (!jp5.m8563do(w68Var, w68Var3) && w68Var2 != null && !jp5.m8563do(w68Var2, w68Var3)) {
                t4c t4cVar = (t4c) w68Var.mo6207do(this.f24893new);
                if (!jp5.m8563do(t4cVar, t4c.f36587catch) && jp5.m8563do(t4cVar, w68Var2.mo6207do(this.f24893new))) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: if, reason: not valid java name */
    public final void m10707if(w68 w68Var) {
        this.f24892if.mo9879do(this, f24889do[0], w68Var);
    }
}
