package defpackage;

import android.content.Context;
import defpackage.ce9;
import defpackage.h59;
import defpackage.wa9;
import ru.yandex.music.R;
import ru.yandex.music.data.stores.CoverPath;

/* loaded from: classes2.dex */
public class ta9 extends wa9 {
    private static final long serialVersionUID = 8183017413482772548L;

    /* renamed from: catch, reason: not valid java name */
    public final h59 f36898catch;

    public ta9(h59 h59Var) {
        this.f36898catch = h59Var;
    }

    @Override // defpackage.wa9
    /* renamed from: case, reason: not valid java name */
    public CharSequence mo14748case() {
        return qd9.w(this.f36898catch);
    }

    @Override // defpackage.wa9
    /* renamed from: do, reason: not valid java name */
    public CharSequence mo14749do(Context context, wa9.b bVar) {
        int ordinal = bVar.ordinal();
        if (ordinal == 0) {
            return null;
        }
        if (ordinal == 1) {
            if (this.f36898catch.m7015case() != h59.a.PODCAST) {
                return this.f36898catch.f14709static;
            }
            return null;
        }
        if (ordinal != 2 && ordinal != 3) {
            throw new IllegalArgumentException("Illegal type " + bVar);
        }
        if (this.f36898catch.m7015case() != h59.a.SINGLE) {
            return this.f36898catch.f14709static;
        }
        return this.f36898catch.f14709static + context.getString(R.string.dot_divider) + context.getString(R.string.album_type_single);
    }

    @Override // defpackage.wa9
    /* renamed from: else, reason: not valid java name */
    public CharSequence mo14750else() {
        return this.f36898catch.f14711super;
    }

    @Override // defpackage.ae9
    /* renamed from: for */
    public CoverPath mo513for() {
        return this.f36898catch.f14704package;
    }

    @Override // defpackage.wa9
    /* renamed from: goto, reason: not valid java name */
    public wa9.a mo14751goto() {
        return wa9.a.ALBUM;
    }

    @Override // defpackage.wa9
    /* renamed from: if, reason: not valid java name */
    public CharSequence mo14752if() {
        return (this.f36898catch.m7014break() == h59.d.PODCAST || this.f36898catch.m7015case() == h59.a.PODCAST) ? h9d.m7088case(R.string.podcast) : h9d.m7088case(R.string.album);
    }

    @Override // defpackage.ae9
    /* renamed from: new */
    public ce9.a mo514new() {
        return this.f36898catch.mo514new();
    }

    @Override // defpackage.wa9
    /* renamed from: this, reason: not valid java name */
    public boolean mo14753this() {
        return this.f36898catch.f14707public == i69.EXPLICIT;
    }
}
