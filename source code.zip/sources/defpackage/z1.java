package defpackage;

import android.content.Context;
import defpackage.bz3;
import defpackage.j94;
import defpackage.l56;
import defpackage.lc4;
import defpackage.me4;
import defpackage.z1;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class z1 {

    /* renamed from: do, reason: not valid java name */
    public static final b f46453do;

    /* renamed from: if, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f46454if;

    /* renamed from: break, reason: not valid java name */
    public final sf4 f46455break;

    /* renamed from: case, reason: not valid java name */
    public final el5 f46456case;

    /* renamed from: else, reason: not valid java name */
    public final p84 f46457else;

    /* renamed from: for, reason: not valid java name */
    public final el5 f46458for;

    /* renamed from: goto, reason: not valid java name */
    public final d36 f46459goto;

    /* renamed from: new, reason: not valid java name */
    public final qo5<l56.a, l56, pl5> f46460new;

    /* renamed from: this, reason: not valid java name */
    public final k0f<nd4> f46461this;

    /* renamed from: try, reason: not valid java name */
    public final el5 f46462try;

    /* loaded from: classes.dex */
    public static final class a extends kp5 implements mo5<String, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f46463catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ Object f46464class;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(int i, Object obj) {
            super(1);
            this.f46463catch = i;
            this.f46464class = obj;
        }

        @Override // defpackage.mo5
        public final pl5 invoke(String str) {
            int i = this.f46463catch;
            if (i != 0) {
                if (i != 1) {
                    throw null;
                }
                ((z1) this.f46464class).f46457else.f28580do = null;
                return pl5.f29126do;
            }
            p84 p84Var = ((z1) this.f46464class).f46457else;
            p84Var.f28580do = null;
            p84Var.f28582if = null;
            p84Var.f28581for = null;
            p84Var.f28583new = null;
            z1 z1Var = (z1) this.f46464class;
            Objects.requireNonNull(z1Var);
            dn3.e1(dn3.m4670try(kv4.f21091if), null, null, new o84(z1Var, null), 3, null);
            ((z1) this.f46464class).m17801catch();
            return pl5.f29126do;
        }
    }

    /* loaded from: classes.dex */
    public static final class b {
        public b(ep5 ep5Var) {
        }

        /* renamed from: do, reason: not valid java name */
        public final boolean m17808do(String str) {
            return jp5.m8563do(str, "ru.yandex.mobile.music.1month.autorenewable.family.native.app.notrial") || jp5.m8563do(str, "uz.yandex.mobile.music.native.1month.autorenewable.3month.intro.599uzs.kinopoisk_plus.family.24999uzs");
        }
    }

    /* loaded from: classes.dex */
    public static final class c {

        /* renamed from: do, reason: not valid java name */
        public final sg4 f46465do;

        public c(sg4 sg4Var) {
            jp5.m8570try(sg4Var, "pay");
            this.f46465do = sg4Var;
        }
    }

    @ln5(c = "com.yandex.music.model.payment.Billing$accountEmail$2", f = "Billing.kt", l = {}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class d extends pn5 implements qo5<gu5, wm5<? super String>, Object> {
        public d(wm5<? super d> wm5Var) {
            super(2, wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            return new d(wm5Var);
        }

        @Override // defpackage.qo5
        public Object invoke(gu5 gu5Var, wm5<? super String> wm5Var) {
            wm5<? super String> wm5Var2 = wm5Var;
            z1 z1Var = z1.this;
            if (wm5Var2 != null) {
                wm5Var2.getContext();
            }
            pl5 pl5Var = pl5.f29126do;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(pl5Var);
            String str = z1Var.f46457else.f28582if;
            if (str != null) {
                return str;
            }
            String mo8305case = z1Var.m17807try().mo8305case();
            z1Var.f46457else.f28582if = mo8305case;
            return mo8305case;
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(obj);
            String str = z1.this.f46457else.f28582if;
            if (str != null) {
                return str;
            }
            String mo8305case = z1.this.m17807try().mo8305case();
            z1.this.f46457else.f28582if = mo8305case;
            return mo8305case;
        }
    }

    @ln5(c = "com.yandex.music.model.payment.Billing$accountStatus$2", f = "Billing.kt", l = {}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class e extends pn5 implements qo5<gu5, wm5<? super nd4>, Object> {

        /* renamed from: super, reason: not valid java name */
        public final /* synthetic */ boolean f46467super;

        /* renamed from: throw, reason: not valid java name */
        public final /* synthetic */ z1 f46468throw;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(boolean z, z1 z1Var, wm5<? super e> wm5Var) {
            super(2, wm5Var);
            this.f46467super = z;
            this.f46468throw = z1Var;
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            return new e(this.f46467super, this.f46468throw, wm5Var);
        }

        @Override // defpackage.qo5
        public Object invoke(gu5 gu5Var, wm5<? super nd4> wm5Var) {
            nd4 nd4Var;
            wm5<? super nd4> wm5Var2 = wm5Var;
            boolean z = this.f46467super;
            z1 z1Var = this.f46468throw;
            if (wm5Var2 != null) {
                wm5Var2.getContext();
            }
            pl5 pl5Var = pl5.f29126do;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(pl5Var);
            if (!z && (nd4Var = z1Var.f46457else.f28581for) != null) {
                return nd4Var;
            }
            if (z) {
                z1Var.f46457else.m11927do();
            }
            b bVar = z1.f46453do;
            nd4 mo8309do = z1Var.m17807try().mo8309do();
            z1Var.f46457else.f28581for = mo8309do;
            z1Var.f46461this.mo1523case(mo8309do);
            return mo8309do;
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            nd4 nd4Var;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(obj);
            if (!this.f46467super && (nd4Var = this.f46468throw.f46457else.f28581for) != null) {
                return nd4Var;
            }
            if (this.f46467super) {
                this.f46468throw.f46457else.m11927do();
            }
            z1 z1Var = this.f46468throw;
            b bVar = z1.f46453do;
            nd4 mo8309do = z1Var.m17807try().mo8309do();
            z1 z1Var2 = this.f46468throw;
            z1Var2.f46457else.f28581for = mo8309do;
            z1Var2.f46461this.mo1523case(mo8309do);
            return mo8309do;
        }
    }

    /* loaded from: classes.dex */
    public static final class f extends kp5 implements bo5<jd4> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ Context f46469catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ c94 f46470class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ String f46471const;

        /* renamed from: final, reason: not valid java name */
        public final /* synthetic */ z1 f46472final;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(Context context, c94 c94Var, String str, z1 z1Var) {
            super(0);
            this.f46469catch = context;
            this.f46470class = c94Var;
            this.f46471const = str;
            this.f46472final = z1Var;
        }

        @Override // defpackage.bo5
        public jd4 invoke() {
            boolean z;
            String str;
            Context context = this.f46469catch;
            String str2 = jp5.m8563do("gplay", "yauto") ? "YandexMusicAuto" : nc4.m10897do() ? "YandexMusicAndroidSamsung" : "YandexMusicAndroid";
            String str3 = this.f46470class.f4989new;
            String str4 = str3 == null ? "" : str3;
            e84 e84Var = new e84(this.f46470class);
            jp5.m8570try(context, "context");
            jp5.m8570try(str2, "clientId");
            jp5.m8570try(str4, "serviceToken");
            jp5.m8570try(e84Var, "authInfoProvider");
            jp5.m8570try(context, "context");
            jp5.m8570try(str2, "clientId");
            jp5.m8570try(str4, "serviceId");
            jp5.m8570try(e84Var, "authInfoProvider");
            if (nc4.m10897do()) {
                z = false;
                str = "";
            } else {
                String str5 = this.f46471const;
                jp5.m8570try(str5, "googleStorePublicKey");
                z = true;
                str = str5;
            }
            b84 b84Var = new b84();
            jp5.m8570try(b84Var, "logger");
            z1 z1Var = this.f46472final;
            String m18233do = z1Var.m17805new().m18233do(a74.class);
            if (m18233do == null) {
                m18233do = a74.PROD.getUrl();
            }
            String m18233do2 = z1Var.m17805new().m18233do(h74.class);
            if (m18233do2 == null) {
                m18233do2 = h74.PROD.getUrl();
            }
            String m18233do3 = z1Var.m17805new().m18233do(j74.class);
            if (m18233do3 == null) {
                m18233do3 = j74.PROD.getUrl();
            }
            me4.b bVar = new me4.b(m18233do, m18233do2, m18233do3);
            Objects.requireNonNull(this.f46472final);
            je4 je4Var = new je4(bVar, null, null, null, this.f46472final.f46460new);
            jp5.m8570try(je4Var, "debugNetworkConfig");
            c84 c84Var = new c84();
            jp5.m8570try(c84Var, "receiver");
            d84 d84Var = new d84(this.f46470class);
            jp5.m8570try(d84Var, "provider");
            String str6 = this.f46470class.f4990try;
            String str7 = str6 != null ? str6 : "";
            jp5.m8570try(str7, "clid");
            yg4.f45495do = b84Var;
            return new wg4(context, str2, str7, str4, e84Var, z, je4Var, str, c84Var, d84Var);
        }
    }

    /* loaded from: classes.dex */
    public static final class g extends kp5 implements qo5<l56.a, l56, pl5> {
        public g() {
            super(2);
        }

        @Override // defpackage.qo5
        public pl5 invoke(l56.a aVar, l56 l56Var) {
            l56.a aVar2 = aVar;
            l56 l56Var2 = l56Var;
            jp5.m8570try(aVar2, "builder");
            jp5.m8570try(l56Var2, "request");
            dn3.m4664switch(aVar2, z1.this.m17805new(), l56Var2);
            return pl5.f29126do;
        }
    }

    /* loaded from: classes.dex */
    public static final class h extends kp5 implements bo5<c> {
        public h() {
            super(0);
        }

        @Override // defpackage.bo5
        public c invoke() {
            return new c(z1.this.m17807try().mo8304break());
        }
    }

    @ln5(c = "com.yandex.music.model.payment.Billing$status$2", f = "Billing.kt", l = {}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class i extends pn5 implements qo5<gu5, wm5<? super fg4>, Object> {

        /* renamed from: super, reason: not valid java name */
        public final /* synthetic */ boolean f46475super;

        /* renamed from: throw, reason: not valid java name */
        public final /* synthetic */ z1 f46476throw;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(boolean z, z1 z1Var, wm5<? super i> wm5Var) {
            super(2, wm5Var);
            this.f46475super = z;
            this.f46476throw = z1Var;
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            return new i(this.f46475super, this.f46476throw, wm5Var);
        }

        @Override // defpackage.qo5
        public Object invoke(gu5 gu5Var, wm5<? super fg4> wm5Var) {
            fg4 fg4Var;
            wm5<? super fg4> wm5Var2 = wm5Var;
            boolean z = this.f46475super;
            z1 z1Var = this.f46476throw;
            if (wm5Var2 != null) {
                wm5Var2.getContext();
            }
            pl5 pl5Var = pl5.f29126do;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(pl5Var);
            if (!z && (fg4Var = z1Var.f46457else.f28583new) != null) {
                return fg4Var;
            }
            if (z) {
                z1Var.f46457else.m11927do();
            }
            b bVar = z1.f46453do;
            fg4 mo8326while = z1Var.m17807try().mo8326while();
            z1Var.f46457else.f28583new = mo8326while;
            return mo8326while;
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            fg4 fg4Var;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(obj);
            if (!this.f46475super && (fg4Var = this.f46476throw.f46457else.f28583new) != null) {
                return fg4Var;
            }
            if (this.f46475super) {
                this.f46476throw.f46457else.m11927do();
            }
            z1 z1Var = this.f46476throw;
            b bVar = z1.f46453do;
            fg4 mo8326while = z1Var.m17807try().mo8326while();
            this.f46476throw.f46457else.f28583new = mo8326while;
            return mo8326while;
        }
    }

    @ln5(c = "com.yandex.music.model.payment.Billing$updateStatus$1", f = "Billing.kt", l = {331}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class j extends pn5 implements qo5<gu5, wm5<? super pl5>, Object> {

        /* renamed from: super, reason: not valid java name */
        public int f46477super;

        public j(wm5<? super j> wm5Var) {
            super(2, wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            return new j(wm5Var);
        }

        @Override // defpackage.qo5
        public Object invoke(gu5 gu5Var, wm5<? super pl5> wm5Var) {
            return new j(wm5Var).mo76return(pl5.f29126do);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            int i = this.f46477super;
            try {
                if (i == 0) {
                    dn3.N2(obj);
                    z1 z1Var = z1.this;
                    this.f46477super = 1;
                    if (z1Var.m17803for(true, this) == cn5Var) {
                        return cn5Var;
                    }
                } else {
                    if (i != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    dn3.N2(obj);
                }
            } catch (ud4 unused) {
            }
            return pl5.f29126do;
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[3];
        wp5 wp5Var = new wp5(dq5.m4763do(z1.class), "buildInfo", "getBuildInfo()Lcom/yandex/music/core/build/BuildInfo;");
        Objects.requireNonNull(dq5.f8909do);
        mr5VarArr[0] = wp5Var;
        f46454if = mr5VarArr;
        f46453do = new b(null);
    }

    public z1(Context context, c94 c94Var, String str) {
        jp5.m8570try(context, "context");
        jp5.m8570try(c94Var, "tokenStore");
        jp5.m8570try(str, "googleKey");
        iz3 l3 = dn3.l3(zs3.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        jp5.m8570try(f46454if[0], "prop");
        this.f46458for = dn3.h1(cz3Var);
        this.f46460new = new g();
        this.f46462try = dn3.h1(new h());
        this.f46456case = dn3.h1(new f(context, c94Var, str, this));
        this.f46457else = new p84();
        this.f46459goto = h36.m6987do(false, 1);
        this.f46461this = k0f.s();
        String[] strArr = {"ru.yandex.mobile.music.1month.autorenewable.native.app.notrial.restricted.cache.99.music", "ru.yandex.mobile.music.1month.autorenewable.family.native.app.notrial", "uz.yandex.mobile.music.native.1month.autorenewable.3month.intro.599uzs.kinopoisk_plus.family.24999uzs"};
        jp5.m8570try(strArr, "ids");
        this.f46455break = new sf4(false, false, strArr, null);
        spe<lc4.e> m14384extends = lc4.f21917catch.m9576case().m14384extends(new yqe() { // from class: r74
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                z1.b bVar = z1.f46453do;
                return Boolean.valueOf(((lc4.e) obj).f21930for);
            }
        });
        iz3 l32 = dn3.l3(j94.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        jp5.m8570try(l32, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var2.f4528if ? new LinkedHashSet() : null;
        spe m14403while = spe.m14371break(((j94) bz3Var2.m2426new(l32, linkedHashSet != null ? new bz3.a(bz3Var2, linkedHashSet) : bz3Var2.f4529new, linkedHashSet)).mo8228if().m14384extends(new yqe() { // from class: s74
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                z1.b bVar = z1.f46453do;
                return Boolean.valueOf(((j94.a) obj).f18261if);
            }
        }).m14403while(), m14384extends, new zqe() { // from class: o74
            @Override // defpackage.zqe
            /* renamed from: do */
            public final Object mo571do(Object obj, Object obj2) {
                z1.b bVar = z1.f46453do;
                return ((j94.a) obj).f18260do;
            }
        }).m14403while();
        jp5.m8568new(m14403while, "combineLatest(\n            userChangeObservable,\n            foregroundObservable\n        ) { user, _ -> user.id }\n            .distinctUntilChanged()");
        dn3.r2(m14403while, new a(0, this));
        iz3 l33 = dn3.l3(j94.class);
        jp5.m8570try(l33, "typeSpec");
        bz3 bz3Var3 = bz3.f4526do;
        jp5.m8565for(bz3Var3);
        jp5.m8570try(l33, "typeSpec");
        LinkedHashSet linkedHashSet2 = bz3Var3.f4528if ? new LinkedHashSet() : null;
        spe<R> k = ((j94) bz3Var3.m2426new(l33, linkedHashSet2 != null ? new bz3.a(bz3Var3, linkedHashSet2) : bz3Var3.f4529new, linkedHashSet2)).mo8228if().m14388import(new yqe() { // from class: m74
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                z1.b bVar = z1.f46453do;
                return ((j94.a) obj).f18260do;
            }
        }).k(new yqe() { // from class: t74
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                z1.b bVar = z1.f46453do;
                if (!((j94.a) obj).f18261if) {
                    return tre.instance();
                }
                iz3 l34 = dn3.l3(v14.class);
                jp5.m8570try(l34, "typeSpec");
                bz3 bz3Var4 = bz3.f4526do;
                jp5.m8565for(bz3Var4);
                jp5.m8570try(l34, "typeSpec");
                LinkedHashSet linkedHashSet3 = bz3Var4.f4528if ? new LinkedHashSet() : null;
                Object value = ((s84) ((v14) bz3Var4.m2426new(l34, linkedHashSet3 != null ? new bz3.a(bz3Var4, linkedHashSet3) : bz3Var4.f4529new, linkedHashSet3)).m15853do(dq5.m4763do(s84.class))).f35126goto.getValue();
                jp5.m8568new(value, "<get-targetSubject>(...)");
                spe m14403while2 = ((k0f) value).m14401try().m14403while();
                jp5.m8568new(m14403while2, "experiment.targetSubject.asObservable().distinctUntilChanged()");
                return m14403while2;
            }
        });
        jp5.m8568new(k, "Di.instance<UserProvider>()\n            .observe()\n            .distinctUntilChanged { user -> user.id }\n            .switchMap {\n                if (it.authorized) {\n                    BillingProductsTargetExperiment.updates()\n                } else {\n                    Observable.empty()\n                }\n            }");
        dn3.r2(k, new a(1, this));
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x00dd A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00b3 A[SYNTHETIC] */
    /* renamed from: do, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.util.List m17797do(defpackage.z1 r12) {
        /*
            Method dump skipped, instructions count: 508
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.z1.m17797do(z1):java.util.List");
    }

    /* renamed from: goto, reason: not valid java name */
    public static Object m17798goto(z1 z1Var, boolean z, wm5 wm5Var, int i2) {
        if ((i2 & 1) != 0) {
            z = false;
        }
        Objects.requireNonNull(z1Var);
        return dn3.F3(kv4.f21091if, new j84(z1Var, z, null), wm5Var);
    }

    /* renamed from: break, reason: not valid java name */
    public final Object m17799break(boolean z, wm5<? super fg4> wm5Var) {
        return dn3.F3(kv4.f21091if, new i(z, this, null), wm5Var);
    }

    /* renamed from: case, reason: not valid java name */
    public final String m17800case() {
        iz3 l3 = dn3.l3(v14.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        return ((s84) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(s84.class))).m14160else();
    }

    /* renamed from: catch, reason: not valid java name */
    public final void m17801catch() {
        dn3.e1(dn3.m4670try(kv4.f21091if), null, null, new j(null), 3, null);
    }

    /* renamed from: else, reason: not valid java name */
    public final c m17802else() {
        return (c) this.f46462try.getValue();
    }

    /* renamed from: for, reason: not valid java name */
    public final Object m17803for(boolean z, wm5<? super nd4> wm5Var) {
        return dn3.F3(kv4.f21091if, new e(z, this, null), wm5Var);
    }

    /* renamed from: if, reason: not valid java name */
    public final Object m17804if(wm5<? super String> wm5Var) {
        return dn3.F3(kv4.f21091if, new d(null), wm5Var);
    }

    /* renamed from: new, reason: not valid java name */
    public final zs3 m17805new() {
        return (zs3) this.f46458for.getValue();
    }

    /* renamed from: this, reason: not valid java name */
    public final ape m17806this(final String str) {
        jp5.m8570try(str, "number");
        Callable callable = new Callable() { // from class: q74
            @Override // java.util.concurrent.Callable
            public final Object call() {
                z1 z1Var = z1.this;
                String str2 = str;
                jp5.m8570try(z1Var, "this$0");
                jp5.m8570try(str2, "$number");
                z1Var.m17807try().mo8310else(str2);
                return pl5.f29126do;
            }
        };
        ape apeVar = ape.f2353do;
        ape m1412for = ape.m1412for(new npe(callable));
        jp5.m8568new(m1412for, "fromCallable { client.registerPhone(number) }");
        return m1412for;
    }

    /* renamed from: try, reason: not valid java name */
    public final jd4 m17807try() {
        return (jd4) this.f46456case.getValue();
    }
}
