package defpackage;

import defpackage.uh4;

/* loaded from: classes.dex */
public final class ji4 extends kp5 implements qo5<uh4.a<pl5>, vh4, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ xf4 f18672catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ji4(xf4 xf4Var) {
        super(2);
        this.f18672catch = xf4Var;
    }

    @Override // defpackage.qo5
    public pl5 invoke(uh4.a<pl5> aVar, vh4 vh4Var) {
        uh4.a<pl5> aVar2 = aVar;
        vh4 vh4Var2 = vh4Var;
        jp5.m8570try(aVar2, "$this$execute");
        jp5.m8570try(vh4Var2, "client");
        String str = this.f18672catch.f43745super;
        ii4 ii4Var = new ii4(aVar2);
        jp5.m8570try(str, "purchaseToken");
        jp5.m8570try(ii4Var, "listener");
        lw lwVar = vh4Var2.f40595do;
        qw qwVar = new qw(null);
        qwVar.f31426do = str;
        qh4 qh4Var = new qh4(ii4Var);
        mw mwVar = (mw) lwVar;
        if (!mwVar.mo10016do()) {
            qh4Var.m12732do(fx.f12682const, qwVar.f31426do);
        } else if (mwVar.m10630case(new px(mwVar, qwVar, qh4Var), 30000L, new ox(qh4Var, qwVar)) == null) {
            qh4Var.m12732do(mwVar.m10632goto(), qwVar.f31426do);
        }
        return pl5.f29126do;
    }
}
