package defpackage;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.bz3;
import defpackage.t2b;
import defpackage.t5d;
import defpackage.v09;
import defpackage.z2b;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.catalog.album.AlbumActivity;
import ru.yandex.music.common.media.context.Page;
import ru.yandex.music.common.media.context.PlaybackScope;
import ru.yandex.music.kids.KidsCatalogActivity;
import ru.yandex.music.novelties.podcasts.PodcastsActivity;
import ru.yandex.music.novelties.podcasts.catalog.PodcastsCatalogActivity;
import ru.yandex.music.url.ui.UrlActivity;

/* loaded from: classes2.dex */
public final class j9b extends o58<Cursor, h59, bt6, o9b, b0b> {

    /* renamed from: package, reason: not valid java name */
    public static final a f18275package;

    /* renamed from: private, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f18276private;

    /* renamed from: abstract, reason: not valid java name */
    public final el5 f18277abstract;

    /* renamed from: continue, reason: not valid java name */
    public final el5 f18278continue;

    /* renamed from: implements, reason: not valid java name */
    public final b0b f18279implements;

    /* renamed from: interface, reason: not valid java name */
    public boolean f18280interface;

    /* renamed from: protected, reason: not valid java name */
    public final el5 f18281protected;

    /* renamed from: strictfp, reason: not valid java name */
    public final z2b.b f18282strictfp;

    /* renamed from: transient, reason: not valid java name */
    public final el5 f18283transient;

    /* renamed from: volatile, reason: not valid java name */
    public final z2b.b f18284volatile;

    /* loaded from: classes2.dex */
    public static final class a {
        public a(ep5 ep5Var) {
        }
    }

    /* loaded from: classes2.dex */
    public static final class b implements p57 {
        public b() {
        }

        @Override // defpackage.p57
        /* renamed from: do */
        public void mo6065do(h59 h59Var) {
            jp5.m8570try(h59Var, "album");
            j9b j9bVar = j9b.this;
            Objects.requireNonNull(j9bVar);
            g57 g57Var = new g57(kz6.UNKNOWN);
            Context requireContext = j9bVar.requireContext();
            jp5.m8568new(requireContext, "requireContext()");
            g57Var.m6390for(requireContext);
            zg requireFragmentManager = j9bVar.requireFragmentManager();
            jp5.m8568new(requireFragmentManager, "requireFragmentManager()");
            g57Var.m6392new(requireFragmentManager);
            k78 k78Var = new k78(Page.OWN_ALBUMS, h59Var);
            jp5.m8568new(k78Var, "forGlobalAlbumsFragment(album)");
            g57Var.m6393try(k78Var);
            g57Var.m6391if(h59Var);
            l77 m6389do = g57Var.m6389do();
            zg requireFragmentManager2 = j9bVar.requireFragmentManager();
            jp5.m8568new(requireFragmentManager2, "requireFragmentManager()");
            ((d87) m6389do).mo480import(requireFragmentManager2);
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends kp5 implements bo5<z2b> {
        public c() {
            super(0);
        }

        @Override // defpackage.bo5
        public z2b invoke() {
            z2b z2bVar = new z2b(j9b.this.getContext());
            final j9b j9bVar = j9b.this;
            z2bVar.f46565if = new z2b.a() { // from class: v8b
                @Override // z2b.a
                /* renamed from: do */
                public final void mo6199do() {
                    j9b j9bVar2 = j9b.this;
                    jp5.m8570try(j9bVar2, "this$0");
                    Context context = j9bVar2.getContext();
                    jp5.m8568new(context, "context");
                    jp5.m8570try(context, "context");
                    iz3 l3 = dn3.l3(v14.class);
                    jp5.m8570try(l3, "typeSpec");
                    bz3 bz3Var = bz3.f4526do;
                    jp5.m8565for(bz3Var);
                    jp5.m8570try(l3, "typeSpec");
                    LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
                    j9bVar2.startActivity(((yma) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(yma.class))).m13409else() ? PodcastsCatalogActivity.m13677implements(context) : PodcastsActivity.f33449default.m13675new(context));
                }
            };
            sqe sqeVar = new sqe() { // from class: u8b
                @Override // defpackage.sqe
                public final void call() {
                    j9b j9bVar2 = j9b.this;
                    jp5.m8570try(j9bVar2, "this$0");
                    dn3.e0(h9b.f14880for.m17714static(), "MyPodcasts_BlankState_QuestionTapped", null, 2);
                    t5d.a m14666case = t5d.a.m14666case();
                    m14666case.f36633try = false;
                    t5d m14667try = m14666case.m14667try("yamusic-podcast", "1000");
                    jp5.m8568new(m14667try, "yandexmusic()\n                    .needPermissions(false)\n                    .build(\"yamusic-podcast\", \"1000\")");
                    Intent m13791synchronized = UrlActivity.m13791synchronized(j9bVar2.getContext(), m14667try, PlaybackScope.f33221catch, null);
                    jp5.m8568new(m13791synchronized, "schemeIntent(context, urlScheme, PlaybackScope.EMPTY, null)");
                    j9bVar2.getContext().startActivity(m13791synchronized);
                }
            };
            z2bVar.f46559class.setVisibility(0);
            z2bVar.f46559class.setText(R.string.blank_podcasts_link);
            z2bVar.f46559class.setOnClickListener(new x2b(sqeVar));
            return z2bVar;
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends kp5 implements bo5<z2b> {
        public d() {
            super(0);
        }

        @Override // defpackage.bo5
        public z2b invoke() {
            z2b z2bVar = new z2b(j9b.this.getContext());
            final j9b j9bVar = j9b.this;
            z2bVar.f46565if = new z2b.a() { // from class: w8b
                @Override // z2b.a
                /* renamed from: do */
                public final void mo6199do() {
                    j9b j9bVar2 = j9b.this;
                    jp5.m8570try(j9bVar2, "this$0");
                    Context context = j9bVar2.getContext();
                    jp5.m8568new(context, "context");
                    j9bVar2.startActivity(KidsCatalogActivity.m13655implements(context));
                }
            };
            return z2bVar;
        }
    }

    /* loaded from: classes2.dex */
    public static final class e implements v09.a {
        @Override // v09.a
        /* renamed from: do */
        public void mo2200do() {
            dn3.e0(h9b.f14880for.m17714static(), "MyPodcasts_Page_Closed", null, 2);
        }

        @Override // v09.a
        /* renamed from: if */
        public void mo2201if() {
            dn3.e0(h9b.f14880for.m17714static(), "MyPodcasts_Page_Opened", null, 2);
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[4];
        wp5 wp5Var = new wp5(dq5.m4763do(j9b.class), "blankStateAnimController", "getBlankStateAnimController()Lru/yandex/music/phonoteka/mymusic/blankstate/BlankStateAnimController;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        mr5VarArr[0] = wp5Var;
        wp5 wp5Var2 = new wp5(dq5.m4763do(j9b.class), "connectivityBox", "getConnectivityBox()Lru/yandex/music/network/connectivity/ConnectivityBox;");
        Objects.requireNonNull(eq5Var);
        mr5VarArr[1] = wp5Var2;
        f18276private = mr5VarArr;
        f18275package = new a(null);
    }

    public j9b() {
        iz3 l3 = dn3.l3(t2b.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        mr5<Object>[] mr5VarArr = f18276private;
        jp5.m8570try(mr5VarArr[0], "prop");
        this.f18277abstract = dn3.h1(cz3Var);
        iz3 l32 = dn3.l3(wga.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        bz3Var2.m2425do(l32);
        cz3 cz3Var2 = new cz3(l32);
        jp5.m8570try(cz3Var2, "provider");
        jp5.m8570try(mr5VarArr[1], "prop");
        this.f18278continue = dn3.h1(cz3Var2);
        y2b y2bVar = y2b.PODCASTS;
        this.f18282strictfp = new z2b.b(y2bVar, R.string.blank_podcasts_title, R.string.empty_subscribed_podcasts_new, Integer.valueOf(R.string.blank_podcasts_button), R.drawable.blank_state_podcast_front_image, R.drawable.blank_state_middle_back_image);
        this.f18284volatile = new z2b.b(y2bVar, R.string.kids_collection_blank_title, R.string.kids_collection_blank_text, Integer.valueOf(R.string.blank_podcasts_button), 0, 0);
        this.f18281protected = dn3.h1(new c());
        this.f18283transient = dn3.h1(new d());
        this.f18279implements = new b0b(new b());
    }

    @Override // defpackage.n58, defpackage.r58
    /* renamed from: break */
    public boolean mo2196break() {
        return false;
    }

    @Override // defpackage.n58
    /* renamed from: continue */
    public ls7 mo3981continue() {
        return this.f18279implements;
    }

    @Override // defpackage.m58
    public void e(boolean z) {
        if (z) {
            dn3.e0(h9b.f14880for.m17714static(), "MyPodcasts_SearchBar_Tapped", null, 2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.us7
    /* renamed from: extends */
    public void mo610extends(Object obj, int i) {
        jp5.m8570try((h59) obj, "item");
        if (this.f23425throws) {
            dn3.e0(iuc.f17351for.m17714static(), "Albums_SearchResultClick", null, 2);
        } else {
            dn3.e0(iuc.f17351for.m17714static(), "Albums_AlbumClick", null, 2);
        }
        startActivity(AlbumActivity.m13534instanceof(getContext(), ((b0b) m10774strictfp()).m9928if(i), null));
    }

    @Override // lj.a
    /* renamed from: final */
    public pj mo3073final(int i, Bundle bundle) {
        return new o9b(getContext(), (wga) this.f18278continue.getValue(), bundle, m58.m10161implements(bundle), this.f18280interface);
    }

    @Override // defpackage.m58
    /* renamed from: instanceof */
    public int mo3982instanceof() {
        return this.f18280interface ? R.string.filter_hint_kids : R.string.filter_hint_podcasts;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.o58, defpackage.m58, defpackage.n58
    /* renamed from: interface */
    public void mo3983interface(Object obj) {
        Cursor cursor = (Cursor) obj;
        ((b0b) m10774strictfp()).m2321do(cursor);
        super.mo3983interface(cursor);
    }

    @Override // defpackage.m58, defpackage.p58, defpackage.j68, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Bundle arguments = getArguments();
        this.f18280interface = arguments == null ? false : arguments.getBoolean("NewAlbumPodcastsFragment_FOR_KIDS_PARAM");
        v09 v09Var = new v09(new e());
        this.f28385final = v09Var;
        v09Var.mo15812for(this);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.m58, androidx.fragment.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        jp5.m8570try(menu, "menu");
        jp5.m8570try(menuInflater, "inflater");
        g8d.a(menu, ((b0b) m10774strictfp()).getItemCount() == 0);
    }

    @Override // defpackage.n58, androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        jp5.m8570try(layoutInflater, "inflater");
        return layoutInflater.inflate(R.layout.fragment_recycler_toolbar_refreshable_no_padding, viewGroup, false);
    }

    @Override // defpackage.o58, defpackage.m58, defpackage.n58, defpackage.j68, androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        jp5.m8570try(view, "view");
        super.onViewCreated(view, bundle);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        toolbar.setTitle(mo2199try());
        mg activity = getActivity();
        o3 o3Var = activity instanceof o3 ? (o3) activity : null;
        if (o3Var != null) {
            o3Var.setSupportActionBar(toolbar);
        }
        int m7696goto = i9d.m7696goto(getContext());
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setTag(R.string.podcasts_album_tag_description, "");
        jp5.m8568new(recyclerView, "recyclerView");
        t2.m14596do(recyclerView, 0, m7696goto, 0, 0);
        recyclerView.m1122this(new b19(toolbar, m7696goto));
    }

    public final z2b q() {
        return (z2b) this.f18281protected.getValue();
    }

    public final z2b r() {
        return (z2b) this.f18283transient.getValue();
    }

    @Override // defpackage.c19
    /* renamed from: static */
    public int mo2516static() {
        return mo2199try();
    }

    @Override // defpackage.m58
    /* renamed from: synchronized */
    public View mo3984synchronized() {
        if (this.f18280interface) {
            z2b r = r();
            t2.m14603implements(r.f46563for, i9d.m7696goto(getContext()));
            r().m17819new(this.f18284volatile, ((t2b) this.f18277abstract.getValue()).m14629do(t2b.a.PODCASTS));
            View view = r().f46563for;
            jp5.m8568new(view, "{\n            blankStateViewKids.setTopPadding(Utils.getToolbarHeight(context))\n            blankStateViewKids.showOnce(\n                blankStateSpecsKids,\n                blankStateAnimController.needAnimFor(BlankStateAnimController.AnimTargetType.PODCASTS)\n            )\n            blankStateViewKids.view()\n        }");
            return view;
        }
        z2b q = q();
        t2.m14603implements(q.f46563for, i9d.m7696goto(getContext()));
        q().m17819new(this.f18282strictfp, ((t2b) this.f18277abstract.getValue()).m14629do(t2b.a.PODCASTS));
        View view2 = q().f46563for;
        jp5.m8568new(view2, "{\n            blankStateView.setTopPadding(Utils.getToolbarHeight(context))\n            blankStateView.showOnce(\n                blankStateSpecs,\n                blankStateAnimController.needAnimFor(BlankStateAnimController.AnimTargetType.PODCASTS)\n            )\n            blankStateView.view()\n        }");
        return view2;
    }

    @Override // defpackage.n58, defpackage.r58
    /* renamed from: throws */
    public List<cbd> mo2198throws() {
        return em5.f10300catch;
    }

    @Override // defpackage.n58, defpackage.s58
    /* renamed from: try */
    public int mo2199try() {
        return this.f18280interface ? R.string.kids_subscribes_title : R.string.podcast_subscribes_title;
    }
}
