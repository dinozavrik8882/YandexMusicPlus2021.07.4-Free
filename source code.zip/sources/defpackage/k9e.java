package defpackage;

/* loaded from: classes2.dex */
public final class k9e extends l9e {

    /* renamed from: case, reason: not valid java name */
    public final String f20103case;

    /* renamed from: else, reason: not valid java name */
    public final boolean f20104else;

    /* renamed from: goto, reason: not valid java name */
    public final boolean f20105goto;

    /* renamed from: this, reason: not valid java name */
    public final boolean f20106this;

    /* renamed from: try, reason: not valid java name */
    public final String f20107try;

    public k9e(String str, String str2, boolean z, boolean z2, boolean z3) {
        super(str, str2, z, z2, (ep5) null);
        this.f20107try = str;
        this.f20103case = str2;
        this.f20104else = z;
        this.f20105goto = z2;
        this.f20106this = z3;
    }

    /* renamed from: try, reason: not valid java name */
    public static k9e m8882try(k9e k9eVar, String str, String str2, boolean z, boolean z2, boolean z3, int i) {
        String str3 = (i & 1) != 0 ? k9eVar.f20107try : null;
        String str4 = (i & 2) != 0 ? k9eVar.f20103case : null;
        if ((i & 4) != 0) {
            z = k9eVar.f20104else;
        }
        boolean z4 = z;
        if ((i & 8) != 0) {
            z2 = k9eVar.f20105goto;
        }
        boolean z5 = z2;
        if ((i & 16) != 0) {
            z3 = k9eVar.f20106this;
        }
        return new k9e(str3, str4, z4, z5, z3);
    }

    @Override // defpackage.l9e
    /* renamed from: do, reason: not valid java name */
    public String mo8883do() {
        return this.f20107try;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof k9e)) {
            return false;
        }
        k9e k9eVar = (k9e) obj;
        return jp5.m8563do(this.f20107try, k9eVar.f20107try) && jp5.m8563do(this.f20103case, k9eVar.f20103case) && this.f20104else == k9eVar.f20104else && this.f20105goto == k9eVar.f20105goto && this.f20106this == k9eVar.f20106this;
    }

    @Override // defpackage.l9e
    /* renamed from: for, reason: not valid java name */
    public boolean mo8884for() {
        return this.f20104else;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public int hashCode() {
        String str = this.f20107try;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.f20103case;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        boolean z = this.f20104else;
        int i = z;
        if (z != 0) {
            i = 1;
        }
        int i2 = (hashCode2 + i) * 31;
        boolean z2 = this.f20105goto;
        int i3 = z2;
        if (z2 != 0) {
            i3 = 1;
        }
        int i4 = (i2 + i3) * 31;
        boolean z3 = this.f20106this;
        return i4 + (z3 ? 1 : z3 ? 1 : 0);
    }

    @Override // defpackage.l9e
    /* renamed from: if, reason: not valid java name */
    public String mo8885if() {
        return this.f20103case;
    }

    @Override // defpackage.l9e
    /* renamed from: new, reason: not valid java name */
    public boolean mo8886new() {
        return this.f20105goto;
    }

    public String toString() {
        StringBuilder r = by.r("BooleanSettingData(id=");
        r.append(this.f20107try);
        r.append(", metricaName=");
        r.append(this.f20103case);
        r.append(", isEnabled=");
        r.append(this.f20104else);
        r.append(", isLocal=");
        r.append(this.f20105goto);
        r.append(", value=");
        return by.k(r, this.f20106this, ")");
    }
}
