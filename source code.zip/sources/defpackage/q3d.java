package defpackage;

import android.content.Context;

/* loaded from: classes2.dex */
public class q3d extends w2d<p3d, r3d> {
    public q3d() {
        super(true, true);
    }

    @Override // defpackage.w2d
    /* renamed from: if */
    public g2d<p3d, r3d> mo146if(Context context, p3d p3dVar) {
        p3d p3dVar2 = p3dVar;
        j59 m6674new = m16352for().m9704continue(p3dVar2.m15883if(1)).m6674new();
        final String m15883if = p3dVar2.m15883if(3);
        e69 e69Var = (e69) g8d.m6495switch(g8d.m6503while(new g9d() { // from class: l3d
            @Override // defpackage.g9d
            public final boolean apply(Object obj) {
                return ((e69) obj).f9541catch.equals(m15883if);
            }
        }, m6674new.f18057catch.f14706protected), null);
        if (m15883if == null || e69Var != null) {
            return new g2d<>(p3dVar2, new r3d(m6674new.f18057catch, e69Var));
        }
        throw new IllegalArgumentException("No track!");
    }
}
