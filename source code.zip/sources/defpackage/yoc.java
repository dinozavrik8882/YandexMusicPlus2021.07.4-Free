package defpackage;

import java.io.IOException;
import java.util.Map;

@ln5(c = "ru.yandex.music.settings.sync.UserSettingsCenter$uploadForUser$2", f = "UserSettingsCenter.kt", l = {84}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class yoc extends pn5 implements qo5<gu5, wm5<? super Boolean>, Object> {

    /* renamed from: import, reason: not valid java name */
    public final /* synthetic */ Map<String, String> f45952import;

    /* renamed from: super, reason: not valid java name */
    public int f45953super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ zoc f45954throw;

    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ mg9 f45955while;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public yoc(zoc zocVar, mg9 mg9Var, Map<String, String> map, wm5<? super yoc> wm5Var) {
        super(2, wm5Var);
        this.f45954throw = zocVar;
        this.f45955while = mg9Var;
        this.f45952import = map;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        return new yoc(this.f45954throw, this.f45955while, this.f45952import, wm5Var);
    }

    @Override // defpackage.qo5
    public Object invoke(gu5 gu5Var, wm5<? super Boolean> wm5Var) {
        return new yoc(this.f45954throw, this.f45955while, this.f45952import, wm5Var).mo76return(pl5.f29126do);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        int i = this.f45953super;
        boolean z = true;
        try {
            if (i == 0) {
                dn3.N2(obj);
                if (!jp5.m8563do(this.f45954throw.f47641if.mo9658else().getId(), this.f45955while.getId())) {
                    return Boolean.FALSE;
                }
                db6<x64<pl5>> m2258do = this.f45954throw.f47640for.m2258do(this.f45952import);
                this.f45953super = 1;
                obj = dn3.m4653interface(m2258do, this);
                if (obj == cn5Var) {
                    return cn5Var;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                dn3.N2(obj);
            }
            dn3.D((x64) obj);
        } catch (c74 | IOException | zv3 unused) {
            z = false;
        }
        return Boolean.valueOf(z);
    }
}
