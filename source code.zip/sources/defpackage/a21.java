package defpackage;

import android.net.Uri;
import defpackage.ap0;
import java.util.Collections;
import java.util.Objects;

/* loaded from: classes.dex */
public final class a21 extends ap0 {

    /* renamed from: if, reason: not valid java name */
    public static final Object f104if = new Object();

    /* renamed from: break, reason: not valid java name */
    public final boolean f105break;

    /* renamed from: case, reason: not valid java name */
    public final long f106case;

    /* renamed from: catch, reason: not valid java name */
    public final boolean f107catch;

    /* renamed from: class, reason: not valid java name */
    public final Object f108class;

    /* renamed from: const, reason: not valid java name */
    public final fo0 f109const;

    /* renamed from: else, reason: not valid java name */
    public final long f110else;

    /* renamed from: for, reason: not valid java name */
    public final long f111for;

    /* renamed from: goto, reason: not valid java name */
    public final long f112goto;

    /* renamed from: new, reason: not valid java name */
    public final long f113new;

    /* renamed from: this, reason: not valid java name */
    public final boolean f114this;

    /* renamed from: try, reason: not valid java name */
    public final long f115try;

    static {
        Collections.emptyList();
        Collections.emptyMap();
        Collections.emptyList();
        Collections.emptyList();
        Uri uri = Uri.EMPTY;
        h81.m7061else(true);
        Objects.requireNonNull("com.google.android.exoplayer2.source.SinglePeriodTimeline");
    }

    public a21(long j, long j2, long j3, long j4, long j5, long j6, long j7, boolean z, boolean z2, boolean z3, Object obj, fo0 fo0Var) {
        this.f111for = j;
        this.f113new = j2;
        this.f115try = j4;
        this.f106case = j5;
        this.f110else = j6;
        this.f112goto = j7;
        this.f114this = z;
        this.f105break = z2;
        this.f107catch = z3;
        this.f108class = obj;
        Objects.requireNonNull(fo0Var);
        this.f109const = fo0Var;
    }

    public a21(long j, long j2, long j3, long j4, boolean z, boolean z2, boolean z3, Object obj, fo0 fo0Var) {
        this(-9223372036854775807L, -9223372036854775807L, -9223372036854775807L, j, j2, j3, j4, z, z2, z3, obj, fo0Var);
    }

    public a21(long j, boolean z, boolean z2, boolean z3, Object obj, fo0 fo0Var) {
        this(j, j, 0L, 0L, z, z2, z3, null, fo0Var);
    }

    @Override // defpackage.ap0
    /* renamed from: const, reason: not valid java name */
    public Object mo69const(int i) {
        h81.m7055case(i, 0, 1);
        return f104if;
    }

    @Override // defpackage.ap0
    /* renamed from: else, reason: not valid java name */
    public ap0.b mo70else(int i, ap0.b bVar, boolean z) {
        h81.m7055case(i, 0, 1);
        bVar.m1354case(null, z ? f104if : null, 0, this.f115try, -this.f110else);
        return bVar;
    }

    @Override // defpackage.ap0
    /* renamed from: if, reason: not valid java name */
    public int mo71if(Object obj) {
        return f104if.equals(obj) ? 0 : -1;
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0025, code lost:
    
        if (r1 > r5) goto L11;
     */
    @Override // defpackage.ap0
    /* renamed from: super, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public ap0.c mo72super(int r25, ap0.c r26, long r27) {
        /*
            r24 = this;
            r0 = r24
            r1 = 0
            r2 = 1
            r3 = r25
            defpackage.h81.m7055case(r3, r1, r2)
            long r1 = r0.f112goto
            boolean r14 = r0.f105break
            r3 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            if (r14 == 0) goto L2a
            r5 = 0
            int r5 = (r27 > r5 ? 1 : (r27 == r5 ? 0 : -1))
            if (r5 == 0) goto L2a
            long r5 = r0.f106case
            int r7 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
            if (r7 != 0) goto L21
            goto L27
        L21:
            long r1 = r1 + r27
            int r5 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r5 <= 0) goto L2a
        L27:
            r16 = r3
            goto L2c
        L2a:
            r16 = r1
        L2c:
            java.lang.Object r4 = ap0.c.f2250do
            fo0 r5 = r0.f109const
            java.lang.Object r6 = r0.f108class
            long r7 = r0.f111for
            long r9 = r0.f113new
            r11 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            boolean r13 = r0.f114this
            boolean r15 = r0.f107catch
            long r1 = r0.f106case
            r18 = r1
            r20 = 0
            r21 = 0
            long r1 = r0.f110else
            r22 = r1
            r3 = r26
            r3.m1361for(r4, r5, r6, r7, r9, r11, r13, r14, r15, r16, r18, r20, r21, r22)
            return r26
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.a21.mo72super(int, ap0$c, long):ap0$c");
    }

    @Override // defpackage.ap0
    /* renamed from: this, reason: not valid java name */
    public int mo73this() {
        return 1;
    }

    @Override // defpackage.ap0
    /* renamed from: throw, reason: not valid java name */
    public int mo74throw() {
        return 1;
    }
}
