package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.IdToken;

/* loaded from: classes.dex */
public final class ae1 implements Parcelable.Creator<IdToken> {
    @Override // android.os.Parcelable.Creator
    public final IdToken createFromParcel(Parcel parcel) {
        int m7283protected = hg1.m7283protected(parcel);
        String str = null;
        String str2 = null;
        while (parcel.dataPosition() < m7283protected) {
            int readInt = parcel.readInt();
            int i = 65535 & readInt;
            if (i == 1) {
                str = hg1.m7297while(parcel, readInt);
            } else if (i != 2) {
                hg1.m7278interface(parcel, readInt);
            } else {
                str2 = hg1.m7297while(parcel, readInt);
            }
        }
        hg1.m7286static(parcel, m7283protected);
        return new IdToken(str, str2);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ IdToken[] newArray(int i) {
        return new IdToken[i];
    }
}
