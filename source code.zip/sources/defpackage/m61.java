package defpackage;

import android.text.TextUtils;
import com.google.android.exoplayer2.util.Util;

/* loaded from: classes.dex */
public final class m61 {

    /* renamed from: do, reason: not valid java name */
    public final int f23458do;

    /* renamed from: for, reason: not valid java name */
    public final int f23459for;

    /* renamed from: if, reason: not valid java name */
    public final int f23460if;

    /* renamed from: new, reason: not valid java name */
    public final int f23461new;

    /* renamed from: try, reason: not valid java name */
    public final int f23462try;

    public m61(int i, int i2, int i3, int i4, int i5) {
        this.f23458do = i;
        this.f23460if = i2;
        this.f23459for = i3;
        this.f23461new = i4;
        this.f23462try = i5;
    }

    /* renamed from: do, reason: not valid java name */
    public static m61 m10171do(String str) {
        char c;
        h81.m7064for(str.startsWith("Format:"));
        String[] split = TextUtils.split(str.substring(7), ",");
        int i = -1;
        int i2 = -1;
        int i3 = -1;
        int i4 = -1;
        for (int i5 = 0; i5 < split.length; i5++) {
            String lowerInvariant = Util.toLowerInvariant(split[i5].trim());
            lowerInvariant.hashCode();
            switch (lowerInvariant.hashCode()) {
                case 100571:
                    if (lowerInvariant.equals("end")) {
                        c = 0;
                        break;
                    }
                    break;
                case 3556653:
                    if (lowerInvariant.equals("text")) {
                        c = 1;
                        break;
                    }
                    break;
                case 109757538:
                    if (lowerInvariant.equals("start")) {
                        c = 2;
                        break;
                    }
                    break;
                case 109780401:
                    if (lowerInvariant.equals("style")) {
                        c = 3;
                        break;
                    }
                    break;
            }
            c = 65535;
            switch (c) {
                case 0:
                    i2 = i5;
                    break;
                case 1:
                    i4 = i5;
                    break;
                case 2:
                    i = i5;
                    break;
                case 3:
                    i3 = i5;
                    break;
            }
        }
        if (i == -1 || i2 == -1) {
            return null;
        }
        return new m61(i, i2, i3, i4, split.length);
    }
}
