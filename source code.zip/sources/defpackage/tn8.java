package defpackage;

import android.content.Context;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class tn8 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f37516do;

    /* renamed from: for, reason: not valid java name */
    public final el5 f37517for;

    /* renamed from: if, reason: not valid java name */
    public final Context f37518if;

    /* renamed from: new, reason: not valid java name */
    public final el5 f37519new;

    /* renamed from: try, reason: not valid java name */
    public final el5 f37520try;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements bo5<mg> {
        public a() {
            super(0);
        }

        @Override // defpackage.bo5
        public mg invoke() {
            return (mg) wuc.m16816native(tn8.this.f37518if);
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements bo5<z28> {

        /* renamed from: catch, reason: not valid java name */
        public static final b f37522catch = new b();

        public b() {
            super(0);
        }

        @Override // defpackage.bo5
        public z28 invoke() {
            return new z28();
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[3];
        wp5 wp5Var = new wp5(dq5.m4763do(tn8.class), "connectivityManager", "getConnectivityManager()Lru/yandex/music/network/connectivity/ConnectivityBox;");
        Objects.requireNonNull(dq5.f8909do);
        mr5VarArr[0] = wp5Var;
        f37516do = mr5VarArr;
    }

    public tn8(Context context) {
        jp5.m8570try(context, "context");
        this.f37518if = context;
        iz3 l3 = dn3.l3(wga.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        this.f37517for = new ez3(new cz3(l3)).m5533do(f37516do[0]);
        this.f37519new = dn3.h1(b.f37522catch);
        this.f37520try = dn3.h1(new a());
    }

    /* renamed from: do, reason: not valid java name */
    public final void m15091do(q68 q68Var) {
        pl5 pl5Var = null;
        e69 mo286new = q68Var == null ? null : q68Var.mo286new();
        if (mo286new == null) {
            return;
        }
        n59 n59Var = mo286new.f9549import;
        boolean z = true;
        if (n59Var == n59.NO_META) {
            i9d.m7694final(this.f37518if, R.string.local_track_not_available, 0);
            return;
        }
        if (!(n59Var == n59.OK)) {
            if (!lc4.f21917catch.m9578new()) {
                i9d.m7694final(this.f37518if, R.string.bottom_sheet_track_no_rights_title, 0);
                return;
            }
            mg mgVar = (mg) this.f37520try.getValue();
            if (mgVar != null) {
                jp5.m8570try(mgVar, "activity");
                zg supportFragmentManager = mgVar.getSupportFragmentManager();
                jp5.m8568new(supportFragmentManager, "activity.supportFragmentManager");
                jp5.m8570try(supportFragmentManager, "fragmentManager");
                new f48().mo480import(supportFragmentManager);
                pl5Var = pl5.f29126do;
            }
            if (pl5Var == null) {
                k2f.f19768new.mo8777while("PlayableWarningDemonstrator is used from non-activity context", new Object[0]);
                i9d.m7694final(this.f37518if, R.string.bottom_sheet_track_no_rights_title, 0);
                return;
            }
            return;
        }
        if (((z28) this.f37519new.getValue()).apply(mo286new)) {
            d69 d69Var = mo286new.f9559super;
            d69 d69Var2 = d69.LOCAL;
            if (d69Var != d69Var2) {
                if (!(gx7.m6886if(true).m7519for(mo286new) || mo286new.f9559super == d69Var2)) {
                    z = false;
                }
            }
            if (z) {
                return;
            }
            wuc.m16818super(this.f37518if, (wga) this.f37517for.getValue());
            return;
        }
        if (!lc4.f21917catch.m9578new()) {
            i9d.m7694final(this.f37518if, R.string.bottom_sheet_track_explicit_title, 0);
            return;
        }
        mg mgVar2 = (mg) this.f37520try.getValue();
        if (mgVar2 != null) {
            jp5.m8570try(mo286new, "track");
            jp5.m8570try(mgVar2, "activity");
            zg supportFragmentManager2 = mgVar2.getSupportFragmentManager();
            jp5.m8568new(supportFragmentManager2, "activity.supportFragmentManager");
            jp5.m8570try(mo286new, "track");
            jp5.m8570try(supportFragmentManager2, "fragmentManager");
            joc jocVar = new joc();
            jocVar.setArguments(qb.m12632try(new hl5("ARG_TRACK", mo286new)));
            jocVar.mo480import(supportFragmentManager2);
            pl5Var = pl5.f29126do;
        }
        if (pl5Var == null) {
            k2f.f19768new.mo8777while("PlayableWarningDemonstrator is used from non-activity context", new Object[0]);
            i9d.m7694final(this.f37518if, R.string.bottom_sheet_track_explicit_title, 0);
        }
    }
}
