package defpackage;

/* loaded from: classes.dex */
public interface d70 {
    /* renamed from: break */
    boolean mo1792break();

    void clear();

    /* renamed from: do */
    boolean mo1796do();

    /* renamed from: goto */
    void mo1799goto();

    boolean isRunning();

    /* renamed from: new */
    boolean mo1801new(d70 d70Var);

    void pause();

    /* renamed from: try */
    boolean mo1803try();
}
