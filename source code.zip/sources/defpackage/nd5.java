package defpackage;

import java.io.IOException;
import java.io.InputStream;

/* loaded from: classes2.dex */
public interface nd5 {
    /* renamed from: do */
    String mo5913do();

    /* renamed from: if */
    InputStream mo5915if(InputStream inputStream) throws IOException;
}
