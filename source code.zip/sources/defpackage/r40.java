package defpackage;

import android.graphics.Bitmap;
import java.io.IOException;

/* loaded from: classes.dex */
public final class r40 implements oz<Bitmap, Bitmap> {

    /* loaded from: classes.dex */
    public static final class a implements f10<Bitmap> {

        /* renamed from: catch, reason: not valid java name */
        public final Bitmap f31866catch;

        public a(Bitmap bitmap) {
            this.f31866catch = bitmap;
        }

        @Override // defpackage.f10
        /* renamed from: for */
        public Class<Bitmap> mo2606for() {
            return Bitmap.class;
        }

        @Override // defpackage.f10
        public Bitmap get() {
            return this.f31866catch;
        }

        @Override // defpackage.f10
        public int getSize() {
            return j80.m8202new(this.f31866catch);
        }

        @Override // defpackage.f10
        /* renamed from: if */
        public void mo2607if() {
        }
    }

    @Override // defpackage.oz
    /* renamed from: do */
    public /* bridge */ /* synthetic */ boolean mo158do(Bitmap bitmap, mz mzVar) throws IOException {
        return true;
    }

    @Override // defpackage.oz
    /* renamed from: if */
    public f10<Bitmap> mo159if(Bitmap bitmap, int i, int i2, mz mzVar) throws IOException {
        return new a(bitmap);
    }
}
