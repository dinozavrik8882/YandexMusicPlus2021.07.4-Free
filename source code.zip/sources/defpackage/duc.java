package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import java.util.Date;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes2.dex */
public final class duc implements Parcelable, Serializable {
    public static final Parcelable.Creator<duc> CREATOR = new a();
    private static final long serialVersionUID = 1;

    /* renamed from: catch, reason: not valid java name */
    public final String f9079catch;

    /* renamed from: class, reason: not valid java name */
    public final String f9080class;

    /* renamed from: const, reason: not valid java name */
    public final Date f9081const;

    /* loaded from: classes2.dex */
    public static final class a implements Parcelable.Creator<duc> {
        @Override // android.os.Parcelable.Creator
        public duc createFromParcel(Parcel parcel) {
            jp5.m8570try(parcel, "parcel");
            return new duc(parcel.readString(), parcel.readString(), (Date) parcel.readSerializable());
        }

        @Override // android.os.Parcelable.Creator
        public duc[] newArray(int i) {
            return new duc[i];
        }
    }

    public duc(String str, String str2, Date date) {
        jp5.m8570try(str, DatabaseHelper.OttTrackingTable.COLUMN_ID);
        jp5.m8570try(date, "timestamp");
        this.f9079catch = str;
        this.f9080class = str2;
        this.f9081const = date;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof duc)) {
            return false;
        }
        duc ducVar = (duc) obj;
        return jp5.m8563do(this.f9079catch, ducVar.f9079catch) && jp5.m8563do(this.f9080class, ducVar.f9080class) && jp5.m8563do(this.f9081const, ducVar.f9081const);
    }

    public int hashCode() {
        int hashCode = this.f9079catch.hashCode() * 31;
        String str = this.f9080class;
        return this.f9081const.hashCode() + ((hashCode + (str == null ? 0 : str.hashCode())) * 31);
    }

    public String toString() {
        StringBuilder r = by.r("PlayedTrack(id=");
        r.append(this.f9079catch);
        r.append(", albumId=");
        r.append((Object) this.f9080class);
        r.append(", timestamp=");
        r.append(this.f9081const);
        r.append(')');
        return r.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        jp5.m8570try(parcel, "out");
        parcel.writeString(this.f9079catch);
        parcel.writeString(this.f9080class);
        parcel.writeSerializable(this.f9081const);
    }
}
