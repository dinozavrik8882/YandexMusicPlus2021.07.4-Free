package defpackage;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import defpackage.gy8;
import defpackage.qpe;
import ru.yandex.music.YMApplication;

/* loaded from: classes2.dex */
public class gy8 extends jr8<a> {

    /* renamed from: for, reason: not valid java name */
    public static final IntentFilter f14357for;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: native, reason: not valid java name */
        void mo6910native();

        /* renamed from: public, reason: not valid java name */
        void mo6911public();

        /* renamed from: return, reason: not valid java name */
        void mo6912return(float f);

        /* renamed from: switch, reason: not valid java name */
        void mo6913switch();
    }

    /* loaded from: classes2.dex */
    public enum b {
        IDLE(false),
        STARTED(false),
        IN_PROGRESS(false),
        SUCCEEDED(true),
        FAILED(true);

        private final boolean mTerminal;

        b(boolean z) {
            this.mTerminal = z;
        }

        public boolean isTerminal() {
            return this.mTerminal;
        }
    }

    static {
        IntentFilter intentFilter = new IntentFilter();
        f14357for = intentFilter;
        intentFilter.addAction("SyncService.ACTION_SYNC_STARTED");
        intentFilter.addAction("SyncService.ACTION_SYNC_SUCCEED");
        intentFilter.addAction("SyncService.ACTION_SYNC_FAILED");
        intentFilter.addAction("SyncService.ACTION_SYNC_PROGRESS");
    }

    /* renamed from: case, reason: not valid java name */
    public static spe<b> m6906case(Context context) {
        IntentFilter intentFilter = f14357for;
        return spe.m14372class(new ubd(context, intentFilter, true), qpe.a.LATEST).m14390interface(new yqe() { // from class: nx8
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                IntentFilter intentFilter2 = gy8.f14357for;
                String action = ((Intent) obj).getAction();
                if (action == null) {
                    return gy8.b.IDLE;
                }
                char c = 65535;
                switch (action.hashCode()) {
                    case -2101669684:
                        if (action.equals("SyncService.ACTION_SYNC_FAILED")) {
                            c = 0;
                            break;
                        }
                        break;
                    case -1537845838:
                        if (action.equals("SyncService.ACTION_SYNC_STARTED")) {
                            c = 1;
                            break;
                        }
                        break;
                    case -1507830925:
                        if (action.equals("SyncService.ACTION_SYNC_SUCCEED")) {
                            c = 2;
                            break;
                        }
                        break;
                    case 1548505852:
                        if (action.equals("SyncService.ACTION_SYNC_PROGRESS")) {
                            c = 3;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        return gy8.b.FAILED;
                    case 1:
                        return gy8.b.STARTED;
                    case 2:
                        return gy8.b.SUCCEEDED;
                    case 3:
                        return gy8.b.IN_PROGRESS;
                    default:
                        return gy8.b.IDLE;
                }
            }
        }).m14403while();
    }

    /* renamed from: try, reason: not valid java name */
    public static void m6907try() {
        YMApplication.f33061catch.m13516if(new Intent("SyncService.ACTION_SYNC_FAILED"));
    }

    @Override // defpackage.jr8
    /* renamed from: do, reason: not valid java name */
    public IntentFilter mo6908do() {
        return f14357for;
    }

    @Override // defpackage.jr8
    /* renamed from: if, reason: not valid java name */
    public void mo6909if(Context context, Intent intent, a aVar) {
        a aVar2 = aVar;
        String action = intent.getAction();
        if ("SyncService.ACTION_SYNC_STARTED".equals(action)) {
            aVar2.mo6910native();
            return;
        }
        if ("SyncService.ACTION_SYNC_SUCCEED".equals(action)) {
            aVar2.mo6913switch();
        } else if ("SyncService.ACTION_SYNC_PROGRESS".equals(action)) {
            aVar2.mo6912return(intent.getFloatExtra("SyncService.EXTRA_PROGRESS", 0.0f));
        } else if ("SyncService.ACTION_SYNC_FAILED".equals(action)) {
            aVar2.mo6911public();
        }
    }
}
