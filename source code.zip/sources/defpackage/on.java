package defpackage;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.um;

/* loaded from: classes.dex */
public class on implements um.b {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ RecyclerView f27542do;

    public on(RecyclerView recyclerView) {
        this.f27542do = recyclerView;
    }

    /* renamed from: do, reason: not valid java name */
    public View m11659do(int i) {
        return this.f27542do.getChildAt(i);
    }

    /* renamed from: for, reason: not valid java name */
    public void m11660for(int i) {
        View childAt = this.f27542do.getChildAt(i);
        if (childAt != null) {
            this.f27542do.m1127while(childAt);
            childAt.clearAnimation();
        }
        this.f27542do.removeViewAt(i);
    }

    /* renamed from: if, reason: not valid java name */
    public int m11661if() {
        return this.f27542do.getChildCount();
    }
}
