package defpackage;

import com.google.gson.Gson;
import defpackage.bz3;
import java.util.LinkedHashSet;

/* loaded from: classes2.dex */
public final class ig9 {

    /* renamed from: do, reason: not valid java name */
    public static final ig9 f16763do = new ig9();

    /* renamed from: if, reason: not valid java name */
    public static final Gson f16764if;

    static {
        iz3 l3 = dn3.l3(ut3.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        f16764if = ((ut3) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).f39494for.getValue();
    }
}
