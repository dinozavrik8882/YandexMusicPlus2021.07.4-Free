package defpackage;

/* loaded from: classes2.dex */
public final class u18 extends kp5 implements mo5<e69, CharSequence> {

    /* renamed from: catch, reason: not valid java name */
    public static final u18 f38235catch = new u18();

    public u18() {
        super(1);
    }

    @Override // defpackage.mo5
    public CharSequence invoke(e69 e69Var) {
        e69 e69Var2 = e69Var;
        jp5.m8570try(e69Var2, "it");
        StringBuilder sb = new StringBuilder();
        sb.append(e69Var2.f9541catch);
        sb.append(" - '");
        return by.c(sb, e69Var2.f9542class, '\'');
    }
}
