package defpackage;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.transformation.FabTransformationBehavior;
import defpackage.wm2;

/* loaded from: classes.dex */
public class gr2 extends AnimatorListenerAdapter {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ wm2 f14059do;

    public gr2(FabTransformationBehavior fabTransformationBehavior, wm2 wm2Var) {
        this.f14059do = wm2Var;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        wm2.e revealInfo = this.f14059do.getRevealInfo();
        revealInfo.f42530for = Float.MAX_VALUE;
        this.f14059do.setRevealInfo(revealInfo);
    }
}
