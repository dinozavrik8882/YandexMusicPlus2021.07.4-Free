package defpackage;

import defpackage.j8;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public class d8<K, V> extends k8<K, V> implements Map<K, V> {

    /* renamed from: import, reason: not valid java name */
    public j8<K, V> f8115import;

    /* loaded from: classes.dex */
    public class a extends j8<K, V> {
        public a() {
        }

        @Override // defpackage.j8
        /* renamed from: case, reason: not valid java name */
        public int mo4262case(Object obj) {
            return d8.this.m8855else(obj);
        }

        @Override // defpackage.j8
        /* renamed from: do, reason: not valid java name */
        public void mo4263do() {
            d8.this.clear();
        }

        @Override // defpackage.j8
        /* renamed from: else, reason: not valid java name */
        public void mo4264else(K k, V v) {
            d8.this.put(k, v);
        }

        @Override // defpackage.j8
        /* renamed from: for, reason: not valid java name */
        public Map<K, V> mo4265for() {
            return d8.this;
        }

        @Override // defpackage.j8
        /* renamed from: goto, reason: not valid java name */
        public void mo4266goto(int i) {
            d8.this.mo1812break(i);
        }

        @Override // defpackage.j8
        /* renamed from: if, reason: not valid java name */
        public Object mo4267if(int i, int i2) {
            return d8.this.f19979throw[(i << 1) + i2];
        }

        @Override // defpackage.j8
        /* renamed from: new, reason: not valid java name */
        public int mo4268new() {
            return d8.this.f19980while;
        }

        @Override // defpackage.j8
        /* renamed from: this, reason: not valid java name */
        public V mo4269this(int i, V v) {
            return d8.this.mo1813catch(i, v);
        }

        @Override // defpackage.j8
        /* renamed from: try, reason: not valid java name */
        public int mo4270try(Object obj) {
            return d8.this.m8859try(obj);
        }
    }

    public d8() {
    }

    public d8(int i) {
        super(i);
    }

    public d8(k8 k8Var) {
        if (k8Var != null) {
            mo1814this(k8Var);
        }
    }

    @Override // java.util.Map
    public Set<Map.Entry<K, V>> entrySet() {
        j8<K, V> m4261final = m4261final();
        if (m4261final.f18175do == null) {
            m4261final.f18175do = new j8.b();
        }
        return m4261final.f18175do;
    }

    /* renamed from: final, reason: not valid java name */
    public final j8<K, V> m4261final() {
        if (this.f8115import == null) {
            this.f8115import = new a();
        }
        return this.f8115import;
    }

    @Override // java.util.Map
    public Set<K> keySet() {
        j8<K, V> m4261final = m4261final();
        if (m4261final.f18177if == null) {
            m4261final.f18177if = new j8.c();
        }
        return m4261final.f18177if;
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> map) {
        m8857if(map.size() + this.f19980while);
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map
    public Collection<V> values() {
        j8<K, V> m4261final = m4261final();
        if (m4261final.f18176for == null) {
            m4261final.f18176for = new j8.e();
        }
        return m4261final.f18176for;
    }
}
