package defpackage;

import defpackage.ey8;
import defpackage.hy8;

/* loaded from: classes2.dex */
public class dy8 implements hy8.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ ey8.a f9189do;

    public dy8(ey8.a aVar) {
        this.f9189do = aVar;
    }

    @Override // hy8.a
    /* renamed from: do, reason: not valid java name */
    public void mo4847do(float f) {
    }

    @Override // hy8.a
    /* renamed from: if, reason: not valid java name */
    public void mo4848if() {
        ey8 ey8Var;
        qo5<? super vt3, ? super Boolean, pl5> qo5Var;
        if (this.f9189do.isCancelled() || (ey8Var = this.f9189do.f10893new.get()) == null || (qo5Var = ey8Var.f41147do) == null) {
            return;
        }
        qo5Var.invoke(ey8Var, Boolean.FALSE);
    }
}
