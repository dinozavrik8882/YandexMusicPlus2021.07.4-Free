package defpackage;

import defpackage.ied;

/* loaded from: classes2.dex */
public final class ned extends kp5 implements mo5<ied.a, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ boolean f25418catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ned(boolean z) {
        super(1);
        this.f25418catch = z;
    }

    @Override // defpackage.mo5
    public pl5 invoke(ied.a aVar) {
        ied.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$updateState");
        aVar2.f16709for = this.f25418catch;
        return pl5.f29126do;
    }
}
