package defpackage;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;

/* loaded from: classes.dex */
public interface yx2 extends IInterface {
    void d(Bundle bundle) throws RemoteException;

    void e(Bundle bundle) throws RemoteException;

    void j0(Bundle bundle, Bundle bundle2) throws RemoteException;
}
