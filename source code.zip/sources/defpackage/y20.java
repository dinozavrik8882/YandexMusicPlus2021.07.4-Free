package defpackage;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* loaded from: classes.dex */
public interface y20<Model, Data> {

    /* loaded from: classes.dex */
    public static class a<Data> {

        /* renamed from: do, reason: not valid java name */
        public final jz f44905do;

        /* renamed from: for, reason: not valid java name */
        public final uz<Data> f44906for;

        /* renamed from: if, reason: not valid java name */
        public final List<jz> f44907if;

        public a(jz jzVar, uz<Data> uzVar) {
            List<jz> emptyList = Collections.emptyList();
            Objects.requireNonNull(jzVar, "Argument must not be null");
            this.f44905do = jzVar;
            Objects.requireNonNull(emptyList, "Argument must not be null");
            this.f44907if = emptyList;
            Objects.requireNonNull(uzVar, "Argument must not be null");
            this.f44906for = uzVar;
        }
    }

    /* renamed from: do */
    boolean mo1672do(Model model);

    /* renamed from: if */
    a<Data> mo1673if(Model model, int i, int i2, mz mzVar);
}
