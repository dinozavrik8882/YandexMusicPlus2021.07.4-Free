package defpackage;

import com.yandex.auth.sync.AccountProvider;
import defpackage.l59;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import ru.yandex.music.data.stores.CoverPath;
import ru.yandex.video.ott.data.local.db.DatabaseHelper;

/* loaded from: classes2.dex */
public class e99 extends a89<l59> {

    /* renamed from: do, reason: not valid java name */
    public static final e99 f9743do = new e99();

    @Override // defpackage.c89
    /* renamed from: for, reason: not valid java name and merged with bridge method [inline-methods] */
    public l59 mo1839do(v79 v79Var) throws IOException {
        return m5064new(v79Var, null);
    }

    /* renamed from: new, reason: not valid java name */
    public l59 m5064new(v79 v79Var, String str) throws IOException {
        String str2;
        CoverPath mo1839do;
        v79Var.m15970do();
        l59.a aVar = l59.a.f21617catch;
        List emptyList = Collections.emptyList();
        CoverPath none = CoverPath.none();
        String str3 = null;
        String str4 = null;
        String str5 = null;
        LinkedList linkedList = null;
        boolean z = true;
        boolean z2 = false;
        boolean z3 = false;
        int i = 0;
        boolean z4 = false;
        loop0: while (v79Var.m15972for()) {
            String m15971else = v79Var.m15971else();
            if ("composer".equals(m15971else)) {
                z3 = v79Var.m15977try();
            } else {
                if ("cover".equals(m15971else)) {
                    mo1839do = k99.f20097do.mo1839do(v79Var);
                } else if ("coverUri".equals(m15971else)) {
                    mo1839do = CoverPath.fromCoverUriString(v79Var.m15973goto());
                } else if (DatabaseHelper.OttTrackingTable.COLUMN_ID.equals(m15971else)) {
                    str4 = v79Var.m15973goto();
                } else if (AccountProvider.NAME.equals(m15971else)) {
                    str5 = v79Var.m15973goto();
                } else if ("various".equals(m15971else)) {
                    z2 = v79Var.m15977try();
                } else if ("likesCount".equals(m15971else)) {
                    i = v79Var.m15967case();
                } else if ("links".equals(m15971else)) {
                    d89 d89Var = new c89() { // from class: d89
                        /* JADX WARN: Removed duplicated region for block: B:19:0x0051 A[SYNTHETIC] */
                        /* JADX WARN: Removed duplicated region for block: B:23:0x0056 A[SYNTHETIC] */
                        /* JADX WARN: Removed duplicated region for block: B:26:0x005b A[SYNTHETIC] */
                        /* JADX WARN: Removed duplicated region for block: B:29:0x0064 A[SYNTHETIC] */
                        /* JADX WARN: Removed duplicated region for block: B:32:0x004d A[SYNTHETIC] */
                        @Override // defpackage.c89
                        /* renamed from: do */
                        /*
                            Code decompiled incorrectly, please refer to instructions dump.
                            To view partially-correct add '--show-bad-code' argument
                        */
                        public final java.lang.Object mo1839do(java.lang.Object r10) {
                            /*
                                r9 = this;
                                v79 r10 = (defpackage.v79) r10
                                r10.m15970do()
                                r0 = 0
                                r1 = r0
                                r2 = r1
                                r3 = r2
                            L9:
                                boolean r4 = r10.m15972for()
                                java.lang.String r5 = "type"
                                java.lang.String r6 = "title"
                                if (r4 == 0) goto L69
                                java.lang.String r4 = r10.m15971else()
                                r4.hashCode()
                                r7 = -1
                                int r8 = r4.hashCode()
                                switch(r8) {
                                    case 3211051: goto L40;
                                    case 3575610: goto L37;
                                    case 110371416: goto L2e;
                                    case 326768129: goto L23;
                                    default: goto L22;
                                }
                            L22:
                                goto L4a
                            L23:
                                java.lang.String r5 = "socialNetwork"
                                boolean r4 = r4.equals(r5)
                                if (r4 != 0) goto L2c
                                goto L4a
                            L2c:
                                r7 = 3
                                goto L4a
                            L2e:
                                boolean r4 = r4.equals(r6)
                                if (r4 != 0) goto L35
                                goto L4a
                            L35:
                                r7 = 2
                                goto L4a
                            L37:
                                boolean r4 = r4.equals(r5)
                                if (r4 != 0) goto L3e
                                goto L4a
                            L3e:
                                r7 = 1
                                goto L4a
                            L40:
                                java.lang.String r5 = "href"
                                boolean r4 = r4.equals(r5)
                                if (r4 != 0) goto L49
                                goto L4a
                            L49:
                                r7 = 0
                            L4a:
                                switch(r7) {
                                    case 0: goto L64;
                                    case 1: goto L5b;
                                    case 2: goto L56;
                                    case 3: goto L51;
                                    default: goto L4d;
                                }
                            L4d:
                                r10.m15968catch()
                                goto L9
                            L51:
                                java.lang.String r3 = r10.m15973goto()
                                goto L9
                            L56:
                                java.lang.String r2 = r10.m15973goto()
                                goto L9
                            L5b:
                                java.lang.String r0 = r10.m15973goto()
                                v59$c r0 = v59.c.fromString(r0)
                                goto L9
                            L64:
                                java.lang.String r1 = r10.m15973goto()
                                goto L9
                            L69:
                                r10.m15974if()
                                if (r0 == 0) goto L79
                                if (r1 == 0) goto L79
                                if (r2 != 0) goto L73
                                goto L79
                            L73:
                                v59 r10 = new v59
                                r10.<init>(r0, r1, r2, r3)
                                return r10
                            L79:
                                java.lang.StringBuilder r10 = new java.lang.StringBuilder
                                java.lang.String r3 = "Next fields must not be null:"
                                r10.<init>(r3)
                                java.lang.String r3 = " "
                                if (r0 != 0) goto L8a
                                r10.append(r3)
                                r10.append(r5)
                            L8a:
                                if (r1 != 0) goto L94
                                r10.append(r3)
                                java.lang.String r0 = "url"
                                r10.append(r0)
                            L94:
                                if (r2 != 0) goto L9c
                                r10.append(r3)
                                r10.append(r6)
                            L9c:
                                java.io.IOException r0 = new java.io.IOException
                                java.lang.String r10 = r10.toString()
                                r0.<init>(r10)
                                throw r0
                            */
                            throw new UnsupportedOperationException("Method not decompiled: defpackage.d89.mo1839do(java.lang.Object):java.lang.Object");
                        }
                    };
                    LinkedList linkedList2 = new LinkedList();
                    w79 w79Var = v79Var.f40238do;
                    w79Var.f41785do.mo517do();
                    w79Var.f41787if.push(bf3.BEGIN_ARRAY);
                    while (v79Var.m15972for()) {
                        try {
                            v79Var.m15975new();
                            linkedList2.add(d89Var.mo1839do(v79Var));
                        } catch (y79 e) {
                            v79Var.m15966break();
                            k2f.f19768new.mo8767import(e);
                        } catch (Exception e2) {
                            v79Var.m15966break();
                            int i2 = e8d.f9711do;
                            jr3.m8595if(e2);
                        }
                    }
                    w79 w79Var2 = v79Var.f40238do;
                    w79Var2.f41785do.endArray();
                    e8d.m5045do(bf3.BEGIN_ARRAY, w79Var2.f41787if.pop());
                    emptyList = linkedList2;
                } else if ("counts".equals(m15971else)) {
                    v79Var.m15970do();
                    int i3 = -1;
                    int i4 = -1;
                    int i5 = -1;
                    while (v79Var.m15972for()) {
                        String m15971else2 = v79Var.m15971else();
                        if ("tracks".equals(m15971else2)) {
                            i3 = v79Var.m15967case();
                        } else if ("directAlbums".equals(m15971else2)) {
                            i4 = v79Var.m15967case();
                        } else if ("alsoAlbums".equals(m15971else2)) {
                            i5 = v79Var.m15967case();
                        } else {
                            v79Var.m15968catch();
                        }
                    }
                    v79Var.m15974if();
                    aVar = new l59.a(i3, i4, i5, 0, 0, 0, 56);
                } else if ("available".equals(m15971else)) {
                    z = v79Var.m15977try();
                } else if ("decomposed".equals(m15971else)) {
                    LinkedList linkedList3 = new LinkedList();
                    w79 w79Var3 = v79Var.f40238do;
                    w79Var3.f41785do.mo517do();
                    w79Var3.f41787if.push(bf3.BEGIN_ARRAY);
                    while (v79Var.m15972for()) {
                        try {
                            v79Var.m15975new();
                            try {
                                linkedList3.add(f9743do.m5064new(v79Var, v79Var.m15976this() == bf3.STRING ? v79Var.m15973goto() : null));
                            } catch (Exception e3) {
                                throw new y79(e3);
                                break loop0;
                            }
                        } catch (y79 e4) {
                            v79Var.m15966break();
                            k2f.f19768new.mo8767import(e4);
                        } catch (Exception e5) {
                            v79Var.m15966break();
                            int i6 = e8d.f9711do;
                            jr3.m8595if(e5);
                        }
                    }
                    w79 w79Var4 = v79Var.f40238do;
                    w79Var4.f41785do.endArray();
                    e8d.m5045do(bf3.BEGIN_ARRAY, w79Var4.f41787if.pop());
                    linkedList = linkedList3;
                } else if ("error".equals(m15971else)) {
                    str3 = v79Var.m15973goto();
                } else if ("childContent".equals(m15971else)) {
                    z4 = v79Var.m15977try();
                } else {
                    v79Var.m15968catch();
                }
                none = mo1839do;
            }
        }
        v79Var.m15974if();
        if (!g8d.g(str3)) {
            k2f.f19768new.mo8777while("unknown artist: %s, error: %s", str4, str3);
            return l59.f21601class;
        }
        if (g8d.l(str4)) {
            f9d.m5797for(str5, "arg is null");
            str2 = g8d.m6494super(str5);
        } else {
            str2 = str4;
        }
        return new l59(str2, g8d.m6493strictfp(str4), str5, z2, z3, z, null, i, linkedList, str, aVar, emptyList, none, z4);
    }
}
