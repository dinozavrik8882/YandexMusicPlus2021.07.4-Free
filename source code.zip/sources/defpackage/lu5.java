package defpackage;

/* loaded from: classes2.dex */
public interface lu5<T> extends nv5 {
    Object b(wm5<? super T> wm5Var);

    /* renamed from: import, reason: not valid java name */
    T mo9982import();
}
