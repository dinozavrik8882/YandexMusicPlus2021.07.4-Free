package defpackage;

/* loaded from: classes2.dex */
public final class d8e implements e8e {

    /* renamed from: do, reason: not valid java name */
    public final gie f8143do;

    public d8e(gie gieVar) {
        jp5.m8570try(gieVar, "modalView");
        this.f8143do = gieVar;
    }
}
