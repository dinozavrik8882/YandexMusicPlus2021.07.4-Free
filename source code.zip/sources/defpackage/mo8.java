package defpackage;

/* loaded from: classes2.dex */
public final class mo8 extends Exception {

    /* renamed from: catch, reason: not valid java name */
    public static final a f24379catch = new a(null);

    /* renamed from: class, reason: not valid java name */
    public final b f24380class;

    /* renamed from: const, reason: not valid java name */
    public final String f24381const;

    /* loaded from: classes2.dex */
    public static final class a {
        public a(ep5 ep5Var) {
        }

        /* renamed from: do, reason: not valid java name */
        public final mo8 m10536do(w68 w68Var, Throwable th) {
            jp5.m8570try(w68Var, "queueDescriptor");
            b bVar = b.CONTENT_ERROR;
            t78 t78Var = w68Var.f41757for;
            StringBuilder sb = new StringBuilder();
            sb.append(t78Var.m14694goto());
            sb.append('(');
            sb.append((Object) t78Var.m14691else());
            sb.append(')');
            return new mo8(bVar, sb.toString(), th);
        }
    }

    /* loaded from: classes2.dex */
    public enum b {
        CONTENT_ERROR,
        STATION_ERROR
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public mo8(b bVar, String str, Throwable th) {
        super(th);
        jp5.m8570try(bVar, "reason");
        jp5.m8570try(str, "technicalDescription");
        this.f24380class = bVar;
        this.f24381const = str;
    }
}
