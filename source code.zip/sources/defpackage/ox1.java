package defpackage;

import android.os.IInterface;
import android.os.RemoteException;

/* loaded from: classes.dex */
public interface ox1 extends IInterface {
    hx1 H0(hx1 hx1Var, String str, int i) throws RemoteException;

    hx1 I(hx1 hx1Var, String str, int i) throws RemoteException;

    hx1 X0(hx1 hx1Var, String str, boolean z, long j) throws RemoteException;

    int Z(hx1 hx1Var, String str, boolean z) throws RemoteException;

    /* renamed from: do */
    int mo11244do() throws RemoteException;

    /* renamed from: goto */
    hx1 mo11245goto(hx1 hx1Var, String str, int i, hx1 hx1Var2) throws RemoteException;

    int u0(hx1 hx1Var, String str, boolean z) throws RemoteException;
}
