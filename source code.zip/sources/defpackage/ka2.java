package defpackage;

/* loaded from: classes.dex */
public interface ka2 {
    /* renamed from: do */
    boolean mo2703do(Class<?> cls);

    /* renamed from: if */
    ha2 mo2704if(Class<?> cls);
}
