package defpackage;

import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;

/* loaded from: classes.dex */
public abstract class xv implements Closeable {

    /* renamed from: catch, reason: not valid java name */
    public static final String[] f44582catch = new String[128];

    /* renamed from: class, reason: not valid java name */
    public int f44583class;

    /* renamed from: const, reason: not valid java name */
    public int[] f44584const = new int[32];

    /* renamed from: final, reason: not valid java name */
    public String[] f44585final = new String[32];

    /* renamed from: super, reason: not valid java name */
    public int[] f44586super = new int[32];

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: do, reason: not valid java name */
        public final String[] f44587do;

        /* renamed from: if, reason: not valid java name */
        public final ba6 f44588if;

        public a(String[] strArr, ba6 ba6Var) {
            this.f44587do = strArr;
            this.f44588if = ba6Var;
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x003a A[Catch: IOException -> 0x006b, TryCatch #0 {IOException -> 0x006b, blocks: (B:2:0x0000, B:3:0x000a, B:5:0x000d, B:7:0x001e, B:9:0x0026, B:13:0x0042, B:15:0x003a, B:16:0x003d, B:27:0x0047, B:29:0x004a, B:32:0x0059), top: B:1:0x0000 }] */
        /* renamed from: do, reason: not valid java name */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public static xv.a m17337do(java.lang.String... r12) {
            /*
                int r0 = r12.length     // Catch: java.io.IOException -> L6b
                t96[] r0 = new defpackage.t96[r0]     // Catch: java.io.IOException -> L6b
                p96 r1 = new p96     // Catch: java.io.IOException -> L6b
                r1.<init>()     // Catch: java.io.IOException -> L6b
                r2 = 0
                r3 = r2
            La:
                int r4 = r12.length     // Catch: java.io.IOException -> L6b
                if (r3 >= r4) goto L59
                r4 = r12[r3]     // Catch: java.io.IOException -> L6b
                java.lang.String[] r5 = defpackage.xv.f44582catch     // Catch: java.io.IOException -> L6b
                r6 = 34
                r1.c0(r6)     // Catch: java.io.IOException -> L6b
                int r7 = r4.length()     // Catch: java.io.IOException -> L6b
                r8 = r2
                r9 = r8
            L1c:
                if (r8 >= r7) goto L45
                char r10 = r4.charAt(r8)     // Catch: java.io.IOException -> L6b
                r11 = 128(0x80, float:1.8E-43)
                if (r10 >= r11) goto L2b
                r10 = r5[r10]     // Catch: java.io.IOException -> L6b
                if (r10 != 0) goto L38
                goto L42
            L2b:
                r11 = 8232(0x2028, float:1.1535E-41)
                if (r10 != r11) goto L32
                java.lang.String r10 = "\\u2028"
                goto L38
            L32:
                r11 = 8233(0x2029, float:1.1537E-41)
                if (r10 != r11) goto L42
                java.lang.String r10 = "\\u2029"
            L38:
                if (r9 >= r8) goto L3d
                r1.i0(r4, r9, r8)     // Catch: java.io.IOException -> L6b
            L3d:
                r1.h0(r10)     // Catch: java.io.IOException -> L6b
                int r9 = r8 + 1
            L42:
                int r8 = r8 + 1
                goto L1c
            L45:
                if (r9 >= r7) goto L4a
                r1.i0(r4, r9, r7)     // Catch: java.io.IOException -> L6b
            L4a:
                r1.c0(r6)     // Catch: java.io.IOException -> L6b
                r1.readByte()     // Catch: java.io.IOException -> L6b
                t96 r4 = r1.q()     // Catch: java.io.IOException -> L6b
                r0[r3] = r4     // Catch: java.io.IOException -> L6b
                int r3 = r3 + 1
                goto La
            L59:
                xv$a r1 = new xv$a     // Catch: java.io.IOException -> L6b
                java.lang.Object r12 = r12.clone()     // Catch: java.io.IOException -> L6b
                java.lang.String[] r12 = (java.lang.String[]) r12     // Catch: java.io.IOException -> L6b
                ba6$a r2 = defpackage.ba6.f3270catch     // Catch: java.io.IOException -> L6b
                ba6 r0 = r2.m1882for(r0)     // Catch: java.io.IOException -> L6b
                r1.<init>(r12, r0)     // Catch: java.io.IOException -> L6b
                return r1
            L6b:
                r12 = move-exception
                java.lang.AssertionError r0 = new java.lang.AssertionError
                r0.<init>(r12)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: xv.a.m17337do(java.lang.String[]):xv$a");
        }
    }

    /* loaded from: classes.dex */
    public enum b {
        BEGIN_ARRAY,
        END_ARRAY,
        BEGIN_OBJECT,
        END_OBJECT,
        NAME,
        STRING,
        NUMBER,
        BOOLEAN,
        NULL,
        END_DOCUMENT
    }

    static {
        for (int i = 0; i <= 31; i++) {
            f44582catch[i] = String.format("\\u%04x", Integer.valueOf(i));
        }
        String[] strArr = f44582catch;
        strArr[34] = "\\\"";
        strArr[92] = "\\\\";
        strArr[9] = "\\t";
        strArr[8] = "\\b";
        strArr[10] = "\\n";
        strArr[13] = "\\r";
        strArr[12] = "\\f";
    }

    public final wv b(String str) throws wv {
        StringBuilder v = by.v(str, " at path ");
        v.append(m17330goto());
        throw new wv(v.toString());
    }

    /* renamed from: do, reason: not valid java name */
    public abstract void mo17328do() throws IOException;

    public abstract void endArray() throws IOException;

    public abstract void endObject() throws IOException;

    /* renamed from: finally, reason: not valid java name */
    public abstract b mo17329finally() throws IOException;

    /* renamed from: goto, reason: not valid java name */
    public final String m17330goto() {
        int i = this.f44583class;
        int[] iArr = this.f44584const;
        String[] strArr = this.f44585final;
        int[] iArr2 = this.f44586super;
        StringBuilder q = by.q('$');
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = iArr[i2];
            if (i3 == 1 || i3 == 2) {
                q.append('[');
                q.append(iArr2[i2]);
                q.append(']');
            } else if (i3 == 3 || i3 == 4 || i3 == 5) {
                q.append('.');
                if (strArr[i2] != null) {
                    q.append(strArr[i2]);
                }
            }
        }
        return q.toString();
    }

    public abstract boolean hasNext() throws IOException;

    /* renamed from: implements, reason: not valid java name */
    public abstract int mo17331implements(a aVar) throws IOException;

    /* renamed from: import, reason: not valid java name */
    public abstract double mo17332import() throws IOException;

    /* renamed from: interface, reason: not valid java name */
    public final void m17333interface(int i) {
        int i2 = this.f44583class;
        int[] iArr = this.f44584const;
        if (i2 == iArr.length) {
            if (i2 == 256) {
                StringBuilder r = by.r("Nesting too deep at ");
                r.append(m17330goto());
                throw new vv(r.toString());
            }
            this.f44584const = Arrays.copyOf(iArr, iArr.length * 2);
            String[] strArr = this.f44585final;
            this.f44585final = (String[]) Arrays.copyOf(strArr, strArr.length * 2);
            int[] iArr2 = this.f44586super;
            this.f44586super = Arrays.copyOf(iArr2, iArr2.length * 2);
        }
        int[] iArr3 = this.f44584const;
        int i3 = this.f44583class;
        this.f44583class = i3 + 1;
        iArr3[i3] = i;
    }

    /* renamed from: new, reason: not valid java name */
    public abstract void mo17334new() throws IOException;

    public abstract String nextName() throws IOException;

    public abstract String nextString() throws IOException;

    /* renamed from: return, reason: not valid java name */
    public abstract int mo17335return() throws IOException;

    public abstract void skipValue() throws IOException;

    /* renamed from: super, reason: not valid java name */
    public abstract boolean mo17336super() throws IOException;

    public abstract void throwables() throws IOException;
}
