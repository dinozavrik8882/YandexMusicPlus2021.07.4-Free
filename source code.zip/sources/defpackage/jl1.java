package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class jl1 extends fu1 {
    public static final Parcelable.Creator<jl1> CREATOR = new il1();

    /* renamed from: catch, reason: not valid java name */
    public final float f18827catch;

    /* renamed from: class, reason: not valid java name */
    public final float f18828class;

    /* renamed from: const, reason: not valid java name */
    public final float f18829const;

    public jl1(float f, float f2, float f3) {
        this.f18827catch = f;
        this.f18828class = f2;
        this.f18829const = f3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof jl1)) {
            return false;
        }
        jl1 jl1Var = (jl1) obj;
        return this.f18827catch == jl1Var.f18827catch && this.f18828class == jl1Var.f18828class && this.f18829const == jl1Var.f18829const;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f18827catch), Float.valueOf(this.f18828class), Float.valueOf(this.f18829const)});
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        int e = hg1.e(parcel, 20293);
        float f = this.f18827catch;
        hg1.i(parcel, 2, 4);
        parcel.writeFloat(f);
        float f2 = this.f18828class;
        hg1.i(parcel, 3, 4);
        parcel.writeFloat(f2);
        float f3 = this.f18829const;
        hg1.i(parcel, 4, 4);
        parcel.writeFloat(f3);
        hg1.j(parcel, e);
    }
}
