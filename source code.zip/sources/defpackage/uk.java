package defpackage;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import defpackage.rl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes.dex */
public class uk extends w3 {

    /* renamed from: const, reason: not valid java name */
    public final rl f38973const;

    /* renamed from: final, reason: not valid java name */
    public final b f38974final;

    /* renamed from: import, reason: not valid java name */
    public c f38975import;

    /* renamed from: native, reason: not valid java name */
    public ListView f38976native;

    /* renamed from: public, reason: not valid java name */
    public boolean f38977public;

    /* renamed from: return, reason: not valid java name */
    public long f38978return;

    /* renamed from: static, reason: not valid java name */
    public final Handler f38979static;

    /* renamed from: super, reason: not valid java name */
    public TextView f38980super;

    /* renamed from: throw, reason: not valid java name */
    public ql f38981throw;

    /* renamed from: while, reason: not valid java name */
    public ArrayList<rl.f> f38982while;

    /* loaded from: classes.dex */
    public class a extends Handler {
        public a() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                return;
            }
            uk ukVar = uk.this;
            List list = (List) message.obj;
            Objects.requireNonNull(ukVar);
            ukVar.f38978return = SystemClock.uptimeMillis();
            ukVar.f38982while.clear();
            ukVar.f38982while.addAll(list);
            ukVar.f38975import.notifyDataSetChanged();
        }
    }

    /* loaded from: classes.dex */
    public final class b extends rl.a {
        public b() {
        }

        @Override // rl.a
        /* renamed from: else */
        public void mo1053else(rl rlVar, rl.f fVar) {
            uk.this.m15629new();
        }

        @Override // rl.a
        /* renamed from: goto */
        public void mo1055goto(rl rlVar, rl.f fVar) {
            uk.this.dismiss();
        }

        @Override // rl.a
        /* renamed from: new */
        public void mo1057new(rl rlVar, rl.f fVar) {
            uk.this.m15629new();
        }

        @Override // rl.a
        /* renamed from: try */
        public void mo1059try(rl rlVar, rl.f fVar) {
            uk.this.m15629new();
        }
    }

    /* loaded from: classes.dex */
    public final class c extends ArrayAdapter<rl.f> implements AdapterView.OnItemClickListener {

        /* renamed from: catch, reason: not valid java name */
        public final LayoutInflater f38985catch;

        /* renamed from: class, reason: not valid java name */
        public final Drawable f38986class;

        /* renamed from: const, reason: not valid java name */
        public final Drawable f38987const;

        /* renamed from: final, reason: not valid java name */
        public final Drawable f38988final;

        /* renamed from: super, reason: not valid java name */
        public final Drawable f38989super;

        public c(Context context, List<rl.f> list) {
            super(context, 0, list);
            this.f38985catch = LayoutInflater.from(context);
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.mediaRouteDefaultIconDrawable, R.attr.mediaRouteTvIconDrawable, R.attr.mediaRouteSpeakerIconDrawable, R.attr.mediaRouteSpeakerGroupIconDrawable});
            this.f38986class = obtainStyledAttributes.getDrawable(0);
            this.f38987const = obtainStyledAttributes.getDrawable(1);
            this.f38988final = obtainStyledAttributes.getDrawable(2);
            this.f38989super = obtainStyledAttributes.getDrawable(3);
            obtainStyledAttributes.recycle();
        }

        @Override // android.widget.BaseAdapter, android.widget.ListAdapter
        public boolean areAllItemsEnabled() {
            return false;
        }

        /* JADX WARN: Code restructure failed: missing block: B:29:0x007f, code lost:
        
            if (r0 != null) goto L35;
         */
        @Override // android.widget.ArrayAdapter, android.widget.Adapter
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public android.view.View getView(int r7, android.view.View r8, android.view.ViewGroup r9) {
            /*
                r6 = this;
                r0 = 0
                if (r8 != 0) goto Lc
                android.view.LayoutInflater r8 = r6.f38985catch
                r1 = 2131624221(0x7f0e011d, float:1.8875616E38)
                android.view.View r8 = r8.inflate(r1, r9, r0)
            Lc:
                java.lang.Object r7 = r6.getItem(r7)
                rl$f r7 = (rl.f) r7
                r9 = 2131428381(0x7f0b041d, float:1.8478405E38)
                android.view.View r9 = r8.findViewById(r9)
                android.widget.TextView r9 = (android.widget.TextView) r9
                r1 = 2131428379(0x7f0b041b, float:1.84784E38)
                android.view.View r1 = r8.findViewById(r1)
                android.widget.TextView r1 = (android.widget.TextView) r1
                java.lang.String r2 = r7.f32629new
                r9.setText(r2)
                java.lang.String r2 = r7.f32637try
                int r3 = r7.f32625goto
                r4 = 2
                r5 = 1
                if (r3 == r4) goto L36
                if (r3 != r5) goto L34
                goto L36
            L34:
                r3 = r0
                goto L37
            L36:
                r3 = r5
            L37:
                if (r3 == 0) goto L4b
                boolean r3 = android.text.TextUtils.isEmpty(r2)
                if (r3 != 0) goto L4b
                r3 = 80
                r9.setGravity(r3)
                r1.setVisibility(r0)
                r1.setText(r2)
                goto L5a
            L4b:
                r0 = 16
                r9.setGravity(r0)
                r9 = 8
                r1.setVisibility(r9)
                java.lang.String r9 = ""
                r1.setText(r9)
            L5a:
                boolean r9 = r7.f32622else
                r8.setEnabled(r9)
                r9 = 2131428380(0x7f0b041c, float:1.8478403E38)
                android.view.View r9 = r8.findViewById(r9)
                android.widget.ImageView r9 = (android.widget.ImageView) r9
                if (r9 == 0) goto Lb4
                android.net.Uri r0 = r7.f32617case
                if (r0 == 0) goto L99
                android.content.Context r1 = r6.getContext()     // Catch: java.io.IOException -> L82
                android.content.ContentResolver r1 = r1.getContentResolver()     // Catch: java.io.IOException -> L82
                java.io.InputStream r1 = r1.openInputStream(r0)     // Catch: java.io.IOException -> L82
                r2 = 0
                android.graphics.drawable.Drawable r0 = android.graphics.drawable.Drawable.createFromStream(r1, r2)     // Catch: java.io.IOException -> L82
                if (r0 == 0) goto L99
                goto Lb1
            L82:
                r1 = move-exception
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "Failed to load "
                r2.append(r3)
                r2.append(r0)
                java.lang.String r0 = r2.toString()
                java.lang.String r2 = "MediaRouteChooserDialog"
                android.util.Log.w(r2, r0, r1)
            L99:
                int r0 = r7.f32620const
                if (r0 == r5) goto Lae
                if (r0 == r4) goto Lab
                boolean r7 = r7.m13376try()
                if (r7 == 0) goto La8
                android.graphics.drawable.Drawable r7 = r6.f38989super
                goto Lb0
            La8:
                android.graphics.drawable.Drawable r7 = r6.f38986class
                goto Lb0
            Lab:
                android.graphics.drawable.Drawable r7 = r6.f38988final
                goto Lb0
            Lae:
                android.graphics.drawable.Drawable r7 = r6.f38987const
            Lb0:
                r0 = r7
            Lb1:
                r9.setImageDrawable(r0)
            Lb4:
                return r8
            */
            throw new UnsupportedOperationException("Method not decompiled: uk.c.getView(int, android.view.View, android.view.ViewGroup):android.view.View");
        }

        @Override // android.widget.BaseAdapter, android.widget.ListAdapter
        public boolean isEnabled(int i) {
            return getItem(i).f32622else;
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            rl.f item = getItem(i);
            if (item.f32622else) {
                item.m13367class();
                uk.this.dismiss();
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class d implements Comparator<rl.f> {

        /* renamed from: catch, reason: not valid java name */
        public static final d f38991catch = new d();

        @Override // java.util.Comparator
        public int compare(rl.f fVar, rl.f fVar2) {
            return fVar.f32629new.compareToIgnoreCase(fVar2.f32629new);
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public uk(android.content.Context r2) {
        /*
            r1 = this;
            r0 = 0
            android.content.Context r2 = defpackage.jl.m8494do(r2, r0, r0)
            int r0 = defpackage.jl.m8498if(r2)
            r1.<init>(r2, r0)
            ql r2 = defpackage.ql.f30874do
            r1.f38981throw = r2
            uk$a r2 = new uk$a
            r2.<init>()
            r1.f38979static = r2
            android.content.Context r2 = r1.getContext()
            rl r2 = defpackage.rl.m13332try(r2)
            r1.f38973const = r2
            uk$b r2 = new uk$b
            r2.<init>()
            r1.f38974final = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.uk.<init>(android.content.Context):void");
    }

    /* renamed from: new, reason: not valid java name */
    public void m15629new() {
        if (this.f38977public) {
            ArrayList arrayList = new ArrayList(this.f38973const.m13339else());
            int size = arrayList.size();
            while (true) {
                int i = size - 1;
                if (size <= 0) {
                    break;
                }
                rl.f fVar = (rl.f) arrayList.get(i);
                if (!(!fVar.m13374new() && fVar.f32622else && fVar.m13372goto(this.f38981throw))) {
                    arrayList.remove(i);
                }
                size = i;
            }
            Collections.sort(arrayList, d.f38991catch);
            if (SystemClock.uptimeMillis() - this.f38978return < 300) {
                this.f38979static.removeMessages(1);
                Handler handler = this.f38979static;
                handler.sendMessageAtTime(handler.obtainMessage(1, arrayList), this.f38978return + 300);
            } else {
                this.f38978return = SystemClock.uptimeMillis();
                this.f38982while.clear();
                this.f38982while.addAll(arrayList);
                this.f38975import.notifyDataSetChanged();
            }
        }
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f38977public = true;
        this.f38973const.m13338do(this.f38981throw, this.f38974final, 1);
        m15629new();
    }

    @Override // defpackage.w3, android.app.Dialog
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.mr_chooser_dialog);
        this.f38982while = new ArrayList<>();
        this.f38975import = new c(getContext(), this.f38982while);
        ListView listView = (ListView) findViewById(R.id.mr_chooser_list);
        this.f38976native = listView;
        listView.setAdapter((ListAdapter) this.f38975import);
        this.f38976native.setOnItemClickListener(this.f38975import);
        this.f38976native.setEmptyView(findViewById(android.R.id.empty));
        this.f38980super = (TextView) findViewById(R.id.mr_chooser_title);
        getWindow().setLayout(sk.m14280try(getContext()), -2);
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onDetachedFromWindow() {
        this.f38977public = false;
        this.f38973const.m13333break(this.f38974final);
        this.f38979static.removeMessages(1);
        super.onDetachedFromWindow();
    }

    @Override // defpackage.w3, android.app.Dialog
    public void setTitle(int i) {
        this.f38980super.setText(i);
    }

    @Override // defpackage.w3, android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        this.f38980super.setText(charSequence);
    }

    /* renamed from: try, reason: not valid java name */
    public void m15630try(ql qlVar) {
        if (qlVar == null) {
            throw new IllegalArgumentException("selector must not be null");
        }
        if (this.f38981throw.equals(qlVar)) {
            return;
        }
        this.f38981throw = qlVar;
        if (this.f38977public) {
            this.f38973const.m13333break(this.f38974final);
            this.f38973const.m13338do(qlVar, this.f38974final, 1);
        }
        m15629new();
    }
}
