package defpackage;

import android.database.Cursor;
import android.net.Uri;

/* loaded from: classes2.dex */
public interface ggc<T> {
    /* renamed from: do */
    String[] mo575do(String str);

    /* renamed from: for */
    String mo576for();

    /* renamed from: if */
    ue9<Cursor, T> mo577if();

    /* renamed from: new */
    Uri mo578new();

    /* renamed from: try */
    String mo579try();
}
