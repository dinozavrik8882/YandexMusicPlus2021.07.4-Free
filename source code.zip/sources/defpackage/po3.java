package defpackage;

/* loaded from: classes.dex */
public class po3 {

    /* renamed from: do, reason: not valid java name */
    public final to3 f29244do;

    /* renamed from: for, reason: not valid java name */
    public final String f29245for;

    /* renamed from: if, reason: not valid java name */
    public final String f29246if;

    /* renamed from: new, reason: not valid java name */
    public final long f29247new;

    /* renamed from: try, reason: not valid java name */
    public long f29248try;

    public po3(to3 to3Var, String str, String str2, long j, long j2) {
        this.f29244do = to3Var;
        this.f29246if = str;
        this.f29245for = str2;
        this.f29247new = j;
        this.f29248try = j2;
    }

    public String toString() {
        StringBuilder r = by.r("BillingInfo{type=");
        r.append(this.f29244do);
        r.append("sku='");
        r.append(this.f29246if);
        r.append("'purchaseToken='");
        r.append(this.f29245for);
        r.append("'purchaseTime=");
        r.append(this.f29247new);
        r.append("sendTime=");
        return by.a(r, this.f29248try, "}");
    }
}
