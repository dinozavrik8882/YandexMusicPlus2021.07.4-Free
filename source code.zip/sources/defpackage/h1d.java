package defpackage;

import android.content.Context;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class h1d {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f14541do;

    /* renamed from: case, reason: not valid java name */
    public final f1d f14542case;

    /* renamed from: for, reason: not valid java name */
    public final el5 f14543for;

    /* renamed from: if, reason: not valid java name */
    public final el5 f14544if;

    /* renamed from: new, reason: not valid java name */
    public final nz5<a> f14545new;

    /* renamed from: try, reason: not valid java name */
    public jr2 f14546try;

    /* loaded from: classes2.dex */
    public enum a {
        UNDEFINED,
        AVAILABLE,
        IN_PROGRESS,
        DOWNLOADED,
        ERROR
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements bo5<kr2> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ Context f14547catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(Context context) {
            super(0);
            this.f14547catch = context;
        }

        @Override // defpackage.bo5
        public kr2 invoke() {
            ds2 ds2Var;
            Context context = this.f14547catch;
            synchronized (el2.class) {
                if (el2.f10235do == null) {
                    Context applicationContext = context.getApplicationContext();
                    if (applicationContext != null) {
                        context = applicationContext;
                    }
                    pr2 pr2Var = new pr2(context);
                    el2.r(pr2Var, pr2.class);
                    el2.f10235do = new ds2(pr2Var);
                }
                ds2Var = el2.f10235do;
            }
            return ds2Var.f8987case.a();
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[2];
        wp5 wp5Var = new wp5(dq5.m4763do(h1d.class), "playbackControl", "getPlaybackControl()Lru/yandex/music/common/media/control/PlaybackControl;");
        Objects.requireNonNull(dq5.f8909do);
        mr5VarArr[0] = wp5Var;
        f14541do = mr5VarArr;
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [f1d] */
    public h1d(Context context) {
        jp5.m8570try(context, "context");
        iz3 l3 = dn3.l3(oa8.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        jp5.m8570try(f14541do[0], "prop");
        this.f14544if = dn3.h1(cz3Var);
        this.f14543for = dn3.h1(new b(context));
        this.f14545new = c06.m2489do(a.UNDEFINED);
        this.f14542case = new zx2() { // from class: f1d
            @Override // defpackage.zx2
            /* renamed from: do, reason: not valid java name */
            public final void mo5570do(Object obj) {
            }
        };
    }

    /* renamed from: do, reason: not valid java name */
    public final kr2 m6968do() {
        return (kr2) this.f14543for.getValue();
    }

    /* renamed from: if, reason: not valid java name */
    public final void m6969if() {
        this.f14545new.mo1617this(a.ERROR);
        this.f14546try = null;
        m6968do().mo9201new(this.f14542case);
    }
}
