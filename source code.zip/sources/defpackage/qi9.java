package defpackage;

/* loaded from: classes2.dex */
public interface qi9 {
    /* renamed from: do */
    void mo12137do();

    /* renamed from: if */
    void mo12138if();
}
