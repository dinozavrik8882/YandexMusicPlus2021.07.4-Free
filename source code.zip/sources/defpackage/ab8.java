package defpackage;

/* loaded from: classes2.dex */
public final /* synthetic */ class ab8 extends ip5 implements mo5<Throwable, pl5> {
    public ab8(ac8 ac8Var) {
        super(1, ac8Var, ac8.class, "notifyError", "notifyError(Ljava/lang/Throwable;)V", 0);
    }

    @Override // defpackage.mo5
    public pl5 invoke(Throwable th) {
        Throwable th2 = th;
        jp5.m8570try(th2, "p0");
        ((ac8) this.receiver).m483if(th2);
        return pl5.f29126do;
    }
}
