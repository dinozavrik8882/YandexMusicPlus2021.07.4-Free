package defpackage;

/* loaded from: classes.dex */
public final class ct4 {

    /* renamed from: do, reason: not valid java name */
    public final String f7416do;

    /* renamed from: if, reason: not valid java name */
    public final String f7417if;

    public ct4(String str, String str2) {
        jp5.m8570try(str, "url");
        jp5.m8570try(str2, "token");
        this.f7416do = str;
        this.f7417if = str2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ct4)) {
            return false;
        }
        ct4 ct4Var = (ct4) obj;
        return jp5.m8563do(this.f7416do, ct4Var.f7416do) && jp5.m8563do(this.f7417if, ct4Var.f7417if);
    }

    public int hashCode() {
        return this.f7417if.hashCode() + (this.f7416do.hashCode() * 31);
    }

    public String toString() {
        StringBuilder r = by.r("PreGetData(url=");
        r.append(this.f7416do);
        r.append(", token=");
        return by.c(r, this.f7417if, ')');
    }
}
