package defpackage;

import java.util.List;

/* loaded from: classes.dex */
public class gt extends kt<ps, ps> {
    public gt(List<gw<ps>> list) {
        super((List) list);
    }

    @Override // defpackage.jt
    /* renamed from: do */
    public wr mo1502do() {
        return new js(this.f20995do);
    }
}
