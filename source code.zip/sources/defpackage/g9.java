package defpackage;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.motion.widget.MotionLayout;
import java.util.HashMap;

/* loaded from: classes.dex */
public class g9 extends h9 {

    /* renamed from: case, reason: not valid java name */
    public String f13245case = null;

    /* renamed from: else, reason: not valid java name */
    public int f13249else = -1;

    /* renamed from: goto, reason: not valid java name */
    public int f13250goto = 0;

    /* renamed from: this, reason: not valid java name */
    public float f13251this = Float.NaN;

    /* renamed from: break, reason: not valid java name */
    public float f13244break = Float.NaN;

    /* renamed from: catch, reason: not valid java name */
    public float f13246catch = Float.NaN;

    /* renamed from: class, reason: not valid java name */
    public float f13247class = Float.NaN;

    /* renamed from: const, reason: not valid java name */
    public int f13248const = 0;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: do, reason: not valid java name */
        public static SparseIntArray f13252do;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f13252do = sparseIntArray;
            sparseIntArray.append(4, 1);
            f13252do.append(2, 2);
            f13252do.append(11, 3);
            f13252do.append(0, 4);
            f13252do.append(1, 5);
            f13252do.append(8, 6);
            f13252do.append(9, 7);
            f13252do.append(3, 9);
            f13252do.append(10, 8);
            f13252do.append(7, 11);
            f13252do.append(6, 12);
            f13252do.append(5, 10);
        }
    }

    @Override // defpackage.a9
    /* renamed from: do */
    public void mo348do(HashMap<String, q9> hashMap) {
    }

    @Override // defpackage.a9
    /* renamed from: for */
    public void mo349for(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, kb.f20155else);
        SparseIntArray sparseIntArray = a.f13252do;
        int indexCount = obtainStyledAttributes.getIndexCount();
        for (int i = 0; i < indexCount; i++) {
            int index = obtainStyledAttributes.getIndex(i);
            switch (a.f13252do.get(index)) {
                case 1:
                    if (MotionLayout.f1521package) {
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.f521if);
                        this.f521if = resourceId;
                        if (resourceId == -1) {
                            this.f520for = obtainStyledAttributes.getString(index);
                            break;
                        } else {
                            break;
                        }
                    } else if (obtainStyledAttributes.peekValue(index).type == 3) {
                        this.f520for = obtainStyledAttributes.getString(index);
                        break;
                    } else {
                        this.f521if = obtainStyledAttributes.getResourceId(index, this.f521if);
                        break;
                    }
                case 2:
                    this.f519do = obtainStyledAttributes.getInt(index, this.f519do);
                    break;
                case 3:
                    if (obtainStyledAttributes.peekValue(index).type == 3) {
                        this.f13245case = obtainStyledAttributes.getString(index);
                        break;
                    } else {
                        this.f13245case = u8.f38502if[obtainStyledAttributes.getInteger(index, 0)];
                        break;
                    }
                case 4:
                    this.f14857try = obtainStyledAttributes.getInteger(index, this.f14857try);
                    break;
                case 5:
                    this.f13250goto = obtainStyledAttributes.getInt(index, this.f13250goto);
                    break;
                case 6:
                    this.f13246catch = obtainStyledAttributes.getFloat(index, this.f13246catch);
                    break;
                case 7:
                    this.f13247class = obtainStyledAttributes.getFloat(index, this.f13247class);
                    break;
                case 8:
                    float f = obtainStyledAttributes.getFloat(index, this.f13244break);
                    this.f13251this = f;
                    this.f13244break = f;
                    break;
                case 9:
                    this.f13248const = obtainStyledAttributes.getInt(index, this.f13248const);
                    break;
                case 10:
                    this.f13249else = obtainStyledAttributes.getInt(index, this.f13249else);
                    break;
                case 11:
                    this.f13251this = obtainStyledAttributes.getFloat(index, this.f13251this);
                    break;
                case 12:
                    this.f13244break = obtainStyledAttributes.getFloat(index, this.f13244break);
                    break;
                default:
                    StringBuilder r = by.r("unused attribute 0x");
                    r.append(Integer.toHexString(index));
                    r.append("   ");
                    r.append(a.f13252do.get(index));
                    Log.e("KeyPosition", r.toString());
                    break;
            }
        }
        if (this.f519do == -1) {
            Log.e("KeyPosition", "no frame position");
        }
    }
}
