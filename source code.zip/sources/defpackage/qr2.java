package defpackage;

import android.content.Context;
import java.util.Objects;

/* loaded from: classes.dex */
public final class qr2 implements ix2<kr2> {

    /* renamed from: do, reason: not valid java name */
    public final ix2 f31197do;

    /* renamed from: if, reason: not valid java name */
    public final /* synthetic */ int f31198if = 0;

    public qr2(ix2<nr2> ix2Var) {
        this.f31197do = ix2Var;
    }

    public qr2(ix2<Context> ix2Var, byte[] bArr) {
        this.f31197do = ix2Var;
    }

    public qr2(ix2<Context> ix2Var, char[] cArr) {
        this.f31197do = ix2Var;
    }

    public qr2(ix2<Context> ix2Var, short[] sArr) {
        this.f31197do = ix2Var;
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [kr2, mr2] */
    /* JADX WARN: Type inference failed for: r1v4, types: [as2, kr2] */
    /* JADX WARN: Type inference failed for: r1v5, types: [ly2, kr2] */
    @Override // defpackage.ix2
    public final kr2 a() {
        int i = this.f31198if;
        if (i != 0) {
            return i != 1 ? i != 2 ? new ly2((Context) this.f31197do.a()) : new as2(((rr2) this.f31197do).a()) : new mr2(((rr2) this.f31197do).a());
        }
        nr2 nr2Var = (nr2) this.f31197do.a();
        Objects.requireNonNull(nr2Var, "Cannot return null from a non-@Nullable @Provides method");
        return nr2Var;
    }
}
