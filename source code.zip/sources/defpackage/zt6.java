package defpackage;

import android.R;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import defpackage.jm7;
import defpackage.jw6;
import defpackage.kn6;
import defpackage.mt7;
import defpackage.tx6;
import defpackage.vn8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import ru.yandex.music.catalog.album.AlbumActivity;
import ru.yandex.music.catalog.artist.ArtistActivity;
import ru.yandex.music.catalog.artist.ArtistFullInfoActivity;
import ru.yandex.music.catalog.artist.ArtistItemsActivity;
import ru.yandex.music.common.media.context.Page;
import ru.yandex.music.common.media.context.PlaybackScope;
import ru.yandex.music.concert.ConcertActivity;
import ru.yandex.music.data.stores.CoverPath;
import ru.yandex.music.data.user.Permission;
import ru.yandex.music.video.VideoActivity;

/* loaded from: classes2.dex */
public class zt6 extends u58 {

    /* renamed from: throw, reason: not valid java name */
    public static final /* synthetic */ int f47869throw = 0;

    /* renamed from: import, reason: not valid java name */
    public PlaybackScope f47870import;

    /* renamed from: native, reason: not valid java name */
    public yt6 f47871native;

    /* renamed from: public, reason: not valid java name */
    public g3d f47872public;

    /* renamed from: return, reason: not valid java name */
    public boolean f47873return;

    /* renamed from: static, reason: not valid java name */
    public jw6 f47874static;

    /* renamed from: while, reason: not valid java name */
    public mt7 f47875while;

    /* loaded from: classes2.dex */
    public class a implements jw6.b {
        public a() {
        }

        @Override // defpackage.qy6
        /* renamed from: break */
        public void mo13021break(v59 v59Var) {
            pic.m12144if("Artist_OpenLink");
            g8d.B(zt6.this.getContext(), v59Var.f40131class);
        }

        @Override // jw6.b
        /* renamed from: case */
        public PointF mo8659case() {
            mg activity = zt6.this.getActivity();
            lr7 lr7Var = activity instanceof lr7 ? (lr7) activity : null;
            if (lr7Var != null) {
                return lr7Var.m9901finally(s9a.MY_MUSIC);
            }
            return null;
        }

        @Override // defpackage.qy6
        /* renamed from: catch */
        public void mo13022catch(l59 l59Var) {
            pic.m12144if("Artist_OpenAllTracks");
            zt6 zt6Var = zt6.this;
            Context context = zt6Var.getContext();
            int i = ArtistItemsActivity.f33120default;
            zt6Var.startActivity(ArtistItemsActivity.m13538implements(context, l59Var, ArtistItemsActivity.a.POPULAR_TRACKS));
        }

        @Override // defpackage.qy6
        /* renamed from: class */
        public void mo13023class(l59 l59Var) {
            pic.m12144if("Artist_OpenAllAlbums");
            zt6 zt6Var = zt6.this;
            Context context = zt6Var.getContext();
            int i = ArtistItemsActivity.f33120default;
            zt6Var.startActivity(ArtistItemsActivity.m13538implements(context, l59Var, ArtistItemsActivity.a.ALBUMS));
        }

        @Override // defpackage.qy6
        /* renamed from: const */
        public void mo13024const(l59 l59Var) {
            pic.m12144if("Artist_OpenAllCompilations");
            zt6 zt6Var = zt6.this;
            Context context = zt6Var.getContext();
            int i = ArtistItemsActivity.f33120default;
            zt6Var.startActivity(ArtistItemsActivity.m13538implements(context, l59Var, ArtistItemsActivity.a.COMPILATIONS));
        }

        @Override // defpackage.qy6
        /* renamed from: do */
        public void mo13025do(h59 h59Var) {
            pic.m12144if("Artist_OpenAlbum");
            zt6.this.startActivity(AlbumActivity.m13534instanceof(zt6.this.getContext(), h59Var, zt6.this.f47870import));
        }

        @Override // jw6.b
        /* renamed from: else */
        public void mo8660else(e69 e69Var, x57 x57Var, vn8.a aVar) {
            m57 m57Var = new m57(new fz6(kz6.ARTIST, lz6.COMMON));
            m57Var.m10157for(zt6.this.requireContext());
            m57Var.m10159new(zt6.this.requireFragmentManager());
            m57Var.m10154case(zt6.this.f47870import);
            m57Var.m10158if(aVar);
            m57Var.m10156else(e69Var, x57Var);
            ((ac7) m57Var.m10155do()).mo480import(zt6.this.requireFragmentManager());
        }

        @Override // defpackage.qy6
        /* renamed from: final */
        public void mo13026final(l59 l59Var) {
            pic.m12144if("Artist_OpenAllSimilarArtists");
            zt6 zt6Var = zt6.this;
            Context context = zt6Var.getContext();
            int i = ArtistItemsActivity.f33120default;
            zt6Var.startActivity(ArtistItemsActivity.m13538implements(context, l59Var, ArtistItemsActivity.a.SIMILAR_ARTISTS));
        }

        @Override // defpackage.px6
        /* renamed from: for */
        public void mo12344for() {
            zt6.this.requireActivity().finish();
        }

        @Override // defpackage.qy6
        /* renamed from: goto */
        public void mo13027goto(l59 l59Var, au6 au6Var) {
            pic.m12144if("Artist_OpenSimilarArtist");
            zt6.this.startActivity(ArtistActivity.m13537synchronized(zt6.this.getContext(), new yt6(l59Var, au6Var)));
        }

        @Override // defpackage.qy6
        /* renamed from: if */
        public void mo13028if(oa9 oa9Var) {
            pic.m12144if("Artist_OpenPlaylist");
            zt6 zt6Var = zt6.this;
            zt6Var.startActivity(v56.m15920strictfp(zt6Var.getContext(), oa9Var, zt6.this.f47870import));
        }

        @Override // defpackage.qy6
        /* renamed from: import */
        public void mo13029import(qdd qddVar) {
            zt6 zt6Var = zt6.this;
            Context context = zt6Var.getContext();
            mv6 mv6Var = zt6.this.f47874static.f19427import;
            Bundle bundle = null;
            if (mv6Var == null) {
                int i = e8d.f9711do;
                jr3.m8593do("getVideoAnalyticsAttrs(): mCachedArtistMetadata is null");
            } else {
                cu6 cu6Var = mv6Var.m10625do().f34442class;
                if (cu6Var == null) {
                    int i2 = e8d.f9711do;
                    jr3.m8593do("getVideoAnalyticsAttrs(): ArtistBriefInfo is null");
                } else {
                    String str = cu6Var.f7444catch.f21602const;
                    int indexOf = cu6Var.f7448import.indexOf(qddVar);
                    Bundle bundle2 = new Bundle();
                    bundle2.putString("artist_id", str);
                    bundle2.putInt("position", indexOf);
                    bundle = bundle2;
                }
            }
            int i3 = VideoActivity.f33918throws;
            zt6Var.startActivity(new Intent(context, (Class<?>) VideoActivity.class).putExtra("extra_video", qddVar).putExtra("extra_analytics_params", bundle));
        }

        @Override // defpackage.qy6
        /* renamed from: native */
        public void mo13030native(h59 h59Var) {
            pic.m12144if("Artist_OpenLastRelease");
            zt6.this.startActivity(AlbumActivity.m13534instanceof(zt6.this.getContext(), h59Var, new c88(Page.LAST_RELEASE, Permission.LIBRARY_PLAY)));
        }

        @Override // defpackage.qy6
        /* renamed from: new */
        public void mo13031new(j19 j19Var) {
            pic.m12144if("Artist_OpenConcert");
            zt6 zt6Var = zt6.this;
            zt6Var.startActivity(ConcertActivity.m13598implements(zt6Var.getContext(), j19Var.f17752catch));
        }

        @Override // defpackage.qy6
        /* renamed from: public */
        public void mo13032public(l59 l59Var) {
            pic.m12144if("Artist_OpenAllTracks");
            zt6 zt6Var = zt6.this;
            Context context = zt6Var.getContext();
            int i = ArtistItemsActivity.f33120default;
            zt6Var.startActivity(ArtistItemsActivity.m13538implements(context, l59Var, ArtistItemsActivity.a.DOWNLOADED_TRACKS));
        }

        @Override // jw6.b
        /* renamed from: super */
        public void mo8661super(l59 l59Var) {
            h57 h57Var = new h57(kz6.ARTIST);
            h57Var.m7010if(l59Var);
            h57Var.m7009for(zt6.this.requireContext());
            h57Var.m7011new(zt6.this.requireFragmentManager());
            h57Var.m7012try(zt6.this.f47870import);
            ((k87) h57Var.m7008do()).mo480import(zt6.this.requireFragmentManager());
        }

        @Override // defpackage.px6
        /* renamed from: this */
        public void mo12345this(l59 l59Var, List<CoverPath> list) {
            pic.m12144if("ArtistHeader_OpenAllCovers");
            Context context = zt6.this.getContext();
            int i = ArtistFullInfoActivity.f33112class;
            ActivityOptions makeCustomAnimation = ActivityOptions.makeCustomAnimation(context, R.anim.fade_in, R.anim.fade_out);
            e8d.m5048goto(!list.isEmpty());
            if (list.isEmpty()) {
                list = Collections.singletonList(l59Var.f21603default);
            }
            context.startActivity(new Intent(context, (Class<?>) ArtistFullInfoActivity.class).putParcelableArrayListExtra("extra.covers", new ArrayList<>(list)), makeCustomAnimation.toBundle());
        }

        @Override // jw6.b
        /* renamed from: throw */
        public void mo8662throw(rv6 rv6Var) {
            h57 h57Var = new h57(kz6.ARTIST);
            jp5.m8570try(rv6Var, "artistInfo");
            h57Var.f14687for = rv6Var;
            h57Var.f14688if = rv6Var.f34441catch;
            h57Var.m7009for(zt6.this.requireContext());
            h57Var.m7011new(zt6.this.requireFragmentManager());
            h57Var.m7012try(zt6.this.f47870import);
            ((k87) h57Var.m7008do()).mo480import(zt6.this.requireFragmentManager());
        }

        @Override // jw6.b
        /* renamed from: try */
        public sqe mo8663try() {
            mg activity = zt6.this.getActivity();
            final lr7 lr7Var = activity instanceof lr7 ? (lr7) activity : null;
            if (lr7Var != null) {
                return new sqe() { // from class: vt6
                    @Override // defpackage.sqe
                    public final void call() {
                        lr7.this.m9907return(s9a.MY_MUSIC);
                    }
                };
            }
            return null;
        }

        @Override // jw6.b
        /* renamed from: while */
        public void mo8664while(l59 l59Var) {
            kn6.a aVar = kn6.f20664while;
            mg requireActivity = zt6.this.requireActivity();
            g3d g3dVar = zt6.this.f47872public;
            jp5.m8570try(requireActivity, "activity");
            jp5.m8570try(l59Var, "artist");
            aVar.m9110if(requireActivity, vn6.ARTIST, l59Var, g3dVar);
        }
    }

    @Override // defpackage.p58, defpackage.j68, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
        Bundle arguments = getArguments();
        if (arguments == null) {
            int i = e8d.f9711do;
            jr3.m8593do("null arguments");
            mg activity = getActivity();
            f9d.m5797for(activity, "arg is null");
            activity.finish();
            return;
        }
        Parcelable parcelable = arguments.getParcelable("arg.artistParams");
        f9d.m5797for(parcelable, "arg is null");
        this.f47871native = (yt6) parcelable;
        this.f47873return = arguments.getBoolean("arg.needShowBanner");
        this.f47872public = bundle == null ? g3d.m6349else(arguments) : g3d.m6349else(bundle);
        this.f47875while = new mt7((o3) wuc.m16815import(getContext()));
        PlaybackScope playbackScope = (PlaybackScope) getArguments().getSerializable("arg.prevPlaybackScope");
        f9d.m5797for(playbackScope, "arg is null");
        this.f47870import = a88.m317abstract(playbackScope, new l78(Page.ARTIST, this.f47871native.f46140catch));
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        super.onCreateOptionsMenu(menu, menuInflater);
        int i = this.f47875while.f24563for;
        if (i == 0) {
            return;
        }
        menuInflater.inflate(i, menu);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(ru.yandex.music.R.layout.view_artist, viewGroup, false);
    }

    @Override // defpackage.j68, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        jw6 jw6Var = this.f47874static;
        jw6Var.f19433while = null;
        iw6 iw6Var = jw6Var.f19428new;
        iw6Var.f17447class.m6464if();
        iw6Var.f17451for.m15417if();
        iw6Var.f17454new.m16881if();
        iw6Var.f17453if.f18969if = null;
        iw6Var.f17452goto = null;
        gw6 gw6Var = jw6Var.f19432try;
        kw6 kw6Var = gw6Var.f14275new;
        kw6Var.f21129do.m11792try();
        kw6Var.f21131if = null;
        lw6 lw6Var = gw6Var.f14276try;
        lw6Var.f22988do.m11792try();
        lw6Var.f22990if = null;
        gw6Var.f14272do = null;
        zbd.m17945try(jw6Var.f19422else);
        jw6Var.f19417case.m16881if();
        this.f47874static.m8658if(null);
    }

    @Override // androidx.fragment.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        mt7.a aVar = this.f47875while.f24561case;
        return (aVar != null && aVar.onMenuItemClick(menuItem)) || super.onOptionsItemSelected(menuItem);
    }

    @Override // androidx.fragment.app.Fragment
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        this.f47875while.m10598do(menu);
    }

    @Override // defpackage.p58, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBoolean("saveStateBannerShown", this.f47874static.f19419class);
        g3d g3dVar = this.f47872public;
        if (g3dVar != null) {
            g3dVar.m14710new(bundle);
        }
    }

    @Override // defpackage.j68, androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        jw6.b bVar;
        super.onViewCreated(view, bundle);
        Context context = getContext();
        yt6 yt6Var = this.f47871native;
        jw6 jw6Var = new jw6(context, yt6Var.f46141class, this.f47870import, this.f38400super, this.f47873return, yt6Var.f46142const, bundle, yt6Var.f46143final, this.f47872public);
        this.f47874static = jw6Var;
        sx6 sx6Var = new sx6(getContext(), view, this.f47875while);
        jw6Var.f19433while = sx6Var;
        iw6 iw6Var = jw6Var.f19428new;
        final tx6.b bVar2 = sx6Var.f36175if;
        iw6Var.f17452goto = bVar2;
        rx6 rx6Var = (rx6) bVar2;
        iw6Var.f17451for.m15415do(rx6Var.f34521break);
        iw6Var.f17454new.m16879do(rx6Var.f34525const);
        iw6Var.f17453if.f18969if = new jm7.a() { // from class: ew6
            @Override // jm7.a
            /* renamed from: do, reason: not valid java name */
            public final void mo5482do() {
                ((rx6) tx6.b.this).f34537static.mo5482do();
            }
        };
        lv6 lv6Var = iw6Var.f17455this;
        if (lv6Var != null) {
            iw6Var.m7980for(lv6Var);
        }
        boolean z = iw6Var.f17448const;
        iw6Var.f17448const = z;
        tx6.b bVar3 = iw6Var.f17452goto;
        if (bVar3 != null) {
            ((rx6) bVar3).f34529for.setExpanded(!z);
        }
        gw6 gw6Var = jw6Var.f19432try;
        tx6.a aVar = sx6Var.f36174for;
        gw6Var.f14272do = aVar;
        ox6 ox6Var = (ox6) aVar;
        ox6Var.f28029do.setEnabled(false);
        ox6Var.f28029do.setNestedScrollingEnabled(false);
        kw6 kw6Var = gw6Var.f14275new;
        kw6Var.f21131if = aVar;
        cu6 cu6Var = kw6Var.f21130for;
        if (cu6Var != null) {
            kw6Var.m9283for(cu6Var);
        }
        lw6 lw6Var = gw6Var.f14276try;
        lw6Var.f22990if = aVar;
        ov6 ov6Var = lw6Var.f22989for;
        if (ov6Var != null) {
            lw6Var.m10046for(ov6Var);
        }
        rv6 rv6Var = gw6Var.f14274if;
        if (rv6Var != null) {
            gw6Var.m6868if(rv6Var);
        }
        bu6 bu6Var = gw6Var.f14273for;
        if (bu6Var != null) {
            gw6Var.m6867do(bu6Var);
        }
        mv6 mv6Var = jw6Var.f19427import;
        if (mv6Var != null) {
            jw6Var.m8656do(mv6Var);
        }
        jw6Var.f19417case.m16879do(new z0d(jw6Var.f19421do));
        this.f47874static.m8658if(new a());
        jw6 jw6Var2 = this.f47874static;
        l59 l59Var = this.f47871native.f46140catch;
        Permission m13562class = jw6Var2.f19426if.m13562class();
        if (m13562class != null && !jw6Var2.f19420const.mo9664try().m17618try(m13562class) && l59Var.f21607import && jw6Var2.f19416break && jw6Var2.f19418catch && !jw6Var2.f19419class && (bVar = jw6Var2.f19431throw) != null) {
            jw6Var2.f19419class = true;
            bVar.mo8664while(l59Var);
        }
        jw6Var2.m8657for(l59Var);
    }
}
