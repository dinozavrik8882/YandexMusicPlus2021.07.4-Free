package defpackage;

/* loaded from: classes.dex */
public abstract class yb2 {
    /* renamed from: do */
    public abstract int mo17043do(int i, byte[] bArr, int i2, int i3);

    /* renamed from: if */
    public abstract int mo17044if(CharSequence charSequence, byte[] bArr, int i, int i2);
}
