package defpackage;

import defpackage.jd4;
import defpackage.sg4;

/* loaded from: classes.dex */
public final class kj4 implements sg4 {

    /* renamed from: do, reason: not valid java name */
    public final pd4 f20534do;

    /* renamed from: for, reason: not valid java name */
    public final jd4.a f20535for;

    /* renamed from: if, reason: not valid java name */
    public final el5<nh4> f20536if;

    public kj4(al4 al4Var, pd4 pd4Var, el5<nh4> el5Var, jj4 jj4Var, jd4.a aVar) {
        jp5.m8570try(al4Var, "networkDirector");
        jp5.m8570try(pd4Var, "authInfoProvider");
        jp5.m8570try(el5Var, "db");
        jp5.m8570try(jj4Var, "samsungHolder");
        jp5.m8570try(aVar, "experimentsProvider");
        this.f20534do = pd4Var;
        this.f20536if = el5Var;
        this.f20535for = aVar;
    }

    @Override // defpackage.sg4
    /* renamed from: do, reason: not valid java name */
    public ve4 mo9049do(ee4 ee4Var, String str, String str2) {
        jp5.m8570try(ee4Var, "product");
        jp5.m8570try(str, "email");
        jp5.m8570try(str2, "merchantName");
        throw new zd4("SamsungPay not work", null, 2);
    }

    @Override // defpackage.sg4
    /* renamed from: for, reason: not valid java name */
    public void mo9050for() {
    }

    @Override // defpackage.sg4
    /* renamed from: if, reason: not valid java name */
    public void mo9051if() {
    }

    @Override // defpackage.sg4
    /* renamed from: new, reason: not valid java name */
    public void mo9052new() {
    }

    @Override // defpackage.sg4
    /* renamed from: try, reason: not valid java name */
    public sg4.a mo9053try() {
        return new sg4.a(ug4.NOT_SUPPORTED, tg4.SPAY_NOT_SUPPORTED, null, null);
    }
}
