package defpackage;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.Group;
import com.google.android.material.appbar.AppBarLayout;
import defpackage.c67;
import defpackage.eh7;
import defpackage.hg7;
import defpackage.n0;
import java.util.Objects;
import ru.yandex.music.R;
import ru.yandex.music.catalog.buttons.RoundPlayButtonWithDescription;
import ru.yandex.music.data.stores.CoverPath;
import ru.yandex.music.ui.view.YaRotatingProgress;

/* loaded from: classes2.dex */
public class n0 implements gh7 {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f24774do;

    /* renamed from: abstract, reason: not valid java name */
    public boolean f24775abstract;

    /* renamed from: break, reason: not valid java name */
    public final ey3 f24776break;

    /* renamed from: case, reason: not valid java name */
    public final ey3 f24777case;

    /* renamed from: catch, reason: not valid java name */
    public final ey3 f24778catch;

    /* renamed from: class, reason: not valid java name */
    public final ey3 f24779class;

    /* renamed from: const, reason: not valid java name */
    public final ey3 f24780const;

    /* renamed from: continue, reason: not valid java name */
    public boolean f24781continue;

    /* renamed from: default, reason: not valid java name */
    public eh7.a f24782default;

    /* renamed from: else, reason: not valid java name */
    public final ey3 f24783else;

    /* renamed from: extends, reason: not valid java name */
    public boolean f24784extends;

    /* renamed from: final, reason: not valid java name */
    public final ey3 f24785final;

    /* renamed from: finally, reason: not valid java name */
    public boolean f24786finally;

    /* renamed from: for, reason: not valid java name */
    public final RoundPlayButtonWithDescription f24787for;

    /* renamed from: goto, reason: not valid java name */
    public final ey3 f24788goto;

    /* renamed from: if, reason: not valid java name */
    public final nt7 f24789if;

    /* renamed from: import, reason: not valid java name */
    public final ey3 f24790import;

    /* renamed from: native, reason: not valid java name */
    public final b67 f24791native;

    /* renamed from: new, reason: not valid java name */
    public final ImageView f24792new;

    /* renamed from: package, reason: not valid java name */
    public boolean f24793package;

    /* renamed from: private, reason: not valid java name */
    public CoverPath f24794private;

    /* renamed from: public, reason: not valid java name */
    public final ey3 f24795public;

    /* renamed from: return, reason: not valid java name */
    public final c67 f24796return;

    /* renamed from: static, reason: not valid java name */
    public final ey3 f24797static;

    /* renamed from: super, reason: not valid java name */
    public final ey3 f24798super;

    /* renamed from: switch, reason: not valid java name */
    public final Context f24799switch;

    /* renamed from: this, reason: not valid java name */
    public final ey3 f24800this;

    /* renamed from: throw, reason: not valid java name */
    public final ey3 f24801throw;

    /* renamed from: throws, reason: not valid java name */
    public View f24802throws;

    /* renamed from: try, reason: not valid java name */
    public final View f24803try;

    /* renamed from: while, reason: not valid java name */
    public final ey3 f24804while;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<mr5<?>, View> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f24805catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ int f24806class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ Object f24807const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(int i, int i2, Object obj) {
            super(1);
            this.f24805catch = i;
            this.f24806class = i2;
            this.f24807const = obj;
        }

        @Override // defpackage.mo5
        public final View invoke(mr5<?> mr5Var) {
            int i = this.f24805catch;
            if (i == 0) {
                mr5<?> mr5Var2 = mr5Var;
                jp5.m8570try(mr5Var2, "property");
                try {
                    View findViewById = ((View) this.f24807const).findViewById(R.id.progress_anchor);
                    if (findViewById != null) {
                        return findViewById;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.view.View");
                } catch (ClassCastException e) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
                }
            }
            if (i == 1) {
                mr5<?> mr5Var3 = mr5Var;
                jp5.m8570try(mr5Var3, "property");
                try {
                    View findViewById2 = ((View) this.f24807const).findViewById(R.id.fading_backdrop);
                    if (findViewById2 != null) {
                        return findViewById2;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.view.View");
                } catch (ClassCastException e2) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var3).toString(), e2);
                }
            }
            if (i == 2) {
                mr5<?> mr5Var4 = mr5Var;
                jp5.m8570try(mr5Var4, "property");
                try {
                    View findViewById3 = ((View) this.f24807const).findViewById(R.id.cover_progress);
                    if (findViewById3 != null) {
                        return findViewById3;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.view.View");
                } catch (ClassCastException e3) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var4).toString(), e3);
                }
            }
            if (i != 3) {
                throw null;
            }
            mr5<?> mr5Var5 = mr5Var;
            jp5.m8570try(mr5Var5, "property");
            try {
                View findViewById4 = ((View) this.f24807const).findViewById(R.id.anchor_host);
                if (findViewById4 != null) {
                    return findViewById4;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.view.View");
            } catch (ClassCastException e4) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var5).toString(), e4);
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends kp5 implements mo5<mr5<?>, Group> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f24808catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ int f24809class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ Object f24810const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(int i, int i2, Object obj) {
            super(1);
            this.f24808catch = i;
            this.f24809class = i2;
            this.f24810const = obj;
        }

        @Override // defpackage.mo5
        public final Group invoke(mr5<?> mr5Var) {
            int i = this.f24808catch;
            if (i == 0) {
                mr5<?> mr5Var2 = mr5Var;
                jp5.m8570try(mr5Var2, "property");
                try {
                    View findViewById = ((View) this.f24810const).findViewById(R.id.like_group);
                    if (findViewById != null) {
                        return (Group) findViewById;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type androidx.constraintlayout.widget.Group");
                } catch (ClassCastException e) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
                }
            }
            if (i != 1) {
                throw null;
            }
            mr5<?> mr5Var3 = mr5Var;
            jp5.m8570try(mr5Var3, "property");
            try {
                View findViewById2 = ((View) this.f24810const).findViewById(R.id.share_group);
                if (findViewById2 != null) {
                    return (Group) findViewById2;
                }
                throw new NullPointerException("null cannot be cast to non-null type androidx.constraintlayout.widget.Group");
            } catch (ClassCastException e2) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var3).toString(), e2);
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class c extends kp5 implements mo5<mr5<?>, TextView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f24811catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ int f24812class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ Object f24813const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(int i, int i2, Object obj) {
            super(1);
            this.f24811catch = i;
            this.f24812class = i2;
            this.f24813const = obj;
        }

        @Override // defpackage.mo5
        public final TextView invoke(mr5<?> mr5Var) {
            int i = this.f24811catch;
            if (i == 0) {
                mr5<?> mr5Var2 = mr5Var;
                jp5.m8570try(mr5Var2, "property");
                try {
                    View findViewById = ((View) this.f24813const).findViewById(R.id.toolbar_title);
                    if (findViewById != null) {
                        return (TextView) findViewById;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
                }
            }
            if (i == 1) {
                mr5<?> mr5Var3 = mr5Var;
                jp5.m8570try(mr5Var3, "property");
                try {
                    View findViewById2 = ((View) this.f24813const).findViewById(R.id.title);
                    if (findViewById2 != null) {
                        return (TextView) findViewById2;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e2) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var3).toString(), e2);
                }
            }
            if (i == 2) {
                mr5<?> mr5Var4 = mr5Var;
                jp5.m8570try(mr5Var4, "property");
                try {
                    View findViewById3 = ((View) this.f24813const).findViewById(R.id.subtitle);
                    if (findViewById3 != null) {
                        return (TextView) findViewById3;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
                } catch (ClassCastException e3) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var4).toString(), e3);
                }
            }
            if (i != 3) {
                throw null;
            }
            mr5<?> mr5Var5 = mr5Var;
            jp5.m8570try(mr5Var5, "property");
            try {
                View findViewById4 = ((View) this.f24813const).findViewById(R.id.likes_counter);
                if (findViewById4 != null) {
                    return (TextView) findViewById4;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.TextView");
            } catch (ClassCastException e4) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var5).toString(), e4);
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class d extends kp5 implements mo5<mr5<?>, ImageView> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ int f24814catch;

        /* renamed from: class, reason: not valid java name */
        public final /* synthetic */ int f24815class;

        /* renamed from: const, reason: not valid java name */
        public final /* synthetic */ Object f24816const;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(int i, int i2, Object obj) {
            super(1);
            this.f24814catch = i;
            this.f24815class = i2;
            this.f24816const = obj;
        }

        @Override // defpackage.mo5
        public final ImageView invoke(mr5<?> mr5Var) {
            int i = this.f24814catch;
            if (i == 0) {
                mr5<?> mr5Var2 = mr5Var;
                jp5.m8570try(mr5Var2, "property");
                try {
                    View findViewById = ((View) this.f24816const).findViewById(R.id.playlist_cover);
                    if (findViewById != null) {
                        return (ImageView) findViewById;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type android.widget.ImageView");
                } catch (ClassCastException e) {
                    throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
                }
            }
            if (i != 1) {
                throw null;
            }
            mr5<?> mr5Var3 = mr5Var;
            jp5.m8570try(mr5Var3, "property");
            try {
                View findViewById2 = ((View) this.f24816const).findViewById(R.id.toolbar_cover);
                if (findViewById2 != null) {
                    return (ImageView) findViewById2;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.widget.ImageView");
            } catch (ClassCastException e2) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var3).toString(), e2);
            }
        }
    }

    /* loaded from: classes2.dex */
    public /* synthetic */ class e {

        /* renamed from: do, reason: not valid java name */
        public static final /* synthetic */ int[] f24817do;

        static {
            lh7.values();
            int[] iArr = new int[2];
            iArr[lh7.OVERFLOW.ordinal()] = 1;
            f24817do = iArr;
        }
    }

    /* loaded from: classes2.dex */
    public static final class f implements c67.a {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ eh7.a f24818do;

        public f(eh7.a aVar) {
            this.f24818do = aVar;
        }

        @Override // c67.a
        /* renamed from: do */
        public void mo2623do() {
            this.f24818do.mo2906new();
        }
    }

    /* loaded from: classes2.dex */
    public static final class g extends n70<Drawable> {

        /* renamed from: super, reason: not valid java name */
        public final /* synthetic */ ae9 f24820super;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public g(ae9 ae9Var) {
            super(Integer.MIN_VALUE, Integer.MIN_VALUE);
            this.f24820super = ae9Var;
        }

        @Override // defpackage.t70
        /* renamed from: catch */
        public void mo2430catch(Drawable drawable) {
            n0.this.f24792new.setImageDrawable(drawable);
            n0.this.throwables().setImageDrawable(drawable);
        }

        @Override // defpackage.n70, defpackage.t70
        /* renamed from: else */
        public void mo2431else(Drawable drawable) {
            ColorDrawable colorDrawable = new ColorDrawable(t2.m14594continue(n0.this.f24799switch, R.attr.coverPlaceholderColor));
            n0.this.throwables().setImageDrawable(colorDrawable);
            n0.this.f24792new.setImageDrawable(colorDrawable);
            n0 n0Var = n0.this;
            n0Var.f24775abstract = true;
            n0.m10685volatile(n0Var);
        }

        @Override // defpackage.t70
        /* renamed from: for */
        public void mo2432for(Object obj, w70 w70Var) {
            Drawable drawable = (Drawable) obj;
            jp5.m8570try(drawable, "resource");
            n0.this.f24792new.setImageDrawable(drawable);
            n0.this.throwables().setImageDrawable(drawable);
            n0.this.f24794private = this.f24820super.mo513for();
            n0 n0Var = n0.this;
            n0Var.f24775abstract = true;
            n0.m10685volatile(n0Var);
        }
    }

    /* loaded from: classes2.dex */
    public static final class h extends n70<Drawable> {
        public h() {
            super(Integer.MIN_VALUE, Integer.MIN_VALUE);
        }

        @Override // defpackage.t70
        /* renamed from: catch */
        public void mo2430catch(Drawable drawable) {
            n0.this.m10688protected().setImageDrawable(drawable);
        }

        @Override // defpackage.n70, defpackage.t70
        /* renamed from: else */
        public void mo2431else(Drawable drawable) {
            n0.this.m10688protected().setImageDrawable(drawable);
            n0 n0Var = n0.this;
            n0Var.f24781continue = true;
            n0.m10685volatile(n0Var);
        }

        @Override // defpackage.t70
        /* renamed from: for */
        public void mo2432for(Object obj, w70 w70Var) {
            Drawable drawable = (Drawable) obj;
            jp5.m8570try(drawable, "resource");
            n0.this.m10688protected().setImageDrawable(drawable);
            n0 n0Var = n0.this;
            n0Var.f24781continue = true;
            n0.m10685volatile(n0Var);
        }
    }

    /* loaded from: classes2.dex */
    public static final class i extends kp5 implements mo5<mr5<?>, YaRotatingProgress> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f24822catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public i(View view, int i) {
            super(1);
            this.f24822catch = view;
        }

        @Override // defpackage.mo5
        public YaRotatingProgress invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f24822catch.findViewById(R.id.progress_view);
                if (findViewById != null) {
                    return (YaRotatingProgress) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type ru.yandex.music.ui.view.YaRotatingProgress");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class j extends kp5 implements mo5<mr5<?>, ViewStub> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f24823catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public j(View view, int i) {
            super(1);
            this.f24823catch = view;
        }

        @Override // defpackage.mo5
        public ViewStub invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f24823catch.findViewById(R.id.error_stub);
                if (findViewById != null) {
                    return (ViewStub) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type android.view.ViewStub");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    /* loaded from: classes2.dex */
    public static final class k extends kp5 implements mo5<mr5<?>, Toolbar> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ View f24824catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public k(View view, int i) {
            super(1);
            this.f24824catch = view;
        }

        @Override // defpackage.mo5
        public Toolbar invoke(mr5<?> mr5Var) {
            mr5<?> mr5Var2 = mr5Var;
            jp5.m8570try(mr5Var2, "property");
            try {
                View findViewById = this.f24824catch.findViewById(R.id.toolbar);
                if (findViewById != null) {
                    return (Toolbar) findViewById;
                }
                throw new NullPointerException("null cannot be cast to non-null type androidx.appcompat.widget.Toolbar");
            } catch (ClassCastException e) {
                throw new IllegalStateException(jp5.m8559break("Invalid view binding (see cause) for ", mr5Var2).toString(), e);
            }
        }
    }

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(n0.class), "toolbar", "getToolbar()Landroidx/appcompat/widget/Toolbar;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var2 = new wp5(dq5.m4763do(n0.class), "toolbarTitle", "getToolbarTitle()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var3 = new wp5(dq5.m4763do(n0.class), "cover", "getCover()Landroid/widget/ImageView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var4 = new wp5(dq5.m4763do(n0.class), "toolbarCover", "getToolbarCover()Landroid/widget/ImageView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var5 = new wp5(dq5.m4763do(n0.class), "coverProgress", "getCoverProgress()Landroid/view/View;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var6 = new wp5(dq5.m4763do(n0.class), "title", "getTitle()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var7 = new wp5(dq5.m4763do(n0.class), "subtitle", "getSubtitle()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var8 = new wp5(dq5.m4763do(n0.class), "likesCounter", "getLikesCounter()Landroid/widget/TextView;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var9 = new wp5(dq5.m4763do(n0.class), "playbackButtonAnchor", "getPlaybackButtonAnchor()Landroid/view/View;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var10 = new wp5(dq5.m4763do(n0.class), "progress", "getProgress()Lru/yandex/music/ui/view/YaRotatingProgress;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var11 = new wp5(dq5.m4763do(n0.class), "progressAnchor", "getProgressAnchor()Landroid/view/View;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var12 = new wp5(dq5.m4763do(n0.class), "errorStub", "getErrorStub()Landroid/view/ViewStub;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var13 = new wp5(dq5.m4763do(n0.class), "fadingBackdrop", "getFadingBackdrop()Landroid/view/View;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var14 = new wp5(dq5.m4763do(n0.class), "likeVisibilityControl", "getLikeVisibilityControl()Landroidx/constraintlayout/widget/Group;");
        Objects.requireNonNull(eq5Var);
        wp5 wp5Var15 = new wp5(dq5.m4763do(n0.class), "shareVisibilityControl", "getShareVisibilityControl()Landroidx/constraintlayout/widget/Group;");
        Objects.requireNonNull(eq5Var);
        f24774do = new mr5[]{wp5Var, wp5Var2, wp5Var3, wp5Var4, wp5Var5, wp5Var6, wp5Var7, wp5Var8, wp5Var9, wp5Var10, wp5Var11, wp5Var12, wp5Var13, wp5Var14, wp5Var15};
    }

    public n0(ViewGroup viewGroup, nt7 nt7Var, RoundPlayButtonWithDescription roundPlayButtonWithDescription, AppBarLayout appBarLayout, ImageView imageView) {
        jp5.m8570try(viewGroup, "parent");
        jp5.m8570try(nt7Var, "toolbarAdapter");
        jp5.m8570try(roundPlayButtonWithDescription, "playbackButton");
        jp5.m8570try(appBarLayout, "appBarLayout");
        jp5.m8570try(imageView, "headerBackground");
        this.f24789if = nt7Var;
        this.f24787for = roundPlayButtonWithDescription;
        this.f24792new = imageView;
        Context context = viewGroup.getContext();
        jp5.m8568new(context, "parent.context");
        View mo590interface = mo590interface(context, viewGroup);
        this.f24803try = mo590interface;
        ey3 ey3Var = new ey3(new k(mo590interface, R.id.toolbar));
        this.f24777case = ey3Var;
        this.f24783else = new ey3(new c(0, R.id.toolbar_title, mo590interface));
        this.f24788goto = new ey3(new d(0, R.id.playlist_cover, mo590interface));
        this.f24800this = new ey3(new d(1, R.id.toolbar_cover, mo590interface));
        this.f24776break = new ey3(new a(2, R.id.cover_progress, mo590interface));
        this.f24778catch = new ey3(new c(1, R.id.title, mo590interface));
        this.f24779class = new ey3(new c(2, R.id.subtitle, mo590interface));
        this.f24780const = new ey3(new c(3, R.id.likes_counter, mo590interface));
        this.f24785final = new ey3(new a(3, R.id.anchor_host, mo590interface));
        this.f24798super = new ey3(new i(mo590interface, R.id.progress_view));
        this.f24801throw = new ey3(new a(0, R.id.progress_anchor, mo590interface));
        this.f24804while = new ey3(new j(mo590interface, R.id.error_stub));
        this.f24790import = new ey3(new a(1, R.id.fading_backdrop, mo590interface));
        View findViewById = mo590interface.findViewById(R.id.round_buttons_container);
        jp5.m8568new(findViewById, "contentView.findViewById(R.id.round_buttons_container)");
        this.f24791native = new b67(findViewById);
        this.f24795public = new ey3(new b(0, R.id.like_group, mo590interface));
        View findViewById2 = mo590interface.findViewById(R.id.round_buttons_container);
        jp5.m8568new(findViewById2, "contentView.findViewById(R.id.round_buttons_container)");
        this.f24796return = new c67(findViewById2);
        this.f24797static = new ey3(new b(1, R.id.share_group, mo590interface));
        Context context2 = viewGroup.getContext();
        jp5.m8568new(context2, "parent.context");
        this.f24799switch = context2;
        t2.b(imageView);
        t2.m14613return(m10690transient(), m10689synchronized(), roundPlayButtonWithDescription, m10686implements());
        ImageView throwables = throwables();
        t2 t2Var = t2.f36494do;
        throwables.setColorFilter(t2Var.m14627final());
        imageView.setColorFilter(t2Var.m14627final());
        nt7Var.m11171do(lh7.class, new eu7() { // from class: qe7
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // defpackage.eu7, defpackage.ue9
            /* renamed from: do */
            public final Integer mo58do(Object obj) {
                lh7 lh7Var = (lh7) obj;
                mr5<Object>[] mr5VarArr = n0.f24774do;
                jp5.m8570try(lh7Var, "obj");
                return Integer.valueOf(lh7Var.getId());
            }
        }, R.menu.actionbar_playlist_menu);
        mo5232catch().mo4815for();
        nt7Var.m11174goto((Toolbar) ey3Var.m5520do(f24774do[0]));
        a().setAlpha(0.0f);
        ImageView throwables2 = throwables();
        ViewGroup.LayoutParams layoutParams = throwables2.getLayoutParams();
        if (layoutParams == null) {
            throw new ml5("null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
        }
        jp5.m8568new(context2.getResources().getConfiguration(), "context.resources.configuration");
        layoutParams.height = (int) TypedValue.applyDimension(1, Math.min((r6.screenWidthDp * 1.25f) + 40.0f, 512.0f), context2.getResources().getDisplayMetrics());
        throwables2.setLayoutParams(layoutParams);
        appBarLayout.m3119do(new szc(a(), 0.37d));
        appBarLayout.m3119do(new tzc(roundPlayButtonWithDescription, 0.23d, R.anim.fab_elevation_small));
        appBarLayout.m3119do(new AppBarLayout.c() { // from class: oe7
            @Override // com.google.android.material.appbar.AppBarLayout.a
            /* renamed from: do */
            public final void mo1973do(AppBarLayout appBarLayout2, int i2) {
                n0 n0Var = n0.this;
                jp5.m8570try(n0Var, "this$0");
                ey3 ey3Var2 = n0Var.f24777case;
                float measuredHeight = appBarLayout2.getMeasuredHeight() - ((Toolbar) ey3Var2.m5520do(r2[0])).getMeasuredHeight();
                float f2 = (i2 + measuredHeight) / measuredHeight;
                ((View) n0Var.f24790import.m5520do(n0.f24774do[12])).setAlpha(1 - f2);
                n0Var.f24787for.setDescriptionAlpha(f2);
            }
        });
    }

    /* renamed from: volatile, reason: not valid java name */
    public static final void m10685volatile(n0 n0Var) {
        eh7.a aVar = n0Var.f24782default;
        if (aVar != null && n0Var.f24775abstract && n0Var.f24781continue) {
            aVar.mo2904for();
        }
    }

    public final TextView a() {
        return (TextView) this.f24783else.m5520do(f24774do[1]);
    }

    @Override // defpackage.eh7
    /* renamed from: break */
    public n8a mo5231break() {
        return this.f24791native;
    }

    @Override // defpackage.gh7
    /* renamed from: case */
    public void mo6641case() {
        Context context = this.f24799switch;
        Object obj = mc.f23742do;
        int color = context.getColor(R.color.red_pinkish);
        throwables().setBackgroundColor(color);
        this.f24792new.setBackgroundColor(color);
        m10688protected().setImageResource(R.drawable.cover_liked);
        this.f24781continue = true;
    }

    @Override // defpackage.eh7
    /* renamed from: catch */
    public final du7<lh7> mo5232catch() {
        fu7 m11175if = this.f24789if.m11175if(lh7.class);
        jp5.m8568new(m11175if, "toolbarAdapter.getMenuAdapter(PlaylistToolbarItem::class.java)");
        return m11175if;
    }

    @Override // defpackage.eh7
    /* renamed from: continue */
    public void mo5233continue() {
        t2.m14613return(m10686implements());
    }

    @Override // defpackage.eh7
    /* renamed from: do */
    public hg7.a mo588do() {
        return hg7.a.DEFAULT;
    }

    @Override // defpackage.eh7
    /* renamed from: else */
    public View mo5234else() {
        return this.f24803try;
    }

    @Override // defpackage.eh7
    /* renamed from: final */
    public void mo5235final(boolean z) {
        if (z) {
            t2.m14613return(this.f24787for, m10687instanceof(), m10689synchronized(), m10690transient());
            return;
        }
        mo5236finally(this.f24784extends);
        mo5240package(this.f24786finally);
        mo5241private(this.f24793package);
    }

    @Override // defpackage.eh7
    /* renamed from: finally */
    public void mo5236finally(boolean z) {
        this.f24784extends = z;
        t2.c(z, m10690transient());
    }

    @Override // defpackage.eh7
    /* renamed from: for */
    public void mo5237for(boolean z) {
        if (z) {
            ey3 ey3Var = this.f24798super;
            mr5<Object>[] mr5VarArr = f24774do;
            ((YaRotatingProgress) ey3Var.m5520do(mr5VarArr[9])).m13781for(300L);
            t2.b((View) this.f24801throw.m5520do(mr5VarArr[10]));
            return;
        }
        ey3 ey3Var2 = this.f24798super;
        mr5<Object>[] mr5VarArr2 = f24774do;
        ((YaRotatingProgress) ey3Var2.m5520do(mr5VarArr2[9])).m13780do();
        t2.m14613return((View) this.f24801throw.m5520do(mr5VarArr2[10]));
    }

    @Override // defpackage.eh7
    /* renamed from: goto */
    public void mo5238goto(String str) {
        jp5.m8570try(str, "title");
        ((TextView) this.f24778catch.m5520do(f24774do[5])).setText(str);
        a().setText(str);
    }

    /* renamed from: implements, reason: not valid java name */
    public final TextView m10686implements() {
        return (TextView) this.f24780const.m5520do(f24774do[7]);
    }

    /* renamed from: instanceof, reason: not valid java name */
    public final View m10687instanceof() {
        return (View) this.f24785final.m5520do(f24774do[8]);
    }

    /* renamed from: interface */
    public View mo590interface(Context context, ViewGroup viewGroup) {
        jp5.m8570try(context, "context");
        jp5.m8570try(viewGroup, "parent");
        View inflate = LayoutInflater.from(context).inflate(R.layout.view_playlist_header, viewGroup, false);
        jp5.m8568new(inflate, "from(context).inflate(R.layout.view_playlist_header, parent, false)");
        return inflate;
    }

    @Override // defpackage.eh7
    /* renamed from: native */
    public void mo5239native(String str) {
        jp5.m8570try(str, "subtitle");
        ((TextView) this.f24779class.m5520do(f24774do[6])).setText(str);
    }

    @Override // defpackage.gh7
    /* renamed from: new */
    public void mo6642new(ae9 ae9Var) {
        jp5.m8570try(ae9Var, "coverMeta");
        if (jp5.m8563do(((oa9) ae9Var).mo513for(), this.f24794private)) {
            return;
        }
        g gVar = new g(ae9Var);
        h hVar = new h();
        ce9.m2847class(this.f24799switch).m2854else(ae9Var, g8d.m6467case(), gVar, cad.m2712for(this.f24799switch));
        ce9.m2847class(this.f24799switch).m2853catch(ae9Var, g8d.m6474else(), g8d.m6467case(), hVar);
    }

    @Override // defpackage.eh7
    /* renamed from: package */
    public void mo5240package(boolean z) {
        this.f24786finally = z;
        t2.m14614static(!z, this.f24787for, m10687instanceof());
    }

    @Override // defpackage.eh7
    /* renamed from: private */
    public void mo5241private(boolean z) {
        this.f24793package = z;
        t2.m14614static(!z, m10689synchronized());
    }

    /* renamed from: protected, reason: not valid java name */
    public final ImageView m10688protected() {
        return (ImageView) this.f24788goto.m5520do(f24774do[2]);
    }

    @Override // defpackage.eh7
    /* renamed from: public */
    public void mo5242public(boolean z) {
        m10688protected().setClickable(z);
    }

    @Override // defpackage.eh7
    public void release() {
        this.f24789if.m11176new(lh7.class);
        this.f24789if.m11174goto(null);
    }

    @Override // defpackage.eh7
    /* renamed from: return */
    public q08 mo5243return() {
        r08 r08Var = new r08();
        jp5.m8568new(r08Var, "create()");
        return r08Var;
    }

    @Override // defpackage.eh7
    /* renamed from: strictfp */
    public y0d mo5244strictfp() {
        return this.f24787for;
    }

    /* renamed from: synchronized, reason: not valid java name */
    public final Group m10689synchronized() {
        return (Group) this.f24797static.m5520do(f24774do[14]);
    }

    @Override // defpackage.gh7
    /* renamed from: this */
    public void mo6643this(final eh7.a aVar) {
        jp5.m8570try(aVar, "actions");
        this.f24782default = aVar;
        if (this.f24775abstract && this.f24781continue) {
            aVar.mo2904for();
        }
        m10688protected().setOnClickListener(new View.OnClickListener() { // from class: pe7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                eh7.a aVar2 = eh7.a.this;
                jp5.m8570try(aVar2, "$actions");
                aVar2.mo2905if();
            }
        });
        this.f24789if.m11175if(lh7.class).mo6217goto(new tqe() { // from class: se7
            @Override // defpackage.tqe
            public final void call(Object obj) {
                eh7.a aVar2 = eh7.a.this;
                lh7 lh7Var = (lh7) obj;
                jp5.m8570try(aVar2, "$actions");
                jp5.m8570try(lh7Var, "item");
                if (n0.e.f24817do[lh7Var.ordinal()] == 1) {
                    aVar2.mo2907try();
                }
            }
        });
        c67 c67Var = this.f24796return;
        f fVar = new f(aVar);
        Objects.requireNonNull(c67Var);
        jp5.m8570try(fVar, "listener");
        c67Var.f4911for = fVar;
    }

    public final ImageView throwables() {
        return (ImageView) this.f24800this.m5520do(f24774do[3]);
    }

    /* renamed from: transient, reason: not valid java name */
    public final Group m10690transient() {
        return (Group) this.f24795public.m5520do(f24774do[13]);
    }

    @Override // defpackage.gh7
    /* renamed from: try */
    public void mo6644try(boolean z) {
        t2.c(z, (View) this.f24776break.m5520do(f24774do[4]));
    }

    @Override // defpackage.eh7
    /* renamed from: while */
    public void mo5245while(int i2, boolean z) {
        this.f24791native.m1784for(i2);
        m10686implements().setText(v8d.m15981do(i2));
        qd9.u(m10686implements(), this.f24799switch, false);
        t2.b(m10686implements());
    }
}
