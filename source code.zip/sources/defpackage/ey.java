package defpackage;

import defpackage.dy;
import defpackage.gy;
import defpackage.j60;
import defpackage.y10;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class ey {

    /* renamed from: break, reason: not valid java name */
    public i20 f10863break;

    /* renamed from: case, reason: not valid java name */
    public h20 f10864case;

    /* renamed from: catch, reason: not valid java name */
    public x50 f10865catch;

    /* renamed from: else, reason: not valid java name */
    public k20 f10869else;

    /* renamed from: final, reason: not valid java name */
    public j60.b f10870final;

    /* renamed from: for, reason: not valid java name */
    public u00 f10871for;

    /* renamed from: goto, reason: not valid java name */
    public k20 f10872goto;

    /* renamed from: new, reason: not valid java name */
    public o10 f10874new;

    /* renamed from: super, reason: not valid java name */
    public k20 f10875super;

    /* renamed from: this, reason: not valid java name */
    public y10.a f10876this;

    /* renamed from: throw, reason: not valid java name */
    public List<g70<Object>> f10877throw;

    /* renamed from: try, reason: not valid java name */
    public m10 f10878try;

    /* renamed from: do, reason: not valid java name */
    public final Map<Class<?>, my<?, ?>> f10868do = new d8();

    /* renamed from: if, reason: not valid java name */
    public final gy.a f10873if = new gy.a();

    /* renamed from: class, reason: not valid java name */
    public int f10866class = 4;

    /* renamed from: const, reason: not valid java name */
    public dy.a f10867const = new a(this);

    /* loaded from: classes.dex */
    public class a implements dy.a {
        public a(ey eyVar) {
        }
    }

    /* loaded from: classes.dex */
    public static final class b {
    }

    /* loaded from: classes.dex */
    public static final class c {
    }

    /* loaded from: classes.dex */
    public static final class d {
    }
}
