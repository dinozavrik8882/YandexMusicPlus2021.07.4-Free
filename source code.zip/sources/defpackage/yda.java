package defpackage;

import android.content.Context;
import defpackage.vn8;
import defpackage.x0d;
import defpackage.yda;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.common.media.context.Page;
import ru.yandex.music.common.media.context.PlaybackScope;
import ru.yandex.music.data.user.Permission;
import ru.yandex.music.metatag.track.MetaTagTracksActivity;

/* loaded from: classes2.dex */
public class yda extends dda<e69, rm7> {

    /* renamed from: break, reason: not valid java name */
    public final lca f45389break;

    /* renamed from: class, reason: not valid java name */
    public final x0d f45391class;

    /* renamed from: const, reason: not valid java name */
    public final x0d f45392const;

    /* renamed from: final, reason: not valid java name */
    public final t78 f45393final;

    /* renamed from: super, reason: not valid java name */
    public final a f45394super;

    /* renamed from: this, reason: not valid java name */
    public final Context f45395this;

    /* renamed from: while, reason: not valid java name */
    public zda f45397while;

    /* renamed from: throw, reason: not valid java name */
    public final qg9 f45396throw = (qg9) dz3.m4865do(qg9.class);

    /* renamed from: catch, reason: not valid java name */
    public final xaa f45390catch = new xaa((lh6) dz3.m4865do(lh6.class));

    /* loaded from: classes2.dex */
    public interface a {
    }

    public yda(Context context, lca lcaVar, a aVar) {
        this.f45395this = context;
        this.f45389break = lcaVar;
        this.f45394super = aVar;
        this.f45391class = new x0d(context);
        x0d x0dVar = new x0d(context);
        this.f45392const = x0dVar;
        x0dVar.f43102break = x0d.d.START;
        this.f45393final = new o78(Page.METATAG_TRACKS, PlaybackScope.Type.META_TAG, lcaVar.f21949catch, lcaVar.f21951const).mo1838case();
    }

    @Override // defpackage.dda
    /* renamed from: break */
    public int mo4368break() {
        return 25;
    }

    @Override // defpackage.dda
    /* renamed from: case */
    public us7<e69> mo4369case() {
        return new us7() { // from class: vda
            @Override // defpackage.us7
            /* renamed from: extends */
            public final void mo610extends(Object obj, int i) {
                yda ydaVar = yda.this;
                e69 e69Var = (e69) obj;
                nn8 nn8Var = (nn8) ydaVar.m17579catch();
                nn8Var.f25777case = e69Var;
                nn8Var.f25784new = i;
                ydaVar.f45391class.m16878case(nn8Var.mo11067do(), e69Var);
            }
        };
    }

    /* renamed from: catch, reason: not valid java name */
    public final vn8.a m17579catch() {
        t78 t78Var = this.f45393final;
        Adapter adapter = this.f8337try;
        return new nn8("not_synced", t78Var, new kxe(adapter != 0 ? adapter.m9223if() : Collections.emptyList()));
    }

    @Override // defpackage.dda
    /* renamed from: for */
    public void mo4371for(eda<e69, rm7> edaVar) {
        super.mo4371for(edaVar);
        this.f45391class.m16879do(new z0d(this.f45395this));
        zda zdaVar = (zda) edaVar;
        this.f45397while = zdaVar;
        this.f45392const.m16879do(zdaVar.f47076final);
    }

    @Override // defpackage.dda
    /* renamed from: goto */
    public wpe<dca> mo4372goto(int i, String str) {
        xaa xaaVar = this.f45390catch;
        return xaaVar.f43520if.m9712goto(this.f45389break.f21949catch, i, 25, str, "week").m16758final(h0f.m6949for()).m16753break(new yqe() { // from class: caa
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                return dca.m4358do(((kca) obj).m6674new());
            }
        }).m16757else(new yqe() { // from class: u9a
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                dca dcaVar = (dca) obj;
                return dcaVar != null ? new kxe(dcaVar) : wpe.m16748case(new d74(new IllegalStateException("invalid server response")));
            }
        });
    }

    @Override // defpackage.dda
    /* renamed from: if */
    public rm7 mo4373if() {
        return new rm7(new u57() { // from class: uda
            @Override // defpackage.u57
            /* renamed from: do */
            public final void mo3911do(e69 e69Var, int i) {
                yda ydaVar = yda.this;
                yda.a aVar = ydaVar.f45394super;
                lca lcaVar = ydaVar.f45389break;
                x57 x57Var = new x57(i);
                vn8.a m17579catch = ydaVar.m17579catch();
                MetaTagTracksActivity metaTagTracksActivity = ((MetaTagTracksActivity.a) aVar).f33445do;
                int i2 = MetaTagTracksActivity.f33444finally;
                Objects.requireNonNull(metaTagTracksActivity);
                m57 m57Var = new m57(new fz6(kz6.METATAG, lz6.COMMON));
                m57Var.m10157for(metaTagTracksActivity);
                m57Var.m10159new(metaTagTracksActivity.getSupportFragmentManager());
                m57Var.m10154case(new o78(Page.METATAG_TRACKS, PlaybackScope.Type.META_TAG, lcaVar.f21949catch, lcaVar.f21951const));
                m57Var.m10156else(e69Var, x57Var);
                m57Var.m10158if(m17579catch);
                ((ac7) m57Var.m10155do()).mo480import(metaTagTracksActivity.getSupportFragmentManager());
            }
        });
    }

    @Override // defpackage.dda
    /* renamed from: new */
    public List<e69> mo4374new(dca dcaVar) {
        return dcaVar.f8304else;
    }

    @Override // defpackage.dda
    /* renamed from: this */
    public void mo4375this(List<e69> list) {
        super.mo4375this(list);
        t78 t78Var = this.f45393final;
        Adapter adapter = this.f8337try;
        kxe kxeVar = new kxe(adapter != 0 ? adapter.m9223if() : Collections.emptyList());
        eo8 eo8Var = new eo8(null);
        this.f45392const.m16880for(new on8(new jo8(), "not_synced", t78Var, kxeVar.m16753break(bm8.f3887catch), null, this.f45396throw.mo9664try().m17618try(Permission.SHUFFLE_OFF) ? null : oo8.ON, null, -1, -1L, null, null, eo8Var));
        zda zdaVar = this.f45397while;
        if (zdaVar == null || zdaVar.f47076final.getVisibility() == 0) {
            return;
        }
        zdaVar.f47075const.setPadding(0, 0, 0, zdaVar.f47072break);
        zdaVar.f47074class.setPadding(0, zdaVar.f47073catch, 0, 0);
        zdaVar.f47076final.setVisibility(0);
        t2.m14619this(zdaVar.f47074class);
    }

    @Override // defpackage.dda
    /* renamed from: try */
    public void mo4376try() {
        this.f45391class.m16881if();
        this.f45392const.m16881if();
        this.f45392const.m16880for(null);
        this.f45397while = null;
        super.mo4376try();
    }
}
