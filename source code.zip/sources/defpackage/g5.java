package defpackage;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* loaded from: classes.dex */
public class g5 extends c5 implements SubMenu {

    /* renamed from: try, reason: not valid java name */
    public final nd f13063try;

    public g5(Context context, nd ndVar) {
        super(context, ndVar);
        this.f13063try = ndVar;
    }

    @Override // android.view.SubMenu
    public void clearHeader() {
        this.f13063try.clearHeader();
    }

    @Override // android.view.SubMenu
    public MenuItem getItem() {
        return m12459for(this.f13063try.getItem());
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(int i) {
        this.f13063try.setHeaderIcon(i);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(Drawable drawable) {
        this.f13063try.setHeaderIcon(drawable);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(int i) {
        this.f13063try.setHeaderTitle(i);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(CharSequence charSequence) {
        this.f13063try.setHeaderTitle(charSequence);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderView(View view) {
        this.f13063try.setHeaderView(view);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(int i) {
        this.f13063try.setIcon(i);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(Drawable drawable) {
        this.f13063try.setIcon(drawable);
        return this;
    }
}
