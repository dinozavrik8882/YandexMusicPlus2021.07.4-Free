package defpackage;

/* loaded from: classes2.dex */
public final class l07 extends mz6 {
    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public l07(defpackage.mo5 r15, int r16, boolean r17, int r18, boolean r19, defpackage.gz6 r20, int r21) {
        /*
            r14 = this;
            r0 = r21 & 2
            if (r0 == 0) goto L9
            r0 = 2131952448(0x7f130340, float:1.954134E38)
            r5 = r0
            goto Lb
        L9:
            r5 = r16
        Lb:
            r0 = r21 & 4
            r1 = 0
            if (r0 == 0) goto L12
            r7 = r1
            goto L14
        L12:
            r7 = r17
        L14:
            r0 = r21 & 8
            if (r0 == 0) goto L1d
            r0 = 2131231375(0x7f08028f, float:1.807883E38)
            r3 = r0
            goto L1f
        L1d:
            r3 = r18
        L1f:
            r0 = r21 & 16
            if (r0 == 0) goto L25
            r4 = r1
            goto L27
        L25:
            r4 = r19
        L27:
            r0 = r21 & 32
            if (r0 == 0) goto L2e
            gz6 r0 = defpackage.gz6.IMPORT
            goto L2f
        L2e:
            r0 = 0
        L2f:
            java.lang.String r1 = "action"
            r2 = r15
            defpackage.jp5.m8570try(r15, r1)
            java.lang.String r1 = "type"
            defpackage.jp5.m8570try(r0, r1)
            w47 r13 = new w47
            r6 = 0
            r8 = 0
            r9 = 0
            r10 = 0
            r11 = 0
            r12 = 960(0x3c0, float:1.345E-42)
            r1 = r13
            r1.<init>(r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12)
            r1 = r14
            r14.<init>(r13, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.l07.<init>(mo5, int, boolean, int, boolean, gz6, int):void");
    }
}
