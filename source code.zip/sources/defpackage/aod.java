package defpackage;

/* loaded from: classes2.dex */
public class aod extends Exception {
    public aod(Throwable th) {
        super(th);
    }
}
