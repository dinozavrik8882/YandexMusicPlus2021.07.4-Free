package defpackage;

import com.google.android.exoplayer2.util.Util;
import defpackage.n51;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* loaded from: classes.dex */
public final class j71 implements q51 {

    /* renamed from: catch, reason: not valid java name */
    public final List<f71> f18142catch;

    /* renamed from: class, reason: not valid java name */
    public final long[] f18143class;

    /* renamed from: const, reason: not valid java name */
    public final long[] f18144const;

    public j71(List<f71> list) {
        this.f18142catch = Collections.unmodifiableList(new ArrayList(list));
        this.f18143class = new long[list.size() * 2];
        for (int i = 0; i < list.size(); i++) {
            f71 f71Var = list.get(i);
            int i2 = i * 2;
            long[] jArr = this.f18143class;
            jArr[i2] = f71Var.f11387if;
            jArr[i2 + 1] = f71Var.f11386for;
        }
        long[] jArr2 = this.f18143class;
        long[] copyOf = Arrays.copyOf(jArr2, jArr2.length);
        this.f18144const = copyOf;
        Arrays.sort(copyOf);
    }

    @Override // defpackage.q51
    /* renamed from: case */
    public List<n51> mo4143case(long j) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < this.f18142catch.size(); i++) {
            long[] jArr = this.f18143class;
            int i2 = i * 2;
            if (jArr[i2] <= j && j < jArr[i2 + 1]) {
                f71 f71Var = this.f18142catch.get(i);
                n51 n51Var = f71Var.f11385do;
                if (n51Var.f25071try == -3.4028235E38f) {
                    arrayList2.add(f71Var);
                } else {
                    arrayList.add(n51Var);
                }
            }
        }
        Collections.sort(arrayList2, new Comparator() { // from class: a71
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return Long.compare(((f71) obj).f11387if, ((f71) obj2).f11387if);
            }
        });
        for (int i3 = 0; i3 < arrayList2.size(); i3++) {
            n51.b m10768do = ((f71) arrayList2.get(i3)).f11385do.m10768do();
            m10768do.f25083new = (-1) - i3;
            m10768do.f25086try = 1;
            arrayList.add(m10768do.m10769do());
        }
        return arrayList;
    }

    @Override // defpackage.q51
    /* renamed from: goto */
    public int mo4144goto() {
        return this.f18144const.length;
    }

    @Override // defpackage.q51
    /* renamed from: if */
    public int mo4145if(long j) {
        int binarySearchCeil = Util.binarySearchCeil(this.f18144const, j, false, false);
        if (binarySearchCeil < this.f18144const.length) {
            return binarySearchCeil;
        }
        return -1;
    }

    @Override // defpackage.q51
    /* renamed from: try */
    public long mo4146try(int i) {
        h81.m7064for(i >= 0);
        h81.m7064for(i < this.f18144const.length);
        return this.f18144const[i];
    }
}
