package defpackage;

import android.content.Context;
import android.content.Intent;
import com.yandex.metrica.YandexMetricaInternal;
import com.yandex.strannik.a.C1312i;
import com.yandex.strannik.a.M;
import com.yandex.strannik.a.r;
import com.yandex.strannik.api.Passport;
import com.yandex.strannik.api.PassportAccount;
import com.yandex.strannik.api.PassportApi;
import com.yandex.strannik.api.PassportAutoLoginProperties;
import com.yandex.strannik.api.PassportAutoLoginResult;
import com.yandex.strannik.api.PassportFilter;
import com.yandex.strannik.api.PassportLoginProperties;
import com.yandex.strannik.api.PassportUid;
import com.yandex.strannik.api.exception.PassportAccountNotAuthorizedException;
import com.yandex.strannik.api.exception.PassportAccountNotFoundException;
import com.yandex.strannik.api.exception.PassportIOException;
import com.yandex.strannik.api.exception.PassportRuntimeUnknownException;
import defpackage.ck6;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

/* loaded from: classes2.dex */
public class bk6 implements ck6 {

    /* renamed from: do, reason: not valid java name */
    public final el5<String> f3783do;

    /* renamed from: for, reason: not valid java name */
    public volatile PassportAccount f3784for;

    /* renamed from: if, reason: not valid java name */
    public final el5<PassportApi> f3785if;

    public bk6(final Context context) {
        this.f3785if = dn3.h1(new bo5() { // from class: wi6
            @Override // defpackage.bo5
            public final Object invoke() {
                return Passport.createPassportApi(context);
            }
        });
        bo5 bo5Var = new bo5() { // from class: ej6
            @Override // defpackage.bo5
            public final Object invoke() {
                Context context2 = context;
                e8d.m5046else();
                String uuid = YandexMetricaInternal.getUuid(context2);
                if (uuid == null) {
                    jr3.m8593do("YandexMetricaInternal.getUuid() should not return null");
                }
                if (uuid == null) {
                    uuid = "";
                }
                ((c94) dz3.m4865do(c94.class)).f4988if = uuid;
                return uuid;
            }
        };
        jp5.m8570try(bo5Var, "valueProducer");
        this.f3783do = dn3.h1(bo5Var);
        if (Passport.isInPassportProcess()) {
            Passport.initializePassport(context, ((M.a) ((M.a) ((M.a) Passport.createPassportPropertiesBuilder()).m3559addCredentials(Passport.PASSPORT_ENVIRONMENT_PRODUCTION, Passport.createPassportCredentials("2hrlSIPH5MiBX5Pshy3X/wed7sKNfnqKDxODrg5sCwCS3/fqduwjuCuK2zM2exyV", "3RrkStaQtJ/aD8Drh3jfptIgi3KCK2AlQRBrM+JbBns1sQnVHnTkIDEwE521IN4f"))).m3559addCredentials(Passport.PASSPORT_ENVIRONMENT_TESTING, Passport.createPassportCredentials("ikrkENSSt53XX8m+hyXaqY8wpzepYGkL9MHP4seA+OigMPkcOeW+Z5Rth/dxqmUK", "20q+H4OcsZTbWcjuh3/bq5OJw7bS99ycScbKFfjoNFHmoklAwtj9Cp4lMCQDzgnQ"))).m3560build());
        }
    }

    @Override // defpackage.ck6
    /* renamed from: case, reason: not valid java name */
    public PassportAccount mo2104case() {
        if (this.f3784for == null) {
            try {
                zbd.m17941do(m2111this());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return this.f3784for;
    }

    @Override // defpackage.ck6
    public Intent createAutoLoginIntent(Context context, PassportUid passportUid, PassportAutoLoginProperties passportAutoLoginProperties) {
        return this.f3785if.getValue().createAutoLoginIntent(context, passportUid, passportAutoLoginProperties);
    }

    @Override // defpackage.ck6
    public Intent createLoginIntent(Context context, PassportLoginProperties passportLoginProperties) {
        return this.f3785if.getValue().createLoginIntent(context, passportLoginProperties);
    }

    @Override // defpackage.ck6
    /* renamed from: do, reason: not valid java name */
    public String mo2105do() throws kk6 {
        return this.f3783do.getValue();
    }

    @Override // defpackage.ck6
    /* renamed from: else, reason: not valid java name */
    public void mo2106else(String str) {
        mo2107for(str).m1420goto(new sqe() { // from class: aj6
            @Override // defpackage.sqe
            public final void call() {
            }
        }, ak6.f960catch);
    }

    @Override // defpackage.ck6
    /* renamed from: for, reason: not valid java name */
    public ape mo2107for(final String str) {
        Callable callable = new Callable() { // from class: hj6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                bk6Var.f3785if.getValue().dropToken(str);
                return null;
            }
        };
        ape apeVar = ape.f2353do;
        return ape.m1412for(new npe(callable)).m1422this(h0f.m6949for());
    }

    @Override // defpackage.ck6
    public wpe<PassportAccount> getAccount(final PassportUid passportUid) {
        return wpe.m16751this(new Callable() { // from class: gj6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                return bk6Var.f3785if.getValue().getAccount(passportUid);
            }
        }).m16758final(h0f.m6949for()).m16762new(new tqe() { // from class: bj6
            @Override // defpackage.tqe
            public final void call(Object obj) {
                Throwable th = (Throwable) obj;
                if (th instanceof PassportRuntimeUnknownException) {
                    int i = e8d.f9711do;
                    jr3.m8595if(th);
                }
            }
        });
    }

    @Override // defpackage.ck6
    public wpe<List<PassportAccount>> getAccounts(final PassportFilter passportFilter) {
        return wpe.m16751this(new Callable() { // from class: ui6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                return bk6Var.f3785if.getValue().getAccounts(passportFilter);
            }
        }).m16758final(h0f.m6949for()).m16762new(new tqe() { // from class: ti6
            @Override // defpackage.tqe
            public final void call(Object obj) {
                Throwable th = (Throwable) obj;
                if (th instanceof PassportRuntimeUnknownException) {
                    int i = e8d.f9711do;
                    jr3.m8595if(th);
                }
            }
        });
    }

    @Override // defpackage.ck6
    public wpe<String> getToken(final PassportUid passportUid) {
        return wpe.m16751this(new Callable() { // from class: dj6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                return ((C1312i) bk6Var.f3785if.getValue().getToken(passportUid)).getValue();
            }
        }).m16758final(h0f.m6949for()).m16762new(new tqe() { // from class: jj6
            @Override // defpackage.tqe
            public final void call(Object obj) {
                Throwable th = (Throwable) obj;
                if (th instanceof PassportRuntimeUnknownException) {
                    int i = e8d.f9711do;
                    jr3.m8595if(th);
                }
            }
        });
    }

    @Override // defpackage.ck6
    /* renamed from: goto, reason: not valid java name */
    public void mo2108goto(final bh9 bh9Var) {
        if (bh9Var == null) {
            return;
        }
        Callable callable = new Callable() { // from class: ij6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                bk6Var.f3785if.getValue().setCurrentAccount(bh9Var.f3598catch);
                bk6Var.f3784for = bk6Var.f3785if.getValue().getCurrentAccount();
                return null;
            }
        };
        ape apeVar = ape.f2353do;
        ape.m1412for(new npe(callable)).m1422this(h0f.m6949for()).m1420goto(new sqe() { // from class: vi6
            @Override // defpackage.sqe
            public final void call() {
            }
        }, new tqe() { // from class: si6
            @Override // defpackage.tqe
            public final void call(Object obj) {
                Throwable th = (Throwable) obj;
                if (th instanceof PassportRuntimeUnknownException) {
                    int i = e8d.f9711do;
                    jr3.m8595if(th);
                }
            }
        });
    }

    @Override // defpackage.ck6
    /* renamed from: if, reason: not valid java name */
    public ape mo2109if() {
        sqe sqeVar = new sqe() { // from class: cj6
            @Override // defpackage.sqe
            public final void call() {
                bk6 bk6Var = bk6.this;
                if (bk6Var.mo2104case() != null) {
                    try {
                        bk6Var.f3785if.getValue().logout(bk6Var.mo2104case().getUid());
                    } catch (PassportRuntimeUnknownException unused) {
                    }
                }
            }
        };
        ape apeVar = ape.f2353do;
        return ape.m1412for(new mpe(sqeVar)).m1422this(h0f.m6949for());
    }

    @Override // defpackage.ck6
    /* renamed from: new, reason: not valid java name */
    public wpe<List<PassportAccount>> mo2110new() {
        return getAccounts(((r.a) ((r.a) PassportFilter.Builder.Factory.createBuilder()).m3595setPrimaryEnvironment(ck6.a.m2930do())).m3592build());
    }

    @Deprecated
    /* renamed from: this, reason: not valid java name */
    public final wpe<PassportAccount> m2111this() {
        return wpe.m16751this(new Callable() { // from class: fj6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                return bk6.this.f3785if.getValue().getCurrentAccount();
            }
        }).m16758final(h0f.m6948do()).m16762new(new tqe() { // from class: zi6
            @Override // defpackage.tqe
            public final void call(Object obj) {
                Throwable th = (Throwable) obj;
                if (th instanceof PassportRuntimeUnknownException) {
                    int i = e8d.f9711do;
                    jr3.m8595if(th);
                }
            }
        }).m16765try(new tqe() { // from class: kj6
            @Override // defpackage.tqe
            public final void call(Object obj) {
                bk6.this.f3784for = (PassportAccount) obj;
            }
        });
    }

    @Override // defpackage.ck6
    /* renamed from: try, reason: not valid java name */
    public wpe<b9d<String>> mo2112try(final String str, final String str2) {
        return wpe.m16751this(new Callable() { // from class: xi6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                String str3 = str;
                String str4 = str2;
                PassportAccount passportAccount = (PassportAccount) new j0f(bk6Var.m2111this()).m8059do();
                try {
                    if (passportAccount == null) {
                        return b9d.f3242if;
                    }
                    String authorizationUrl = bk6Var.f3785if.getValue().getAuthorizationUrl(passportAccount.getUid(), str3, str4, null);
                    b9d b9dVar = authorizationUrl == null ? null : new b9d(authorizationUrl, null);
                    return b9dVar == null ? b9d.f3242if : b9dVar;
                } catch (PassportAccountNotAuthorizedException | PassportAccountNotFoundException | PassportIOException unused) {
                    return b9d.f3242if;
                } catch (PassportRuntimeUnknownException e) {
                    int i = e8d.f9711do;
                    jr3.m8595if(e);
                    return b9d.f3242if;
                }
            }
        }).m16758final(h0f.m6949for());
    }

    @Override // defpackage.ck6
    public wpe<PassportAutoLoginResult> tryAutoLogin(final Context context, final PassportAutoLoginProperties passportAutoLoginProperties) {
        return wpe.m16751this(new Callable() { // from class: yi6
            @Override // java.util.concurrent.Callable
            public final Object call() {
                bk6 bk6Var = bk6.this;
                return bk6Var.f3785if.getValue().tryAutoLogin(context, passportAutoLoginProperties);
            }
        });
    }
}
