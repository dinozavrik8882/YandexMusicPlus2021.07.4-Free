package defpackage;

import defpackage.i11;
import defpackage.m11;

/* loaded from: classes.dex */
public final class g21 extends z01<m11.a> {

    /* renamed from: public, reason: not valid java name */
    public static final m11.a f12945public = new m11.a(new Object(), -1);

    /* loaded from: classes.dex */
    public final class a implements i11.a {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ g21 f12946do;
    }
}
