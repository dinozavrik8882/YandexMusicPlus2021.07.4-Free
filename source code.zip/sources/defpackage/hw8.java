package defpackage;

import android.support.v4.media.session.MediaSessionCompat;

/* loaded from: classes2.dex */
public final class hw8 extends kp5 implements bo5<pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ aw8 f15761catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ MediaSessionCompat.Token f15762class;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public hw8(aw8 aw8Var, MediaSessionCompat.Token token) {
        super(0);
        this.f15761catch = aw8Var;
        this.f15762class = token;
    }

    @Override // defpackage.bo5
    public pl5 invoke() {
        k2f.f19768new.mo8773super("NotificationCenter: restore seekbar", new Object[0]);
        this.f15761catch.f2594case.m18255const(this.f15762class);
        aw8.m1548do(this.f15761catch);
        return pl5.f29126do;
    }
}
