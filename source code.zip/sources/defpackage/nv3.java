package defpackage;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;

/* loaded from: classes.dex */
public final class nv3 implements rc4 {

    /* renamed from: do, reason: not valid java name */
    public final Gson f26139do;

    /* renamed from: if, reason: not valid java name */
    public final ov3 f26140if;

    @ln5(c = "com.yandex.music.core.network.cache.NetworkCache", f = "NetworkCache.kt", l = {42}, m = "get")
    /* loaded from: classes.dex */
    public static final class a extends jn5 {

        /* renamed from: final, reason: not valid java name */
        public /* synthetic */ Object f26141final;

        /* renamed from: throw, reason: not valid java name */
        public int f26143throw;

        public a(wm5<? super a> wm5Var) {
            super(wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            this.f26141final = obj;
            this.f26143throw |= Integer.MIN_VALUE;
            return nv3.this.mo11227do(null, null, this);
        }
    }

    @ln5(c = "com.yandex.music.core.network.cache.NetworkCache$get$2", f = "NetworkCache.kt", l = {}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class b extends pn5 implements qo5<InputStream, wm5<? super hl5<? extends Object, ? extends Long>>, Object> {

        /* renamed from: super, reason: not valid java name */
        public /* synthetic */ Object f26144super;

        /* renamed from: while, reason: not valid java name */
        public final /* synthetic */ Type f26146while;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(Type type, wm5<? super b> wm5Var) {
            super(2, wm5Var);
            this.f26146while = type;
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            b bVar = new b(this.f26146while, wm5Var);
            bVar.f26144super = obj;
            return bVar;
        }

        @Override // defpackage.qo5
        public Object invoke(InputStream inputStream, wm5<? super hl5<? extends Object, ? extends Long>> wm5Var) {
            InputStream inputStream2 = inputStream;
            wm5<? super hl5<? extends Object, ? extends Long>> wm5Var2 = wm5Var;
            nv3 nv3Var = nv3.this;
            Type type = this.f26146while;
            if (wm5Var2 != null) {
                wm5Var2.getContext();
            }
            pl5 pl5Var = pl5.f29126do;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(pl5Var);
            if (inputStream2 == null) {
                return null;
            }
            long readLong = new DataInputStream(inputStream2).readLong();
            Gson gson = nv3Var.f26139do;
            Reader inputStreamReader = new InputStreamReader(inputStream2, ns5.f26008do);
            af3 m3348class = gson.m3348class(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
            Object m3361try = gson.m3361try(m3348class, type);
            Gson.m3343do(m3361try, m3348class);
            jp5.m8565for(m3361try);
            return new hl5(m3361try, new Long(readLong));
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(obj);
            InputStream inputStream = (InputStream) this.f26144super;
            if (inputStream == null) {
                return null;
            }
            long readLong = new DataInputStream(inputStream).readLong();
            Gson gson = nv3.this.f26139do;
            Reader inputStreamReader = new InputStreamReader(inputStream, ns5.f26008do);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            Type type = this.f26146while;
            af3 m3348class = gson.m3348class(bufferedReader);
            Object m3361try = gson.m3361try(m3348class, type);
            Gson.m3343do(m3361try, m3348class);
            jp5.m8565for(m3361try);
            return new hl5(m3361try, new Long(readLong));
        }
    }

    @ln5(c = "com.yandex.music.core.network.cache.NetworkCache", f = "NetworkCache.kt", l = {24}, m = "put")
    /* loaded from: classes.dex */
    public static final class c extends jn5 {

        /* renamed from: final, reason: not valid java name */
        public /* synthetic */ Object f26147final;

        /* renamed from: throw, reason: not valid java name */
        public int f26149throw;

        public c(wm5<? super c> wm5Var) {
            super(wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            this.f26147final = obj;
            this.f26149throw |= Integer.MIN_VALUE;
            return nv3.this.mo11228if(null, null, null, 0L, this);
        }
    }

    @ln5(c = "com.yandex.music.core.network.cache.NetworkCache$put$2", f = "NetworkCache.kt", l = {}, m = "invokeSuspend")
    /* loaded from: classes.dex */
    public static final class d extends pn5 implements qo5<OutputStream, wm5<? super pl5>, Object> {

        /* renamed from: import, reason: not valid java name */
        public final /* synthetic */ Object f26150import;

        /* renamed from: native, reason: not valid java name */
        public final /* synthetic */ Type f26151native;

        /* renamed from: super, reason: not valid java name */
        public /* synthetic */ Object f26152super;

        /* renamed from: throw, reason: not valid java name */
        public final /* synthetic */ long f26153throw;

        /* renamed from: while, reason: not valid java name */
        public final /* synthetic */ nv3 f26154while;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(long j, nv3 nv3Var, Object obj, Type type, wm5<? super d> wm5Var) {
            super(2, wm5Var);
            this.f26153throw = j;
            this.f26154while = nv3Var;
            this.f26150import = obj;
            this.f26151native = type;
        }

        @Override // defpackage.hn5
        /* renamed from: final */
        public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
            d dVar = new d(this.f26153throw, this.f26154while, this.f26150import, this.f26151native, wm5Var);
            dVar.f26152super = obj;
            return dVar;
        }

        @Override // defpackage.qo5
        public Object invoke(OutputStream outputStream, wm5<? super pl5> wm5Var) {
            OutputStream outputStream2 = outputStream;
            wm5<? super pl5> wm5Var2 = wm5Var;
            long j = this.f26153throw;
            nv3 nv3Var = this.f26154while;
            Object obj = this.f26150import;
            Type type = this.f26151native;
            if (wm5Var2 != null) {
                wm5Var2.getContext();
            }
            pl5 pl5Var = pl5.f29126do;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(pl5Var);
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream2);
            dataOutputStream.writeLong(j);
            dataOutputStream.flush();
            Writer outputStreamWriter = new OutputStreamWriter(outputStream2, ns5.f26008do);
            BufferedWriter bufferedWriter = outputStreamWriter instanceof BufferedWriter ? (BufferedWriter) outputStreamWriter : new BufferedWriter(outputStreamWriter, 8192);
            nv3Var.f26139do.m3355native(obj, type, bufferedWriter);
            bufferedWriter.flush();
            return pl5Var;
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            dn3.N2(obj);
            OutputStream outputStream = (OutputStream) this.f26152super;
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            dataOutputStream.writeLong(this.f26153throw);
            dataOutputStream.flush();
            Writer outputStreamWriter = new OutputStreamWriter(outputStream, ns5.f26008do);
            BufferedWriter bufferedWriter = outputStreamWriter instanceof BufferedWriter ? (BufferedWriter) outputStreamWriter : new BufferedWriter(outputStreamWriter, 8192);
            this.f26154while.f26139do.m3355native(this.f26150import, this.f26151native, bufferedWriter);
            bufferedWriter.flush();
            return pl5.f29126do;
        }
    }

    public nv3(Gson gson, ov3 ov3Var) {
        jp5.m8570try(gson, "gson");
        jp5.m8570try(ov3Var, "storage");
        this.f26139do = gson;
        this.f26140if = ov3Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0022  */
    @Override // defpackage.rc4
    /* renamed from: do, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object mo11227do(java.lang.String r6, java.lang.reflect.Type r7, defpackage.wm5<? super defpackage.hl5<? extends java.lang.Object, java.lang.Long>> r8) {
        /*
            r5 = this;
            boolean r0 = r8 instanceof nv3.a
            if (r0 == 0) goto L13
            r0 = r8
            nv3$a r0 = (nv3.a) r0
            int r1 = r0.f26143throw
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f26143throw = r1
            goto L18
        L13:
            nv3$a r0 = new nv3$a
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f26141final
            cn5 r1 = defpackage.cn5.COROUTINE_SUSPENDED
            int r2 = r0.f26143throw
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L30
            if (r2 != r3) goto L28
            defpackage.dn3.N2(r8)     // Catch: java.io.IOException -> L51
            goto L4d
        L28:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L30:
            defpackage.dn3.N2(r8)
            ov3 r8 = r5.f26140if     // Catch: java.io.IOException -> L51
            nv3$b r2 = new nv3$b     // Catch: java.io.IOException -> L51
            r2.<init>(r7, r4)     // Catch: java.io.IOException -> L51
            r0.f26143throw = r3     // Catch: java.io.IOException -> L51
            java.util.Objects.requireNonNull(r8)     // Catch: java.io.IOException -> L51
            pv3 r7 = new pv3     // Catch: java.io.IOException -> L51
            r7.<init>(r8, r6, r2, r4)     // Catch: java.io.IOException -> L51
            du5 r6 = defpackage.kv4.f21091if     // Catch: java.io.IOException -> L51
            java.lang.Object r8 = defpackage.dn3.F3(r6, r7, r0)     // Catch: java.io.IOException -> L51
            if (r8 != r1) goto L4d
            return r1
        L4d:
            hl5 r8 = (defpackage.hl5) r8     // Catch: java.io.IOException -> L51
            r4 = r8
            goto L5d
        L51:
            r6 = move-exception
            lr3 r7 = new lr3
            java.lang.String r8 = "Exception in NetworkCache#get"
            r7.<init>(r8, r6)
            r6 = 2
            defpackage.jr3.m8596new(r7, r4, r6)
        L5d:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.nv3.mo11227do(java.lang.String, java.lang.reflect.Type, wm5):java.lang.Object");
    }

    /* JADX WARN: Can't wrap try/catch for region: R(9:1|(2:3|(7:5|6|7|(1:(1:10)(2:16|17))(3:18|19|(1:21))|11|12|13))|24|6|7|(0)(0)|11|12|13) */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x005b, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x005c, code lost:
    
        defpackage.jr3.m8596new(new defpackage.lr3("Exception in NetworkCache#put", r0), null, 2);
     */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0026  */
    @Override // defpackage.rc4
    /* renamed from: if, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object mo11228if(java.lang.String r15, java.lang.reflect.Type r16, java.lang.Object r17, long r18, defpackage.wm5<? super defpackage.pl5> r20) {
        /*
            r14 = this;
            r8 = r14
            r0 = r20
            boolean r1 = r0 instanceof nv3.c
            if (r1 == 0) goto L16
            r1 = r0
            nv3$c r1 = (nv3.c) r1
            int r2 = r1.f26149throw
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L16
            int r2 = r2 - r3
            r1.f26149throw = r2
            goto L1b
        L16:
            nv3$c r1 = new nv3$c
            r1.<init>(r0)
        L1b:
            r0 = r1
            java.lang.Object r1 = r0.f26147final
            cn5 r9 = defpackage.cn5.COROUTINE_SUSPENDED
            int r2 = r0.f26149throw
            r10 = 0
            r11 = 1
            if (r2 == 0) goto L34
            if (r2 != r11) goto L2c
            defpackage.dn3.N2(r1)     // Catch: java.io.IOException -> L5b
            goto L67
        L2c:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L34:
            defpackage.dn3.N2(r1)
            ov3 r12 = r8.f26140if     // Catch: java.io.IOException -> L5b
            nv3$d r13 = new nv3$d     // Catch: java.io.IOException -> L5b
            r7 = 0
            r1 = r13
            r2 = r18
            r4 = r14
            r5 = r17
            r6 = r16
            r1.<init>(r2, r4, r5, r6, r7)     // Catch: java.io.IOException -> L5b
            r0.f26149throw = r11     // Catch: java.io.IOException -> L5b
            java.util.Objects.requireNonNull(r12)     // Catch: java.io.IOException -> L5b
            qv3 r1 = new qv3     // Catch: java.io.IOException -> L5b
            r2 = r15
            r1.<init>(r12, r15, r13, r10)     // Catch: java.io.IOException -> L5b
            du5 r2 = defpackage.kv4.f21091if     // Catch: java.io.IOException -> L5b
            java.lang.Object r0 = defpackage.dn3.F3(r2, r1, r0)     // Catch: java.io.IOException -> L5b
            if (r0 != r9) goto L67
            return r9
        L5b:
            r0 = move-exception
            lr3 r1 = new lr3
            java.lang.String r2 = "Exception in NetworkCache#put"
            r1.<init>(r2, r0)
            r0 = 2
            defpackage.jr3.m8596new(r1, r10, r0)
        L67:
            pl5 r0 = defpackage.pl5.f29126do
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.nv3.mo11228if(java.lang.String, java.lang.reflect.Type, java.lang.Object, long, wm5):java.lang.Object");
    }
}
