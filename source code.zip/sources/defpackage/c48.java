package defpackage;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import androidx.fragment.app.Fragment;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public class c48 extends xh {

    /* renamed from: class, reason: not valid java name */
    public q58 f4856class;

    /* renamed from: const, reason: not valid java name */
    public boolean f4857const;

    /* renamed from: final, reason: not valid java name */
    public boolean f4858final;

    @Override // androidx.fragment.app.Fragment
    public Context getContext() {
        q58 q58Var = this.f4856class;
        f9d.m5797for(q58Var, "arg is null");
        return q58Var;
    }

    @Override // androidx.fragment.app.Fragment
    public final void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override // defpackage.xh, defpackage.lg, androidx.fragment.app.Fragment
    public final void onAttach(Context context) {
        Fragment parentFragment = getParentFragment();
        if (parentFragment != null) {
            context = parentFragment.getContext();
        }
        q58 q58Var = new q58(context, this);
        this.f4856class = q58Var;
        super.onAttach(q58Var);
        this.f4857const = false;
        mo2600private(q58Var);
        if (this.f4857const) {
            return;
        }
        throw new RuntimeException("Fragment " + this + " did not call through to super.onAttachContext(Context)");
    }

    @Override // defpackage.lg
    public Dialog onCreateDialog(Bundle bundle) {
        int theme = getTheme();
        if (theme == 0) {
            TypedValue typedValue = new TypedValue();
            getContext().getTheme().resolveAttribute(R.attr.appDialogTheme, typedValue, true);
            theme = typedValue.resourceId;
        }
        return new Dialog(getContext(), theme);
    }

    @Override // defpackage.lg, androidx.fragment.app.Fragment
    public LayoutInflater onGetLayoutInflater(Bundle bundle) {
        return super.onGetLayoutInflater(bundle).cloneInContext(this.f4858final ? new ContextThemeWrapper(this.f4856class, getTheme()) : this.f4856class);
    }

    /* renamed from: private, reason: not valid java name */
    public void mo2600private(Context context) {
        this.f4857const = true;
    }

    @Override // defpackage.lg
    public void setStyle(int i, int i2) {
        super.setStyle(i, i2);
        if (i2 != 0) {
            this.f4858final = true;
        }
    }
}
