package defpackage;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import defpackage.wm2;

/* loaded from: classes.dex */
public class xm2 extends qm2 implements wm2 {
    @Override // defpackage.wm2
    /* renamed from: do */
    public void mo16138do() {
        throw null;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public Drawable getCircularRevealOverlayDrawable() {
        throw null;
    }

    @Override // defpackage.wm2
    public int getCircularRevealScrimColor() {
        throw null;
    }

    @Override // defpackage.wm2
    public wm2.e getRevealInfo() {
        throw null;
    }

    @Override // defpackage.wm2
    /* renamed from: if */
    public void mo16139if() {
        throw null;
    }

    @Override // android.view.View
    public boolean isOpaque() {
        return super.isOpaque();
    }

    @Override // defpackage.wm2
    public void setCircularRevealOverlayDrawable(Drawable drawable) {
        throw null;
    }

    @Override // defpackage.wm2
    public void setCircularRevealScrimColor(int i) {
        throw null;
    }

    @Override // defpackage.wm2
    public void setRevealInfo(wm2.e eVar) {
        throw null;
    }
}
