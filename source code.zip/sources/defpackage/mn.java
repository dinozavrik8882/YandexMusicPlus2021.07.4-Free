package defpackage;

import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes.dex */
public abstract class mn {

    /* renamed from: do, reason: not valid java name */
    public final RecyclerView.m f24293do;

    /* renamed from: if, reason: not valid java name */
    public int f24295if = Integer.MIN_VALUE;

    /* renamed from: for, reason: not valid java name */
    public final Rect f24294for = new Rect();

    public mn(RecyclerView.m mVar, kn knVar) {
        this.f24293do = mVar;
    }

    /* renamed from: do, reason: not valid java name */
    public static mn m10519do(RecyclerView.m mVar, int i) {
        if (i == 0) {
            return new kn(mVar);
        }
        if (i == 1) {
            return new ln(mVar);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    /* renamed from: break */
    public abstract int mo9092break();

    /* renamed from: case */
    public abstract int mo9093case();

    /* renamed from: catch */
    public abstract int mo9094catch();

    /* renamed from: class */
    public abstract int mo9095class();

    /* renamed from: const, reason: not valid java name */
    public int m10520const() {
        if (Integer.MIN_VALUE == this.f24295if) {
            return 0;
        }
        return mo9095class() - this.f24295if;
    }

    /* renamed from: else */
    public abstract int mo9096else();

    /* renamed from: final */
    public abstract int mo9097final(View view);

    /* renamed from: for */
    public abstract int mo9098for(View view);

    /* renamed from: goto */
    public abstract int mo9099goto();

    /* renamed from: if */
    public abstract int mo9100if(View view);

    /* renamed from: new */
    public abstract int mo9101new(View view);

    /* renamed from: super */
    public abstract int mo9102super(View view);

    /* renamed from: this */
    public abstract int mo9103this();

    /* renamed from: throw */
    public abstract void mo9104throw(int i);

    /* renamed from: try */
    public abstract int mo9105try(View view);
}
