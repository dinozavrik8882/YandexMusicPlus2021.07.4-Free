package defpackage;

import android.content.Context;
import defpackage.bz3;
import java.util.LinkedHashSet;
import java.util.concurrent.Executor;
import okhttp3.OkHttpClient;

/* loaded from: classes2.dex */
public final class u0 {

    /* renamed from: do, reason: not valid java name */
    public final m28 f38136do;

    /* renamed from: if, reason: not valid java name */
    public final rr4 f38137if;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements bo5<Boolean> {

        /* renamed from: catch, reason: not valid java name */
        public static final a f38138catch = new a(0);

        /* renamed from: class, reason: not valid java name */
        public static final a f38139class = new a(1);

        /* renamed from: const, reason: not valid java name */
        public static final a f38140const = new a(2);

        /* renamed from: final, reason: not valid java name */
        public final /* synthetic */ int f38141final;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(int i) {
            super(0);
            this.f38141final = i;
        }

        @Override // defpackage.bo5
        public final Boolean invoke() {
            LinkedHashSet linkedHashSet;
            int i = this.f38141final;
            if (i == 0) {
                iz3 l3 = dn3.l3(v14.class);
                jp5.m8570try(l3, "typeSpec");
                bz3 bz3Var = bz3.f4526do;
                jp5.m8565for(bz3Var);
                jp5.m8570try(l3, "typeSpec");
                linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
                return Boolean.valueOf(((ti8) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(ti8.class))).m13409else());
            }
            if (i == 1) {
                iz3 l32 = dn3.l3(v14.class);
                jp5.m8570try(l32, "typeSpec");
                bz3 bz3Var2 = bz3.f4526do;
                jp5.m8565for(bz3Var2);
                jp5.m8570try(l32, "typeSpec");
                linkedHashSet = bz3Var2.f4528if ? new LinkedHashSet() : null;
                return Boolean.valueOf(((si8) ((v14) bz3Var2.m2426new(l32, linkedHashSet != null ? new bz3.a(bz3Var2, linkedHashSet) : bz3Var2.f4529new, linkedHashSet)).m15853do(dq5.m4763do(si8.class))).m13409else());
            }
            if (i != 2) {
                throw null;
            }
            iz3 l33 = dn3.l3(v14.class);
            jp5.m8570try(l33, "typeSpec");
            bz3 bz3Var3 = bz3.f4526do;
            jp5.m8565for(bz3Var3);
            jp5.m8570try(l33, "typeSpec");
            linkedHashSet = bz3Var3.f4528if ? new LinkedHashSet() : null;
            return Boolean.valueOf(((ni8) ((v14) bz3Var3.m2426new(l33, linkedHashSet != null ? new bz3.a(bz3Var3, linkedHashSet) : bz3Var3.f4529new, linkedHashSet)).m15853do(dq5.m4763do(ni8.class))).m13409else());
        }
    }

    public u0(Context context, zs3 zs3Var, xr4 xr4Var, zr4 zr4Var, wr4 wr4Var, m28 m28Var, OkHttpClient okHttpClient, up0[] up0VarArr, OkHttpClient okHttpClient2) {
        jp5.m8570try(context, "context");
        jp5.m8570try(zs3Var, "buildInfo");
        jp5.m8570try(xr4Var, "storageRootResolver");
        jp5.m8570try(zr4Var, "tracksCacheDatabase");
        jp5.m8570try(wr4Var, "networkConnectivityProvider");
        jp5.m8570try(m28Var, "trackVariantFactory");
        jp5.m8570try(okHttpClient, "httpClient");
        jp5.m8570try(up0VarArr, "audioProcessors");
        jp5.m8570try(okHttpClient2, "mediaSourceHttpClient");
        this.f38136do = m28Var;
        du5 du5Var = kv4.f21091if;
        cv5 cv5Var = du5Var instanceof cv5 ? (cv5) du5Var : null;
        final Executor qu5Var = cv5Var == null ? new qu5(du5Var) : cv5Var.a0();
        Executor executor = new Executor() { // from class: ek8
            @Override // java.util.concurrent.Executor
            public final void execute(final Runnable runnable) {
                Executor executor2 = qu5Var;
                jp5.m8570try(executor2, "$this_thatClearsInterruptFlag");
                executor2.execute(new Runnable() { // from class: dk8
                    @Override // java.lang.Runnable
                    public final void run() {
                        try {
                            runnable.run();
                        } finally {
                            Thread.interrupted();
                        }
                    }
                });
            }
        };
        ruc rucVar = ruc.f34420for;
        String m18233do = zs3Var.m18233do(a74.class);
        m18233do = m18233do == null ? a74.PROD.getUrl() : m18233do;
        String V = g8d.V();
        jp5.m8568new(V, "storageKey()");
        this.f38137if = new rr4(context, okHttpClient, okHttpClient2, executor, xr4Var, rucVar, zr4Var, wr4Var, m18233do, V, 4023, "ru.yandex.music", up0VarArr, a.f38138catch, a.f38139class, a.f38140const);
    }
}
