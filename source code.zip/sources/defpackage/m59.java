package defpackage;

import java.io.Serializable;
import java.util.List;

/* loaded from: classes2.dex */
public class m59 extends fad<l59, List<e69>> implements Serializable {
    private static final long serialVersionUID = 1;

    public m59(l59 l59Var, List<e69> list) {
        super(l59Var, list);
    }
}
