package defpackage;

import defpackage.f66;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes2.dex */
public final class j46 implements Iterator<String>, iq5 {

    /* renamed from: catch, reason: not valid java name */
    public final Iterator<f66.c> f17923catch;

    /* renamed from: class, reason: not valid java name */
    public String f17924class;

    /* renamed from: const, reason: not valid java name */
    public boolean f17925const;

    public j46(i46 i46Var) {
        h66 h66Var;
        f66 f66Var = i46Var.f16171catch;
        synchronized (f66Var) {
            f66Var.m5679import();
            h66Var = new h66(f66Var);
        }
        this.f17923catch = h66Var;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        if (this.f17924class != null) {
            return true;
        }
        this.f17925const = false;
        while (this.f17923catch.hasNext()) {
            try {
                f66.c next = this.f17923catch.next();
                try {
                    continue;
                    this.f17924class = ((fa6) v56.m15901else(next.m5690do(0))).s();
                    dn3.s(next, null);
                    return true;
                } finally {
                    try {
                        continue;
                        break;
                    } catch (Throwable th) {
                    }
                }
            } catch (IOException unused) {
            }
        }
        return false;
    }

    @Override // java.util.Iterator
    public String next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        String str = this.f17924class;
        jp5.m8565for(str);
        this.f17924class = null;
        this.f17925const = true;
        return str;
    }

    @Override // java.util.Iterator
    public void remove() {
        if (!this.f17925const) {
            throw new IllegalStateException("remove() before next()".toString());
        }
        this.f17923catch.remove();
    }
}
