package defpackage;

import defpackage.a3a;
import defpackage.lu9;
import ru.yandex.music.common.media.context.PlaybackScope;

/* loaded from: classes2.dex */
public final class ru9 implements a3a.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ lu9 f34418do;

    public ru9(lu9 lu9Var) {
        this.f34418do = lu9Var;
    }

    @Override // a3a.a
    /* renamed from: do */
    public void mo100do(h59 h59Var) {
        jp5.m8570try(h59Var, "album");
        lu9.b bVar = this.f34418do.f22823default;
        if (bVar == null) {
            return;
        }
        PlaybackScope m342this = a88.m342this();
        jp5.m8568new(m342this, "forNewReleases()");
        bVar.mo9254final(h59Var, m342this);
        mt9.f24568for.m10604extends("new_releases", "click");
    }

    @Override // a3a.a
    /* renamed from: goto */
    public void mo101goto() {
        lu9.b bVar = this.f34418do.f22823default;
        if (bVar == null) {
            return;
        }
        bVar.mo9256goto();
        mt9.f24568for.m10604extends("new_releases", "all");
    }
}
