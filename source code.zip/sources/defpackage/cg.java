package defpackage;

import android.os.Looper;
import android.util.AndroidRuntimeException;
import defpackage.bg;
import defpackage.cg;
import java.util.ArrayList;
import java.util.Objects;

/* loaded from: classes.dex */
public abstract class cg<T extends cg<T>> implements bg.b {

    /* renamed from: new, reason: not valid java name */
    public final dg f5302new;

    /* renamed from: do, reason: not valid java name */
    public float f5297do = 0.0f;

    /* renamed from: if, reason: not valid java name */
    public float f5301if = Float.MAX_VALUE;

    /* renamed from: for, reason: not valid java name */
    public boolean f5299for = false;

    /* renamed from: try, reason: not valid java name */
    public boolean f5304try = false;

    /* renamed from: case, reason: not valid java name */
    public float f5295case = Float.MAX_VALUE;

    /* renamed from: else, reason: not valid java name */
    public float f5298else = -3.4028235E38f;

    /* renamed from: goto, reason: not valid java name */
    public long f5300goto = 0;

    /* renamed from: break, reason: not valid java name */
    public final ArrayList<c> f5294break = new ArrayList<>();

    /* renamed from: catch, reason: not valid java name */
    public final ArrayList<d> f5296catch = new ArrayList<>();

    /* renamed from: this, reason: not valid java name */
    public float f5303this = 1.0f;

    /* loaded from: classes.dex */
    public class a extends dg {

        /* renamed from: do, reason: not valid java name */
        public final /* synthetic */ eg f5305do;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(cg cgVar, String str, eg egVar) {
            super(str);
            this.f5305do = egVar;
        }

        @Override // defpackage.dg
        /* renamed from: do, reason: not valid java name */
        public float mo2881do(Object obj) {
            return this.f5305do.f9953do;
        }

        @Override // defpackage.dg
        /* renamed from: if, reason: not valid java name */
        public void mo2882if(Object obj, float f) {
            this.f5305do.f9953do = f;
        }
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: do, reason: not valid java name */
        public float f5306do;

        /* renamed from: if, reason: not valid java name */
        public float f5307if;
    }

    /* loaded from: classes.dex */
    public interface c {
        /* renamed from: do, reason: not valid java name */
        void m2883do(cg cgVar, boolean z, float f, float f2);
    }

    /* loaded from: classes.dex */
    public interface d {
        /* renamed from: do, reason: not valid java name */
        void m2884do(cg cgVar, float f, float f2);
    }

    public cg(eg egVar) {
        this.f5302new = new a(this, "FloatValueHolder", egVar);
    }

    /* renamed from: new, reason: not valid java name */
    public static <T> void m2877new(ArrayList<T> arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (arrayList.get(size) == null) {
                arrayList.remove(size);
            }
        }
    }

    @Override // bg.b
    /* renamed from: do */
    public boolean mo1992do(long j) {
        long j2 = this.f5300goto;
        if (j2 == 0) {
            this.f5300goto = j;
            m2880try(this.f5301if);
            return false;
        }
        long j3 = j - j2;
        this.f5300goto = j;
        fg fgVar = (fg) this;
        boolean z = true;
        if (fgVar.f11839const != Float.MAX_VALUE) {
            gg ggVar = fgVar.f11838class;
            double d2 = ggVar.f13525this;
            long j4 = j3 / 2;
            b m6614do = ggVar.m6614do(fgVar.f5301if, fgVar.f5297do, j4);
            gg ggVar2 = fgVar.f11838class;
            ggVar2.f13525this = fgVar.f11839const;
            fgVar.f11839const = Float.MAX_VALUE;
            b m6614do2 = ggVar2.m6614do(m6614do.f5306do, m6614do.f5307if, j4);
            fgVar.f5301if = m6614do2.f5306do;
            fgVar.f5297do = m6614do2.f5307if;
        } else {
            b m6614do3 = fgVar.f11838class.m6614do(fgVar.f5301if, fgVar.f5297do, j3);
            fgVar.f5301if = m6614do3.f5306do;
            fgVar.f5297do = m6614do3.f5307if;
        }
        float max = Math.max(fgVar.f5301if, fgVar.f5298else);
        fgVar.f5301if = max;
        float min = Math.min(max, fgVar.f5295case);
        fgVar.f5301if = min;
        float f = fgVar.f5297do;
        gg ggVar3 = fgVar.f11838class;
        Objects.requireNonNull(ggVar3);
        if (((double) Math.abs(f)) < ggVar3.f13526try && ((double) Math.abs(min - ((float) ggVar3.f13525this))) < ggVar3.f13524new) {
            fgVar.f5301if = (float) fgVar.f11838class.f13525this;
            fgVar.f5297do = 0.0f;
        } else {
            z = false;
        }
        float min2 = Math.min(this.f5301if, this.f5295case);
        this.f5301if = min2;
        float max2 = Math.max(min2, this.f5298else);
        this.f5301if = max2;
        m2880try(max2);
        if (z) {
            m2878for(false);
        }
        return z;
    }

    /* renamed from: for, reason: not valid java name */
    public final void m2878for(boolean z) {
        this.f5304try = false;
        bg m1990do = bg.m1990do();
        m1990do.f3528if.remove(this);
        int indexOf = m1990do.f3527for.indexOf(this);
        if (indexOf >= 0) {
            m1990do.f3527for.set(indexOf, null);
            m1990do.f3526else = true;
        }
        this.f5300goto = 0L;
        this.f5299for = false;
        for (int i = 0; i < this.f5294break.size(); i++) {
            if (this.f5294break.get(i) != null) {
                this.f5294break.get(i).m2883do(this, z, this.f5301if, this.f5297do);
            }
        }
        m2877new(this.f5294break);
    }

    /* renamed from: if, reason: not valid java name */
    public void m2879if() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new AndroidRuntimeException("Animations may only be canceled on the main thread");
        }
        if (this.f5304try) {
            m2878for(true);
        }
    }

    /* renamed from: try, reason: not valid java name */
    public void m2880try(float f) {
        this.f5302new.mo2882if(null, f);
        for (int i = 0; i < this.f5296catch.size(); i++) {
            if (this.f5296catch.get(i) != null) {
                this.f5296catch.get(i).m2884do(this, this.f5301if, this.f5297do);
            }
        }
        m2877new(this.f5296catch);
    }
}
