package defpackage;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.facebook.CustomTabMainActivity;
import defpackage.vf0;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class gf0 extends fg0 {
    public static final Parcelable.Creator<gf0> CREATOR = new a();

    /* renamed from: final, reason: not valid java name */
    public static boolean f13490final;

    /* renamed from: super, reason: not valid java name */
    public String f13491super;

    /* renamed from: throw, reason: not valid java name */
    public String f13492throw;

    /* renamed from: while, reason: not valid java name */
    public String f13493while;

    /* loaded from: classes.dex */
    public static class a implements Parcelable.Creator {
        @Override // android.os.Parcelable.Creator
        public Object createFromParcel(Parcel parcel) {
            return new gf0(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public Object[] newArray(int i) {
            return new gf0[i];
        }
    }

    public gf0(Parcel parcel) {
        super(parcel);
        this.f13493while = "";
        this.f13492throw = parcel.readString();
    }

    public gf0(vf0 vf0Var) {
        super(vf0Var);
        this.f13493while = "";
        this.f13492throw = new BigInteger(100, new Random()).toString(32);
        f13490final = false;
        this.f13493while = kd0.m8935for(super.m5965native());
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x00d8  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00e1  */
    @Override // defpackage.cg0
    /* renamed from: break */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean mo2886break(int r7, int r8, android.content.Intent r9) {
        /*
            r6 = this;
            r0 = 0
            if (r9 == 0) goto Lc
            java.lang.String r1 = com.facebook.CustomTabMainActivity.f5672throw
            boolean r1 = r9.getBooleanExtra(r1, r0)
            if (r1 == 0) goto Lc
            return r0
        Lc:
            r1 = 1
            if (r7 == r1) goto L10
            return r0
        L10:
            vf0 r7 = r6.f5309class
            vf0$d r7 = r7.f40477while
            r2 = 0
            r3 = -1
            if (r8 != r3) goto Lef
            java.lang.String r8 = com.facebook.CustomTabMainActivity.f5670final
            java.lang.String r8 = r9.getStringExtra(r8)
            if (r8 == 0) goto Lee
            java.lang.String r9 = "fbconnect://cct."
            boolean r9 = r8.startsWith(r9)
            if (r9 != 0) goto L32
            java.lang.String r9 = super.m5965native()
            boolean r9 = r8.startsWith(r9)
            if (r9 == 0) goto Lee
        L32:
            android.net.Uri r8 = android.net.Uri.parse(r8)
            java.lang.String r9 = r8.getQuery()
            android.os.Bundle r9 = defpackage.ee0.m5130private(r9)
            java.lang.String r8 = r8.getFragment()
            android.os.Bundle r8 = defpackage.ee0.m5130private(r8)
            r9.putAll(r8)
            java.lang.String r8 = "state"
            java.lang.String r8 = r9.getString(r8)     // Catch: org.json.JSONException -> L63
            if (r8 != 0) goto L52
            goto L63
        L52:
            org.json.JSONObject r4 = new org.json.JSONObject     // Catch: org.json.JSONException -> L63
            r4.<init>(r8)     // Catch: org.json.JSONException -> L63
            java.lang.String r8 = "7_challenge"
            java.lang.String r8 = r4.getString(r8)     // Catch: org.json.JSONException -> L63
            java.lang.String r4 = r6.f13492throw     // Catch: org.json.JSONException -> L63
            boolean r0 = r8.equals(r4)     // Catch: org.json.JSONException -> L63
        L63:
            if (r0 != 0) goto L71
            x80 r8 = new x80
            java.lang.String r9 = "Invalid state parameter"
            r8.<init>(r9)
            r6.m5967return(r7, r2, r8)
            goto Lee
        L71:
            java.lang.String r8 = "error"
            java.lang.String r8 = r9.getString(r8)
            if (r8 != 0) goto L7f
            java.lang.String r8 = "error_type"
            java.lang.String r8 = r9.getString(r8)
        L7f:
            java.lang.String r0 = "error_msg"
            java.lang.String r0 = r9.getString(r0)
            if (r0 != 0) goto L8d
            java.lang.String r0 = "error_message"
            java.lang.String r0 = r9.getString(r0)
        L8d:
            if (r0 != 0) goto L95
            java.lang.String r0 = "error_description"
            java.lang.String r0 = r9.getString(r0)
        L95:
            java.lang.String r4 = "error_code"
            java.lang.String r4 = r9.getString(r4)
            boolean r5 = defpackage.ee0.m5115default(r4)
            if (r5 != 0) goto La6
            int r4 = java.lang.Integer.parseInt(r4)     // Catch: java.lang.NumberFormatException -> La6
            goto La7
        La6:
            r4 = r3
        La7:
            boolean r5 = defpackage.ee0.m5115default(r8)
            if (r5 == 0) goto Lb9
            boolean r5 = defpackage.ee0.m5115default(r0)
            if (r5 == 0) goto Lb9
            if (r4 != r3) goto Lb9
            r6.m5967return(r7, r9, r2)
            goto Lee
        Lb9:
            if (r8 == 0) goto Ld4
            java.lang.String r9 = "access_denied"
            boolean r9 = r8.equals(r9)
            if (r9 != 0) goto Lcb
            java.lang.String r9 = "OAuthAccessDeniedException"
            boolean r9 = r8.equals(r9)
            if (r9 == 0) goto Ld4
        Lcb:
            z80 r8 = new z80
            r8.<init>()
            r6.m5967return(r7, r2, r8)
            goto Lee
        Ld4:
            r9 = 4201(0x1069, float:5.887E-42)
            if (r4 != r9) goto Le1
            z80 r8 = new z80
            r8.<init>()
            r6.m5967return(r7, r2, r8)
            goto Lee
        Le1:
            a90 r9 = new a90
            r9.<init>(r4, r8, r0)
            d90 r8 = new d90
            r8.<init>(r9, r0)
            r6.m5967return(r7, r2, r8)
        Lee:
            return r1
        Lef:
            z80 r8 = new z80
            r8.<init>()
            r6.m5967return(r7, r2, r8)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.gf0.mo2886break(int, int, android.content.Intent):boolean");
    }

    @Override // defpackage.cg0
    /* renamed from: case */
    public String mo2887case() {
        return "custom_tab";
    }

    @Override // defpackage.cg0
    /* renamed from: catch */
    public void mo2888catch(JSONObject jSONObject) throws JSONException {
        jSONObject.put("7_challenge", this.f13492throw);
    }

    @Override // defpackage.cg0
    /* renamed from: class */
    public int mo2889class(vf0.d dVar) {
        if (this.f13493while.isEmpty()) {
            return 0;
        }
        Bundle m5968throw = m5968throw(dVar);
        m5968throw.putString("redirect_uri", this.f13493while);
        m5968throw.putString("client_id", dVar.f40481final);
        m5968throw.putString("e2e", vf0.m16052break());
        m5968throw.putString("response_type", "token,signed_request,graph_domain");
        m5968throw.putString("return_scopes", "true");
        m5968throw.putString("auth_type", dVar.f40482import);
        m5968throw.putString("login_behavior", dVar.f40478catch.name());
        Locale locale = Locale.ROOT;
        HashSet<l90> hashSet = b90.f3183do;
        m5968throw.putString("sdk", String.format(locale, "android-%s", "8.2.0"));
        m5968throw.putString("sso", "chrome_custom_tab");
        m5968throw.putString("cct_prefetching", b90.f3182const ? "1" : "0");
        if (f13490final) {
            m5968throw.putString("cct_over_app_switch", "1");
        }
        if (b90.f3182const) {
            hf0.m7214if(jd0.m8302do("oauth", m5968throw));
        }
        Intent intent = new Intent(this.f5309class.m16054case(), (Class<?>) CustomTabMainActivity.class);
        intent.putExtra(CustomTabMainActivity.f5667catch, "oauth");
        intent.putExtra(CustomTabMainActivity.f5668class, m5968throw);
        String str = CustomTabMainActivity.f5669const;
        String str2 = this.f13491super;
        if (str2 == null) {
            str2 = kd0.m8934do();
            this.f13491super = str2;
        }
        intent.putExtra(str, str2);
        this.f5309class.f40468const.startActivityForResult(intent, 1);
        return 1;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // defpackage.fg0
    /* renamed from: public */
    public s80 mo5966public() {
        return s80.CHROME_CUSTOM_TAB;
    }

    @Override // defpackage.cg0, android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        ee0.m5124implements(parcel, this.f5308catch);
        parcel.writeString(this.f13492throw);
    }
}
