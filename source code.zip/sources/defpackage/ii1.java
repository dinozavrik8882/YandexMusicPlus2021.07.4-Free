package defpackage;

import android.util.LruCache;

/* loaded from: classes.dex */
public final class ii1 extends LruCache<Integer, xf1> {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ qg1 f16868do;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ii1(qg1 qg1Var, int i) {
        super(i);
        this.f16868do = qg1Var;
    }

    @Override // android.util.LruCache
    public final /* synthetic */ void entryRemoved(boolean z, Integer num, xf1 xf1Var, xf1 xf1Var2) {
        Integer num2 = num;
        if (z) {
            this.f16868do.f30553else.add(num2);
        }
    }
}
