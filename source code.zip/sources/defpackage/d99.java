package defpackage;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

/* loaded from: classes2.dex */
public class d99 extends a89<glb> {

    /* renamed from: do, reason: not valid java name */
    public static final d99 f8178do = new d99();

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.LinkedList] */
    @Override // defpackage.c89
    /* renamed from: for, reason: not valid java name and merged with bridge method [inline-methods] */
    public glb mo1839do(v79 v79Var) throws IOException {
        LinkedList emptyList = Collections.emptyList();
        v79Var.m15970do();
        h59 h59Var = null;
        while (v79Var.m15972for()) {
            String m15971else = v79Var.m15971else();
            if ("album".equals(m15971else)) {
                h59Var = gr8.m6786finally(v79Var);
            } else if ("tracks".equals(m15971else)) {
                emptyList = new LinkedList();
                w79 w79Var = v79Var.f40238do;
                w79Var.f41785do.mo517do();
                w79Var.f41787if.push(bf3.BEGIN_ARRAY);
                while (v79Var.m15972for()) {
                    try {
                        v79Var.m15975new();
                        emptyList.add(gr8.m6774abstract(v79Var));
                    } catch (y79 e) {
                        v79Var.m15966break();
                        k2f.f19768new.mo8767import(e);
                    } catch (Exception e2) {
                        v79Var.m15966break();
                        int i = e8d.f9711do;
                        jr3.m8595if(e2);
                    }
                }
                w79 w79Var2 = v79Var.f40238do;
                w79Var2.f41785do.endArray();
                e8d.m5045do(bf3.BEGIN_ARRAY, w79Var2.f41787if.pop());
            } else {
                v79Var.m15968catch();
            }
        }
        v79Var.m15974if();
        f9d.m5797for(h59Var, "arg is null");
        f9d.m5797for(emptyList, "arg is null");
        return new glb(h59Var, emptyList);
    }
}
