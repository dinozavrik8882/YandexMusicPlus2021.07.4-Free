package defpackage;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.exoplayer2.util.Util;

/* loaded from: classes.dex */
public final class yy0 extends zy0 {
    public static final Parcelable.Creator<yy0> CREATOR = new a();

    /* renamed from: catch, reason: not valid java name */
    public final long f46316catch;

    /* renamed from: class, reason: not valid java name */
    public final long f46317class;

    /* renamed from: const, reason: not valid java name */
    public final byte[] f46318const;

    /* loaded from: classes.dex */
    public class a implements Parcelable.Creator<yy0> {
        @Override // android.os.Parcelable.Creator
        public yy0 createFromParcel(Parcel parcel) {
            return new yy0(parcel, null);
        }

        @Override // android.os.Parcelable.Creator
        public yy0[] newArray(int i) {
            return new yy0[i];
        }
    }

    public yy0(long j, byte[] bArr, long j2) {
        this.f46316catch = j2;
        this.f46317class = j;
        this.f46318const = bArr;
    }

    public yy0(Parcel parcel, a aVar) {
        this.f46316catch = parcel.readLong();
        this.f46317class = parcel.readLong();
        this.f46318const = (byte[]) Util.castNonNull(parcel.createByteArray());
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(this.f46316catch);
        parcel.writeLong(this.f46317class);
        parcel.writeByteArray(this.f46318const);
    }
}
