package defpackage;

/* loaded from: classes2.dex */
public interface i29 {
    /* renamed from: do */
    void mo6977do();
}
