package defpackage;

import android.net.Uri;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/* loaded from: classes.dex */
public final class g11 {

    /* renamed from: do, reason: not valid java name */
    public static final AtomicLong f12893do = new AtomicLong();

    /* renamed from: for, reason: not valid java name */
    public final Map<String, List<String>> f12894for;

    /* renamed from: if, reason: not valid java name */
    public final Uri f12895if;

    /* renamed from: new, reason: not valid java name */
    public final long f12896new;

    /* renamed from: try, reason: not valid java name */
    public final long f12897try;

    public g11(long j, n91 n91Var, long j2) {
        Uri uri = n91Var.f25240do;
        Map<String, List<String>> emptyMap = Collections.emptyMap();
        this.f12895if = uri;
        this.f12894for = emptyMap;
        this.f12896new = 0L;
        this.f12897try = 0L;
    }

    public g11(long j, n91 n91Var, Uri uri, Map<String, List<String>> map, long j2, long j3, long j4) {
        this.f12895if = uri;
        this.f12894for = map;
        this.f12896new = j3;
        this.f12897try = j4;
    }

    /* renamed from: do, reason: not valid java name */
    public static long m6324do() {
        return f12893do.getAndIncrement();
    }
}
