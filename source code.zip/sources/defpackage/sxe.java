package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class sxe<E> extends AtomicReference<sxe<E>> {
    private static final long serialVersionUID = 2404266111789071508L;

    /* renamed from: catch, reason: not valid java name */
    public E f36214catch;

    public sxe() {
    }

    public sxe(E e) {
        this.f36214catch = e;
    }

    /* renamed from: do, reason: not valid java name */
    public E m14503do() {
        E e = this.f36214catch;
        this.f36214catch = null;
        return e;
    }

    /* renamed from: if, reason: not valid java name */
    public sxe<E> m14504if() {
        return get();
    }
}
