package defpackage;

/* loaded from: classes2.dex */
public enum pp6 {
    SYSTEM,
    LIGHT,
    DARK
}
