package defpackage;

/* loaded from: classes.dex */
public final class ld3 extends hd3 {
    private static final long serialVersionUID = 1;

    public ld3(String str) {
        super(str);
    }

    public ld3(String str, Throwable th) {
        super(str, th);
    }

    public ld3(Throwable th) {
        super(th);
    }
}
