package defpackage;

import android.text.Layout;
import android.text.NoCopySpan;
import android.text.Selection;
import android.text.Spannable;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ClickableSpan;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.TextView;

/* loaded from: classes2.dex */
public class kke extends ScrollingMovementMethod {

    /* renamed from: do, reason: not valid java name */
    public static Object f20595do = new NoCopySpan.Concrete();

    /* renamed from: if, reason: not valid java name */
    public final a f20596if;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: do, reason: not valid java name */
        boolean mo9058do(ClickableSpan clickableSpan);
    }

    public kke(a aVar) {
        this.f20596if = aVar;
    }

    @Override // android.text.method.BaseMovementMethod, android.text.method.MovementMethod
    public boolean canSelectArbitrarily() {
        return true;
    }

    /* renamed from: do, reason: not valid java name */
    public final boolean m9057do(int i, TextView textView, Spannable spannable) {
        Layout layout = textView.getLayout();
        int totalPaddingBottom = textView.getTotalPaddingBottom() + textView.getTotalPaddingTop();
        int scrollY = textView.getScrollY();
        int height = (textView.getHeight() + scrollY) - totalPaddingBottom;
        int lineForVertical = layout.getLineForVertical(scrollY);
        int lineForVertical2 = layout.getLineForVertical(height);
        int lineStart = layout.getLineStart(lineForVertical);
        int lineEnd = layout.getLineEnd(lineForVertical2);
        ClickableSpan[] clickableSpanArr = (ClickableSpan[]) spannable.getSpans(lineStart, lineEnd, ClickableSpan.class);
        int selectionStart = Selection.getSelectionStart(spannable);
        int selectionEnd = Selection.getSelectionEnd(spannable);
        int min = Math.min(selectionStart, selectionEnd);
        int max = Math.max(selectionStart, selectionEnd);
        if (min < 0 && spannable.getSpanStart(f20595do) >= 0) {
            min = spannable.length();
            max = min;
        }
        if (min > lineEnd) {
            max = Integer.MAX_VALUE;
            min = Integer.MAX_VALUE;
        }
        int i2 = -1;
        if (max < lineStart) {
            max = -1;
            min = -1;
        }
        if (i == 1) {
            if (min == max) {
                return false;
            }
            ClickableSpan[] clickableSpanArr2 = (ClickableSpan[]) spannable.getSpans(min, max, ClickableSpan.class);
            if (clickableSpanArr2.length != 1) {
                return false;
            }
            ClickableSpan clickableSpan = clickableSpanArr2[0];
            if (!this.f20596if.mo9058do(clickableSpan)) {
                clickableSpan.onClick(textView);
            }
        } else if (i == 2) {
            int i3 = -1;
            for (int i4 = 0; i4 < clickableSpanArr.length; i4++) {
                int spanEnd = spannable.getSpanEnd(clickableSpanArr[i4]);
                if ((spanEnd < max || min == max) && spanEnd > i3) {
                    i2 = spannable.getSpanStart(clickableSpanArr[i4]);
                    i3 = spanEnd;
                }
            }
            if (i2 >= 0) {
                Selection.setSelection(spannable, i3, i2);
                return true;
            }
        } else if (i == 3) {
            int i5 = Integer.MAX_VALUE;
            int i6 = Integer.MAX_VALUE;
            for (int i7 = 0; i7 < clickableSpanArr.length; i7++) {
                int spanStart = spannable.getSpanStart(clickableSpanArr[i7]);
                if ((spanStart > min || min == max) && spanStart < i6) {
                    i5 = spannable.getSpanEnd(clickableSpanArr[i7]);
                    i6 = spanStart;
                }
            }
            if (i5 < Integer.MAX_VALUE) {
                Selection.setSelection(spannable, i6, i5);
                return true;
            }
        }
        return false;
    }

    @Override // android.text.method.ScrollingMovementMethod, android.text.method.BaseMovementMethod
    public boolean down(TextView textView, Spannable spannable) {
        if (m9057do(3, textView, spannable)) {
            return true;
        }
        return super.down(textView, spannable);
    }

    @Override // android.text.method.BaseMovementMethod
    public boolean handleMovementKey(TextView textView, Spannable spannable, int i, int i2, KeyEvent keyEvent) {
        if ((i == 23 || i == 66) && KeyEvent.metaStateHasNoModifiers(i2) && keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0 && m9057do(1, textView, spannable)) {
            return true;
        }
        return super.handleMovementKey(textView, spannable, i, i2, keyEvent);
    }

    @Override // android.text.method.BaseMovementMethod, android.text.method.MovementMethod
    public void initialize(TextView textView, Spannable spannable) {
        Selection.removeSelection(spannable);
        spannable.removeSpan(f20595do);
    }

    @Override // android.text.method.ScrollingMovementMethod, android.text.method.BaseMovementMethod
    public boolean left(TextView textView, Spannable spannable) {
        if (m9057do(2, textView, spannable)) {
            return true;
        }
        return super.left(textView, spannable);
    }

    @Override // android.text.method.ScrollingMovementMethod, android.text.method.BaseMovementMethod, android.text.method.MovementMethod
    public void onTakeFocus(TextView textView, Spannable spannable, int i) {
        Selection.removeSelection(spannable);
        if ((i & 1) != 0) {
            spannable.setSpan(f20595do, 0, 0, 34);
        } else {
            spannable.removeSpan(f20595do);
        }
    }

    @Override // android.text.method.ScrollingMovementMethod, android.text.method.BaseMovementMethod, android.text.method.MovementMethod
    public boolean onTouchEvent(TextView textView, Spannable spannable, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 1 || action == 0) {
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            int totalPaddingLeft = x - textView.getTotalPaddingLeft();
            int totalPaddingTop = y - textView.getTotalPaddingTop();
            int scrollX = textView.getScrollX() + totalPaddingLeft;
            int scrollY = textView.getScrollY() + totalPaddingTop;
            Layout layout = textView.getLayout();
            int offsetForHorizontal = layout.getOffsetForHorizontal(layout.getLineForVertical(scrollY), scrollX);
            ClickableSpan[] clickableSpanArr = (ClickableSpan[]) spannable.getSpans(offsetForHorizontal, offsetForHorizontal, ClickableSpan.class);
            if (clickableSpanArr.length != 0) {
                if (action == 1) {
                    ClickableSpan clickableSpan = clickableSpanArr[0];
                    if (!this.f20596if.mo9058do(clickableSpan)) {
                        clickableSpan.onClick(textView);
                    }
                } else if (action == 0) {
                    Selection.setSelection(spannable, spannable.getSpanStart(clickableSpanArr[0]), spannable.getSpanEnd(clickableSpanArr[0]));
                }
                return true;
            }
            Selection.removeSelection(spannable);
        }
        return super.onTouchEvent(textView, spannable, motionEvent);
    }

    @Override // android.text.method.ScrollingMovementMethod, android.text.method.BaseMovementMethod
    public boolean right(TextView textView, Spannable spannable) {
        if (m9057do(3, textView, spannable)) {
            return true;
        }
        return super.right(textView, spannable);
    }

    @Override // android.text.method.ScrollingMovementMethod, android.text.method.BaseMovementMethod
    public boolean up(TextView textView, Spannable spannable) {
        if (m9057do(2, textView, spannable)) {
            return true;
        }
        return super.up(textView, spannable);
    }
}
