package defpackage;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.SnackbarContentLayout;

/* loaded from: classes.dex */
public class xp2 extends AnimatorListenerAdapter {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ BaseTransientBottomBar f44225do;

    public xp2(BaseTransientBottomBar baseTransientBottomBar) {
        this.f44225do = baseTransientBottomBar;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f44225do.m3227try();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        SnackbarContentLayout snackbarContentLayout = (SnackbarContentLayout) this.f44225do.f6310else;
        snackbarContentLayout.f6337catch.setAlpha(0.0f);
        long j = 180;
        long j2 = 70;
        snackbarContentLayout.f6337catch.animate().alpha(1.0f).setDuration(j).setStartDelay(j2).start();
        if (snackbarContentLayout.f6338class.getVisibility() == 0) {
            snackbarContentLayout.f6338class.setAlpha(0.0f);
            snackbarContentLayout.f6338class.animate().alpha(1.0f).setDuration(j).setStartDelay(j2).start();
        }
    }
}
