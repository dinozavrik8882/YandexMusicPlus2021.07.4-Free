package defpackage;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.cq6;
import defpackage.kq6;
import defpackage.sp6;
import java.util.List;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class kq6 extends lg {

    /* renamed from: catch, reason: not valid java name */
    public static final b f20869catch;

    /* renamed from: class, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f20870class;

    /* renamed from: const, reason: not valid java name */
    public cq6 f20871const;

    /* renamed from: final, reason: not valid java name */
    public TextView f20872final;

    /* renamed from: import, reason: not valid java name */
    public final mq5 f20873import;

    /* renamed from: native, reason: not valid java name */
    public final mq5 f20874native;

    /* renamed from: public, reason: not valid java name */
    public final mq5 f20875public;

    /* renamed from: return, reason: not valid java name */
    public final mq5 f20876return;

    /* renamed from: static, reason: not valid java name */
    public final cq6.a f20877static;

    /* renamed from: super, reason: not valid java name */
    public TextView f20878super;

    /* renamed from: throw, reason: not valid java name */
    public bq6 f20879throw;

    /* renamed from: while, reason: not valid java name */
    public a f20880while;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: do, reason: not valid java name */
        void mo9185do(rp6 rp6Var);

        /* renamed from: for, reason: not valid java name */
        void mo9186for(qp6 qp6Var);

        /* renamed from: if, reason: not valid java name */
        void mo9187if();

        /* renamed from: new, reason: not valid java name */
        void mo9188new();
    }

    /* loaded from: classes2.dex */
    public static final class b {
        public b(ep5 ep5Var) {
        }
    }

    /* loaded from: classes2.dex */
    public static final class c extends lq5<List<? extends rp6>> {

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ kq6 f20881if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(Object obj, Object obj2, kq6 kq6Var) {
            super(obj2);
            this.f20881if = kq6Var;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, List<? extends rp6> list, List<? extends rp6> list2) {
            jp5.m8570try(mr5Var, "property");
            this.f20881if.m9184strictfp();
            this.f20881if.m9180abstract();
        }
    }

    /* loaded from: classes2.dex */
    public static final class d extends lq5<sp6> {

        /* renamed from: for, reason: not valid java name */
        public final /* synthetic */ kq6 f20882for;

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ Object f20883if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(Object obj, Object obj2, kq6 kq6Var) {
            super(obj2);
            this.f20883if = obj;
            this.f20882for = kq6Var;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, sp6 sp6Var, sp6 sp6Var2) {
            jp5.m8570try(mr5Var, "property");
            this.f20882for.m9181continue();
        }
    }

    /* loaded from: classes2.dex */
    public static final class e extends lq5<qp6> {

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ kq6 f20884if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public e(Object obj, Object obj2, kq6 kq6Var) {
            super(null);
            this.f20884if = kq6Var;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, qp6 qp6Var, qp6 qp6Var2) {
            jp5.m8570try(mr5Var, "property");
            this.f20884if.m9182package();
        }
    }

    /* loaded from: classes2.dex */
    public static final class f extends lq5<Boolean> {

        /* renamed from: if, reason: not valid java name */
        public final /* synthetic */ kq6 f20885if;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public f(Object obj, Object obj2, kq6 kq6Var) {
            super(obj2);
            this.f20885if = kq6Var;
        }

        @Override // defpackage.lq5
        /* renamed from: for */
        public void mo57for(mr5<?> mr5Var, Boolean bool, Boolean bool2) {
            jp5.m8570try(mr5Var, "property");
            bool2.booleanValue();
            bool.booleanValue();
            this.f20885if.m9183private();
        }
    }

    static {
        op5 op5Var = new op5(dq5.m4763do(kq6.class), "items", "getItems()Ljava/util/List;");
        eq5 eq5Var = dq5.f8909do;
        Objects.requireNonNull(eq5Var);
        op5 op5Var2 = new op5(dq5.m4763do(kq6.class), "selection", "getSelection()Lru/yandex/music/cast/picker/data/CastSelection;");
        Objects.requireNonNull(eq5Var);
        op5 op5Var3 = new op5(dq5.m4763do(kq6.class), "explanation", "getExplanation()Lru/yandex/music/cast/picker/data/CastExplanation;");
        Objects.requireNonNull(eq5Var);
        op5 op5Var4 = new op5(dq5.m4763do(kq6.class), "showFeedbackButton", "getShowFeedbackButton()Z");
        Objects.requireNonNull(eq5Var);
        f20870class = new mr5[]{op5Var, op5Var2, op5Var3, op5Var4};
        f20869catch = new b(null);
    }

    public kq6() {
        em5 em5Var = em5.f10300catch;
        this.f20873import = new c(em5Var, em5Var, this);
        sp6.b bVar = sp6.b.f35826if;
        this.f20874native = new d(bVar, bVar, this);
        this.f20875public = new e(null, null, this);
        Boolean bool = Boolean.FALSE;
        this.f20876return = new f(bool, bool, this);
        this.f20877static = new cq6.a() { // from class: zp6
            @Override // cq6.a
            /* renamed from: do */
            public final void mo3805do(rp6 rp6Var) {
                kq6 kq6Var = kq6.this;
                jp5.m8570try(kq6Var, "this$0");
                jp5.m8570try(rp6Var, "item");
                kq6.a aVar = kq6Var.f20880while;
                if (aVar == null) {
                    return;
                }
                aVar.mo9185do(rp6Var);
            }
        };
    }

    /* renamed from: abstract, reason: not valid java name */
    public final void m9180abstract() {
        cq6 cq6Var = this.f20871const;
        if (cq6Var == null) {
            return;
        }
        cq6Var.m7389do((List) this.f20873import.mo9880if(this, f20870class[0]));
    }

    /* renamed from: continue, reason: not valid java name */
    public final void m9181continue() {
        cq6 cq6Var = this.f20871const;
        if (cq6Var == null) {
            return;
        }
        sp6 sp6Var = (sp6) this.f20874native.mo9880if(this, f20870class[1]);
        jp5.m8570try(sp6Var, "<set-?>");
        cq6Var.f7346try.mo9879do(cq6Var, cq6.f7343for[0], sp6Var);
    }

    @Override // defpackage.lg, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (this.f20880while == null) {
            dismissAllowingStateLoss();
            return;
        }
        Bundle arguments = getArguments();
        int i = R.style.CastPicker_Theme;
        Integer valueOf = arguments == null ? null : Integer.valueOf(arguments.getInt("cast_picker_theme", R.style.CastPicker_Theme));
        if (valueOf != null) {
            i = valueOf.intValue();
        }
        setStyle(2, i);
        setCancelable(true);
        setRetainInstance(true);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        jp5.m8570try(layoutInflater, "inflater");
        return layoutInflater.inflate(R.layout.cast_picker_bottomsheet, viewGroup, false);
    }

    @Override // defpackage.lg, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        jp5.m8570try(dialogInterface, "dialog");
        super.onDismiss(dialogInterface);
        a aVar = this.f20880while;
        if (aVar != null) {
            aVar.mo9187if();
        }
        this.f20880while = null;
    }

    @Override // defpackage.lg, androidx.fragment.app.Fragment
    public void onStart() {
        Window window;
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog == null || (window = dialog.getWindow()) == null) {
            return;
        }
        window.setLayout(-1, -1);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        jp5.m8570try(view, "view");
        super.onViewCreated(view, bundle);
        view.setOnClickListener(new View.OnClickListener() { // from class: aq6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                kq6 kq6Var = kq6.this;
                jp5.m8570try(kq6Var, "this$0");
                kq6Var.dismissAllowingStateLoss();
            }
        });
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.rv_devices);
        Context context = recyclerView.getContext();
        jp5.m8568new(context, "context");
        recyclerView.m1107goto(new vp6(context, false, false, 6));
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        cq6 cq6Var = new cq6(this.f20877static);
        this.f20871const = cq6Var;
        recyclerView.setAdapter(cq6Var);
        this.f20872final = (TextView) view.findViewById(R.id.cast_picker_title);
        this.f20878super = (TextView) view.findViewById(R.id.cast_picker_feedback);
        this.f20879throw = new bq6(view, new xp6(this));
        TextView textView = this.f20878super;
        if (textView != null) {
            m9183private();
            textView.setOnClickListener(new View.OnClickListener() { // from class: yp6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    kq6 kq6Var = kq6.this;
                    jp5.m8570try(kq6Var, "this$0");
                    kq6.a aVar = kq6Var.f20880while;
                    if (aVar == null) {
                        return;
                    }
                    aVar.mo9188new();
                }
            });
        }
        m9184strictfp();
        m9180abstract();
        m9181continue();
        m9182package();
    }

    /* renamed from: package, reason: not valid java name */
    public final void m9182package() {
        pl5 pl5Var;
        bq6 bq6Var = this.f20879throw;
        if (bq6Var == null) {
            return;
        }
        qp6 qp6Var = (qp6) this.f20875public.mo9880if(this, f20870class[2]);
        Object value = bq6Var.f4155if.getValue();
        jp5.m8568new(value, "<get-itemView>(...)");
        ((ViewGroup) value).setVisibility(qp6Var != null ? 0 : 8);
        if (qp6Var == null) {
            return;
        }
        Object value2 = bq6Var.f4154for.getValue();
        jp5.m8568new(value2, "<get-icon>(...)");
        ImageView imageView = (ImageView) value2;
        Integer num = qp6Var.f31111do;
        jp5.m8570try(imageView, "<this>");
        imageView.setVisibility(num != null ? 0 : 8);
        if (num == null) {
            pl5Var = null;
        } else {
            imageView.setImageResource(num.intValue());
            pl5Var = pl5.f29126do;
        }
        if (pl5Var == null) {
            imageView.setImageDrawable(null);
        }
        Object value3 = bq6Var.f4156new.getValue();
        jp5.m8568new(value3, "<get-title>(...)");
        dn3.f2((TextView) value3, qp6Var.f31113if, qp6Var.f31112for);
        Object value4 = bq6Var.f4157try.getValue();
        jp5.m8568new(value4, "<get-button>(...)");
        dn3.f2((Button) value4, qp6Var.f31114new, qp6Var.f31115try);
    }

    /* renamed from: private, reason: not valid java name */
    public final void m9183private() {
        TextView textView = this.f20878super;
        if (textView == null) {
            return;
        }
        textView.setVisibility(((Boolean) this.f20876return.mo9880if(this, f20870class[3])).booleanValue() ? 0 : 8);
    }

    /* renamed from: strictfp, reason: not valid java name */
    public final void m9184strictfp() {
        TextView textView = this.f20872final;
        if (textView == null) {
            return;
        }
        textView.setVisibility(((List) this.f20873import.mo9880if(this, f20870class[0])).isEmpty() ^ true ? 0 : 8);
    }
}
