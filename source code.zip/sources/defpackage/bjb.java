package defpackage;

import android.app.Activity;
import android.os.Bundle;
import defpackage.cjb;
import defpackage.rl;
import java.util.ArrayList;

/* loaded from: classes2.dex */
public class bjb {

    /* renamed from: break, reason: not valid java name */
    public final rn8 f3737break;

    /* renamed from: case, reason: not valid java name */
    public final fo6 f3738case;

    /* renamed from: catch, reason: not valid java name */
    public final cjb.a f3739catch;

    /* renamed from: class, reason: not valid java name */
    public final rl.a f3740class;

    /* renamed from: const, reason: not valid java name */
    public uq7 f3741const;

    /* renamed from: else, reason: not valid java name */
    public final vq7 f3743else;

    /* renamed from: final, reason: not valid java name */
    public cjb f3744final;

    /* renamed from: for, reason: not valid java name */
    public final Activity f3745for;

    /* renamed from: goto, reason: not valid java name */
    public final oa8 f3746goto;

    /* renamed from: new, reason: not valid java name */
    public final rl f3748new;

    /* renamed from: super, reason: not valid java name */
    public boolean f3749super;

    /* renamed from: this, reason: not valid java name */
    public final wga f3750this;

    /* renamed from: try, reason: not valid java name */
    public final ql f3751try;

    /* renamed from: do, reason: not valid java name */
    public final r0f f3742do = new r0f();

    /* renamed from: if, reason: not valid java name */
    public final r0f f3747if = new r0f();

    /* loaded from: classes2.dex */
    public class a implements cjb.a {
        public a() {
        }
    }

    /* loaded from: classes2.dex */
    public class b extends rl.a {
        public b() {
        }

        @Override // rl.a
        /* renamed from: do */
        public void mo1052do(rl rlVar, rl.e eVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: else */
        public void mo1053else(rl rlVar, rl.f fVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: for */
        public void mo1054for(rl rlVar, rl.e eVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: goto */
        public void mo1055goto(rl rlVar, rl.f fVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: if */
        public void mo1056if(rl rlVar, rl.e eVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: new */
        public void mo1057new(rl rlVar, rl.f fVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: this */
        public void mo1058this(rl rlVar, rl.f fVar) {
            bjb.this.m2098if();
        }

        @Override // rl.a
        /* renamed from: try */
        public void mo1059try(rl rlVar, rl.f fVar) {
            bjb.this.m2098if();
        }
    }

    public bjb(Activity activity) {
        String m8965do = kf1.m8965do("F3514B38");
        if (m8965do == null) {
            throw new IllegalArgumentException("category must not be null");
        }
        ArrayList<String> arrayList = new ArrayList<>();
        if (!arrayList.contains(m8965do)) {
            arrayList.add(m8965do);
        }
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("controlCategories", arrayList);
        this.f3751try = new ql(bundle, arrayList);
        this.f3739catch = new a();
        this.f3740class = new b();
        this.f3741const = uq7.DISCONNECTED;
        this.f3748new = rl.m13332try(activity);
        this.f3746goto = (oa8) dz3.m4865do(oa8.class);
        this.f3750this = (wga) dz3.m4865do(wga.class);
        this.f3738case = (fo6) dz3.m4865do(fo6.class);
        this.f3743else = (vq7) dz3.m4865do(vq7.class);
        this.f3745for = activity;
        this.f3737break = new rn8();
    }

    /* renamed from: do, reason: not valid java name */
    public final void m2097do() {
        cjb cjbVar = this.f3744final;
        if (cjbVar == null) {
            return;
        }
        if (!this.f3749super) {
            cjbVar.f5395for.mo9879do(cjbVar, cjb.f5392do[0], null);
        } else {
            cjbVar.f5395for.mo9879do(cjbVar, cjb.f5392do[0], this.f3751try);
        }
    }

    /* renamed from: if, reason: not valid java name */
    public final void m2098if() {
        this.f3749super = this.f3748new.m13343this(this.f3751try, 2);
        m2097do();
        this.f3748new.m13338do(this.f3751try, this.f3740class, 1);
    }
}
