package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class t8a {

    /* renamed from: do, reason: not valid java name */
    public static final t8a f36801do = null;

    /* renamed from: if, reason: not valid java name */
    public static final bz3.b f36802if = new bz3.b(a.f36803catch);

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements mo5<az3, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public static final a f36803catch = new a();

        public a() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(az3 az3Var) {
            az3 az3Var2 = az3Var;
            jp5.m8570try(az3Var2, "$this$$receiver");
            az3Var2.m1595if(dn3.l3(p8a.class)).m1597if(r8a.f32059catch);
            az3Var2.m1595if(dn3.l3(h8a.class)).m1597if(s8a.f35133catch);
            return pl5.f29126do;
        }
    }
}
