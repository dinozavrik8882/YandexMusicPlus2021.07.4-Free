package defpackage;

import defpackage.bz3;
import defpackage.so4;
import java.util.LinkedHashSet;

/* loaded from: classes2.dex */
public final class xq9 extends so4 {

    /* loaded from: classes2.dex */
    public static final class a {
        /* renamed from: do, reason: not valid java name */
        public static final boolean m17279do() {
            return true;
        }
    }

    public xq9() {
        super("AndroidKidsLanding", new so4.a("link", "default", "on"), false, false, false, 28);
    }

    @Override // defpackage.so4
    /* renamed from: try */
    public void mo11361try() {
        iz3 l3 = dn3.l3(v14.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        jp5.m8570try(l3, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var.f4528if ? new LinkedHashSet() : null;
        if (jp5.m8563do(((xq9) ((v14) bz3Var.m2426new(l3, linkedHashSet != null ? new bz3.a(bz3Var, linkedHashSet) : bz3Var.f4529new, linkedHashSet)).m15853do(dq5.m4763do(xq9.class))).m14341new(), "on")) {
            iz3 l32 = dn3.l3(zoc.class);
            jp5.m8570try(l32, "typeSpec");
            bz3 bz3Var2 = bz3.f4526do;
            jp5.m8565for(bz3Var2);
            jp5.m8570try(l32, "typeSpec");
            LinkedHashSet linkedHashSet2 = bz3Var2.f4528if ? new LinkedHashSet() : null;
            zoc zocVar = (zoc) bz3Var2.m2426new(l32, linkedHashSet2 != null ? new bz3.a(bz3Var2, linkedHashSet2) : bz3Var2.f4529new, linkedHashSet2);
            iz3 l33 = dn3.l3(qg9.class);
            jp5.m8570try(l33, "typeSpec");
            bz3 bz3Var3 = bz3.f4526do;
            jp5.m8565for(bz3Var3);
            jp5.m8570try(l33, "typeSpec");
            LinkedHashSet linkedHashSet3 = bz3Var3.f4528if ? new LinkedHashSet() : null;
            mg9 mo9658else = ((qg9) bz3Var3.m2426new(l33, linkedHashSet3 != null ? new bz3.a(bz3Var3, linkedHashSet3) : bz3Var3.f4529new, linkedHashSet3)).mo9658else();
            jp5.m8568new(mo9658else, "Di.instance<UserCenter>().latestSmallUser()");
            jp5.m8570try(mo9658else, "user");
            zocVar.f47642new.put(mo9658else.getId(), new cpc(zocVar.f47639do, zocVar, mo9658else));
        }
    }
}
