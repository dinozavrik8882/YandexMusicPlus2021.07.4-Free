package defpackage;

import android.content.Context;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public class vyd {

    /* renamed from: do, reason: not valid java name */
    public final int f41389do;

    /* renamed from: if, reason: not valid java name */
    public Context f41390if;

    public vyd(Context context) {
        this.f41390if = context;
        this.f41389do = context.getResources().getDimensionPixelSize(R.dimen.cashback_glyph_big_view_size);
    }
}
