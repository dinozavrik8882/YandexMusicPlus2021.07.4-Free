package defpackage;

/* loaded from: classes2.dex */
public final class n9e extends l9e {
    public n9e(String str) {
        super(str, (String) null, false, false, 14);
    }
}
