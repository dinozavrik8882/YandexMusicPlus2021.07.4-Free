package defpackage;

import java.util.NoSuchElementException;

/* loaded from: classes2.dex */
public final class sq5 extends bm5 {

    /* renamed from: catch, reason: not valid java name */
    public final int f35885catch;

    /* renamed from: class, reason: not valid java name */
    public boolean f35886class;

    /* renamed from: const, reason: not valid java name */
    public int f35887const;

    /* renamed from: final, reason: not valid java name */
    public final int f35888final;

    public sq5(char c, char c2, int i) {
        this.f35888final = i;
        this.f35885catch = c2;
        boolean z = true;
        if (i <= 0 ? jp5.m8564else(c, c2) < 0 : jp5.m8564else(c, c2) > 0) {
            z = false;
        }
        this.f35886class = z;
        this.f35887const = z ? c : c2;
    }

    @Override // defpackage.bm5
    /* renamed from: do */
    public char mo2170do() {
        int i = this.f35887const;
        if (i != this.f35885catch) {
            this.f35887const = this.f35888final + i;
        } else {
            if (!this.f35886class) {
                throw new NoSuchElementException();
            }
            this.f35886class = false;
        }
        return (char) i;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.f35886class;
    }
}
