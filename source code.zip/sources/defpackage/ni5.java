package defpackage;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;
import java.util.logging.Level;
import java.util.logging.Logger;

/* loaded from: classes2.dex */
public class ni5 implements Executor {

    /* renamed from: catch, reason: not valid java name */
    public static final Logger f25554catch = Logger.getLogger(ni5.class.getName());

    /* renamed from: class, reason: not valid java name */
    public boolean f25555class;

    /* renamed from: const, reason: not valid java name */
    public ArrayDeque<Runnable> f25556const;

    /* renamed from: do, reason: not valid java name */
    public final void m10958do() {
        while (true) {
            Runnable poll = this.f25556const.poll();
            if (poll == null) {
                return;
            }
            try {
                poll.run();
            } catch (Throwable th) {
                f25554catch.log(Level.SEVERE, "Exception while executing runnable " + poll, th);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0035, code lost:
    
        if (r6.f25556const == null) goto L9;
     */
    @Override // java.util.concurrent.Executor
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void execute(java.lang.Runnable r7) {
        /*
            r6 = this;
            java.lang.String r0 = "'task' must not be null."
            defpackage.el2.m5308default(r7, r0)
            boolean r0 = r6.f25555class
            if (r0 != 0) goto L43
            r0 = 1
            r6.f25555class = r0
            r0 = 0
            r7.run()     // Catch: java.lang.Throwable -> L1a
            java.util.ArrayDeque<java.lang.Runnable> r7 = r6.f25556const
            if (r7 == 0) goto L17
        L14:
            r6.m10958do()
        L17:
            r6.f25555class = r0
            goto L54
        L1a:
            r1 = move-exception
            java.util.logging.Logger r2 = defpackage.ni5.f25554catch     // Catch: java.lang.Throwable -> L38
            java.util.logging.Level r3 = java.util.logging.Level.SEVERE     // Catch: java.lang.Throwable -> L38
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L38
            r4.<init>()     // Catch: java.lang.Throwable -> L38
            java.lang.String r5 = "Exception while executing runnable "
            r4.append(r5)     // Catch: java.lang.Throwable -> L38
            r4.append(r7)     // Catch: java.lang.Throwable -> L38
            java.lang.String r7 = r4.toString()     // Catch: java.lang.Throwable -> L38
            r2.log(r3, r7, r1)     // Catch: java.lang.Throwable -> L38
            java.util.ArrayDeque<java.lang.Runnable> r7 = r6.f25556const
            if (r7 == 0) goto L17
            goto L14
        L38:
            r7 = move-exception
            java.util.ArrayDeque<java.lang.Runnable> r1 = r6.f25556const
            if (r1 == 0) goto L40
            r6.m10958do()
        L40:
            r6.f25555class = r0
            throw r7
        L43:
            java.util.ArrayDeque<java.lang.Runnable> r0 = r6.f25556const
            if (r0 != 0) goto L4f
            java.util.ArrayDeque r0 = new java.util.ArrayDeque
            r1 = 4
            r0.<init>(r1)
            r6.f25556const = r0
        L4f:
            java.util.ArrayDeque<java.lang.Runnable> r0 = r6.f25556const
            r0.add(r7)
        L54:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ni5.execute(java.lang.Runnable):void");
    }
}
