package defpackage;

import java.util.List;

/* loaded from: classes2.dex */
public final class lm7 extends ze3<List<? extends dd3>> {
}
