package defpackage;

import android.util.Log;
import com.bumptech.glide.load.ImageHeaderParser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Objects;
import kotlin.KotlinVersion;

/* loaded from: classes.dex */
public final class b40 implements ImageHeaderParser {

    /* renamed from: do, reason: not valid java name */
    public static final byte[] f2877do = "Exif\u0000\u0000".getBytes(Charset.forName("UTF-8"));

    /* renamed from: if, reason: not valid java name */
    public static final int[] f2878if = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8};

    /* loaded from: classes.dex */
    public static final class a implements c {

        /* renamed from: do, reason: not valid java name */
        public final ByteBuffer f2879do;

        public a(ByteBuffer byteBuffer) {
            this.f2879do = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // b40.c
        /* renamed from: do, reason: not valid java name */
        public int mo1700do() throws c.a {
            return (mo1701for() << 8) | mo1701for();
        }

        @Override // b40.c
        /* renamed from: for, reason: not valid java name */
        public short mo1701for() throws c.a {
            if (this.f2879do.remaining() >= 1) {
                return (short) (this.f2879do.get() & 255);
            }
            throw new c.a();
        }

        @Override // b40.c
        /* renamed from: if, reason: not valid java name */
        public int mo1702if(byte[] bArr, int i) {
            int min = Math.min(i, this.f2879do.remaining());
            if (min == 0) {
                return -1;
            }
            this.f2879do.get(bArr, 0, min);
            return min;
        }

        @Override // b40.c
        public long skip(long j) {
            int min = (int) Math.min(this.f2879do.remaining(), j);
            ByteBuffer byteBuffer = this.f2879do;
            byteBuffer.position(byteBuffer.position() + min);
            return min;
        }
    }

    /* loaded from: classes.dex */
    public static final class b {

        /* renamed from: do, reason: not valid java name */
        public final ByteBuffer f2880do;

        public b(byte[] bArr, int i) {
            this.f2880do = (ByteBuffer) ByteBuffer.wrap(bArr).order(ByteOrder.BIG_ENDIAN).limit(i);
        }

        /* renamed from: do, reason: not valid java name */
        public short m1703do(int i) {
            if (this.f2880do.remaining() - i >= 2) {
                return this.f2880do.getShort(i);
            }
            return (short) -1;
        }

        /* renamed from: if, reason: not valid java name */
        public int m1704if(int i) {
            if (this.f2880do.remaining() - i >= 4) {
                return this.f2880do.getInt(i);
            }
            return -1;
        }
    }

    /* loaded from: classes.dex */
    public interface c {

        /* loaded from: classes.dex */
        public static final class a extends IOException {
            private static final long serialVersionUID = 1;

            public a() {
                super("Unexpectedly reached end of a file");
            }
        }

        /* renamed from: do */
        int mo1700do() throws IOException;

        /* renamed from: for */
        short mo1701for() throws IOException;

        /* renamed from: if */
        int mo1702if(byte[] bArr, int i) throws IOException;

        long skip(long j) throws IOException;
    }

    /* loaded from: classes.dex */
    public static final class d implements c {

        /* renamed from: do, reason: not valid java name */
        public final InputStream f2881do;

        public d(InputStream inputStream) {
            this.f2881do = inputStream;
        }

        @Override // b40.c
        /* renamed from: do */
        public int mo1700do() throws IOException {
            return (mo1701for() << 8) | mo1701for();
        }

        @Override // b40.c
        /* renamed from: for */
        public short mo1701for() throws IOException {
            int read = this.f2881do.read();
            if (read != -1) {
                return (short) read;
            }
            throw new c.a();
        }

        @Override // b40.c
        /* renamed from: if */
        public int mo1702if(byte[] bArr, int i) throws IOException {
            int i2 = 0;
            int i3 = 0;
            while (i2 < i && (i3 = this.f2881do.read(bArr, i2, i - i2)) != -1) {
                i2 += i3;
            }
            if (i2 == 0 && i3 == -1) {
                throw new c.a();
            }
            return i2;
        }

        @Override // b40.c
        public long skip(long j) throws IOException {
            if (j < 0) {
                return 0L;
            }
            long j2 = j;
            while (j2 > 0) {
                long skip = this.f2881do.skip(j2);
                if (skip <= 0) {
                    if (this.f2881do.read() == -1) {
                        break;
                    }
                    skip = 1;
                }
                j2 -= skip;
            }
            return j - j2;
        }
    }

    /* renamed from: case, reason: not valid java name */
    public final int m1694case(c cVar, byte[] bArr, int i) throws IOException {
        ByteOrder byteOrder;
        int mo1702if = cVar.mo1702if(bArr, i);
        if (mo1702if != i) {
            if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                Log.d("DfltImageHeaderParser", "Unable to read exif segment data, length: " + i + ", actually read: " + mo1702if);
            }
            return -1;
        }
        boolean z = bArr != null && i > f2877do.length;
        if (z) {
            int i2 = 0;
            while (true) {
                byte[] bArr2 = f2877do;
                if (i2 >= bArr2.length) {
                    break;
                }
                if (bArr[i2] != bArr2[i2]) {
                    z = false;
                    break;
                }
                i2++;
            }
        }
        if (!z) {
            if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                Log.d("DfltImageHeaderParser", "Missing jpeg exif preamble");
            }
            return -1;
        }
        b bVar = new b(bArr, i);
        short m1703do = bVar.m1703do(6);
        if (m1703do == 18761) {
            byteOrder = ByteOrder.LITTLE_ENDIAN;
        } else if (m1703do != 19789) {
            if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                by.K("Unknown endianness = ", m1703do, "DfltImageHeaderParser");
            }
            byteOrder = ByteOrder.BIG_ENDIAN;
        } else {
            byteOrder = ByteOrder.BIG_ENDIAN;
        }
        bVar.f2880do.order(byteOrder);
        int m1704if = bVar.m1704if(10) + 6;
        short m1703do2 = bVar.m1703do(m1704if);
        for (int i3 = 0; i3 < m1703do2; i3++) {
            int i4 = (i3 * 12) + m1704if + 2;
            short m1703do3 = bVar.m1703do(i4);
            if (m1703do3 == 274) {
                short m1703do4 = bVar.m1703do(i4 + 2);
                if (m1703do4 >= 1 && m1703do4 <= 12) {
                    int m1704if2 = bVar.m1704if(i4 + 4);
                    if (m1704if2 >= 0) {
                        if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                            StringBuilder t = by.t("Got tagIndex=", i3, " tagType=", m1703do3, " formatCode=");
                            t.append((int) m1703do4);
                            t.append(" componentCount=");
                            t.append(m1704if2);
                            Log.d("DfltImageHeaderParser", t.toString());
                        }
                        int i5 = m1704if2 + f2878if[m1703do4];
                        if (i5 <= 4) {
                            int i6 = i4 + 8;
                            if (i6 >= 0 && i6 <= bVar.f2880do.remaining()) {
                                if (i5 >= 0 && i5 + i6 <= bVar.f2880do.remaining()) {
                                    return bVar.m1703do(i6);
                                }
                                if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                                    by.K("Illegal number of bytes for TI tag data tagType=", m1703do3, "DfltImageHeaderParser");
                                }
                            } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                                Log.d("DfltImageHeaderParser", "Illegal tagValueOffset=" + i6 + " tagType=" + ((int) m1703do3));
                            }
                        } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                            by.K("Got byte count > 4, not orientation, continuing, formatCode=", m1703do4, "DfltImageHeaderParser");
                        }
                    } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                        Log.d("DfltImageHeaderParser", "Negative tiff component count");
                    }
                } else if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                    by.K("Got invalid format code = ", m1703do4, "DfltImageHeaderParser");
                }
            }
        }
        return -1;
    }

    @Override // com.bumptech.glide.load.ImageHeaderParser
    /* renamed from: do, reason: not valid java name */
    public ImageHeaderParser.ImageType mo1695do(ByteBuffer byteBuffer) throws IOException {
        Objects.requireNonNull(byteBuffer, "Argument must not be null");
        return m1698new(new a(byteBuffer));
    }

    @Override // com.bumptech.glide.load.ImageHeaderParser
    /* renamed from: for, reason: not valid java name */
    public int mo1696for(InputStream inputStream, m10 m10Var) throws IOException {
        Objects.requireNonNull(inputStream, "Argument must not be null");
        d dVar = new d(inputStream);
        Objects.requireNonNull(m10Var, "Argument must not be null");
        try {
            int mo1700do = dVar.mo1700do();
            if (!((mo1700do & 65496) == 65496 || mo1700do == 19789 || mo1700do == 18761)) {
                if (!Log.isLoggable("DfltImageHeaderParser", 3)) {
                    return -1;
                }
                Log.d("DfltImageHeaderParser", "Parser doesn't handle magic number: " + mo1700do);
                return -1;
            }
            int m1699try = m1699try(dVar);
            if (m1699try == -1) {
                if (!Log.isLoggable("DfltImageHeaderParser", 3)) {
                    return -1;
                }
                Log.d("DfltImageHeaderParser", "Failed to parse exif segment length, or exif segment not found");
                return -1;
            }
            byte[] bArr = (byte[]) m10Var.mo10097new(m1699try, byte[].class);
            try {
                int m1694case = m1694case(dVar, bArr, m1699try);
                m10Var.put(bArr);
                return m1694case;
            } catch (Throwable th) {
                m10Var.put(bArr);
                throw th;
            }
        } catch (c.a unused) {
            return -1;
        }
    }

    @Override // com.bumptech.glide.load.ImageHeaderParser
    /* renamed from: if, reason: not valid java name */
    public ImageHeaderParser.ImageType mo1697if(InputStream inputStream) throws IOException {
        Objects.requireNonNull(inputStream, "Argument must not be null");
        return m1698new(new d(inputStream));
    }

    /* renamed from: new, reason: not valid java name */
    public final ImageHeaderParser.ImageType m1698new(c cVar) throws IOException {
        try {
            int mo1700do = cVar.mo1700do();
            if (mo1700do == 65496) {
                return ImageHeaderParser.ImageType.JPEG;
            }
            int mo1701for = (mo1700do << 8) | cVar.mo1701for();
            if (mo1701for == 4671814) {
                return ImageHeaderParser.ImageType.GIF;
            }
            int mo1701for2 = (mo1701for << 8) | cVar.mo1701for();
            if (mo1701for2 == -1991225785) {
                cVar.skip(21L);
                try {
                    return cVar.mo1701for() >= 3 ? ImageHeaderParser.ImageType.PNG_A : ImageHeaderParser.ImageType.PNG;
                } catch (c.a unused) {
                    return ImageHeaderParser.ImageType.PNG;
                }
            }
            if (mo1701for2 != 1380533830) {
                return ImageHeaderParser.ImageType.UNKNOWN;
            }
            cVar.skip(4L);
            if (((cVar.mo1700do() << 16) | cVar.mo1700do()) != 1464156752) {
                return ImageHeaderParser.ImageType.UNKNOWN;
            }
            int mo1700do2 = (cVar.mo1700do() << 16) | cVar.mo1700do();
            if ((mo1700do2 & (-256)) != 1448097792) {
                return ImageHeaderParser.ImageType.UNKNOWN;
            }
            int i = mo1700do2 & KotlinVersion.MAX_COMPONENT_VALUE;
            if (i == 88) {
                cVar.skip(4L);
                return (cVar.mo1701for() & 16) != 0 ? ImageHeaderParser.ImageType.WEBP_A : ImageHeaderParser.ImageType.WEBP;
            }
            if (i != 76) {
                return ImageHeaderParser.ImageType.WEBP;
            }
            cVar.skip(4L);
            return (cVar.mo1701for() & 8) != 0 ? ImageHeaderParser.ImageType.WEBP_A : ImageHeaderParser.ImageType.WEBP;
        } catch (c.a unused2) {
            return ImageHeaderParser.ImageType.UNKNOWN;
        }
    }

    /* renamed from: try, reason: not valid java name */
    public final int m1699try(c cVar) throws IOException {
        short mo1701for;
        int mo1700do;
        long j;
        long skip;
        do {
            short mo1701for2 = cVar.mo1701for();
            if (mo1701for2 != 255) {
                if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                    by.K("Unknown segmentId=", mo1701for2, "DfltImageHeaderParser");
                }
                return -1;
            }
            mo1701for = cVar.mo1701for();
            if (mo1701for == 218) {
                return -1;
            }
            if (mo1701for == 217) {
                if (Log.isLoggable("DfltImageHeaderParser", 3)) {
                    Log.d("DfltImageHeaderParser", "Found MARKER_EOI in exif segment");
                }
                return -1;
            }
            mo1700do = cVar.mo1700do() - 2;
            if (mo1701for == 225) {
                return mo1700do;
            }
            j = mo1700do;
            skip = cVar.skip(j);
        } while (skip == j);
        if (Log.isLoggable("DfltImageHeaderParser", 3)) {
            StringBuilder t = by.t("Unable to skip enough data, type: ", mo1701for, ", wanted to skip: ", mo1700do, ", but actually skipped: ");
            t.append(skip);
            Log.d("DfltImageHeaderParser", t.toString());
        }
        return -1;
    }
}
