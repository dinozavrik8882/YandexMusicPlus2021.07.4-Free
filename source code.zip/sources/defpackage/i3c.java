package defpackage;

import defpackage.v6c;

/* loaded from: classes2.dex */
public final /* synthetic */ class i3c implements v6c.a {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ spe f16137catch;

    public /* synthetic */ i3c(spe speVar) {
        this.f16137catch = speVar;
    }

    @Override // defpackage.o8c
    public final y6c call(Object obj) {
        spe speVar = this.f16137catch;
        final w6c w6cVar = (w6c) obj;
        w6cVar.getClass();
        final fqe i = speVar.i(new tqe() { // from class: g3c
            @Override // defpackage.tqe
            public final void call(Object obj2) {
                w6c.this.mo294for(obj2);
            }
        }, new tqe() { // from class: n3c
            @Override // defpackage.tqe
            public final void call(Object obj2) {
                qd9.m12678strictfp((Throwable) obj2);
            }
        }, new sqe() { // from class: h3c
            @Override // defpackage.sqe
            public final void call() {
                qd9.m12678strictfp(new g8c("observable completed, but client expect endless bus"));
            }
        });
        i.getClass();
        return new y6c() { // from class: f3c
            @Override // defpackage.y6c
            public final void cancel() {
                fqe.this.unsubscribe();
            }
        };
    }
}
