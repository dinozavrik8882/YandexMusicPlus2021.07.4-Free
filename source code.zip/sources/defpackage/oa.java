package defpackage;

import java.util.ArrayList;

/* loaded from: classes.dex */
public class oa extends ga {
    public ArrayList<ga> O = new ArrayList<>();

    @Override // defpackage.ga
    /* renamed from: default */
    public void mo6519default() {
        this.O.clear();
        super.mo6519default();
    }

    /* renamed from: do, reason: not valid java name */
    public void m11442do(ga gaVar) {
        this.O.add(gaVar);
        ga gaVar2 = gaVar.f13311synchronized;
        if (gaVar2 != null) {
            ((oa) gaVar2).O.remove(gaVar);
            gaVar.f13311synchronized = null;
        }
        gaVar.f13311synchronized = this;
    }

    @Override // defpackage.ga
    /* renamed from: extends */
    public void mo6520extends(x9 x9Var) {
        super.mo6520extends(x9Var);
        int size = this.O.size();
        for (int i = 0; i < size; i++) {
            this.O.get(i).mo6520extends(x9Var);
        }
    }

    /* renamed from: protected */
    public void mo7098protected() {
        ArrayList<ga> arrayList = this.O;
        if (arrayList == null) {
            return;
        }
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ga gaVar = this.O.get(i);
            if (gaVar instanceof oa) {
                ((oa) gaVar).mo7098protected();
            }
        }
    }
}
