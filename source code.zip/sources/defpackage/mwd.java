package defpackage;

import com.yandex.auth.sync.AccountProvider;
import java.util.List;

@hrd
/* loaded from: classes2.dex */
public final class mwd {

    @ird("items")
    private final List<fwd> items;

    @ird("style")
    private final nwd style;

    @qd3("subtitle")
    private final String subtitle;

    @qd3("title")
    private final String title;

    @qd3(AccountProvider.TYPE)
    private final owd type;

    public mwd() {
        nwd nwdVar = nwd.UNKNOWN;
        em5 em5Var = em5.f10300catch;
        jp5.m8570try(nwdVar, "style");
        jp5.m8570try(em5Var, "items");
        this.type = null;
        this.title = null;
        this.subtitle = null;
        this.style = nwdVar;
        this.items = em5Var;
    }

    /* renamed from: do, reason: not valid java name */
    public final List<fwd> m10641do() {
        return this.items;
    }

    /* renamed from: for, reason: not valid java name */
    public final String m10642for() {
        return this.title;
    }

    /* renamed from: if, reason: not valid java name */
    public final String m10643if() {
        return this.subtitle;
    }

    /* renamed from: new, reason: not valid java name */
    public final owd m10644new() {
        return this.type;
    }
}
