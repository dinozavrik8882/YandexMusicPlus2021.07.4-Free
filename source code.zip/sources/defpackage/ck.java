package defpackage;

import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;
import defpackage.tj;
import java.util.Objects;

/* loaded from: classes.dex */
public class ck implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ tj.l f5408catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ String f5409class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ int f5410const;

    /* renamed from: final, reason: not valid java name */
    public final /* synthetic */ int f5411final;

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ Bundle f5412super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ tj.k f5413throw;

    public ck(tj.k kVar, tj.l lVar, String str, int i, int i2, Bundle bundle) {
        this.f5413throw = kVar;
        this.f5408catch = lVar;
        this.f5409class = str;
        this.f5410const = i;
        this.f5411final = i2;
        this.f5412super = bundle;
    }

    @Override // java.lang.Runnable
    public void run() {
        IBinder m15017do = ((tj.m) this.f5408catch).m15017do();
        tj.this.f37302super.remove(m15017do);
        tj.c cVar = new tj.c(this.f5409class, this.f5410const, this.f5411final, this.f5412super, this.f5408catch);
        Objects.requireNonNull(tj.this);
        cVar.f37312case = tj.this.mo13571for(this.f5409class, this.f5411final, this.f5412super);
        Objects.requireNonNull(tj.this);
        if (cVar.f37312case == null) {
            StringBuilder r = by.r("No root for client ");
            r.append(this.f5409class);
            r.append(" from service ");
            r.append(ck.class.getName());
            Log.i("MBServiceCompat", r.toString());
            try {
                ((tj.m) this.f5408catch).m15020new(2, null);
                return;
            } catch (RemoteException unused) {
                by.S(by.r("Calling onConnectFailed() failed. Ignoring. pkg="), this.f5409class, "MBServiceCompat");
                return;
            }
        }
        try {
            tj.this.f37302super.put(m15017do, cVar);
            m15017do.linkToDeath(cVar, 0);
            MediaSessionCompat.Token token = tj.this.f37304while;
            if (token != null) {
                tj.l lVar = this.f5408catch;
                tj.b bVar = cVar.f37312case;
                ((tj.m) lVar).m15019if(bVar.f37310do, token, bVar.f37311if);
            }
        } catch (RemoteException unused2) {
            by.S(by.r("Calling onConnect() failed. Dropping client. pkg="), this.f5409class, "MBServiceCompat");
            tj.this.f37302super.remove(m15017do);
        }
    }
}
