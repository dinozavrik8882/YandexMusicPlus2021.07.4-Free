package defpackage;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class ml2 {

    /* renamed from: do, reason: not valid java name */
    public final k8<String, nl2> f24237do = new k8<>();

    /* renamed from: if, reason: not valid java name */
    public final k8<String, PropertyValuesHolder[]> f24238if = new k8<>();

    /* renamed from: do, reason: not valid java name */
    public static ml2 m10508do(Context context, TypedArray typedArray, int i) {
        int resourceId;
        if (!typedArray.hasValue(i) || (resourceId = typedArray.getResourceId(i, 0)) == 0) {
            return null;
        }
        return m10510if(context, resourceId);
    }

    /* renamed from: for, reason: not valid java name */
    public static ml2 m10509for(List<Animator> list) {
        ml2 ml2Var = new ml2();
        int size = list.size();
        for (int i = 0; i < size; i++) {
            Animator animator = list.get(i);
            if (!(animator instanceof ObjectAnimator)) {
                throw new IllegalArgumentException("Animator must be an ObjectAnimator: " + animator);
            }
            ObjectAnimator objectAnimator = (ObjectAnimator) animator;
            ml2Var.f24238if.put(objectAnimator.getPropertyName(), objectAnimator.getValues());
            String propertyName = objectAnimator.getPropertyName();
            long startDelay = objectAnimator.getStartDelay();
            long duration = objectAnimator.getDuration();
            TimeInterpolator interpolator = objectAnimator.getInterpolator();
            if ((interpolator instanceof AccelerateDecelerateInterpolator) || interpolator == null) {
                interpolator = gl2.f13817if;
            } else if (interpolator instanceof AccelerateInterpolator) {
                interpolator = gl2.f13816for;
            } else if (interpolator instanceof DecelerateInterpolator) {
                interpolator = gl2.f13818new;
            }
            nl2 nl2Var = new nl2(startDelay, duration, interpolator);
            nl2Var.f25663new = objectAnimator.getRepeatCount();
            nl2Var.f25664try = objectAnimator.getRepeatMode();
            ml2Var.f24237do.put(propertyName, nl2Var);
        }
        return ml2Var;
    }

    /* renamed from: if, reason: not valid java name */
    public static ml2 m10510if(Context context, int i) {
        try {
            Animator loadAnimator = AnimatorInflater.loadAnimator(context, i);
            if (loadAnimator instanceof AnimatorSet) {
                return m10509for(((AnimatorSet) loadAnimator).getChildAnimations());
            }
            if (loadAnimator == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            arrayList.add(loadAnimator);
            return m10509for(arrayList);
        } catch (Exception e) {
            StringBuilder r = by.r("Can't load animation resource ID #0x");
            r.append(Integer.toHexString(i));
            Log.w("MotionSpec", r.toString(), e);
            return null;
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof ml2) {
            return this.f24237do.equals(((ml2) obj).f24237do);
        }
        return false;
    }

    public int hashCode() {
        return this.f24237do.hashCode();
    }

    /* renamed from: new, reason: not valid java name */
    public nl2 m10511new(String str) {
        if (this.f24237do.getOrDefault(str, null) != null) {
            return this.f24237do.getOrDefault(str, null);
        }
        throw new IllegalArgumentException();
    }

    public String toString() {
        StringBuilder q = by.q('\n');
        q.append(ml2.class.getName());
        q.append('{');
        q.append(Integer.toHexString(System.identityHashCode(this)));
        q.append(" timings: ");
        q.append(this.f24237do);
        q.append("}\n");
        return q.toString();
    }
}
