package defpackage;

import android.os.RemoteException;

/* loaded from: classes.dex */
public final class iy2 extends jw2 {

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ zy2 f17533class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ ky2 f17534const;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public iy2(ky2 ky2Var, zy2 zy2Var, zy2 zy2Var2) {
        super(zy2Var);
        this.f17534const = ky2Var;
        this.f17533class = zy2Var2;
    }

    @Override // defpackage.jw2
    /* renamed from: do */
    public final void mo6814do() {
        try {
            ky2 ky2Var = this.f17534const;
            ky2Var.f21224if.f36118class.D0(ky2Var.f21223for, wv2.m16826do("review"), new jy2(this.f17534const, this.f17533class));
        } catch (RemoteException e) {
            ky2.f21222do.m7975do(e, "error requesting in-app review for %s", this.f17534const.f21223for);
            this.f17533class.m18267do(new RuntimeException(e));
        }
    }
}
