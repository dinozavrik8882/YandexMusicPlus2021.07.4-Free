package defpackage;

import defpackage.j29;
import defpackage.l29;

/* loaded from: classes2.dex */
public final /* synthetic */ class g29 implements j29.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ l29.a f12961do;
}
