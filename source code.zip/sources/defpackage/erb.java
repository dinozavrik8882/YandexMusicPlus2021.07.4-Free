package defpackage;

import android.content.Context;

/* loaded from: classes2.dex */
public final class erb {

    /* renamed from: do, reason: not valid java name */
    public final Context f10626do;

    /* renamed from: for, reason: not valid java name */
    public final qg9 f10627for;

    /* renamed from: if, reason: not valid java name */
    public final arb f10628if;

    public erb(Context context, arb arbVar, qg9 qg9Var) {
        jp5.m8570try(context, "context");
        jp5.m8570try(arbVar, "pushServiceFacade");
        jp5.m8570try(qg9Var, "userCenter");
        this.f10626do = context;
        this.f10628if = arbVar;
        this.f10627for = qg9Var;
    }
}
