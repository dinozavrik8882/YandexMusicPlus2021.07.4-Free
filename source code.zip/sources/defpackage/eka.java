package defpackage;

import java.io.Serializable;

/* loaded from: classes2.dex */
public final class eka implements Serializable {
    private static final long serialVersionUID = 4571909957193853670L;

    @qd3("exec-duration-millis")
    private int mRequestDuration;

    @qd3("req-id")
    private String mRequestId = "";

    public String toString() {
        StringBuilder r = by.r("InvocationInfo{requestId='");
        by.R(r, this.mRequestId, '\'', ", requestDuration=");
        return by.m2395instanceof(r, this.mRequestDuration, '}');
    }
}
