package defpackage;

import java.util.Objects;

/* loaded from: classes.dex */
public class fk2<TResult> {

    /* renamed from: do, reason: not valid java name */
    public final bl2<TResult> f12067do = new bl2<>();

    /* renamed from: do, reason: not valid java name */
    public boolean m6083do(Exception exc) {
        bl2<TResult> bl2Var = this.f12067do;
        Objects.requireNonNull(bl2Var);
        hg1.m7291this(exc, "Exception must not be null");
        synchronized (bl2Var.f3814do) {
            if (bl2Var.f3815for) {
                return false;
            }
            bl2Var.f3815for = true;
            bl2Var.f3813case = exc;
            bl2Var.f3816if.m17657do(bl2Var);
            return true;
        }
    }

    /* renamed from: if, reason: not valid java name */
    public boolean m6084if(TResult tresult) {
        bl2<TResult> bl2Var = this.f12067do;
        synchronized (bl2Var.f3814do) {
            if (bl2Var.f3815for) {
                return false;
            }
            bl2Var.f3815for = true;
            bl2Var.f3818try = tresult;
            bl2Var.f3816if.m17657do(bl2Var);
            return true;
        }
    }
}
