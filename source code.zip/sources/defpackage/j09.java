package defpackage;

/* loaded from: classes2.dex */
public final class j09<T> {

    /* renamed from: do, reason: not valid java name */
    public static final j09<?> f17670do = new j09<>();

    /* renamed from: for, reason: not valid java name */
    public final boolean f17671for;

    /* renamed from: if, reason: not valid java name */
    public final T f17672if;

    /* renamed from: new, reason: not valid java name */
    public final Throwable f17673new;

    /* loaded from: classes2.dex */
    public interface a<T> {
        /* renamed from: do */
        void mo6132do(Throwable th);

        /* renamed from: for */
        void mo6133for();

        /* renamed from: if */
        void mo6134if(T t);
    }

    public j09() {
        this.f17672if = null;
        this.f17673new = null;
        this.f17671for = true;
    }

    public j09(T t) {
        this.f17672if = t;
        this.f17673new = null;
        this.f17671for = false;
    }

    public j09(Throwable th, boolean z) {
        this.f17672if = null;
        this.f17673new = th;
        this.f17671for = false;
    }

    /* renamed from: try, reason: not valid java name */
    public static <T> j09<T> m8053try(Throwable th) {
        return new j09<>(th, false);
    }

    /* renamed from: case, reason: not valid java name */
    public boolean m8054case() {
        return this.f17672if != null;
    }

    /* renamed from: do, reason: not valid java name */
    public void m8055do(a<T> aVar) {
        T t = this.f17672if;
        if (t != null) {
            aVar.mo6134if(t);
            return;
        }
        Throwable th = this.f17673new;
        if (th != null) {
            aVar.mo6132do(th);
        } else {
            aVar.mo6133for();
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || j09.class != obj.getClass()) {
            return false;
        }
        j09 j09Var = (j09) obj;
        if (this.f17671for != j09Var.f17671for) {
            return false;
        }
        T t = this.f17672if;
        if (t == null ? j09Var.f17672if != null : !t.equals(j09Var.f17672if)) {
            return false;
        }
        Throwable th = this.f17673new;
        Throwable th2 = j09Var.f17673new;
        return th != null ? th.equals(th2) : th2 == null;
    }

    /* renamed from: for, reason: not valid java name */
    public Throwable m8056for() {
        Throwable th = this.f17673new;
        f9d.m5797for(th, "not failed");
        return th;
    }

    public int hashCode() {
        T t = this.f17672if;
        int hashCode = (((t != null ? t.hashCode() : 0) * 31) + (this.f17671for ? 1 : 0)) * 31;
        Throwable th = this.f17673new;
        return hashCode + (th != null ? th.hashCode() : 0);
    }

    /* renamed from: if, reason: not valid java name */
    public T m8057if() {
        T t = this.f17672if;
        f9d.m5797for(t, "not success");
        return t;
    }

    /* renamed from: new, reason: not valid java name */
    public boolean m8058new() {
        return this.f17673new != null;
    }

    public String toString() {
        StringBuilder r = by.r("Metadata{mData=");
        r.append(this.f17672if);
        r.append(", mLoading=");
        r.append(this.f17671for);
        r.append(", mFailure=");
        r.append(this.f17673new);
        r.append('}');
        return r.toString();
    }
}
