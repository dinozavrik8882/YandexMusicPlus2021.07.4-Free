package defpackage;

/* loaded from: classes.dex */
public interface ppe {
    /* renamed from: do */
    void mo1423do(Throwable th);

    /* renamed from: for */
    void mo1424for(fqe fqeVar);

    /* renamed from: if */
    void mo1425if();
}
