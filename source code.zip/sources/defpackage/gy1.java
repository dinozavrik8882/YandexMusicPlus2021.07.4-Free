package defpackage;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import defpackage.zo1;

/* loaded from: classes.dex */
public final class gy1 extends ut1<cy1> {
    public gy1(Context context, Looper looper, rt1 rt1Var, zo1.b bVar, zo1.c cVar) {
        super(context, looper, 126, rt1Var, bVar, cVar);
    }

    @Override // defpackage.qt1
    /* renamed from: abstract */
    public final String mo2081abstract() {
        return "com.google.android.gms.auth.api.phone.service.SmsRetrieverApiService.START";
    }

    @Override // defpackage.qt1
    /* renamed from: private */
    public final String mo2087private() {
        return "com.google.android.gms.auth.api.phone.internal.ISmsRetrieverApiService";
    }

    @Override // defpackage.qt1, wo1.f
    /* renamed from: super */
    public final int mo2089super() {
        return 12451000;
    }

    @Override // defpackage.qt1
    /* renamed from: switch */
    public final /* synthetic */ IInterface mo2090switch(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.auth.api.phone.internal.ISmsRetrieverApiService");
        return queryLocalInterface instanceof cy1 ? (cy1) queryLocalInterface : new dy1(iBinder);
    }
}
