package defpackage;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.yandex.metrica.rtm.Constants;
import java.util.Objects;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class wh8 implements df8 {

    /* renamed from: do, reason: not valid java name */
    public final Context f42360do;

    /* renamed from: if, reason: not valid java name */
    public final fv8 f42361if;

    public wh8(Context context, fv8 fv8Var) {
        jp5.m8570try(context, "context");
        jp5.m8570try(fv8Var, "mediaSessionCenter");
        this.f42360do = context;
        this.f42361if = fv8Var;
    }

    @Override // defpackage.df8
    /* renamed from: case */
    public void mo4432case() {
        fv8 fv8Var = this.f42361if;
        String string = this.f42360do.getString(R.string.automotive_no_subscription_error);
        jp5.m8568new(string, "context.getString(tanker.R.string.automotive_no_subscription_error)");
        Bundle m16682do = m16682do(dq5.m4763do(xh8.class), R.string.automotive_get_subscription_text);
        Objects.requireNonNull(fv8Var);
        jp5.m8570try(string, Constants.KEY_MESSAGE);
        fv8Var.f12615throw.m10004new(4, string, m16682do);
    }

    /* renamed from: do, reason: not valid java name */
    public final Bundle m16682do(dr5<? extends Activity> dr5Var, int i) {
        Intent intent = new Intent(this.f42360do, (Class<?>) dn3.D0(dr5Var));
        intent.setFlags(268435456);
        return qb.m12632try(new hl5("android.media.extras.ERROR_RESOLUTION_ACTION_LABEL", this.f42360do.getString(i)), new hl5("android.media.extras.ERROR_RESOLUTION_ACTION_INTENT", dn3.e3(intent, this.f42360do, 0, 0)));
    }

    @Override // defpackage.df8
    /* renamed from: for */
    public void mo4433for() {
        fv8 fv8Var = this.f42361if;
        String string = this.f42360do.getString(R.string.automotive_authorization_error);
        jp5.m8568new(string, "context.getString(tanker.R.string.automotive_authorization_error)");
        Bundle m16682do = m16682do(dq5.m4763do(vh8.class), R.string.automotive_sign_in_text);
        Objects.requireNonNull(fv8Var);
        jp5.m8570try(string, Constants.KEY_MESSAGE);
        fv8Var.f12615throw.m10004new(3, string, m16682do);
    }

    @Override // defpackage.df8
    /* renamed from: if */
    public void mo4434if() {
        fv8 fv8Var = this.f42361if;
        String string = this.f42360do.getString(R.string.no_connection_text);
        jp5.m8568new(string, "context.getString(tanker.R.string.no_connection_text)");
        Objects.requireNonNull(fv8Var);
        jp5.m8570try(string, Constants.KEY_MESSAGE);
        fv8Var.f12615throw.m10004new(10, string, null);
    }

    @Override // defpackage.df8
    /* renamed from: new */
    public void mo4435new() {
    }

    @Override // defpackage.df8
    /* renamed from: try */
    public void mo4436try() {
    }
}
