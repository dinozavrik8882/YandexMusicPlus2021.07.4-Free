package defpackage;

/* loaded from: classes.dex */
public final class ry2 implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ dz2 f34579catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ sy2 f34580class;

    public ry2(sy2 sy2Var, dz2 dz2Var) {
        this.f34580class = sy2Var;
        this.f34579catch = dz2Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.f34580class.f36229if) {
            my2<ResultT> my2Var = this.f34580class.f36228for;
            if (my2Var != 0) {
                my2Var.mo2625do(this.f34579catch);
            }
        }
    }
}
