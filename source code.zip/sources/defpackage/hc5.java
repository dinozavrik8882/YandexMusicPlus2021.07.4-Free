package defpackage;

import android.content.Context;
import defpackage.wa5;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class hc5 extends bc5 {

    /* renamed from: break, reason: not valid java name */
    public wa5.c f14958break;

    public hc5(Context context, wa5.c cVar) {
        super(context, mb5.RegisterOpen.getPath());
        this.f14958break = cVar;
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(jb5.DeviceFingerprintID.getKey(), this.f38687new.m14812class());
            jSONObject.put(jb5.IdentityID.getKey(), this.f38687new.m14818final());
            mo1942super(jSONObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public hc5(String str, JSONObject jSONObject, Context context) {
        super(str, jSONObject, context);
    }

    @Override // defpackage.bc5, defpackage.ub5
    /* renamed from: break */
    public void mo1937break() {
        super.mo1937break();
        if (wa5.m16479else().f41940public) {
            this.f14958break.mo7594do(wa5.m16479else().m16486goto(), null);
            wa5 m16479else = wa5.m16479else();
            m16479else.f41947while.put(jb5.InstantDeepLinkSession.getKey(), "true");
            wa5.m16479else().f41940public = false;
        }
    }

    @Override // defpackage.bc5, defpackage.ub5
    /* renamed from: catch */
    public void mo472catch(ic5 ic5Var, wa5 wa5Var) {
        super.mo472catch(ic5Var, wa5Var);
        try {
            JSONObject m7737if = ic5Var.m7737if();
            jb5 jb5Var = jb5.LinkClickID;
            if (m7737if.has(jb5Var.getKey())) {
                this.f38687new.m14828protected("bnc_link_click_id", ic5Var.m7737if().getString(jb5Var.getKey()));
            } else {
                this.f38687new.m14828protected("bnc_link_click_id", "bnc_no_value");
            }
            JSONObject m7737if2 = ic5Var.m7737if();
            jb5 jb5Var2 = jb5.Data;
            if (m7737if2.has(jb5Var2.getKey())) {
                JSONObject jSONObject = new JSONObject(ic5Var.m7737if().getString(jb5Var2.getKey()));
                jb5 jb5Var3 = jb5.Clicked_Branch_Link;
                if (jSONObject.has(jb5Var3.getKey()) && jSONObject.getBoolean(jb5Var3.getKey()) && this.f38687new.m14833super().equals("bnc_no_value") && this.f38687new.m14822import() == 1) {
                    this.f38687new.m14828protected("bnc_install_params", ic5Var.m7737if().getString(jb5Var2.getKey()));
                }
            }
            if (ic5Var.m7737if().has(jb5Var2.getKey())) {
                this.f38687new.m14828protected("bnc_session_params", ic5Var.m7737if().getString(jb5Var2.getKey()));
            } else {
                this.f38687new.m14828protected("bnc_session_params", "bnc_no_value");
            }
            wa5.c cVar = this.f14958break;
            if (cVar != null) {
                cVar.mo7594do(wa5Var.m16486goto(), null);
            }
            this.f38687new.m14828protected("bnc_app_version", nb5.f25343do.m10889do());
        } catch (Exception e) {
            e.printStackTrace();
        }
        m1941return(ic5Var, wa5Var);
    }

    @Override // defpackage.ub5
    /* renamed from: else */
    public void mo473else(int i, String str) {
        if (this.f14958break != null) {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("error_message", "Trouble reaching server. Please try again in a few minutes");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            this.f14958break.mo7594do(jSONObject, new za5(by.m2405strictfp("Trouble initializing Branch. ", str), i));
        }
    }

    @Override // defpackage.ub5
    /* renamed from: goto */
    public boolean mo474goto() {
        return false;
    }

    @Override // defpackage.ub5
    /* renamed from: if */
    public void mo475if() {
        this.f14958break = null;
    }

    @Override // defpackage.bc5
    /* renamed from: import */
    public String mo1939import() {
        return "open";
    }
}
