package defpackage;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class eg2<T> implements rg2<T> {

    /* renamed from: do, reason: not valid java name */
    public final cg2 f9963do;

    /* renamed from: for, reason: not valid java name */
    public final boolean f9964for;

    /* renamed from: if, reason: not valid java name */
    public final fh2<?, ?> f9965if;

    /* renamed from: new, reason: not valid java name */
    public final je2<?> f9966new;

    public eg2(fh2<?, ?> fh2Var, je2<?> je2Var, cg2 cg2Var) {
        this.f9965if = fh2Var;
        this.f9964for = je2Var.mo8334new(cg2Var);
        this.f9966new = je2Var;
        this.f9963do = cg2Var;
    }

    @Override // defpackage.rg2
    /* renamed from: case, reason: not valid java name */
    public final int mo5183case(T t) {
        fh2<?, ?> fh2Var = this.f9965if;
        int mo6033else = fh2Var.mo6033else(fh2Var.mo6032do(t)) + 0;
        if (!this.f9964for) {
            return mo6033else;
        }
        oe2<?> mo8333if = this.f9966new.mo8333if(t);
        int i = 0;
        for (int i2 = 0; i2 < mo8333if.f27081if.m14251try(); i2++) {
            i += oe2.m11489break(mo8333if.f27081if.m14249new(i2));
        }
        Iterator<Map.Entry<?, Object>> it = mo8333if.f27081if.m14245else().iterator();
        while (it.hasNext()) {
            i += oe2.m11489break(it.next());
        }
        return mo6033else + i;
    }

    @Override // defpackage.rg2
    /* renamed from: do, reason: not valid java name */
    public final int mo5184do(T t) {
        int hashCode = this.f9965if.mo6032do(t).hashCode();
        return this.f9964for ? (hashCode * 53) + this.f9966new.mo8333if(t).hashCode() : hashCode;
    }

    @Override // defpackage.rg2
    /* renamed from: else, reason: not valid java name */
    public final void mo5185else(T t, T t2) {
        fh2<?, ?> fh2Var = this.f9965if;
        Class<?> cls = tg2.f37180do;
        fh2Var.mo6034for(t, fh2Var.mo6037new(fh2Var.mo6032do(t), fh2Var.mo6032do(t2)));
        if (this.f9964for) {
            tg2.m14924this(this.f9966new, t, t2);
        }
    }

    @Override // defpackage.rg2
    /* renamed from: for, reason: not valid java name */
    public final void mo5186for(T t) {
        this.f9965if.mo6038try(t);
        this.f9966new.mo8330case(t);
    }

    @Override // defpackage.rg2
    /* renamed from: if, reason: not valid java name */
    public final boolean mo5187if(T t) {
        return this.f9966new.mo8333if(t).m11497const();
    }

    @Override // defpackage.rg2
    /* renamed from: new, reason: not valid java name */
    public final void mo5188new(T t, wh2 wh2Var) throws IOException {
        Iterator<Map.Entry<?, Object>> m11496class = this.f9966new.mo8333if(t).m11496class();
        while (m11496class.hasNext()) {
            Map.Entry<?, Object> next = m11496class.next();
            qe2 qe2Var = (qe2) next.getKey();
            if (qe2Var.mo12691for() != uh2.MESSAGE || qe2Var.mo12690extends() || qe2Var.mo12692instanceof()) {
                throw new IllegalStateException("Found invalid MessageSet item.");
            }
            if (next instanceof ef2) {
                ((ie2) wh2Var).m7769for(qe2Var.zza(), ((ef2) next).f9936catch.getValue().m6604for());
            } else {
                ((ie2) wh2Var).m7769for(qe2Var.zza(), next.getValue());
            }
        }
        fh2<?, ?> fh2Var = this.f9965if;
        fh2Var.mo6031case(fh2Var.mo6032do(t), wh2Var);
    }

    @Override // defpackage.rg2
    /* renamed from: try, reason: not valid java name */
    public final boolean mo5189try(T t, T t2) {
        if (!this.f9965if.mo6032do(t).equals(this.f9965if.mo6032do(t2))) {
            return false;
        }
        if (this.f9964for) {
            return this.f9966new.mo8333if(t).equals(this.f9966new.mo8333if(t2));
        }
        return true;
    }
}
