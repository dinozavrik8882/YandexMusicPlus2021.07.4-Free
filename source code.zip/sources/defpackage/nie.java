package defpackage;

/* loaded from: classes2.dex */
public final class nie implements mhe {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ mo5 f25563do;

    public nie(mo5 mo5Var) {
        this.f25563do = mo5Var;
    }

    @Override // defpackage.mhe
    /* renamed from: do */
    public final /* synthetic */ Object mo1620do(Object obj) {
        return this.f25563do.invoke(obj);
    }
}
