package defpackage;

/* loaded from: classes2.dex */
public class gl5 extends RuntimeException {
}
