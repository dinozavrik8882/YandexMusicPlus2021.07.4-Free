package defpackage;

/* loaded from: classes.dex */
public interface mt {
    /* renamed from: do */
    fr mo1514do(oq oqVar, du duVar);
}
