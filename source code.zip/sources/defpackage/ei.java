package defpackage;

import java.io.Closeable;

/* loaded from: classes.dex */
public final class ei implements Closeable, gu5 {

    /* renamed from: catch, reason: not valid java name */
    public final ym5 f10013catch;

    public ei(ym5 ym5Var) {
        jp5.m8570try(ym5Var, "context");
        this.f10013catch = ym5Var;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        dn3.g(this.f10013catch, null, 1, null);
    }

    @Override // defpackage.gu5
    /* renamed from: interface */
    public ym5 mo1035interface() {
        return this.f10013catch;
    }
}
