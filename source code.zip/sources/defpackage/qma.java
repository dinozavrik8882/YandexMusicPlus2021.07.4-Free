package defpackage;

import java.util.Objects;

/* loaded from: classes2.dex */
public final class qma extends jma {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f30932do;

    /* renamed from: for, reason: not valid java name */
    public final el5 f30933for;

    /* renamed from: if, reason: not valid java name */
    public final String f30934if;

    /* renamed from: new, reason: not valid java name */
    public final boolean f30935new;

    static {
        wp5 wp5Var = new wp5(dq5.m4763do(qma.class), "podcastsCatalogCenter", "getPodcastsCatalogCenter()Lru/yandex/music/novelties/podcasts/catalog/PodcastsCatalogCenter;");
        Objects.requireNonNull(dq5.f8909do);
        f30932do = new mr5[]{wp5Var};
    }

    @jy3
    public qma(String str) {
        jp5.m8570try(str, "categoryName");
        this.f30934if = str;
        iz3 l3 = dn3.l3(sma.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        this.f30933for = new ez3(new cz3(l3)).m5533do(f30932do[0]);
        this.f30935new = !ts5.m15187native(str);
    }

    @Override // defpackage.jma
    /* renamed from: do */
    public spe<j09<upa>> mo8520do() {
        sma m12811for = m12811for();
        String str = this.f30934if;
        if (!this.f30935new) {
            str = null;
        }
        return m12811for.m14294do(str);
    }

    /* renamed from: for, reason: not valid java name */
    public final sma m12811for() {
        return (sma) this.f30933for.getValue();
    }

    @Override // defpackage.jma
    /* renamed from: if */
    public void mo8521if(boolean z) {
        if (this.f30935new) {
            m12811for().m14295for(this.f30934if, z);
        } else {
            m12811for().m14296if(z);
        }
    }
}
