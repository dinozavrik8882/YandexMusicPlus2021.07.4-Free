package defpackage;

import android.content.Context;
import defpackage.bz3;

/* loaded from: classes2.dex */
public final class atc extends kp5 implements mo5<bz3.a, wsc> {

    /* renamed from: catch, reason: not valid java name */
    public static final atc f2481catch = new atc();

    public atc() {
        super(1);
    }

    @Override // defpackage.mo5
    public wsc invoke(bz3.a aVar) {
        bz3.a aVar2 = aVar;
        jp5.m8570try(aVar2, "$this$null");
        return new wsc((Context) aVar2.m2427do(dn3.l3(Context.class)));
    }
}
