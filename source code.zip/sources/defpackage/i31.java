package defpackage;

import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class i31 {

    /* renamed from: case, reason: not valid java name */
    public final List<l31> f16118case;

    /* renamed from: do, reason: not valid java name */
    public final int f16119do;

    /* renamed from: for, reason: not valid java name */
    public final List<q31> f16120for;

    /* renamed from: if, reason: not valid java name */
    public final int f16121if;

    /* renamed from: new, reason: not valid java name */
    public final List<l31> f16122new;

    /* renamed from: try, reason: not valid java name */
    public final List<l31> f16123try;

    public i31(int i, int i2, List<q31> list, List<l31> list2, List<l31> list3, List<l31> list4) {
        this.f16119do = i;
        this.f16121if = i2;
        this.f16120for = Collections.unmodifiableList(list);
        this.f16122new = Collections.unmodifiableList(list2);
        this.f16123try = Collections.unmodifiableList(list3);
        this.f16118case = Collections.unmodifiableList(list4);
    }
}
