package defpackage;

import defpackage.ro9;
import java.util.List;

@ln5(c = "ru.yandex.music.glagol.domain.GlagolCastDiscoveryCenter$observeExperimentGroupsAnalytics$$inlined$flatMapLatest$1", f = "GlagolCastDiscoveryCenter.kt", l = {232}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class fn9 extends pn5 implements ro5<fy5<? super List<? extends ro9.b>>, String, wm5<? super pl5>, Object> {

    /* renamed from: import, reason: not valid java name */
    public final /* synthetic */ zm9 f12266import;

    /* renamed from: super, reason: not valid java name */
    public int f12267super;

    /* renamed from: throw, reason: not valid java name */
    public /* synthetic */ Object f12268throw;

    /* renamed from: while, reason: not valid java name */
    public /* synthetic */ Object f12269while;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public fn9(wm5 wm5Var, zm9 zm9Var) {
        super(3, wm5Var);
        this.f12266import = zm9Var;
    }

    @Override // defpackage.ro5
    public Object invoke(fy5<? super List<? extends ro9.b>> fy5Var, String str, wm5<? super pl5> wm5Var) {
        fn9 fn9Var = new fn9(wm5Var, this.f12266import);
        fn9Var.f12268throw = fy5Var;
        fn9Var.f12269while = str;
        return fn9Var.mo76return(pl5.f29126do);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        int i = this.f12267super;
        if (i == 0) {
            dn3.N2(obj);
            fy5 fy5Var = (fy5) this.f12268throw;
            vy5 vy5Var = new vy5(new hn9(new in9(this.f12266import.f47456const, (String) this.f12269while)), 1);
            this.f12267super = 1;
            if (dn3.Z(fy5Var, vy5Var, this) == cn5Var) {
                return cn5Var;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            dn3.N2(obj);
        }
        return pl5.f29126do;
    }
}
