package defpackage;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import defpackage.i6b;

/* loaded from: classes2.dex */
public final class g6b extends wya {
    public g6b(Context context, wga wgaVar, yg9 yg9Var, Bundle bundle, i6b.a aVar, String str, ep5 ep5Var) {
        super(context, bundle);
        Uri uri = aVar.getUri();
        jp5.m8568new(uri, "params.uri");
        m17784this(uri);
        String selection = aVar.getSelection(wgaVar.mo16667try(), str);
        jp5.m8568new(selection, "params.getSelection(connectivityBox.mode(), constraint)");
        m17778case(selection);
        String[] args = aVar.getArgs(wgaVar.mo16667try(), str, yg9Var);
        jp5.m8568new(args, "params.getArgs(connectivityBox.mode(), constraint, userData)");
        m17779else(args);
        String orderBy = aVar.getOrderBy();
        jp5.m8568new(orderBy, "params.orderBy");
        m17781goto(orderBy);
        gu5 gu5Var = this.f46344if;
        spe<hha> mo16661case = wgaVar.mo16661case();
        jp5.m8568new(mo16661case, "connectivityBox.modes()");
        dn3.f1(new hz5(dn3.W(dn3.X(dn3.n(new bbb(mo16661case, null)), 1), cbb.f5138catch), new f6b(null, this, aVar, str, yg9Var)), gu5Var);
    }
}
