package defpackage;

@ln5(c = "ru.yandex.music.data.stores.avatar.AvatarLoader", f = "AvatarLoader.kt", l = {117, 187, 194}, m = "processResultSafely")
/* loaded from: classes2.dex */
public final class me9 extends jn5 {

    /* renamed from: final, reason: not valid java name */
    public Object f23855final;

    /* renamed from: super, reason: not valid java name */
    public /* synthetic */ Object f23856super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ ke9 f23857throw;

    /* renamed from: while, reason: not valid java name */
    public int f23858while;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public me9(ke9 ke9Var, wm5<? super me9> wm5Var) {
        super(wm5Var);
        this.f23857throw = ke9Var;
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        this.f23856super = obj;
        this.f23858while |= Integer.MIN_VALUE;
        return ke9.m8956if(this.f23857throw, null, null, this);
    }
}
