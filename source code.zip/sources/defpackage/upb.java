package defpackage;

import android.content.SharedPreferences;

/* loaded from: classes2.dex */
public final class upb {

    /* renamed from: do, reason: not valid java name */
    public final el5 f39298do;

    public upb() {
        jp5.m8570try("application_lifecycle_pref", "storageName");
        this.f39298do = dn3.h1(new q9d("application_lifecycle_pref"));
    }

    /* renamed from: do, reason: not valid java name */
    public final SharedPreferences m15695do() {
        return (SharedPreferences) this.f39298do.getValue();
    }
}
