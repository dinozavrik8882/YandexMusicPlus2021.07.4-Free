package defpackage;

/* loaded from: classes.dex */
public interface zf2 {
    /* renamed from: do */
    boolean mo13255do(Class<?> cls);

    /* renamed from: if */
    ag2 mo13256if(Class<?> cls);
}
