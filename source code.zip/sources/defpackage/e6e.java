package defpackage;

/* loaded from: classes2.dex */
public final class e6e implements ufe {

    /* renamed from: if, reason: not valid java name */
    public final /* synthetic */ mo5 f9592if;

    public e6e(mo5 mo5Var) {
        this.f9592if = mo5Var;
    }

    @Override // defpackage.ufe
    /* renamed from: do */
    public final /* synthetic */ void mo242do(Object obj) {
        jp5.m8568new(this.f9592if.invoke(obj), "invoke(...)");
    }
}
