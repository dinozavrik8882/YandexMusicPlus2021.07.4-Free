package defpackage;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class an1 implements Parcelable.Creator<cg1> {
    @Override // android.os.Parcelable.Creator
    public final cg1 createFromParcel(Parcel parcel) {
        int m7283protected = hg1.m7283protected(parcel);
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < m7283protected) {
            int readInt = parcel.readInt();
            int i4 = 65535 & readInt;
            if (i4 == 2) {
                i = hg1.m7265continue(parcel, readInt);
            } else if (i4 == 3) {
                i2 = hg1.m7265continue(parcel, readInt);
            } else if (i4 != 4) {
                hg1.m7278interface(parcel, readInt);
            } else {
                i3 = hg1.m7265continue(parcel, readInt);
            }
        }
        hg1.m7286static(parcel, m7283protected);
        return new cg1(i, i2, i3);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ cg1[] newArray(int i) {
        return new cg1[i];
    }
}
