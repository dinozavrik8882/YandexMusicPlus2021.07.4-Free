package defpackage;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;
import ru.yandex.music.R;

/* loaded from: classes.dex */
public class wo {

    /* renamed from: do, reason: not valid java name */
    public static so f42593do = new ko();

    /* renamed from: if, reason: not valid java name */
    public static ThreadLocal<WeakReference<d8<ViewGroup, ArrayList<so>>>> f42595if = new ThreadLocal<>();

    /* renamed from: for, reason: not valid java name */
    public static ArrayList<ViewGroup> f42594for = new ArrayList<>();

    /* loaded from: classes.dex */
    public static class a implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

        /* renamed from: catch, reason: not valid java name */
        public so f42596catch;

        /* renamed from: class, reason: not valid java name */
        public ViewGroup f42597class;

        /* renamed from: wo$a$a, reason: collision with other inner class name */
        /* loaded from: classes.dex */
        public class C0325a extends vo {

            /* renamed from: do, reason: not valid java name */
            public final /* synthetic */ d8 f42598do;

            public C0325a(d8 d8Var) {
                this.f42598do = d8Var;
            }

            /* JADX WARN: Multi-variable type inference failed */
            @Override // so.d
            /* renamed from: for */
            public void mo9160for(so soVar) {
                ((ArrayList) this.f42598do.get(a.this.f42597class)).remove(soVar);
                soVar.mo14331private(this);
            }
        }

        public a(so soVar, ViewGroup viewGroup) {
            this.f42596catch = soVar;
            this.f42597class = viewGroup;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:11:0x005c  */
        /* JADX WARN: Removed duplicated region for block: B:123:0x01ef A[EDGE_INSN: B:123:0x01ef->B:124:0x01ef BREAK  A[LOOP:1: B:17:0x009a->B:30:0x01e5], SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:127:0x01f4  */
        /* JADX WARN: Removed duplicated region for block: B:137:0x0215  */
        /* JADX WARN: Removed duplicated region for block: B:146:0x0242  */
        /* JADX WARN: Removed duplicated region for block: B:19:0x009f  */
        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public boolean onPreDraw() {
            /*
                Method dump skipped, instructions count: 692
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: wo.a.onPreDraw():boolean");
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            this.f42597class.getViewTreeObserver().removeOnPreDrawListener(this);
            this.f42597class.removeOnAttachStateChangeListener(this);
            wo.f42594for.remove(this.f42597class);
            ArrayList<so> arrayList = wo.m16737if().get(this.f42597class);
            if (arrayList != null && arrayList.size() > 0) {
                Iterator<so> it = arrayList.iterator();
                while (it.hasNext()) {
                    it.next().mo14320continue(this.f42597class);
                }
            }
            this.f42596catch.m14318catch(true);
        }
    }

    /* renamed from: do, reason: not valid java name */
    public static void m16736do(ViewGroup viewGroup, so soVar) {
        if (f42594for.contains(viewGroup)) {
            return;
        }
        AtomicInteger atomicInteger = ze.f47083do;
        if (viewGroup.isLaidOut()) {
            f42594for.add(viewGroup);
            if (soVar == null) {
                soVar = f42593do;
            }
            so clone = soVar.clone();
            ArrayList<so> orDefault = m16737if().getOrDefault(viewGroup, null);
            if (orDefault != null && orDefault.size() > 0) {
                Iterator<so> it = orDefault.iterator();
                while (it.hasNext()) {
                    it.next().mo14330package(viewGroup);
                }
            }
            if (clone != null) {
                clone.m14316break(viewGroup, true);
            }
            if (((ro) viewGroup.getTag(R.id.transition_current_scene)) != null) {
                throw null;
            }
            viewGroup.setTag(R.id.transition_current_scene, null);
            if (clone != null) {
                a aVar = new a(clone, viewGroup);
                viewGroup.addOnAttachStateChangeListener(aVar);
                viewGroup.getViewTreeObserver().addOnPreDrawListener(aVar);
            }
        }
    }

    /* renamed from: if, reason: not valid java name */
    public static d8<ViewGroup, ArrayList<so>> m16737if() {
        d8<ViewGroup, ArrayList<so>> d8Var;
        WeakReference<d8<ViewGroup, ArrayList<so>>> weakReference = f42595if.get();
        if (weakReference != null && (d8Var = weakReference.get()) != null) {
            return d8Var;
        }
        d8<ViewGroup, ArrayList<so>> d8Var2 = new d8<>();
        f42595if.set(new WeakReference<>(d8Var2));
        return d8Var2;
    }
}
