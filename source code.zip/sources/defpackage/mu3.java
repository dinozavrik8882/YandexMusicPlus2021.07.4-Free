package defpackage;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/* loaded from: classes.dex */
public final class mu3 {

    /* renamed from: do, reason: not valid java name */
    public final File f24591do;

    /* renamed from: for, reason: not valid java name */
    public FileOutputStream f24592for;

    /* renamed from: if, reason: not valid java name */
    public boolean f24593if;

    /* renamed from: new, reason: not valid java name */
    public OutputStream f24594new;

    public mu3(File file) {
        jp5.m8570try(file, "file");
        this.f24591do = file;
        this.f24593if = m10621if();
    }

    /* renamed from: do, reason: not valid java name */
    public final void m10620do() {
        OutputStream outputStream = this.f24594new;
        if (outputStream != null) {
            try {
                outputStream.close();
            } catch (IOException e) {
                k2f.f19768new.mo8771return(e);
            }
        }
        this.f24594new = null;
        this.f24592for = null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* renamed from: if, reason: not valid java name */
    public final boolean m10621if() {
        m10620do();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(this.f24591do, true);
            this.f24592for = fileOutputStream;
            this.f24594new = fileOutputStream instanceof BufferedOutputStream ? (BufferedOutputStream) fileOutputStream : new BufferedOutputStream(fileOutputStream, 8192);
            return true;
        } catch (IOException unused) {
            return false;
        }
    }
}
