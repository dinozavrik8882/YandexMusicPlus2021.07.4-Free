package defpackage;

import com.yandex.auth.sync.AccountProvider;
import com.yandex.metrica.rtm.service.EventProcessor;
import defpackage.ro9;
import defpackage.zq3;
import java.util.List;
import java.util.Map;

@ln5(c = "ru.yandex.music.glagol.domain.GlagolCastDiscoveryCenter$observeExperimentGroupsAnalytics$$inlined$collectIn$1", f = "GlagolCastDiscoveryCenter.kt", l = {46}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class dn9 extends pn5 implements qo5<gu5, wm5<? super pl5>, Object> {

    /* renamed from: super, reason: not valid java name */
    public int f8800super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ ey5 f8801throw;

    /* loaded from: classes2.dex */
    public static final class a implements fy5<List<? extends ro9.b>> {
        @Override // defpackage.fy5
        /* renamed from: if */
        public Object mo600if(List<? extends ro9.b> list, wm5 wm5Var) {
            nq3 m17714static = lp6.f22589for.m17714static();
            el5 g1 = dn3.g1(fl5.NONE, zq3.a.f47754catch);
            jp5.m8570try(EventProcessor.KEY_EXPERIMENT, AccountProvider.NAME);
            ((Map) g1.getValue()).put(EventProcessor.KEY_EXPERIMENT, "PultStationAndroid");
            by.P("experiments_filter", g1.mo2941do() ? (Map) g1.getValue() : null, m17714static);
            pl5 pl5Var = pl5.f29126do;
            cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
            return pl5Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public dn9(ey5 ey5Var, wm5 wm5Var) {
        super(2, wm5Var);
        this.f8801throw = ey5Var;
    }

    @Override // defpackage.hn5
    /* renamed from: final */
    public final wm5<pl5> mo75final(Object obj, wm5<?> wm5Var) {
        return new dn9(this.f8801throw, wm5Var);
    }

    @Override // defpackage.qo5
    public Object invoke(gu5 gu5Var, wm5<? super pl5> wm5Var) {
        return new dn9(this.f8801throw, wm5Var).mo76return(pl5.f29126do);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        int i = this.f8800super;
        if (i == 0) {
            dn3.N2(obj);
            ey5 ey5Var = this.f8801throw;
            a aVar = new a();
            this.f8800super = 1;
            if (ey5Var.mo1466do(aVar, this) == cn5Var) {
                return cn5Var;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            dn3.N2(obj);
        }
        return pl5.f29126do;
    }
}
