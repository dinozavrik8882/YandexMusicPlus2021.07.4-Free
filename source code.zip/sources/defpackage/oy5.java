package defpackage;

/* JADX INFO: Add missing generic type declarations: [T] */
/* loaded from: classes2.dex */
public final class oy5<T> implements ey5<T> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ qo5 f28055catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ ey5 f28056class;

    @ln5(c = "kotlinx.coroutines.flow.FlowKt__EmittersKt$onStart$$inlined$unsafeFlow$1", f = "Emitters.kt", l = {116, 120}, m = "collect")
    /* loaded from: classes2.dex */
    public static final class a extends jn5 {

        /* renamed from: final, reason: not valid java name */
        public /* synthetic */ Object f28057final;

        /* renamed from: import, reason: not valid java name */
        public Object f28058import;

        /* renamed from: native, reason: not valid java name */
        public Object f28059native;

        /* renamed from: super, reason: not valid java name */
        public int f28060super;

        /* renamed from: while, reason: not valid java name */
        public Object f28062while;

        public a(wm5 wm5Var) {
            super(wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            this.f28057final = obj;
            this.f28060super |= Integer.MIN_VALUE;
            return oy5.this.mo1466do(null, this);
        }
    }

    public oy5(qo5 qo5Var, ey5 ey5Var) {
        this.f28055catch = qo5Var;
        this.f28056class = ey5Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x007a A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    @Override // defpackage.ey5
    /* renamed from: do */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public java.lang.Object mo1466do(defpackage.fy5<? super T> r7, defpackage.wm5<? super defpackage.pl5> r8) {
        /*
            r6 = this;
            boolean r0 = r8 instanceof oy5.a
            if (r0 == 0) goto L13
            r0 = r8
            oy5$a r0 = (oy5.a) r0
            int r1 = r0.f28060super
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f28060super = r1
            goto L18
        L13:
            oy5$a r0 = new oy5$a
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f28057final
            cn5 r1 = defpackage.cn5.COROUTINE_SUSPENDED
            int r2 = r0.f28060super
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L44
            if (r2 == r4) goto L32
            if (r2 != r3) goto L2a
            defpackage.dn3.N2(r8)
            goto L7b
        L2a:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L32:
            java.lang.Object r7 = r0.f28059native
            d16 r7 = (defpackage.d16) r7
            java.lang.Object r2 = r0.f28058import
            fy5 r2 = (defpackage.fy5) r2
            java.lang.Object r4 = r0.f28062while
            oy5 r4 = (defpackage.oy5) r4
            defpackage.dn3.N2(r8)     // Catch: java.lang.Throwable -> L42
            goto L66
        L42:
            r8 = move-exception
            goto L80
        L44:
            defpackage.dn3.N2(r8)
            ym5 r8 = r0.f18984const
            defpackage.jp5.m8565for(r8)
            d16 r2 = new d16
            r2.<init>(r7, r8)
            qo5 r8 = r6.f28055catch     // Catch: java.lang.Throwable -> L7e
            r0.f28062while = r6     // Catch: java.lang.Throwable -> L7e
            r0.f28058import = r7     // Catch: java.lang.Throwable -> L7e
            r0.f28059native = r2     // Catch: java.lang.Throwable -> L7e
            r0.f28060super = r4     // Catch: java.lang.Throwable -> L7e
            java.lang.Object r8 = r8.invoke(r2, r0)     // Catch: java.lang.Throwable -> L7e
            if (r8 != r1) goto L62
            return r1
        L62:
            r4 = r6
            r5 = r2
            r2 = r7
            r7 = r5
        L66:
            r7.mo4003default()
            ey5 r7 = r4.f28056class
            r8 = 0
            r0.f28062while = r8
            r0.f28058import = r8
            r0.f28059native = r8
            r0.f28060super = r3
            java.lang.Object r7 = r7.mo1466do(r2, r0)
            if (r7 != r1) goto L7b
            return r1
        L7b:
            pl5 r7 = defpackage.pl5.f29126do
            return r7
        L7e:
            r8 = move-exception
            r7 = r2
        L80:
            r7.mo4003default()
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.oy5.mo1466do(fy5, wm5):java.lang.Object");
    }
}
