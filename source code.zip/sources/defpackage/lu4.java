package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class lu4 implements hu4 {

    /* renamed from: do, reason: not valid java name */
    public final AtomicReference<hu4> f22807do = new AtomicReference<>();

    @Override // defpackage.hu4
    public void cancel() {
        hu4 andSet = this.f22807do.getAndSet(null);
        if (andSet == null) {
            return;
        }
        andSet.cancel();
    }
}
