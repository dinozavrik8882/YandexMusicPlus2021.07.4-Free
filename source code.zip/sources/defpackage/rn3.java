package defpackage;

import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class rn3 {

    /* renamed from: do, reason: not valid java name */
    public static final Pattern f32726do = Pattern.compile("^(?:[0-9A-Za-z_=,;\\.\\-\\+]|%[0-9A-Fa-f]{2})*$");
}
