package defpackage;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes2.dex */
public class jfc {

    /* renamed from: do, reason: not valid java name */
    public List<nfc> f18526do = new ArrayList();

    /* renamed from: if, reason: not valid java name */
    public List<ifc> f18527if = new ArrayList();
}
