package defpackage;

import com.yandex.auth.sync.AccountProvider;

/* loaded from: classes2.dex */
public abstract class j66 {

    /* renamed from: do, reason: not valid java name */
    public l66 f18077do;

    /* renamed from: for, reason: not valid java name */
    public final String f18078for;

    /* renamed from: if, reason: not valid java name */
    public long f18079if;

    /* renamed from: new, reason: not valid java name */
    public final boolean f18080new;

    public j66(String str, boolean z) {
        jp5.m8570try(str, AccountProvider.NAME);
        this.f18078for = str;
        this.f18080new = z;
        this.f18079if = -1L;
    }

    /* renamed from: do */
    public abstract long mo5691do();

    public String toString() {
        return this.f18078for;
    }
}
