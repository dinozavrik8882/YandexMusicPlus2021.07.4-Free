package defpackage;

import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class xw6 {

    /* renamed from: do, reason: not valid java name */
    public izc f44673do;

    /* renamed from: if, reason: not valid java name */
    public oa9 f44674if;

    /* renamed from: do, reason: not valid java name */
    public final void m17364do(oa9 oa9Var) {
        jp5.m8570try(oa9Var, "playlist");
        this.f44674if = oa9Var;
        izc izcVar = this.f44673do;
        if (izcVar == null) {
            return;
        }
        izcVar.mo8021do(oa9Var);
        izcVar.setTitle(oa9Var.f26910class);
        int i = oa9Var.f26917import;
        if (i > 0) {
            izcVar.setSubtitle(h9d.m7093new(R.plurals.plural_n_tracks, i, Integer.valueOf(i)));
        } else {
            izcVar.setSubtitle(null);
        }
        izcVar.setExplicitContent(false);
        izcVar.setAdditionalInfo(null);
    }
}
