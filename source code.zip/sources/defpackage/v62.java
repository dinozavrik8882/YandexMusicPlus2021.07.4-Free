package defpackage;

import defpackage.z82;
import java.util.Objects;

/* loaded from: classes.dex */
public final class v62 extends z82<v62, a> implements la2 {
    private static volatile sa2<v62> zzafw;
    private static final v62 zzbbr;
    private int zzafi;
    private c72 zzbbl;
    private boolean zzbbm;
    private long zzbbn;
    private int zzbbo;
    private int zzbbp;
    private int zzbbq;

    /* loaded from: classes.dex */
    public static final class a extends z82.a<v62, a> implements la2 {
        public a() {
            super(v62.zzbbr);
        }

        public a(r72 r72Var) {
            super(v62.zzbbr);
        }

        /* renamed from: final, reason: not valid java name */
        public final a m15945final(t12 t12Var) {
            if (this.f46833const) {
                m17885catch();
                this.f46833const = false;
            }
            v62.m15944while((v62) this.f46832class, t12Var);
            return this;
        }
    }

    static {
        v62 v62Var = new v62();
        zzbbr = v62Var;
        z82.m17881catch(v62.class, v62Var);
    }

    /* renamed from: final, reason: not valid java name */
    public static a m15936final(v62 v62Var) {
        a m17883const = zzbbr.m17883const();
        m17883const.m17888this(v62Var);
        return m17883const;
    }

    /* renamed from: native, reason: not valid java name */
    public static void m15937native(v62 v62Var, c72 c72Var) {
        Objects.requireNonNull(v62Var);
        c72Var.getClass();
        v62Var.zzbbl = c72Var;
        v62Var.zzafi |= 1;
    }

    /* renamed from: public, reason: not valid java name */
    public static void m15938public(v62 v62Var, boolean z) {
        v62Var.zzafi |= 2;
        v62Var.zzbbm = z;
    }

    /* renamed from: return, reason: not valid java name */
    public static a m15939return() {
        return zzbbr.m17883const();
    }

    /* renamed from: static, reason: not valid java name */
    public static v62 m15940static() {
        return zzbbr;
    }

    /* renamed from: super, reason: not valid java name */
    public static void m15941super(v62 v62Var, long j) {
        v62Var.zzafi |= 4;
        v62Var.zzbbn = j;
    }

    /* renamed from: throw, reason: not valid java name */
    public static void m15943throw(v62 v62Var, s12 s12Var) {
        Objects.requireNonNull(v62Var);
        v62Var.zzbbq = s12Var.getNumber();
        v62Var.zzafi |= 32;
    }

    /* renamed from: while, reason: not valid java name */
    public static void m15944while(v62 v62Var, t12 t12Var) {
        Objects.requireNonNull(v62Var);
        v62Var.zzbbp = t12Var.getNumber();
        v62Var.zzafi |= 16;
    }

    /* JADX WARN: Type inference failed for: r2v13, types: [z82$c, sa2<v62>] */
    @Override // defpackage.z82
    /* renamed from: this */
    public final Object mo270this(z82.d dVar, Object obj, Object obj2) {
        sa2<v62> sa2Var;
        switch (r72.f31978do[dVar.ordinal()]) {
            case 1:
                return new v62();
            case 2:
                return new a(null);
            case 3:
                return new za2(zzbbr, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\t\u0000\u0002\u0007\u0001\u0003\u0005\u0002\u0004\u0006\u0003\u0005\f\u0004\u0006\f\u0005", new Object[]{"zzafi", "zzbbl", "zzbbm", "zzbbn", "zzbbo", "zzbbp", t12.zzfv(), "zzbbq", s12.zzfv()});
            case 4:
                return zzbbr;
            case 5:
                sa2<v62> sa2Var2 = zzafw;
                sa2<v62> sa2Var3 = sa2Var2;
                if (sa2Var2 == null) {
                    synchronized (v62.class) {
                        sa2<v62> sa2Var4 = zzafw;
                        sa2Var = sa2Var4;
                        if (sa2Var4 == null) {
                            ?? cVar = new z82.c(zzbbr);
                            zzafw = cVar;
                            sa2Var = cVar;
                        }
                    }
                    sa2Var3 = sa2Var;
                }
                return sa2Var3;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
