package defpackage;

import ru.yandex.music.data.user.Permission;

/* loaded from: classes2.dex */
public abstract class qad implements wad {

    /* renamed from: catch, reason: not valid java name */
    public final qg9 f30412catch;

    /* renamed from: class, reason: not valid java name */
    public Permission[] f30413class;

    /* renamed from: const, reason: not valid java name */
    public a48 f30414const;

    public qad(qg9 qg9Var, a48 a48Var) {
        this.f30412catch = qg9Var;
        this.f30414const = a48Var;
    }

    @Override // defpackage.wad
    public boolean J(Permission... permissionArr) {
        try {
            m12589do(permissionArr);
            return true;
        } catch (sad unused) {
            v56.m15910instanceof(this.f30414const, new vad(this, this.f30413class));
            return false;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public void m12589do(Permission... permissionArr) throws sad {
        this.f30413class = permissionArr;
        if (permissionArr != null && permissionArr.length > 0) {
            k2f.f19768new.mo8777while("you are likely to use another examinee, skipping permissions check: %s", g8d.w(permissionArr));
        }
        if (!this.f30412catch.mo9664try().f45521continue) {
            throw new sad(Permission.LIBRARY_PLAY);
        }
    }
}
