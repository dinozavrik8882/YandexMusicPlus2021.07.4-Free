package defpackage;

import defpackage.t78;
import ru.yandex.music.common.media.context.Card;
import ru.yandex.music.common.media.context.Page;
import ru.yandex.music.common.media.context.PlaybackScope;
import ru.yandex.music.data.user.Permission;

/* loaded from: classes2.dex */
public final class b88 extends PlaybackScope {
    private static final long serialVersionUID = 1;

    @qd3("mInfo")
    private final u78 mInfo;

    @qd3("mIsDefaultLibrary")
    private final Boolean mIsDefaultLibrary;

    @qd3("mPlaylistId")
    private final String mPlaylistId;

    public b88(Page page, oa9 oa9Var) {
        super(page, PlaybackScope.Type.PLAYLIST, Permission.LIBRARY_PLAY, s78.DEFAULT);
        this.mInfo = v78.m15963for(oa9Var);
        this.mPlaylistId = oa9Var.mo4957do();
        this.mIsDefaultLibrary = Boolean.valueOf(oa9Var.m11458class());
    }

    @Override // ru.yandex.music.common.media.context.PlaybackScope
    /* renamed from: case, reason: not valid java name */
    public t78 mo1838case() {
        t78.b m14687if = t78.m14687if();
        m14687if.f36723if = this.mInfo;
        m14687if.f36721do = this;
        m14687if.f36722for = Card.TRACK.name;
        m14687if.f36724new = PlaybackScope.m13560break(this.mPlaylistId, this.mIsDefaultLibrary.booleanValue());
        return m14687if.m14701do();
    }

    @Override // ru.yandex.music.common.media.context.PlaybackScope
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b88) || !super.equals(obj)) {
            return false;
        }
        b88 b88Var = (b88) obj;
        return g8d.m6476final(this.mInfo, b88Var.mInfo) && g8d.m6476final(this.mPlaylistId, b88Var.mPlaylistId) && g8d.m6476final(this.mIsDefaultLibrary, b88Var.mIsDefaultLibrary);
    }

    @Override // ru.yandex.music.common.media.context.PlaybackScope
    public int hashCode() {
        return this.mIsDefaultLibrary.hashCode() + by.A(this.mPlaylistId, (this.mInfo.hashCode() + (super.hashCode() * 31)) * 31, 31);
    }
}
