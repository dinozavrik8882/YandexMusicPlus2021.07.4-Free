package defpackage;

import android.view.View;
import java.util.List;

/* loaded from: classes2.dex */
public final class sz6 extends kp5 implements mo5<View, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ kz6 f36284catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ tt6 f36285class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ c37 f36286const;

    /* renamed from: final, reason: not valid java name */
    public final /* synthetic */ oa8 f36287final;

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ List<q68> f36288super;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public sz6(kz6 kz6Var, tt6 tt6Var, c37 c37Var, oa8 oa8Var, List<? extends q68> list) {
        super(1);
        this.f36284catch = kz6Var;
        this.f36285class = tt6Var;
        this.f36286const = c37Var;
        this.f36287final = oa8Var;
        this.f36288super = list;
    }

    @Override // defpackage.mo5
    public pl5 invoke(View view) {
        jp5.m8570try(view, "it");
        ut6.m15719extends(ut6.f39508for, this.f36284catch, this.f36285class, st6.ADD_TO_QUEUE, null, 8);
        this.f36286const.mo2551if();
        this.f36287final.mo10269finally().mo2228catch(this.f36288super);
        return pl5.f29126do;
    }
}
