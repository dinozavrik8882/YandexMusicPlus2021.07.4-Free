package defpackage;

import java.util.Map;

/* loaded from: classes.dex */
public final class xj3 implements fi3 {

    /* renamed from: do, reason: not valid java name */
    public final sj3 f43862do = new sj3();

    @Override // defpackage.fi3
    /* renamed from: do */
    public qi3 mo2102do(String str, zh3 zh3Var, int i, int i2, Map<bi3, ?> map) throws gi3 {
        if (zh3Var == zh3.UPC_A) {
            return this.f43862do.mo2102do("0".concat(String.valueOf(str)), zh3.EAN_13, i, i2, map);
        }
        throw new IllegalArgumentException("Can only encode UPC-A, but got ".concat(String.valueOf(zh3Var)));
    }
}
