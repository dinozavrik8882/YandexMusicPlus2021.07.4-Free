package defpackage;

import android.util.Log;
import defpackage.a20;
import defpackage.ny;
import defpackage.y10;
import java.io.File;
import java.io.IOException;

/* loaded from: classes.dex */
public class c20 implements y10 {

    /* renamed from: for, reason: not valid java name */
    public final long f4719for;

    /* renamed from: if, reason: not valid java name */
    public final File f4720if;

    /* renamed from: try, reason: not valid java name */
    public ny f4722try;

    /* renamed from: new, reason: not valid java name */
    public final a20 f4721new = new a20();

    /* renamed from: do, reason: not valid java name */
    public final j20 f4718do = new j20();

    @Deprecated
    public c20(File file, long j) {
        this.f4720if = file;
        this.f4719for = j;
    }

    @Override // defpackage.y10
    public synchronized void clear() {
        try {
            try {
                ny m2525for = m2525for();
                m2525for.close();
                py.m12348do(m2525for.f26246catch);
            } catch (IOException e) {
                if (Log.isLoggable("DiskLruCacheWrapper", 5)) {
                    Log.w("DiskLruCacheWrapper", "Unable to clear disk cache or disk cache cleared externally", e);
                }
            }
        } finally {
            m2527new();
        }
    }

    @Override // defpackage.y10
    /* renamed from: do, reason: not valid java name */
    public void mo2524do(jz jzVar, y10.b bVar) {
        a20.a aVar;
        boolean z;
        String m8072do = this.f4718do.m8072do(jzVar);
        a20 a20Var = this.f4721new;
        synchronized (a20Var) {
            aVar = a20Var.f99do.get(m8072do);
            if (aVar == null) {
                a20.b bVar2 = a20Var.f100if;
                synchronized (bVar2.f103do) {
                    aVar = bVar2.f103do.poll();
                }
                if (aVar == null) {
                    aVar = new a20.a();
                }
                a20Var.f99do.put(m8072do, aVar);
            }
            aVar.f102if++;
        }
        aVar.f101do.lock();
        try {
            if (Log.isLoggable("DiskLruCacheWrapper", 2)) {
                Log.v("DiskLruCacheWrapper", "Put: Obtained: " + m8072do + " for for Key: " + jzVar);
            }
            try {
                ny m2525for = m2525for();
                if (m2525for.m11266finally(m8072do) == null) {
                    ny.c m11267import = m2525for.m11267import(m8072do);
                    if (m11267import == null) {
                        throw new IllegalStateException("Had two simultaneous puts for: " + m8072do);
                    }
                    try {
                        o00 o00Var = (o00) bVar;
                        if (o00Var.f26362do.mo1591do(o00Var.f26364if, m11267import.m11271if(0), o00Var.f26363for)) {
                            ny.m11261do(ny.this, m11267import, true);
                            m11267import.f26262for = true;
                        }
                        if (!z) {
                            try {
                                m11267import.m11270do();
                            } catch (IOException unused) {
                            }
                        }
                    } finally {
                        if (!m11267import.f26262for) {
                            try {
                                m11267import.m11270do();
                            } catch (IOException unused2) {
                            }
                        }
                    }
                }
            } catch (IOException e) {
                if (Log.isLoggable("DiskLruCacheWrapper", 5)) {
                    Log.w("DiskLruCacheWrapper", "Unable to put to disk cache", e);
                }
            }
        } finally {
            this.f4721new.m68do(m8072do);
        }
    }

    /* renamed from: for, reason: not valid java name */
    public final synchronized ny m2525for() throws IOException {
        if (this.f4722try == null) {
            this.f4722try = ny.m11263implements(this.f4720if, 1, 1, this.f4719for);
        }
        return this.f4722try;
    }

    @Override // defpackage.y10
    /* renamed from: if, reason: not valid java name */
    public File mo2526if(jz jzVar) {
        String m8072do = this.f4718do.m8072do(jzVar);
        if (Log.isLoggable("DiskLruCacheWrapper", 2)) {
            Log.v("DiskLruCacheWrapper", "Get: Obtained: " + m8072do + " for for Key: " + jzVar);
        }
        try {
            ny.e m11266finally = m2525for().m11266finally(m8072do);
            if (m11266finally != null) {
                return m11266finally.f26273do[0];
            }
            return null;
        } catch (IOException e) {
            if (!Log.isLoggable("DiskLruCacheWrapper", 5)) {
                return null;
            }
            Log.w("DiskLruCacheWrapper", "Unable to get from disk cache", e);
            return null;
        }
    }

    /* renamed from: new, reason: not valid java name */
    public final synchronized void m2527new() {
        this.f4722try = null;
    }
}
