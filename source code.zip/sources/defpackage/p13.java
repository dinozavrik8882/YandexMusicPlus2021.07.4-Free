package defpackage;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/* loaded from: classes.dex */
public final class p13<T> {

    /* renamed from: case, reason: not valid java name */
    public final Set<Class<?>> f28199case;

    /* renamed from: do, reason: not valid java name */
    public final Set<Class<? super T>> f28200do;

    /* renamed from: for, reason: not valid java name */
    public final int f28201for;

    /* renamed from: if, reason: not valid java name */
    public final Set<d23> f28202if;

    /* renamed from: new, reason: not valid java name */
    public final int f28203new;

    /* renamed from: try, reason: not valid java name */
    public final s13<T> f28204try;

    /* loaded from: classes.dex */
    public static class b<T> {

        /* renamed from: case, reason: not valid java name */
        public Set<Class<?>> f28205case;

        /* renamed from: do, reason: not valid java name */
        public final Set<Class<? super T>> f28206do;

        /* renamed from: for, reason: not valid java name */
        public int f28207for;

        /* renamed from: if, reason: not valid java name */
        public final Set<d23> f28208if;

        /* renamed from: new, reason: not valid java name */
        public int f28209new;

        /* renamed from: try, reason: not valid java name */
        public s13<T> f28210try;

        public b(Class cls, Class[] clsArr, a aVar) {
            HashSet hashSet = new HashSet();
            this.f28206do = hashSet;
            this.f28208if = new HashSet();
            this.f28207for = 0;
            this.f28209new = 0;
            this.f28205case = new HashSet();
            Objects.requireNonNull(cls, "Null interface");
            hashSet.add(cls);
            for (Class cls2 : clsArr) {
                Objects.requireNonNull(cls2, "Null interface");
            }
            Collections.addAll(this.f28206do, clsArr);
        }

        /* renamed from: do, reason: not valid java name */
        public b<T> m11826do(d23 d23Var) {
            if (!(!this.f28206do.contains(d23Var.f7878do))) {
                throw new IllegalArgumentException("Components are not allowed to depend on interfaces they themselves provide.");
            }
            this.f28208if.add(d23Var);
            return this;
        }

        /* renamed from: for, reason: not valid java name */
        public b<T> m11827for(s13<T> s13Var) {
            this.f28210try = s13Var;
            return this;
        }

        /* renamed from: if, reason: not valid java name */
        public p13<T> m11828if() {
            if (this.f28210try != null) {
                return new p13<>(new HashSet(this.f28206do), new HashSet(this.f28208if), this.f28207for, this.f28209new, this.f28210try, this.f28205case, null);
            }
            throw new IllegalStateException("Missing required property: factory.");
        }

        /* renamed from: new, reason: not valid java name */
        public final b<T> m11829new(int i) {
            if (!(this.f28207for == 0)) {
                throw new IllegalStateException("Instantiation type has already been set.");
            }
            this.f28207for = i;
            return this;
        }
    }

    public p13(Set set, Set set2, int i, int i2, s13 s13Var, Set set3, a aVar) {
        this.f28200do = Collections.unmodifiableSet(set);
        this.f28202if = Collections.unmodifiableSet(set2);
        this.f28201for = i;
        this.f28203new = i2;
        this.f28204try = s13Var;
        this.f28199case = Collections.unmodifiableSet(set3);
    }

    /* renamed from: do, reason: not valid java name */
    public static <T> b<T> m11823do(Class<T> cls) {
        return new b<>(cls, new Class[0], null);
    }

    @SafeVarargs
    /* renamed from: for, reason: not valid java name */
    public static <T> p13<T> m11824for(final T t, Class<T> cls, Class<? super T>... clsArr) {
        b bVar = new b(cls, clsArr, null);
        bVar.m11827for(new s13(t) { // from class: n13

            /* renamed from: do, reason: not valid java name */
            public final Object f24881do;

            {
                this.f24881do = t;
            }

            @Override // defpackage.s13
            /* renamed from: do, reason: not valid java name */
            public Object mo10703do(q13 q13Var) {
                return this.f24881do;
            }
        });
        return bVar.m11828if();
    }

    /* renamed from: if, reason: not valid java name */
    public boolean m11825if() {
        return this.f28203new == 0;
    }

    public String toString() {
        return "Component<" + Arrays.toString(this.f28200do.toArray()) + ">{" + this.f28201for + ", type=" + this.f28203new + ", deps=" + Arrays.toString(this.f28202if.toArray()) + "}";
    }
}
