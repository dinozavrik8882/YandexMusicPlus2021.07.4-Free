package defpackage;

import defpackage.o5b;

/* loaded from: classes2.dex */
public final /* synthetic */ class q77 implements o5b.a {

    /* renamed from: do, reason: not valid java name */
    public final /* synthetic */ c87 f30252do;

    public /* synthetic */ q77(c87 c87Var) {
        this.f30252do = c87Var;
    }
}
