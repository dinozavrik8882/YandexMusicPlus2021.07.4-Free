package defpackage;

/* JADX INFO: Add missing generic type declarations: [T] */
/* loaded from: classes.dex */
public class pue<T> extends eqe<T> {

    /* renamed from: super, reason: not valid java name */
    public int f29596super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ eqe f29597throw;

    /* renamed from: while, reason: not valid java name */
    public final /* synthetic */ que f29598while;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public pue(que queVar, eqe eqeVar, eqe eqeVar2) {
        super(eqeVar, true);
        this.f29598while = queVar;
        this.f29597throw = eqeVar2;
    }

    @Override // defpackage.tpe
    /* renamed from: case */
    public void mo1523case(T t) {
        int i = this.f29596super;
        if (i >= this.f29598while.f31370catch) {
            this.f29597throw.mo1523case(t);
        } else {
            this.f29596super = i + 1;
        }
    }

    @Override // defpackage.tpe
    /* renamed from: do */
    public void mo1524do(Throwable th) {
        this.f29597throw.mo1524do(th);
    }

    @Override // defpackage.eqe
    /* renamed from: goto */
    public void mo2322goto(upe upeVar) {
        this.f29597throw.mo2322goto(upeVar);
        upeVar.mo1522break(this.f29598while.f31370catch);
    }

    @Override // defpackage.tpe
    /* renamed from: if */
    public void mo1526if() {
        this.f29597throw.mo1526if();
    }
}
