package defpackage;

import android.content.Context;
import defpackage.bz3;
import defpackage.ko8;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/* loaded from: classes2.dex */
public final class cfb implements bfb {

    /* renamed from: do, reason: not valid java name */
    public static final /* synthetic */ mr5<Object>[] f5278do;

    /* renamed from: case, reason: not valid java name */
    public ffb f5279case;

    /* renamed from: for, reason: not valid java name */
    public final boolean f5280for;

    /* renamed from: if, reason: not valid java name */
    public final el5 f5281if;

    /* renamed from: new, reason: not valid java name */
    public final r0f f5282new;

    /* renamed from: try, reason: not valid java name */
    public final kcb f5283try;

    /* loaded from: classes2.dex */
    public static final class a extends kp5 implements bo5<tn8> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ Context f5284catch;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(Context context) {
            super(0);
            this.f5284catch = context;
        }

        @Override // defpackage.bo5
        public tn8 invoke() {
            return new tn8(this.f5284catch);
        }
    }

    static {
        mr5<Object>[] mr5VarArr = new mr5[2];
        wp5 wp5Var = new wp5(dq5.m4763do(cfb.class), "playbackControl", "getPlaybackControl()Lru/yandex/music/common/media/control/PlaybackControl;");
        Objects.requireNonNull(dq5.f8909do);
        mr5VarArr[0] = wp5Var;
        f5278do = mr5VarArr;
    }

    public cfb(Context context, s57 s57Var) {
        jp5.m8570try(context, "context");
        jp5.m8570try(s57Var, "playableDialogOpenCallback");
        iz3 l3 = dn3.l3(oa8.class);
        jp5.m8570try(l3, "typeSpec");
        bz3 bz3Var = bz3.f4526do;
        jp5.m8565for(bz3Var);
        bz3Var.m2425do(l3);
        cz3 cz3Var = new cz3(l3);
        jp5.m8570try(cz3Var, "provider");
        jp5.m8570try(f5278do[0], "prop");
        this.f5281if = dn3.h1(cz3Var);
        iz3 l32 = dn3.l3(v14.class);
        jp5.m8570try(l32, "typeSpec");
        bz3 bz3Var2 = bz3.f4526do;
        jp5.m8565for(bz3Var2);
        jp5.m8570try(l32, "typeSpec");
        LinkedHashSet linkedHashSet = bz3Var2.f4528if ? new LinkedHashSet() : null;
        String m14341new = ((hfb) ((v14) bz3Var2.m2426new(l32, linkedHashSet != null ? new bz3.a(bz3Var2, linkedHashSet) : bz3Var2.f4529new, linkedHashSet)).m15853do(dq5.m4763do(hfb.class))).m14341new();
        this.f5280for = jp5.m8563do(m14341new, "on") || jp5.m8563do(m14341new, "on1");
        this.f5282new = new r0f();
        kcb kcbVar = new kcb(s57Var);
        this.f5283try = kcbVar;
        final el5 h1 = dn3.h1(new a(context));
        kcbVar.f19227if = new us7() { // from class: yeb
            @Override // defpackage.us7
            /* renamed from: extends */
            public final void mo610extends(Object obj, int i) {
                cfb cfbVar = cfb.this;
                el5 el5Var = h1;
                z68 z68Var = (z68) obj;
                jp5.m8570try(cfbVar, "this$0");
                jp5.m8570try(el5Var, "$playableWarningDemonstrator$delegate");
                jp5.m8570try(z68Var, "playable");
                go8 mo2230const = cfbVar.m2876if().mo10269finally().mo2230const();
                jp5.m8568new(mo2230const, "playbackControl.playbackQueue.latestEvent()");
                if (i == (cfbVar.f5280for ? mo2230const.f13945const : mo2230const.f13947final)) {
                    cfbVar.m2876if().toggle();
                    return;
                }
                ko8 ko8Var = new ko8(mo2230const);
                ko8Var.f20760new = i;
                if (!(i == ko8Var.m9156do(ko8.a.FORWARD, 0))) {
                    ((tn8) el5Var.getValue()).m15091do(z68Var);
                } else if (cfbVar.f5280for) {
                    cfbVar.m2876if().mo10272if(i, true);
                } else {
                    cfbVar.m2876if().mo10271goto(i, true);
                }
            }
        };
    }

    @Override // defpackage.bfb
    /* renamed from: do */
    public void mo1984do(ffb ffbVar) {
        Set<fqe> set;
        jp5.m8570try(ffbVar, "view");
        ffbVar.mo5958if(this.f5283try);
        this.f5279case = ffbVar;
        r0f r0fVar = this.f5282new;
        boolean z = false;
        if (!r0fVar.f31638class) {
            synchronized (r0fVar) {
                if (!r0fVar.f31638class && (set = r0fVar.f31637catch) != null && !set.isEmpty()) {
                    z = true;
                }
            }
        }
        if (z) {
            return;
        }
        r0f r0fVar2 = this.f5282new;
        spe m14390interface = m2876if().mo10261catch().m14390interface(new yqe() { // from class: afb
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                cfb cfbVar = cfb.this;
                go8 go8Var = (go8) obj;
                jp5.m8570try(cfbVar, "this$0");
                return cfbVar.f5280for ? go8Var.f13954this : go8Var.f13949goto;
            }
        }).m14403while().m14390interface(new yqe() { // from class: web
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                List<q68> list = (List) obj;
                mr5<Object>[] mr5VarArr = cfb.f5278do;
                ArrayList y = by.y(list, "playables");
                for (q68 q68Var : list) {
                    z68 z68Var = q68Var instanceof z68 ? (z68) q68Var : null;
                    if (z68Var != null) {
                        y.add(z68Var);
                    }
                }
                return y;
            }
        });
        jp5.m8568new(m14390interface, "playbackControl.queuesEvents()\n                .map { event ->\n                    if (shuffledQueueOrderExperimentEnabled) {\n                        event.queueOrderPlayables\n                    } else {\n                        event.originalPlayables\n                    }\n                }\n                .distinctUntilChanged()\n                .map { playables -> playables.mapNotNull { it as? TrackPlayable } }");
        r0fVar2.m13063do(dn3.r2(m14390interface, new dfb(this)));
        r0f r0fVar3 = this.f5282new;
        spe m14387implements = m2876if().mo10261catch().m14390interface(new yqe() { // from class: xeb
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                cfb cfbVar = cfb.this;
                go8 go8Var = (go8) obj;
                jp5.m8570try(cfbVar, "this$0");
                jp5.m8568new(go8Var, "it");
                return Integer.valueOf(cfbVar.f5280for ? go8Var.f13945const : go8Var.f13947final);
            }
        }).m14403while().m14384extends(new yqe() { // from class: zeb
            @Override // defpackage.yqe
            public final Object call(Object obj) {
                Integer num = (Integer) obj;
                mr5<Object>[] mr5VarArr = cfb.f5278do;
                jp5.m8568new(num, "it");
                return Boolean.valueOf(num.intValue() >= 0);
            }
        }).m14398synchronized().m14387implements(jqe.m8590do());
        jp5.m8568new(m14387implements, "playbackControl.queuesEvents()\n                .map { it.getQueueOrderPosition() }\n                .distinctUntilChanged()\n                .filter { it >= 0 }\n                .onBackpressureLatest()\n                .observeOn(AndroidSchedulers.mainThread())");
        r0fVar3.m13063do(dn3.r2(m14387implements, new efb(this)));
    }

    /* renamed from: if, reason: not valid java name */
    public final oa8 m2876if() {
        return (oa8) this.f5281if.getValue();
    }
}
