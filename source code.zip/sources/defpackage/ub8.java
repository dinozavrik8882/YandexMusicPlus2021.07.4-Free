package defpackage;

import defpackage.tab;
import java.util.List;
import ru.yandex.music.YMApplication;

@ln5(c = "ru.yandex.music.common.media.control.PlaybackStartCenter$startDownloadedTracks$1", f = "PlaybackStartCenter.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class ub8 extends pn5 implements mo5<wm5<? super List<? extends e69>>, Object> {

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ tab.a f38691super;

    /* renamed from: throw, reason: not valid java name */
    public final /* synthetic */ String f38692throw;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ub8(tab.a aVar, String str, wm5<? super ub8> wm5Var) {
        super(1, wm5Var);
        this.f38691super = aVar;
        this.f38692throw = str;
    }

    @Override // defpackage.mo5
    public Object invoke(wm5<? super List<? extends e69>> wm5Var) {
        are kcdVar;
        wm5<? super List<? extends e69>> wm5Var2 = wm5Var;
        tab.a aVar = this.f38691super;
        String str = this.f38692throw;
        if (wm5Var2 != null) {
            wm5Var2.getContext();
        }
        pl5 pl5Var = pl5.f29126do;
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(pl5Var);
        if (aVar == tab.a.LOCAL) {
            pd9 pd9Var = pd9.f28818do;
            pd9Var.getClass();
            kcdVar = new lcd(pd9Var);
        } else {
            kcdVar = new kcd(new cd9(YMApplication.f33061catch.getContentResolver()));
        }
        List list = (List) kcdVar.mo233do(aVar.getSelection(str), aVar.getArgs(str), aVar.orderBy);
        jp5.m8568new(list, "TracksFetcher(params, constraint).fetchItems()");
        return list;
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        are kcdVar;
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(obj);
        tab.a aVar = this.f38691super;
        String str = this.f38692throw;
        if (aVar == tab.a.LOCAL) {
            pd9 pd9Var = pd9.f28818do;
            pd9Var.getClass();
            kcdVar = new lcd(pd9Var);
        } else {
            kcdVar = new kcd(new cd9(YMApplication.f33061catch.getContentResolver()));
        }
        List list = (List) kcdVar.mo233do(aVar.getSelection(str), aVar.getArgs(str), aVar.orderBy);
        jp5.m8568new(list, "TracksFetcher(params, constraint).fetchItems()");
        return list;
    }

    @Override // defpackage.hn5
    /* renamed from: super */
    public final wm5<pl5> mo1372super(wm5<?> wm5Var) {
        return new ub8(this.f38691super, this.f38692throw, wm5Var);
    }
}
