package defpackage;

/* loaded from: classes.dex */
public interface zv4 extends aw4, yv4 {
    /* renamed from: switch */
    void mo3910switch();
}
