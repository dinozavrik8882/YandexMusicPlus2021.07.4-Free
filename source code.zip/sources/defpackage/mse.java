package defpackage;

import defpackage.spe;

/* loaded from: classes.dex */
public final class mse<T, R> implements spe.a<R> {

    /* renamed from: catch, reason: not valid java name */
    public final spe.a<T> f24532catch;

    /* renamed from: class, reason: not valid java name */
    public final spe.b<? extends R, ? super T> f24533class;

    public mse(spe.a<T> aVar, spe.b<? extends R, ? super T> bVar) {
        this.f24532catch = aVar;
        this.f24533class = bVar;
    }

    @Override // defpackage.tqe
    public void call(Object obj) {
        eqe eqeVar = (eqe) obj;
        try {
            spe.b bVar = this.f24533class;
            yqe<spe.b, spe.b> yqeVar = a0f.f43super;
            if (yqeVar != null) {
                bVar = yqeVar.call(bVar);
            }
            eqe eqeVar2 = (eqe) bVar.call(eqeVar);
            try {
                eqeVar2.mo1527try();
                this.f24532catch.call(eqeVar2);
            } catch (Throwable th) {
                nke.m11018const(th);
                eqeVar2.mo1524do(th);
            }
        } catch (Throwable th2) {
            nke.m11018const(th2);
            eqeVar.mo1524do(th2);
        }
    }
}
