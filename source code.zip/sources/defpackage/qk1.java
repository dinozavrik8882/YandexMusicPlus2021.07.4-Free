package defpackage;

import android.content.Context;
import defpackage.wo1;
import defpackage.yo1;

/* loaded from: classes.dex */
public final class qk1 extends yo1<wo1.d.C0326d> {

    /* renamed from: catch, reason: not valid java name */
    public static final wo1.g<vk1> f30821catch;

    /* renamed from: class, reason: not valid java name */
    public static final wo1.a<vk1, wo1.d.C0326d> f30822class;

    /* renamed from: const, reason: not valid java name */
    public static final wo1<wo1.d.C0326d> f30823const;

    static {
        wo1.g<vk1> gVar = new wo1.g<>();
        f30821catch = gVar;
        rk1 rk1Var = new rk1();
        f30822class = rk1Var;
        f30823const = new wo1<>("CastApi.API", rk1Var, gVar);
    }

    public qk1(Context context) {
        super(context, f30823const, null, yo1.a.f45921do);
    }
}
