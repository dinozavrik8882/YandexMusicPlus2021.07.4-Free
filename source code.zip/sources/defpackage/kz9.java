package defpackage;

import android.view.View;
import android.view.ViewGroup;
import defpackage.iz9;
import defpackage.jz9;
import defpackage.mz9;
import defpackage.oz9;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public class kz9 extends ms7<ex9> {

    /* renamed from: const, reason: not valid java name */
    public final iz9 f21296const;

    public kz9(ViewGroup viewGroup) {
        super(viewGroup, R.layout.view_landing_promotion);
        iz9 iz9Var = new iz9();
        this.f21296const = iz9Var;
        jz9 jz9Var = new jz9(this.itemView);
        iz9Var.f17578if = jz9Var;
        final bz9 bz9Var = new bz9(iz9Var);
        jz9Var.f19557if.setOnClickListener(new View.OnClickListener() { // from class: cz9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ex9 ex9Var;
                oz9.a aVar;
                mz9.a aVar2;
                iz9 iz9Var2 = ((bz9) jz9.a.this).f4550do;
                iz9.a aVar3 = iz9Var2.f17576do;
                if (aVar3 == null || (ex9Var = iz9Var2.f17577for) == null || (aVar = ((gz9) aVar3).f14414do.f28104try) == null || (aVar2 = ((dz9) aVar).f9240do.f24760if) == null) {
                    return;
                }
                aVar2.mo6143const(ex9Var);
            }
        });
        iz9Var.m8020do();
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [T, ex9, java.lang.Object] */
    @Override // defpackage.ms7
    /* renamed from: goto */
    public void mo381goto(ex9 ex9Var) {
        ex9 ex9Var2 = ex9Var;
        e8d.m5044case(ex9Var2);
        this.f24507class = ex9Var2;
        iz9 iz9Var = this.f21296const;
        iz9Var.f17577for = ex9Var2;
        iz9Var.m8020do();
    }
}
