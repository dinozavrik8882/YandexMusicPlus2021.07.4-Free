package defpackage;

import defpackage.bz3;

/* loaded from: classes2.dex */
public final class lk8 {

    /* renamed from: do, reason: not valid java name */
    public static final lk8 f22320do = null;

    /* renamed from: if, reason: not valid java name */
    public static final bz3.b f22321if = new bz3.b(b.f22323catch);

    /* loaded from: classes2.dex */
    public static final class a {

        /* renamed from: do, reason: not valid java name */
        public final up0[] f22322do;

        public a(up0[] up0VarArr) {
            jp5.m8570try(up0VarArr, "processors");
            this.f22322do = up0VarArr;
        }
    }

    /* loaded from: classes2.dex */
    public static final class b extends kp5 implements mo5<az3, pl5> {

        /* renamed from: catch, reason: not valid java name */
        public static final b f22323catch = new b();

        public b() {
            super(1);
        }

        @Override // defpackage.mo5
        public pl5 invoke(az3 az3Var) {
            az3 az3Var2 = az3Var;
            jp5.m8570try(az3Var2, "$this$$receiver");
            az3Var2.m1595if(dn3.l3(u0.class)).m1597if(yk8.f45707catch);
            az3Var2.m1595if(dn3.l3(o18.class)).m1597if(zk8.f47376catch);
            az3Var2.m1595if(dn3.l3(lc8.class)).m1597if(al8.f997catch);
            az3Var2.m1595if(dn3.l3(d18.class)).m1597if(bl8.f3842catch);
            az3Var2.m1595if(dn3.l3(g18.class)).m1597if(cl8.f5441catch);
            az3Var2.m1595if(dn3.l3(j18.class)).m1597if(dl8.f8714catch);
            az3Var2.m1595if(dn3.l3(q18.class)).m1597if(el8.f10244catch);
            az3Var2.m1595if(dn3.l3(n18.class)).m1597if(fl8.f12153catch);
            az3Var2.m1595if(dn3.l3(yw7.class)).m1596do(gl8.f13845catch);
            az3Var2.m1595if(dn3.l3(vr4.class)).m1597if(mk8.f24200catch);
            az3Var2.m1595if(dn3.l3(s18.class)).m1597if(nk8.f25643catch);
            az3Var2.m1595if(dn3.l3(xx7.class)).m1597if(ok8.f27389catch);
            az3Var2.m1595if(dn3.l3(xr4.class)).m1597if(pk8.f29099catch);
            az3Var2.m1595if(dn3.l3(zr4.class)).m1597if(qk8.f30835catch);
            az3Var2.m1595if(dn3.l3(wr4.class)).m1597if(rk8.f32555catch);
            az3Var2.m1595if(dn3.l3(m28.class)).m1597if(sk8.f35530catch);
            az3Var2.m1595if(dn3.l3(qi8.class)).m1596do(uk8.f39019catch);
            az3Var2.m1595if(dn3.l3(i6a.class)).m1597if(vk8.f40695catch);
            az3Var2.m1595if(dn3.l3(a.class)).m1597if(xk8.f43944catch);
            return pl5.f29126do;
        }
    }
}
