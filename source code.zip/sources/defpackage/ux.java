package defpackage;

import defpackage.pw;

/* loaded from: classes.dex */
public final class ux implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ int f39659catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ String f39660class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ sx f39661const;

    public ux(sx sxVar, int i, String str) {
        this.f39661const = sxVar;
        this.f39659catch = i;
        this.f39660class = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ph4 ph4Var = this.f39661const.f36165if;
        pw.a m12328do = pw.m12328do();
        m12328do.f29637do = this.f39659catch;
        m12328do.f29638if = this.f39660class;
        pw m12329do = m12328do.m12329do();
        mo5 mo5Var = ph4Var.f28972do;
        jp5.m8570try(mo5Var, "$tmp0");
        jp5.m8570try(m12329do, "p0");
        mo5Var.invoke(m12329do);
    }
}
