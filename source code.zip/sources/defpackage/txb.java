package defpackage;

import defpackage.l5c;

/* loaded from: classes2.dex */
public final class txb {

    /* renamed from: do, reason: not valid java name */
    public final g9c f37992do;

    /* renamed from: for, reason: not valid java name */
    public final rxb f37993for;

    /* renamed from: if, reason: not valid java name */
    public final l5c.b f37994if;

    /* loaded from: classes2.dex */
    public static class b {

        /* renamed from: do, reason: not valid java name */
        public g9c f37995do;

        /* renamed from: for, reason: not valid java name */
        public rxb f37996for;

        /* renamed from: if, reason: not valid java name */
        public l5c.b f37997if;
    }

    public txb(g9c g9cVar, l5c.b bVar, rxb rxbVar, a aVar) {
        this.f37992do = g9cVar;
        this.f37994if = bVar;
        this.f37993for = rxbVar;
    }
}
