package defpackage;

/* loaded from: classes2.dex */
public final class h16<T> implements wm5<T>, kn5 {

    /* renamed from: catch, reason: not valid java name */
    public final wm5<T> f14522catch;

    /* renamed from: class, reason: not valid java name */
    public final ym5 f14523class;

    /* JADX WARN: Multi-variable type inference failed */
    public h16(wm5<? super T> wm5Var, ym5 ym5Var) {
        this.f14522catch = wm5Var;
        this.f14523class = ym5Var;
    }

    @Override // defpackage.kn5
    /* renamed from: case */
    public kn5 mo1644case() {
        wm5<T> wm5Var = this.f14522catch;
        if (wm5Var instanceof kn5) {
            return (kn5) wm5Var;
        }
        return null;
    }

    @Override // defpackage.wm5
    /* renamed from: else */
    public void mo52else(Object obj) {
        this.f14522catch.mo52else(obj);
    }

    @Override // defpackage.wm5
    public ym5 getContext() {
        return this.f14523class;
    }
}
