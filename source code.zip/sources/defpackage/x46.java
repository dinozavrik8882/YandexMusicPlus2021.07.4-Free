package defpackage;

import defpackage.r66;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ExecutorService;

/* loaded from: classes2.dex */
public final class x46 {

    /* renamed from: for, reason: not valid java name */
    public ExecutorService f43257for;

    /* renamed from: do, reason: not valid java name */
    public int f43256do = 64;

    /* renamed from: if, reason: not valid java name */
    public int f43258if = 5;

    /* renamed from: new, reason: not valid java name */
    public final ArrayDeque<r66.a> f43259new = new ArrayDeque<>();

    /* renamed from: try, reason: not valid java name */
    public final ArrayDeque<r66.a> f43260try = new ArrayDeque<>();

    /* renamed from: case, reason: not valid java name */
    public final ArrayDeque<r66> f43255case = new ArrayDeque<>();

    /* renamed from: do, reason: not valid java name */
    public final <T> void m16939do(Deque<T> deque, T t) {
        synchronized (this) {
            if (!deque.remove(t)) {
                throw new AssertionError("Call wasn't in-flight!");
            }
        }
        m16940for();
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0068  */
    /* renamed from: for, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean m16940for() {
        /*
            Method dump skipped, instructions count: 248
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.x46.m16940for():boolean");
    }

    /* renamed from: if, reason: not valid java name */
    public final void m16941if(r66.a aVar) {
        jp5.m8570try(aVar, "call");
        aVar.f31955catch.decrementAndGet();
        m16939do(this.f43260try, aVar);
    }

    /* renamed from: new, reason: not valid java name */
    public final void m16942new(int i) {
        if (!(i >= 1)) {
            throw new IllegalArgumentException(by.m2404static("max < 1: ", i).toString());
        }
        synchronized (this) {
            this.f43256do = i;
        }
        m16940for();
    }

    /* renamed from: try, reason: not valid java name */
    public final void m16943try(int i) {
        if (!(i >= 1)) {
            throw new IllegalArgumentException(by.m2404static("max < 1: ", i).toString());
        }
        synchronized (this) {
            this.f43258if = i;
        }
        m16940for();
    }
}
