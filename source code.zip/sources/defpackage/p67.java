package defpackage;

/* loaded from: classes2.dex */
public final class p67 extends kp5 implements mo5<oa9, pl5> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ j67 f28448catch;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p67(j67 j67Var) {
        super(1);
        this.f28448catch = j67Var;
    }

    @Override // defpackage.mo5
    public pl5 invoke(oa9 oa9Var) {
        oa9 oa9Var2 = oa9Var;
        j67 j67Var = this.f28448catch;
        jp5.m8568new(oa9Var2, "playlist");
        j67.m8155do(j67Var, oa9Var2);
        return pl5.f29126do;
    }
}
