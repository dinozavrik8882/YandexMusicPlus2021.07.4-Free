package defpackage;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class u60 {

    /* renamed from: do, reason: not valid java name */
    public final List<a<?>> f38412do = new ArrayList();

    /* loaded from: classes.dex */
    public static final class a<T> {

        /* renamed from: do, reason: not valid java name */
        public final Class<T> f38413do;

        /* renamed from: if, reason: not valid java name */
        public final az<T> f38414if;

        public a(Class<T> cls, az<T> azVar) {
            this.f38413do = cls;
            this.f38414if = azVar;
        }
    }
}
