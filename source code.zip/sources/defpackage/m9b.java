package defpackage;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

/* loaded from: classes2.dex */
public final class m9b {
    /* renamed from: if, reason: not valid java name */
    public static final void m10236if(m9b m9bVar, View view, View view2, View view3, l9b l9bVar, View view4) {
        ll5<Integer, Integer, Integer> m10237do = m9bVar.m10237do(view, view2, view3.getHeight());
        int intValue = m10237do.f22400catch.intValue();
        int intValue2 = m10237do.f22401class.intValue();
        int intValue3 = m10237do.f22402const.intValue();
        l9bVar.update(intValue, intValue2, -1, -1);
        view4.setTranslationX(Math.max(intValue3, 0.0f));
    }

    /* renamed from: do, reason: not valid java name */
    public final ll5<Integer, Integer, Integer> m10237do(View view, View view2, int i) {
        Context context = view2.getContext();
        jp5.m8568new(context, "icon.context");
        int m14608new = t2.m14608new(context, 4);
        Context context2 = view2.getContext();
        jp5.m8568new(context2, "icon.context");
        int m14608new2 = t2.m14608new(context2, 8);
        Context context3 = view2.getContext();
        jp5.m8568new(context3, "icon.context");
        int m14608new3 = t2.m14608new(context3, 6);
        View rootView = view.getRootView();
        int[] iArr = new int[2];
        view2.getLocationOnScreen(iArr);
        rootView.getLocationOnScreen(new int[2]);
        Rect rect = new Rect();
        rootView.getWindowVisibleDisplayFrame(rect);
        int height = view2.getHeight() + iArr[1] + m14608new + i;
        int i2 = rect.left + m14608new2;
        int width = (((view2.getWidth() / 2) + iArr[0]) - m14608new2) - m14608new3;
        int max = Math.max(i2, width - (view2.getWidth() / 2));
        return new ll5<>(Integer.valueOf(max), Integer.valueOf(rootView.getHeight() - height), Integer.valueOf(width - max));
    }
}
