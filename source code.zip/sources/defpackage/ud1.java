package defpackage;

import defpackage.od1;

/* loaded from: classes.dex */
public final class ud1 extends od1.a {

    /* loaded from: classes.dex */
    public static final class a extends od1.a.C0243a {
        /* renamed from: do, reason: not valid java name and merged with bridge method [inline-methods] */
        public final ud1 m15516if() {
            return new ud1(this, null);
        }
    }

    static {
    }

    public ud1(a aVar, yd1 yd1Var) {
        super(aVar);
    }
}
