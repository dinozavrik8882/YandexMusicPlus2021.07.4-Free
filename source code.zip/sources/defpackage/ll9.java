package defpackage;

import android.content.Context;

/* loaded from: classes2.dex */
public final class ll9 {

    /* renamed from: do, reason: not valid java name */
    public final Context f22408do;

    /* renamed from: for, reason: not valid java name */
    public final do9 f22409for;

    /* renamed from: if, reason: not valid java name */
    public final zld f22410if;

    @ln5(c = "ru.yandex.music.glagol.data.GlagolSmartHomeRepository", f = "GlagolSmartHomeRepository.kt", l = {30}, m = "getCurrentUserSmartHomeDevicesOrNull")
    /* loaded from: classes2.dex */
    public static final class a extends jn5 {

        /* renamed from: final, reason: not valid java name */
        public Object f22411final;

        /* renamed from: import, reason: not valid java name */
        public int f22412import;

        /* renamed from: super, reason: not valid java name */
        public Object f22413super;

        /* renamed from: throw, reason: not valid java name */
        public /* synthetic */ Object f22414throw;

        public a(wm5<? super a> wm5Var) {
            super(wm5Var);
        }

        @Override // defpackage.hn5
        /* renamed from: return */
        public final Object mo76return(Object obj) {
            this.f22414throw = obj;
            this.f22412import |= Integer.MIN_VALUE;
            return ll9.this.m9809do(this);
        }
    }

    public ll9(Context context, zld zldVar, do9 do9Var) {
        jp5.m8570try(context, "context");
        jp5.m8570try(zldVar, "connector");
        jp5.m8570try(do9Var, "requirementsChecker");
        this.f22408do = context;
        this.f22410if = zldVar;
        this.f22409for = do9Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0038  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* renamed from: do, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object m9809do(defpackage.wm5<? super java.util.List<ro9.b>> r11) {
        /*
            r10 = this;
            boolean r0 = r11 instanceof ll9.a
            if (r0 == 0) goto L13
            r0 = r11
            ll9$a r0 = (ll9.a) r0
            int r1 = r0.f22412import
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f22412import = r1
            goto L18
        L13:
            ll9$a r0 = new ll9$a
            r0.<init>(r11)
        L18:
            java.lang.Object r11 = r0.f22414throw
            cn5 r1 = defpackage.cn5.COROUTINE_SUSPENDED
            int r2 = r0.f22412import
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L38
            if (r2 != r3) goto L30
            java.lang.Object r1 = r0.f22413super
            lp9 r1 = (defpackage.lp9) r1
            java.lang.Object r0 = r0.f22411final
            ll9 r0 = (defpackage.ll9) r0
            defpackage.dn3.N2(r11)
            goto L66
        L30:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r0)
            throw r11
        L38:
            defpackage.dn3.N2(r11)
            do9 r11 = r10.f22409for
            nz5<do9$b> r11 = r11.f8827else
            java.lang.Object r11 = r11.getValue()
            do9$b r11 = (do9.b) r11
            boolean r2 = r11 instanceof do9.b.c
            if (r2 == 0) goto Lba
            do9$b$c r11 = (do9.b.c) r11
            lp9 r11 = r11.f8838do
            java.lang.String r2 = r11.f22595if
            r0.f22411final = r10
            r0.f22413super = r11
            r0.f22412import = r3
            kl9 r3 = new kl9
            r3.<init>(r10, r2, r4)
            du5 r2 = defpackage.kv4.f21091if
            java.lang.Object r0 = defpackage.dn3.F3(r2, r3, r0)
            if (r0 != r1) goto L63
            return r1
        L63:
            r1 = r11
            r11 = r0
            r0 = r10
        L66:
            ru.yandex.quasar.glagol.backend.model.SmarthomeResult r11 = (ru.yandex.quasar.glagol.backend.model.SmarthomeResult) r11
            if (r11 != 0) goto L6b
            goto Lb9
        L6b:
            java.util.List<ru.yandex.quasar.glagol.backend.model.SmartDevice> r11 = r11.devices
            if (r11 != 0) goto L70
            goto Lb9
        L70:
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.Iterator r11 = r11.iterator()
        L79:
            boolean r3 = r11.hasNext()
            if (r3 == 0) goto Lb8
            java.lang.Object r3 = r11.next()
            ru.yandex.quasar.glagol.backend.model.SmartDevice r3 = (ru.yandex.quasar.glagol.backend.model.SmartDevice) r3
            java.lang.String r5 = "it"
            defpackage.jp5.m8568new(r3, r5)
            java.lang.String r5 = r1.f22594do
            java.util.Objects.requireNonNull(r0)
            ru.yandex.quasar.glagol.backend.model.QuasarInfo r6 = r3.getQuasarInfo()
            if (r6 != 0) goto L97
            r7 = r4
            goto Lb2
        L97:
            ro9$b r7 = new ro9$b
            java.lang.String r8 = r6.getDeviceId()
            java.lang.String r9 = "quasar.deviceId"
            defpackage.jp5.m8568new(r8, r9)
            java.lang.String r3 = r3.getName()
            java.lang.String r9 = "name"
            defpackage.jp5.m8568new(r3, r9)
            java.lang.String r6 = r6.getPlatform()
            r7.<init>(r5, r8, r3, r6)
        Lb2:
            if (r7 == 0) goto L79
            r2.add(r7)
            goto L79
        Lb8:
            r4 = r2
        Lb9:
            return r4
        Lba:
            boolean r0 = r11 instanceof do9.b.d
            if (r0 == 0) goto Lbf
            return r4
        Lbf:
            boolean r0 = r11 instanceof do9.b.C0112b
            if (r0 == 0) goto Lc4
            return r4
        Lc4:
            boolean r11 = r11 instanceof do9.b.a
            if (r11 == 0) goto Lc9
            return r4
        Lc9:
            gl5 r11 = new gl5
            r11.<init>()
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ll9.m9809do(wm5):java.lang.Object");
    }
}
