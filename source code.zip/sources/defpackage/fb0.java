package defpackage;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import com.yandex.metrica.rtm.service.EventProcessor;
import defpackage.f90;
import java.io.ByteArrayOutputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import java.util.concurrent.RejectedExecutionException;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class fb0 {

    /* renamed from: do, reason: not valid java name */
    public static final String f11610do = "fb0";

    /* renamed from: for, reason: not valid java name */
    public WeakReference<Activity> f11611for;

    /* renamed from: new, reason: not valid java name */
    public Timer f11613new;

    /* renamed from: try, reason: not valid java name */
    public String f11614try = null;

    /* renamed from: if, reason: not valid java name */
    public final Handler f11612if = new Handler(Looper.getMainLooper());

    /* loaded from: classes.dex */
    public class a extends TimerTask {
        public a() {
        }

        /* JADX WARN: Removed duplicated region for block: B:17:0x0046 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:18:0x0047 A[Catch: Exception -> 0x00d5, TRY_LEAVE, TryCatch #3 {Exception -> 0x00d5, blocks: (B:3:0x0002, B:7:0x0015, B:13:0x0025, B:60:0x0041, B:18:0x0047, B:55:0x005e, B:20:0x0061, B:25:0x007c, B:27:0x0081, B:28:0x00a6, B:43:0x00d0, B:47:0x009d, B:50:0x0073, B:66:0x0011, B:63:0x000d, B:57:0x0039, B:52:0x005a, B:23:0x0068, B:31:0x00b3, B:38:0x00cb), top: B:2:0x0002, inners: #0, #1, #4, #5, #6, #7 }] */
        /* JADX WARN: Removed duplicated region for block: B:56:0x0039 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        @Override // java.util.TimerTask, java.lang.Runnable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void run() {
            /*
                r8 = this;
                java.lang.Class<fb0> r0 = defpackage.fb0.class
                fb0 r1 = defpackage.fb0.this     // Catch: java.lang.Exception -> Ld5
                boolean r2 = defpackage.se0.m14224if(r0)     // Catch: java.lang.Exception -> Ld5
                r3 = 0
                if (r2 == 0) goto Ld
            Lb:
                r1 = r3
                goto L15
            Ld:
                java.lang.ref.WeakReference<android.app.Activity> r1 = r1.f11611for     // Catch: java.lang.Throwable -> L10
                goto L15
            L10:
                r1 = move-exception
                defpackage.se0.m14223do(r1, r0)     // Catch: java.lang.Exception -> Ld5
                goto Lb
            L15:
                java.lang.Object r1 = r1.get()     // Catch: java.lang.Exception -> Ld5
                android.app.Activity r1 = (android.app.Activity) r1     // Catch: java.lang.Exception -> Ld5
                android.view.View r2 = defpackage.tb0.m14758if(r1)     // Catch: java.lang.Exception -> Ld5
                if (r1 == 0) goto Ld4
                if (r2 != 0) goto L25
                goto Ld4
            L25:
                java.lang.Class r1 = r1.getClass()     // Catch: java.lang.Exception -> Ld5
                java.lang.String r1 = r1.getSimpleName()     // Catch: java.lang.Exception -> Ld5
                hb0 r4 = defpackage.ya0.f45195do     // Catch: java.lang.Exception -> Ld5
                java.lang.Class<ya0> r4 = defpackage.ya0.class
                boolean r5 = defpackage.se0.m14224if(r4)     // Catch: java.lang.Exception -> Ld5
                r6 = 0
                if (r5 == 0) goto L39
                goto L44
            L39:
                java.util.concurrent.atomic.AtomicBoolean r5 = defpackage.ya0.f45194case     // Catch: java.lang.Throwable -> L40
                boolean r6 = r5.get()     // Catch: java.lang.Throwable -> L40
                goto L44
            L40:
                r5 = move-exception
                defpackage.se0.m14223do(r5, r4)     // Catch: java.lang.Exception -> Ld5
            L44:
                if (r6 != 0) goto L47
                return
            L47:
                java.util.concurrent.FutureTask r4 = new java.util.concurrent.FutureTask     // Catch: java.lang.Exception -> Ld5
                fb0$d r5 = new fb0$d     // Catch: java.lang.Exception -> Ld5
                r5.<init>(r2)     // Catch: java.lang.Exception -> Ld5
                r4.<init>(r5)     // Catch: java.lang.Exception -> Ld5
                fb0 r5 = defpackage.fb0.this     // Catch: java.lang.Exception -> Ld5
                boolean r6 = defpackage.se0.m14224if(r0)     // Catch: java.lang.Exception -> Ld5
                if (r6 == 0) goto L5a
                goto L61
            L5a:
                android.os.Handler r3 = r5.f11612if     // Catch: java.lang.Throwable -> L5d
                goto L61
            L5d:
                r5 = move-exception
                defpackage.se0.m14223do(r5, r0)     // Catch: java.lang.Exception -> Ld5
            L61:
                r3.post(r4)     // Catch: java.lang.Exception -> Ld5
                java.lang.String r3 = ""
                r5 = 1
                java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.SECONDS     // Catch: java.lang.Exception -> L72
                java.lang.Object r4 = r4.get(r5, r7)     // Catch: java.lang.Exception -> L72
                java.lang.String r4 = (java.lang.String) r4     // Catch: java.lang.Exception -> L72
                r3 = r4
                goto L7c
            L72:
                r4 = move-exception
                java.lang.String r5 = defpackage.fb0.m5859do()     // Catch: java.lang.Exception -> Ld5
                java.lang.String r6 = "Failed to take screenshot."
                android.util.Log.e(r5, r6, r4)     // Catch: java.lang.Exception -> Ld5
            L7c:
                org.json.JSONObject r4 = new org.json.JSONObject     // Catch: java.lang.Exception -> Ld5
                r4.<init>()     // Catch: java.lang.Exception -> Ld5
                java.lang.String r5 = "screenname"
                r4.put(r5, r1)     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                java.lang.String r1 = "screenshot"
                r4.put(r1, r3)     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                org.json.JSONArray r1 = new org.json.JSONArray     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                r1.<init>()     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                org.json.JSONObject r2 = defpackage.mb0.m10296for(r2)     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                r1.put(r2)     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                java.lang.String r2 = "view"
                r4.put(r2, r1)     // Catch: org.json.JSONException -> L9d java.lang.Exception -> Ld5
                goto La6
            L9d:
                java.lang.String r1 = defpackage.fb0.m5859do()     // Catch: java.lang.Exception -> Ld5
                java.lang.String r2 = "Failed to create JSONObject"
                android.util.Log.e(r1, r2)     // Catch: java.lang.Exception -> Ld5
            La6:
                java.lang.String r1 = r4.toString()     // Catch: java.lang.Exception -> Ld5
                fb0 r2 = defpackage.fb0.this     // Catch: java.lang.Exception -> Ld5
                boolean r3 = defpackage.se0.m14224if(r0)     // Catch: java.lang.Exception -> Ld5
                if (r3 == 0) goto Lb3
                goto Ldf
            Lb3:
                java.util.Objects.requireNonNull(r2)     // Catch: java.lang.Throwable -> Lcf
                boolean r3 = defpackage.se0.m14224if(r2)     // Catch: java.lang.Throwable -> Lcf
                if (r3 == 0) goto Lbd
                goto Ldf
            Lbd:
                java.util.concurrent.Executor r3 = defpackage.b90.m1847do()     // Catch: java.lang.Throwable -> Lca
                gb0 r4 = new gb0     // Catch: java.lang.Throwable -> Lca
                r4.<init>(r2, r1)     // Catch: java.lang.Throwable -> Lca
                r3.execute(r4)     // Catch: java.lang.Throwable -> Lca
                goto Ldf
            Lca:
                r1 = move-exception
                defpackage.se0.m14223do(r1, r2)     // Catch: java.lang.Throwable -> Lcf
                goto Ldf
            Lcf:
                r1 = move-exception
                defpackage.se0.m14223do(r1, r0)     // Catch: java.lang.Exception -> Ld5
                goto Ldf
            Ld4:
                return
            Ld5:
                r0 = move-exception
                java.lang.String r1 = defpackage.fb0.m5859do()
                java.lang.String r2 = "UI Component tree indexing failure!"
                android.util.Log.e(r1, r2, r0)
            Ldf:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: fb0.a.run():void");
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ TimerTask f11616catch;

        public b(TimerTask timerTask) {
            this.f11616catch = timerTask;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                if (se0.m14224if(this)) {
                    return;
                }
                try {
                    if (fb0.m5861if(fb0.this) != null) {
                        fb0.m5861if(fb0.this).cancel();
                    }
                    fb0 fb0Var = fb0.this;
                    if (!se0.m14224if(fb0.class)) {
                        try {
                            fb0Var.f11614try = null;
                        } catch (Throwable th) {
                            se0.m14223do(th, fb0.class);
                        }
                    }
                    fb0 fb0Var2 = fb0.this;
                    Timer timer = new Timer();
                    if (!se0.m14224if(fb0.class)) {
                        try {
                            fb0Var2.f11613new = timer;
                        } catch (Throwable th2) {
                            se0.m14223do(th2, fb0.class);
                        }
                    }
                    fb0.m5861if(fb0.this).scheduleAtFixedRate(this.f11616catch, 0L, 1000L);
                } catch (Exception e) {
                    Log.e(fb0.m5859do(), "Error scheduling indexing job", e);
                }
            } catch (Throwable th3) {
                se0.m14223do(th3, this);
            }
        }
    }

    /* loaded from: classes.dex */
    public static class c implements f90.c {
        @Override // f90.c
        /* renamed from: if */
        public void mo5145if(j90 j90Var) {
            l90 l90Var = l90.APP_EVENTS;
            fb0.m5859do();
            HashMap<String, String> hashMap = yd0.f45375do;
            b90.m1848else(l90Var);
        }
    }

    /* loaded from: classes.dex */
    public static class d implements Callable<String> {

        /* renamed from: do, reason: not valid java name */
        public WeakReference<View> f11618do;

        public d(View view) {
            this.f11618do = new WeakReference<>(view);
        }

        @Override // java.util.concurrent.Callable
        public String call() throws Exception {
            View view = this.f11618do.get();
            if (view == null || view.getWidth() == 0 || view.getHeight() == 0) {
                return "";
            }
            Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.RGB_565);
            view.draw(new Canvas(createBitmap));
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            createBitmap.compress(Bitmap.CompressFormat.JPEG, 10, byteArrayOutputStream);
            return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
        }
    }

    public fb0(Activity activity) {
        this.f11611for = new WeakReference<>(activity);
    }

    /* renamed from: do, reason: not valid java name */
    public static /* synthetic */ String m5859do() {
        if (se0.m14224if(fb0.class)) {
            return null;
        }
        try {
            return f11610do;
        } catch (Throwable th) {
            se0.m14223do(th, fb0.class);
            return null;
        }
    }

    /* renamed from: for, reason: not valid java name */
    public static f90 m5860for(String str, o80 o80Var, String str2, String str3) {
        String str4;
        if (se0.m14224if(fb0.class) || str == null) {
            return null;
        }
        try {
            f90 m5758const = f90.m5758const(o80Var, String.format(Locale.US, "%s/app_indexing", str2), null, null);
            Bundle bundle = m5758const.f11460this;
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putString("tree", str);
            HashSet<l90> hashSet = b90.f3183do;
            ge0.m6598try();
            Context context = b90.f3191this;
            try {
                str4 = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            } catch (PackageManager.NameNotFoundException unused) {
                str4 = "";
            }
            bundle.putString("app_version", str4);
            bundle.putString(EventProcessor.KEY_PLATFORM, "android");
            bundle.putString("request_type", str3);
            if (str3.equals("app_indexing")) {
                bundle.putString("device_session_id", ya0.m17529for());
            }
            m5758const.f11460this = bundle;
            m5758const.m5773return(new c());
            return m5758const;
        } catch (Throwable th) {
            se0.m14223do(th, fb0.class);
            return null;
        }
    }

    /* renamed from: if, reason: not valid java name */
    public static /* synthetic */ Timer m5861if(fb0 fb0Var) {
        if (se0.m14224if(fb0.class)) {
            return null;
        }
        try {
            return fb0Var.f11613new;
        } catch (Throwable th) {
            se0.m14223do(th, fb0.class);
            return null;
        }
    }

    /* renamed from: new, reason: not valid java name */
    public void m5862new(f90 f90Var, String str) {
        if (se0.m14224if(this) || f90Var == null) {
            return;
        }
        try {
            j90 m5772new = f90Var.m5772new();
            try {
                JSONObject jSONObject = m5772new.f18256for;
                if (jSONObject == null) {
                    Log.e(f11610do, "Error sending UI component tree to Facebook: " + m5772new.f18258new);
                    return;
                }
                if ("true".equals(jSONObject.optString("success"))) {
                    l90 l90Var = l90.APP_EVENTS;
                    HashMap<String, String> hashMap = yd0.f45375do;
                    b90.m1848else(l90Var);
                    this.f11614try = str;
                }
                if (jSONObject.has("is_app_indexing_enabled")) {
                    Boolean valueOf = Boolean.valueOf(jSONObject.getBoolean("is_app_indexing_enabled"));
                    hb0 hb0Var = ya0.f45195do;
                    if (se0.m14224if(ya0.class)) {
                        return;
                    }
                    try {
                        ya0.f45194case.set(valueOf.booleanValue());
                    } catch (Throwable th) {
                        se0.m14223do(th, ya0.class);
                    }
                }
            } catch (JSONException e) {
                Log.e(f11610do, "Error decoding server response.", e);
            }
        } catch (Throwable th2) {
            se0.m14223do(th2, this);
        }
    }

    /* renamed from: try, reason: not valid java name */
    public void m5863try() {
        if (se0.m14224if(this)) {
            return;
        }
        try {
            try {
                b90.m1847do().execute(new b(new a()));
            } catch (RejectedExecutionException e) {
                Log.e(f11610do, "Error scheduling indexing job", e);
            }
        } catch (Throwable th) {
            se0.m14223do(th, this);
        }
    }
}
