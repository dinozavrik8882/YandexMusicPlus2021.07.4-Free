package defpackage;

import defpackage.qy;

/* loaded from: classes.dex */
public final class e50 implements qy.a {

    /* renamed from: do, reason: not valid java name */
    public final o10 f9497do;

    /* renamed from: if, reason: not valid java name */
    public final m10 f9498if;

    public e50(o10 o10Var, m10 m10Var) {
        this.f9497do = o10Var;
        this.f9498if = m10Var;
    }

    /* renamed from: do, reason: not valid java name */
    public byte[] m4938do(int i) {
        m10 m10Var = this.f9498if;
        return m10Var == null ? new byte[i] : (byte[]) m10Var.mo10097new(i, byte[].class);
    }
}
