package defpackage;

import android.content.Context;
import java.io.File;
import java.util.Objects;

/* loaded from: classes2.dex */
public final class yw7 {

    /* renamed from: do, reason: not valid java name */
    public ly f46272do;

    public yw7(Context context) {
        this.f46272do = dy.m4836case(context);
    }

    /* renamed from: do, reason: not valid java name */
    public final void m17769do(String str) {
        ly lyVar = this.f46272do;
        Objects.requireNonNull(lyVar);
        lyVar.m10063try(File.class).mo251do(ly.f23022class).b(str).d();
    }

    /* renamed from: if, reason: not valid java name */
    public void m17770if(e69 e69Var) {
        m17769do(e69Var.mo513for().getPathForSize(g8d.m6467case()));
        m17769do(e69Var.mo513for().getPathForSize(t2.m14607native()));
    }
}
