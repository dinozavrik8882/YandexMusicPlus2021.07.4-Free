package defpackage;

import java.util.AbstractList;
import java.util.List;

/* loaded from: classes2.dex */
public abstract class tl5<E> extends AbstractList<E> implements List<E>, kq5 {
    public abstract int getSize();

    /* renamed from: if */
    public abstract E mo12181if(int i);

    @Override // java.util.AbstractList, java.util.List
    public final /* bridge */ E remove(int i) {
        return mo12181if(i);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final /* bridge */ int size() {
        return getSize();
    }
}
