package defpackage;

import java.util.List;

@ln5(c = "ru.yandex.music.novelties.podcasts.catalog.blocks.playlist.TracksPodcastsPresenter$tracksAdapter$2$1$1", f = "TracksPodcastsPresenter.kt", l = {}, m = "invokeSuspend")
/* loaded from: classes2.dex */
public final class zna extends pn5 implements mo5<wm5<? super List<? extends e69>>, Object> {

    /* renamed from: super, reason: not valid java name */
    public final /* synthetic */ e69 f47559super;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public zna(e69 e69Var, wm5<? super zna> wm5Var) {
        super(1, wm5Var);
        this.f47559super = e69Var;
    }

    @Override // defpackage.mo5
    public Object invoke(wm5<? super List<? extends e69>> wm5Var) {
        wm5<? super List<? extends e69>> wm5Var2 = wm5Var;
        e69 e69Var = this.f47559super;
        if (wm5Var2 != null) {
            wm5Var2.getContext();
        }
        pl5 pl5Var = pl5.f29126do;
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(pl5Var);
        return dn3.i1(e69Var);
    }

    @Override // defpackage.hn5
    /* renamed from: return */
    public final Object mo76return(Object obj) {
        cn5 cn5Var = cn5.COROUTINE_SUSPENDED;
        dn3.N2(obj);
        return dn3.i1(this.f47559super);
    }

    @Override // defpackage.hn5
    /* renamed from: super */
    public final wm5<pl5> mo1372super(wm5<?> wm5Var) {
        return new zna(this.f47559super, wm5Var);
    }
}
