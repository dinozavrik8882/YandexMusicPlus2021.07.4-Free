package defpackage;

import java.io.Serializable;
import ru.yandex.music.landing.data.remote.BlockEntityDto;

/* loaded from: classes2.dex */
public class qx9 extends BlockEntityDto<a> {
    private static final long serialVersionUID = -8623001405838321917L;

    /* loaded from: classes2.dex */
    public static class a implements Serializable {
        private static final long serialVersionUID = 4181103290509936018L;

        @qd3("backgroundImageUri")
        public final String backgroundImageUrl;

        @qd3("title")
        public final String title;

        @qd3("textColor")
        public final String titleColor;

        @qd3("urlScheme")
        public final String urlScheme;
    }
}
