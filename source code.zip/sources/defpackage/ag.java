package defpackage;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import com.yandex.metrica.YandexMetricaDefaultValues;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public class ag {

    /* renamed from: do, reason: not valid java name */
    public static final Interpolator f794do = new a();

    /* renamed from: break, reason: not valid java name */
    public int[] f795break;

    /* renamed from: case, reason: not valid java name */
    public float[] f796case;

    /* renamed from: catch, reason: not valid java name */
    public int[] f797catch;

    /* renamed from: class, reason: not valid java name */
    public int f798class;

    /* renamed from: const, reason: not valid java name */
    public VelocityTracker f799const;

    /* renamed from: else, reason: not valid java name */
    public float[] f800else;

    /* renamed from: final, reason: not valid java name */
    public float f801final;

    /* renamed from: for, reason: not valid java name */
    public int f802for;

    /* renamed from: goto, reason: not valid java name */
    public float[] f803goto;

    /* renamed from: if, reason: not valid java name */
    public int f804if;

    /* renamed from: import, reason: not valid java name */
    public final c f805import;

    /* renamed from: native, reason: not valid java name */
    public View f806native;

    /* renamed from: public, reason: not valid java name */
    public boolean f808public;

    /* renamed from: return, reason: not valid java name */
    public final ViewGroup f809return;

    /* renamed from: super, reason: not valid java name */
    public float f811super;

    /* renamed from: this, reason: not valid java name */
    public int[] f812this;

    /* renamed from: throw, reason: not valid java name */
    public int f813throw;

    /* renamed from: try, reason: not valid java name */
    public float[] f814try;

    /* renamed from: while, reason: not valid java name */
    public OverScroller f815while;

    /* renamed from: new, reason: not valid java name */
    public int f807new = -1;

    /* renamed from: static, reason: not valid java name */
    public final Runnable f810static = new b();

    /* loaded from: classes.dex */
    public static class a implements Interpolator {
        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ag.this.m542native(0);
        }
    }

    /* loaded from: classes.dex */
    public static abstract class c {
        /* renamed from: case, reason: not valid java name */
        public abstract void mo553case(int i);

        /* renamed from: do, reason: not valid java name */
        public abstract int mo554do(View view, int i, int i2);

        /* renamed from: else, reason: not valid java name */
        public abstract void mo555else(View view, int i, int i2, int i3, int i4);

        /* renamed from: for, reason: not valid java name */
        public int mo556for(View view) {
            return 0;
        }

        /* renamed from: goto, reason: not valid java name */
        public abstract void mo557goto(View view, float f, float f2);

        /* renamed from: if, reason: not valid java name */
        public abstract int mo558if(View view, int i, int i2);

        /* renamed from: new, reason: not valid java name */
        public int mo559new(View view) {
            return 0;
        }

        /* renamed from: this, reason: not valid java name */
        public abstract boolean mo560this(View view, int i);

        /* renamed from: try, reason: not valid java name */
        public void mo561try(View view, int i) {
        }
    }

    public ag(Context context, ViewGroup viewGroup, c cVar) {
        if (cVar == null) {
            throw new IllegalArgumentException("Callback may not be null");
        }
        this.f809return = viewGroup;
        this.f805import = cVar;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f813throw = (int) ((context.getResources().getDisplayMetrics().density * 20.0f) + 0.5f);
        this.f802for = viewConfiguration.getScaledTouchSlop();
        this.f801final = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f811super = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f815while = new OverScroller(context, f794do);
    }

    /* renamed from: break, reason: not valid java name */
    public final void m530break(float f, float f2) {
        this.f808public = true;
        this.f805import.mo557goto(this.f806native, f, f2);
        this.f808public = false;
        if (this.f804if == 1) {
            m542native(0);
        }
    }

    /* renamed from: case, reason: not valid java name */
    public final int m531case(int i, int i2, int i3) {
        int abs = Math.abs(i);
        if (abs < i2) {
            return 0;
        }
        return abs > i3 ? i > 0 ? i3 : -i3 : i;
    }

    /* renamed from: catch, reason: not valid java name */
    public View m532catch(int i, int i2) {
        for (int childCount = this.f809return.getChildCount() - 1; childCount >= 0; childCount--) {
            ViewGroup viewGroup = this.f809return;
            Objects.requireNonNull(this.f805import);
            View childAt = viewGroup.getChildAt(childCount);
            if (i >= childAt.getLeft() && i < childAt.getRight() && i2 >= childAt.getTop() && i2 < childAt.getBottom()) {
                return childAt;
            }
        }
        return null;
    }

    /* renamed from: class, reason: not valid java name */
    public final boolean m533class(int i, int i2, int i3, int i4) {
        float f;
        float f2;
        float f3;
        float f4;
        int left = this.f806native.getLeft();
        int top = this.f806native.getTop();
        int i5 = i - left;
        int i6 = i2 - top;
        if (i5 == 0 && i6 == 0) {
            this.f815while.abortAnimation();
            m542native(0);
            return false;
        }
        View view = this.f806native;
        int m531case = m531case(i3, (int) this.f811super, (int) this.f801final);
        int m531case2 = m531case(i4, (int) this.f811super, (int) this.f801final);
        int abs = Math.abs(i5);
        int abs2 = Math.abs(i6);
        int abs3 = Math.abs(m531case);
        int abs4 = Math.abs(m531case2);
        int i7 = abs3 + abs4;
        int i8 = abs + abs2;
        if (m531case != 0) {
            f = abs3;
            f2 = i7;
        } else {
            f = abs;
            f2 = i8;
        }
        float f5 = f / f2;
        if (m531case2 != 0) {
            f3 = abs4;
            f4 = i7;
        } else {
            f3 = abs2;
            f4 = i8;
        }
        int m539goto = m539goto(i5, m531case, this.f805import.mo556for(view));
        this.f815while.startScroll(left, top, i5, i6, (int) ((m539goto(i6, m531case2, this.f805import.mo559new(view)) * (f3 / f4)) + (m539goto * f5)));
        m542native(2);
        return true;
    }

    /* renamed from: const, reason: not valid java name */
    public final boolean m534const(int i) {
        if ((this.f798class & (1 << i)) != 0) {
            return true;
        }
        Log.e("ViewDragHelper", "Ignoring pointerId=" + i + " because ACTION_DOWN was not received for this pointer before ACTION_MOVE. It likely happened because  ViewDragHelper did not receive all the events in the event stream.");
        return false;
    }

    /* renamed from: do, reason: not valid java name */
    public void m535do() {
        this.f807new = -1;
        float[] fArr = this.f814try;
        if (fArr != null) {
            Arrays.fill(fArr, 0.0f);
            Arrays.fill(this.f796case, 0.0f);
            Arrays.fill(this.f800else, 0.0f);
            Arrays.fill(this.f803goto, 0.0f);
            Arrays.fill(this.f812this, 0);
            Arrays.fill(this.f795break, 0);
            Arrays.fill(this.f797catch, 0);
            this.f798class = 0;
        }
        VelocityTracker velocityTracker = this.f799const;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f799const = null;
        }
    }

    /* renamed from: else, reason: not valid java name */
    public final void m536else(int i) {
        float[] fArr = this.f814try;
        if (fArr != null) {
            int i2 = this.f798class;
            int i3 = 1 << i;
            if ((i3 & i2) != 0) {
                fArr[i] = 0.0f;
                this.f796case[i] = 0.0f;
                this.f800else[i] = 0.0f;
                this.f803goto[i] = 0.0f;
                this.f812this[i] = 0;
                this.f795break[i] = 0;
                this.f797catch[i] = 0;
                this.f798class = (~i3) & i2;
            }
        }
    }

    /* renamed from: final, reason: not valid java name */
    public void m537final(MotionEvent motionEvent) {
        int i;
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            m535do();
        }
        if (this.f799const == null) {
            this.f799const = VelocityTracker.obtain();
        }
        this.f799const.addMovement(motionEvent);
        int i2 = 0;
        if (actionMasked == 0) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            View m532catch = m532catch((int) x, (int) y);
            m552while(x, y, pointerId);
            m548switch(m532catch, pointerId);
            if ((this.f812this[pointerId] & 0) != 0) {
                Objects.requireNonNull(this.f805import);
                return;
            }
            return;
        }
        if (actionMasked == 1) {
            if (this.f804if == 1) {
                m547super();
            }
            m535do();
            return;
        }
        if (actionMasked == 2) {
            if (this.f804if != 1) {
                int pointerCount = motionEvent.getPointerCount();
                while (i2 < pointerCount) {
                    int pointerId2 = motionEvent.getPointerId(i2);
                    if (m534const(pointerId2)) {
                        float x2 = motionEvent.getX(i2);
                        float y2 = motionEvent.getY(i2);
                        float f = x2 - this.f814try[pointerId2];
                        float f2 = y2 - this.f796case[pointerId2];
                        m550throw(f, f2, pointerId2);
                        if (this.f804if != 1) {
                            View m532catch2 = m532catch((int) x2, (int) y2);
                            if (m543new(m532catch2, f, f2) && m548switch(m532catch2, pointerId2)) {
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                    i2++;
                }
                m541import(motionEvent);
                return;
            }
            if (m534const(this.f807new)) {
                int findPointerIndex = motionEvent.findPointerIndex(this.f807new);
                float x3 = motionEvent.getX(findPointerIndex);
                float y3 = motionEvent.getY(findPointerIndex);
                float[] fArr = this.f800else;
                int i3 = this.f807new;
                int i4 = (int) (x3 - fArr[i3]);
                int i5 = (int) (y3 - this.f803goto[i3]);
                int left = this.f806native.getLeft() + i4;
                int top = this.f806native.getTop() + i5;
                int left2 = this.f806native.getLeft();
                int top2 = this.f806native.getTop();
                if (i4 != 0) {
                    left = this.f805import.mo554do(this.f806native, left, i4);
                    AtomicInteger atomicInteger = ze.f47083do;
                    this.f806native.offsetLeftAndRight(left - left2);
                }
                int i6 = left;
                if (i5 != 0) {
                    top = this.f805import.mo558if(this.f806native, top, i5);
                    AtomicInteger atomicInteger2 = ze.f47083do;
                    this.f806native.offsetTopAndBottom(top - top2);
                }
                int i7 = top;
                if (i4 != 0 || i5 != 0) {
                    this.f805import.mo555else(this.f806native, i6, i7, i6 - left2, i7 - top2);
                }
                m541import(motionEvent);
                return;
            }
            return;
        }
        if (actionMasked == 3) {
            if (this.f804if == 1) {
                m530break(0.0f, 0.0f);
            }
            m535do();
            return;
        }
        if (actionMasked != 5) {
            if (actionMasked != 6) {
                return;
            }
            int pointerId3 = motionEvent.getPointerId(actionIndex);
            if (this.f804if == 1 && pointerId3 == this.f807new) {
                int pointerCount2 = motionEvent.getPointerCount();
                while (true) {
                    if (i2 >= pointerCount2) {
                        i = -1;
                        break;
                    }
                    int pointerId4 = motionEvent.getPointerId(i2);
                    if (pointerId4 != this.f807new) {
                        View m532catch3 = m532catch((int) motionEvent.getX(i2), (int) motionEvent.getY(i2));
                        View view = this.f806native;
                        if (m532catch3 == view && m548switch(view, pointerId4)) {
                            i = this.f807new;
                            break;
                        }
                    }
                    i2++;
                }
                if (i == -1) {
                    m547super();
                }
            }
            m536else(pointerId3);
            return;
        }
        int pointerId5 = motionEvent.getPointerId(actionIndex);
        float x4 = motionEvent.getX(actionIndex);
        float y4 = motionEvent.getY(actionIndex);
        m552while(x4, y4, pointerId5);
        if (this.f804if == 0) {
            m548switch(m532catch((int) x4, (int) y4), pointerId5);
            if ((this.f812this[pointerId5] & 0) != 0) {
                Objects.requireNonNull(this.f805import);
                return;
            }
            return;
        }
        int i8 = (int) x4;
        int i9 = (int) y4;
        View view2 = this.f806native;
        if (view2 != null && i8 >= view2.getLeft() && i8 < view2.getRight() && i9 >= view2.getTop() && i9 < view2.getBottom()) {
            i2 = 1;
        }
        if (i2 != 0) {
            m548switch(this.f806native, pointerId5);
        }
    }

    /* renamed from: for, reason: not valid java name */
    public final boolean m538for(float f, float f2, int i, int i2) {
        float abs = Math.abs(f);
        float abs2 = Math.abs(f2);
        if ((this.f812this[i] & i2) != i2 || (0 & i2) == 0 || (this.f797catch[i] & i2) == i2 || (this.f795break[i] & i2) == i2) {
            return false;
        }
        int i3 = this.f802for;
        if (abs <= i3 && abs2 <= i3) {
            return false;
        }
        if (abs < abs2 * 0.5f) {
            Objects.requireNonNull(this.f805import);
        }
        return (this.f795break[i] & i2) == 0 && abs > ((float) this.f802for);
    }

    /* renamed from: goto, reason: not valid java name */
    public final int m539goto(int i, int i2, int i3) {
        if (i == 0) {
            return 0;
        }
        float width = this.f809return.getWidth() / 2;
        float sin = (((float) Math.sin((Math.min(1.0f, Math.abs(i) / r0) - 0.5f) * 0.47123894f)) * width) + width;
        int abs = Math.abs(i2);
        return Math.min(abs > 0 ? Math.round(Math.abs(sin / abs) * 1000.0f) * 4 : (int) (((Math.abs(i) / i3) + 1.0f) * 256.0f), 600);
    }

    /* renamed from: if, reason: not valid java name */
    public void m540if(View view, int i) {
        if (view.getParent() != this.f809return) {
            StringBuilder r = by.r("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
            r.append(this.f809return);
            r.append(")");
            throw new IllegalArgumentException(r.toString());
        }
        this.f806native = view;
        this.f807new = i;
        this.f805import.mo561try(view, i);
        m542native(1);
    }

    /* renamed from: import, reason: not valid java name */
    public final void m541import(MotionEvent motionEvent) {
        int pointerCount = motionEvent.getPointerCount();
        for (int i = 0; i < pointerCount; i++) {
            int pointerId = motionEvent.getPointerId(i);
            if (m534const(pointerId)) {
                float x = motionEvent.getX(i);
                float y = motionEvent.getY(i);
                this.f800else[pointerId] = x;
                this.f803goto[pointerId] = y;
            }
        }
    }

    /* renamed from: native, reason: not valid java name */
    public void m542native(int i) {
        this.f809return.removeCallbacks(this.f810static);
        if (this.f804if != i) {
            this.f804if = i;
            this.f805import.mo553case(i);
            if (this.f804if == 0) {
                this.f806native = null;
            }
        }
    }

    /* renamed from: new, reason: not valid java name */
    public final boolean m543new(View view, float f, float f2) {
        if (view == null) {
            return false;
        }
        boolean z = this.f805import.mo556for(view) > 0;
        boolean z2 = this.f805import.mo559new(view) > 0;
        if (!z || !z2) {
            return z ? Math.abs(f) > ((float) this.f802for) : z2 && Math.abs(f2) > ((float) this.f802for);
        }
        float f3 = (f2 * f2) + (f * f);
        int i = this.f802for;
        return f3 > ((float) (i * i));
    }

    /* renamed from: public, reason: not valid java name */
    public boolean m544public(int i, int i2) {
        if (this.f808public) {
            return m533class(i, i2, (int) this.f799const.getXVelocity(this.f807new), (int) this.f799const.getYVelocity(this.f807new));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    /* JADX WARN: Code restructure failed: missing block: B:51:0x00dd, code lost:
    
        if (r12 != r11) goto L54;
     */
    /* renamed from: return, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean m545return(android.view.MotionEvent r17) {
        /*
            Method dump skipped, instructions count: 313
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.ag.m545return(android.view.MotionEvent):boolean");
    }

    /* renamed from: static, reason: not valid java name */
    public boolean m546static(View view, int i, int i2) {
        this.f806native = view;
        this.f807new = -1;
        boolean m533class = m533class(i, i2, 0, 0);
        if (!m533class && this.f804if == 0 && this.f806native != null) {
            this.f806native = null;
        }
        return m533class;
    }

    /* renamed from: super, reason: not valid java name */
    public final void m547super() {
        this.f799const.computeCurrentVelocity(YandexMetricaDefaultValues.DEFAULT_MAX_REPORTS_IN_DATABASE_COUNT, this.f801final);
        m530break(m551try(this.f799const.getXVelocity(this.f807new), this.f811super, this.f801final), m551try(this.f799const.getYVelocity(this.f807new), this.f811super, this.f801final));
    }

    /* renamed from: switch, reason: not valid java name */
    public boolean m548switch(View view, int i) {
        if (view == this.f806native && this.f807new == i) {
            return true;
        }
        if (view == null || !this.f805import.mo560this(view, i)) {
            return false;
        }
        this.f807new = i;
        m540if(view, i);
        return true;
    }

    /* renamed from: this, reason: not valid java name */
    public boolean m549this(boolean z) {
        if (this.f804if == 2) {
            boolean computeScrollOffset = this.f815while.computeScrollOffset();
            int currX = this.f815while.getCurrX();
            int currY = this.f815while.getCurrY();
            int left = currX - this.f806native.getLeft();
            int top = currY - this.f806native.getTop();
            if (left != 0) {
                View view = this.f806native;
                AtomicInteger atomicInteger = ze.f47083do;
                view.offsetLeftAndRight(left);
            }
            if (top != 0) {
                View view2 = this.f806native;
                AtomicInteger atomicInteger2 = ze.f47083do;
                view2.offsetTopAndBottom(top);
            }
            if (left != 0 || top != 0) {
                this.f805import.mo555else(this.f806native, currX, currY, left, top);
            }
            if (computeScrollOffset && currX == this.f815while.getFinalX() && currY == this.f815while.getFinalY()) {
                this.f815while.abortAnimation();
                computeScrollOffset = false;
            }
            if (!computeScrollOffset) {
                if (z) {
                    this.f809return.post(this.f810static);
                } else {
                    m542native(0);
                }
            }
        }
        return this.f804if == 2;
    }

    /* renamed from: throw, reason: not valid java name */
    public final void m550throw(float f, float f2, int i) {
        int i2 = m538for(f, f2, i, 1) ? 1 : 0;
        if (m538for(f2, f, i, 4)) {
            i2 |= 4;
        }
        if (m538for(f, f2, i, 2)) {
            i2 |= 2;
        }
        if (m538for(f2, f, i, 8)) {
            i2 |= 8;
        }
        if (i2 != 0) {
            int[] iArr = this.f795break;
            iArr[i] = iArr[i] | i2;
            Objects.requireNonNull(this.f805import);
        }
    }

    /* renamed from: try, reason: not valid java name */
    public final float m551try(float f, float f2, float f3) {
        float abs = Math.abs(f);
        if (abs < f2) {
            return 0.0f;
        }
        return abs > f3 ? f > 0.0f ? f3 : -f3 : f;
    }

    /* renamed from: while, reason: not valid java name */
    public final void m552while(float f, float f2, int i) {
        float[] fArr = this.f814try;
        if (fArr == null || fArr.length <= i) {
            int i2 = i + 1;
            float[] fArr2 = new float[i2];
            float[] fArr3 = new float[i2];
            float[] fArr4 = new float[i2];
            float[] fArr5 = new float[i2];
            int[] iArr = new int[i2];
            int[] iArr2 = new int[i2];
            int[] iArr3 = new int[i2];
            if (fArr != null) {
                System.arraycopy(fArr, 0, fArr2, 0, fArr.length);
                float[] fArr6 = this.f796case;
                System.arraycopy(fArr6, 0, fArr3, 0, fArr6.length);
                float[] fArr7 = this.f800else;
                System.arraycopy(fArr7, 0, fArr4, 0, fArr7.length);
                float[] fArr8 = this.f803goto;
                System.arraycopy(fArr8, 0, fArr5, 0, fArr8.length);
                int[] iArr4 = this.f812this;
                System.arraycopy(iArr4, 0, iArr, 0, iArr4.length);
                int[] iArr5 = this.f795break;
                System.arraycopy(iArr5, 0, iArr2, 0, iArr5.length);
                int[] iArr6 = this.f797catch;
                System.arraycopy(iArr6, 0, iArr3, 0, iArr6.length);
            }
            this.f814try = fArr2;
            this.f796case = fArr3;
            this.f800else = fArr4;
            this.f803goto = fArr5;
            this.f812this = iArr;
            this.f795break = iArr2;
            this.f797catch = iArr3;
        }
        float[] fArr9 = this.f814try;
        this.f800else[i] = f;
        fArr9[i] = f;
        float[] fArr10 = this.f796case;
        this.f803goto[i] = f2;
        fArr10[i] = f2;
        int[] iArr7 = this.f812this;
        int i3 = (int) f;
        int i4 = (int) f2;
        int i5 = i3 < this.f809return.getLeft() + this.f813throw ? 1 : 0;
        if (i4 < this.f809return.getTop() + this.f813throw) {
            i5 |= 4;
        }
        if (i3 > this.f809return.getRight() - this.f813throw) {
            i5 |= 2;
        }
        if (i4 > this.f809return.getBottom() - this.f813throw) {
            i5 |= 8;
        }
        iArr7[i] = i5;
        this.f798class |= 1 << i;
    }
}
