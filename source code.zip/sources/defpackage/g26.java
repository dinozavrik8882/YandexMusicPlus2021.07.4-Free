package defpackage;

import defpackage.h26;
import defpackage.yu5;
import java.lang.Comparable;
import java.util.Arrays;

/* loaded from: classes2.dex */
public class g26<T extends h26 & Comparable<? super T>> {
    private volatile /* synthetic */ int _size = 0;

    /* renamed from: do, reason: not valid java name */
    public T[] f12951do;

    /* renamed from: case, reason: not valid java name */
    public final void m6339case(int i) {
        while (i > 0) {
            T[] tArr = this.f12951do;
            jp5.m8565for(tArr);
            int i2 = (i - 1) / 2;
            T t = tArr[i2];
            jp5.m8565for(t);
            T t2 = tArr[i];
            jp5.m8565for(t2);
            if (((Comparable) t).compareTo(t2) <= 0) {
                return;
            }
            m6341else(i, i2);
            i = i2;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public final void m6340do(T t) {
        yu5.c cVar = (yu5.c) t;
        cVar.mo6974if(this);
        T[] tArr = this.f12951do;
        if (tArr == null) {
            tArr = (T[]) new h26[4];
            this.f12951do = tArr;
        } else if (this._size >= tArr.length) {
            Object[] copyOf = Arrays.copyOf(tArr, this._size * 2);
            jp5.m8568new(copyOf, "java.util.Arrays.copyOf(this, newSize)");
            tArr = (T[]) ((h26[]) copyOf);
            this.f12951do = tArr;
        }
        int i = this._size;
        this._size = i + 1;
        tArr[i] = t;
        cVar.f46177const = i;
        m6339case(i);
    }

    /* renamed from: else, reason: not valid java name */
    public final void m6341else(int i, int i2) {
        T[] tArr = this.f12951do;
        jp5.m8565for(tArr);
        T t = tArr[i2];
        jp5.m8565for(t);
        T t2 = tArr[i];
        jp5.m8565for(t2);
        tArr[i] = t;
        tArr[i2] = t2;
        t.mo6973case(i);
        t2.mo6973case(i2);
    }

    /* renamed from: for, reason: not valid java name */
    public final boolean m6342for() {
        return this._size == 0;
    }

    /* renamed from: if, reason: not valid java name */
    public final T m6343if() {
        T[] tArr = this.f12951do;
        if (tArr == null) {
            return null;
        }
        return tArr[0];
    }

    /* renamed from: new, reason: not valid java name */
    public final T m6344new(int i) {
        T[] tArr = this.f12951do;
        jp5.m8565for(tArr);
        this._size--;
        if (i < this._size) {
            m6341else(i, this._size);
            int i2 = (i - 1) / 2;
            if (i > 0) {
                T t = tArr[i];
                jp5.m8565for(t);
                T t2 = tArr[i2];
                jp5.m8565for(t2);
                if (((Comparable) t).compareTo(t2) < 0) {
                    m6341else(i, i2);
                    m6339case(i2);
                }
            }
            while (true) {
                int i3 = (i * 2) + 1;
                if (i3 >= this._size) {
                    break;
                }
                T[] tArr2 = this.f12951do;
                jp5.m8565for(tArr2);
                int i4 = i3 + 1;
                if (i4 < this._size) {
                    T t3 = tArr2[i4];
                    jp5.m8565for(t3);
                    T t4 = tArr2[i3];
                    jp5.m8565for(t4);
                    if (((Comparable) t3).compareTo(t4) < 0) {
                        i3 = i4;
                    }
                }
                T t5 = tArr2[i];
                jp5.m8565for(t5);
                T t6 = tArr2[i3];
                jp5.m8565for(t6);
                if (((Comparable) t5).compareTo(t6) <= 0) {
                    break;
                }
                m6341else(i, i3);
                i = i3;
            }
        }
        T t7 = tArr[this._size];
        jp5.m8565for(t7);
        t7.mo6974if(null);
        t7.mo6973case(-1);
        tArr[this._size] = null;
        return t7;
    }

    /* renamed from: try, reason: not valid java name */
    public final T m6345try() {
        T m6344new;
        synchronized (this) {
            m6344new = this._size > 0 ? m6344new(0) : null;
        }
        return m6344new;
    }
}
