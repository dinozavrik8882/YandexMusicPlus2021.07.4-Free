package defpackage;

/* loaded from: classes.dex */
public enum zy {
    SOURCE,
    TRANSFORMED,
    NONE
}
