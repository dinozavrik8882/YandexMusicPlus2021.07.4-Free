package defpackage;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import ru.yandex.music.R;

/* loaded from: classes2.dex */
public final class g48 extends d48 {

    /* renamed from: throw, reason: not valid java name */
    public bo5<pl5> f13055throw;

    /* renamed from: while, reason: not valid java name */
    public bo5<pl5> f13056while;

    @Override // defpackage.lg, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Context context = getContext();
        jp5.m8568new(context, "context");
        setStyle(2, t2.m14594continue(context, R.attr.bottomSheetDialogTheme));
        setCancelable(false);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        jp5.m8570try(layoutInflater, "inflater");
        View inflate = layoutInflater.inflate(R.layout.dialog_preferences, viewGroup, false);
        Bundle arguments = getArguments();
        Integer valueOf = arguments == null ? null : Integer.valueOf(arguments.getInt("dialog_hint_bundle_key"));
        if (valueOf != null && valueOf.intValue() != 0) {
            ((TextView) inflate.findViewById(R.id.dialog_hint)).setText(valueOf.intValue());
        }
        return inflate;
    }

    @Override // defpackage.xh, defpackage.lg, androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setLayout(-1, -2);
            }
            if (window != null) {
                window.setGravity(80);
            }
            dialog.setCanceledOnTouchOutside(false);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        jp5.m8570try(view, "view");
        super.onViewCreated(view, bundle);
        view.findViewById(R.id.action_ok).setOnClickListener(new View.OnClickListener() { // from class: v38
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                g48 g48Var = g48.this;
                jp5.m8570try(g48Var, "this$0");
                bo5<pl5> bo5Var = g48Var.f13055throw;
                if (bo5Var != null) {
                    bo5Var.invoke();
                }
                g48Var.dismissAllowingStateLoss();
            }
        });
        view.findViewById(R.id.action_cancel).setOnClickListener(new View.OnClickListener() { // from class: u38
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                g48 g48Var = g48.this;
                jp5.m8570try(g48Var, "this$0");
                bo5<pl5> bo5Var = g48Var.f13056while;
                if (bo5Var != null) {
                    bo5Var.invoke();
                }
                g48Var.dismissAllowingStateLoss();
            }
        });
    }
}
