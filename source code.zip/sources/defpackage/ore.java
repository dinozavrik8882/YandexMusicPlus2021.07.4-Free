package defpackage;

import defpackage.ape;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public final class ore implements ape.i {

    /* renamed from: catch, reason: not valid java name */
    public final tqe<ope> f27805catch;

    /* loaded from: classes.dex */
    public static final class a extends AtomicBoolean implements ope, fqe {
        private static final long serialVersionUID = 5539301318568668881L;

        /* renamed from: catch, reason: not valid java name */
        public final ppe f27806catch;

        /* renamed from: class, reason: not valid java name */
        public final vwe f27807class = new vwe();

        public a(ppe ppeVar) {
            this.f27806catch = ppeVar;
        }

        /* renamed from: do, reason: not valid java name */
        public void m11746do() {
            if (compareAndSet(false, true)) {
                try {
                    this.f27806catch.mo1425if();
                } finally {
                    this.f27807class.unsubscribe();
                }
            }
        }

        /* renamed from: if, reason: not valid java name */
        public void m11747if(Throwable th) {
            if (!compareAndSet(false, true)) {
                a0f.m30for(th);
                return;
            }
            try {
                this.f27806catch.mo1423do(th);
            } finally {
                this.f27807class.unsubscribe();
            }
        }

        @Override // defpackage.fqe
        public boolean isUnsubscribed() {
            return get();
        }

        @Override // defpackage.fqe
        public void unsubscribe() {
            if (compareAndSet(false, true)) {
                this.f27807class.unsubscribe();
            }
        }
    }

    public ore(tqe<ope> tqeVar) {
        this.f27805catch = tqeVar;
    }

    @Override // defpackage.tqe
    public void call(ppe ppeVar) {
        ppe ppeVar2 = ppeVar;
        a aVar = new a(ppeVar2);
        ppeVar2.mo1424for(aVar);
        try {
            this.f27805catch.call(aVar);
        } catch (Throwable th) {
            nke.m11018const(th);
            aVar.m11747if(th);
        }
    }
}
