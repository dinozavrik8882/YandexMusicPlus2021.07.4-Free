package defpackage;

/* loaded from: classes2.dex */
public interface h26 {
    /* renamed from: case, reason: not valid java name */
    void mo6973case(int i);

    /* renamed from: if, reason: not valid java name */
    void mo6974if(g26<?> g26Var);

    /* renamed from: this, reason: not valid java name */
    int mo6975this();

    /* renamed from: try, reason: not valid java name */
    g26<?> mo6976try();
}
