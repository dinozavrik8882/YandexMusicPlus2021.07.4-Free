package defpackage;

/* loaded from: classes.dex */
public interface zc1 {
}
