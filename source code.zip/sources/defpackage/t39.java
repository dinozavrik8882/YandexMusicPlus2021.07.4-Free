package defpackage;

/* loaded from: classes2.dex */
public final class t39 implements ey5<qb8> {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ ey5 f36545catch;

    /* loaded from: classes2.dex */
    public static final class a implements fy5<qb8> {

        /* renamed from: catch, reason: not valid java name */
        public final /* synthetic */ fy5 f36546catch;

        @ln5(c = "ru.yandex.music.connect.ConnectStateManager$start$$inlined$filter$1$2", f = "ConnectStateManager.kt", l = {137}, m = "emit")
        /* renamed from: t39$a$a, reason: collision with other inner class name */
        /* loaded from: classes2.dex */
        public static final class C0295a extends jn5 {

            /* renamed from: final, reason: not valid java name */
            public /* synthetic */ Object f36547final;

            /* renamed from: super, reason: not valid java name */
            public int f36548super;

            public C0295a(wm5 wm5Var) {
                super(wm5Var);
            }

            @Override // defpackage.hn5
            /* renamed from: return */
            public final Object mo76return(Object obj) {
                this.f36547final = obj;
                this.f36548super |= Integer.MIN_VALUE;
                return a.this.mo600if(null, this);
            }
        }

        public a(fy5 fy5Var) {
            this.f36546catch = fy5Var;
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x002f  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
        @Override // defpackage.fy5
        /* renamed from: if */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.Object mo600if(defpackage.qb8 r6, defpackage.wm5 r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof t39.a.C0295a
                if (r0 == 0) goto L13
                r0 = r7
                t39$a$a r0 = (t39.a.C0295a) r0
                int r1 = r0.f36548super
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L13
                int r1 = r1 - r2
                r0.f36548super = r1
                goto L18
            L13:
                t39$a$a r0 = new t39$a$a
                r0.<init>(r7)
            L18:
                java.lang.Object r7 = r0.f36547final
                cn5 r1 = defpackage.cn5.COROUTINE_SUSPENDED
                int r2 = r0.f36548super
                r3 = 1
                if (r2 == 0) goto L2f
                if (r2 != r3) goto L27
                defpackage.dn3.N2(r7)
                goto L53
            L27:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L2f:
                defpackage.dn3.N2(r7)
                fy5 r7 = r5.f36546catch
                r2 = r6
                qb8 r2 = (defpackage.qb8) r2
                ri8$d r2 = r2.f30428if
                ri8$d r4 = ri8.d.READY
                if (r2 != r4) goto L3f
                r2 = r3
                goto L40
            L3f:
                r2 = 0
            L40:
                java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
                boolean r2 = r2.booleanValue()
                if (r2 == 0) goto L53
                r0.f36548super = r3
                java.lang.Object r6 = r7.mo600if(r6, r0)
                if (r6 != r1) goto L53
                return r1
            L53:
                pl5 r6 = defpackage.pl5.f29126do
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: t39.a.mo600if(java.lang.Object, wm5):java.lang.Object");
        }
    }

    public t39(ey5 ey5Var) {
        this.f36545catch = ey5Var;
    }

    @Override // defpackage.ey5
    /* renamed from: do */
    public Object mo1466do(fy5<? super qb8> fy5Var, wm5 wm5Var) {
        Object mo1466do = this.f36545catch.mo1466do(new a(fy5Var), wm5Var);
        return mo1466do == cn5.COROUTINE_SUSPENDED ? mo1466do : pl5.f29126do;
    }
}
