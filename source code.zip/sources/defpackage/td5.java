package defpackage;

import defpackage.zc5;

/* loaded from: classes2.dex */
public abstract class td5<RespT> extends re5<RespT> {

    /* loaded from: classes2.dex */
    public static abstract class a<RespT> extends td5<RespT> {

        /* renamed from: do, reason: not valid java name */
        public final zc5.a<RespT> f37027do;

        public a(zc5.a<RespT> aVar) {
            this.f37027do = aVar;
        }
    }

    @Override // zc5.a
    /* renamed from: for */
    public void mo630for(RespT respt) {
        ((a) this).f37027do.mo630for(respt);
    }
}
