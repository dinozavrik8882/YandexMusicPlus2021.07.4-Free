package defpackage;

import android.app.Application;
import android.content.res.Configuration;
import defpackage.gt3;
import java.util.concurrent.locks.ReentrantLock;

/* loaded from: classes.dex */
public final class bt3 {

    /* renamed from: do, reason: not valid java name */
    public final ReentrantLock f4260do;

    /* renamed from: for, reason: not valid java name */
    public final l0f<ft3> f4261for;

    /* renamed from: if, reason: not valid java name */
    public final k0f<Configuration> f4262if;

    /* loaded from: classes.dex */
    public static final class a implements gt3.a {
        public a() {
        }

        @Override // gt3.a
        /* renamed from: do, reason: not valid java name */
        public void mo2316do(Configuration configuration) {
            jp5.m8570try(configuration, "configuration");
            bt3 bt3Var = bt3.this;
            ReentrantLock reentrantLock = bt3Var.f4260do;
            reentrantLock.lock();
            try {
                int diff = bt3Var.f4262if.v().diff(configuration);
                l0f<ft3> l0fVar = bt3Var.f4261for;
                l0fVar.f21357class.mo1523case(new ft3(diff, configuration));
                bt3Var.f4262if.mo1523case(configuration);
            } finally {
                reentrantLock.unlock();
            }
        }
    }

    public bt3(Application application, gt3 gt3Var) {
        jp5.m8570try(application, "application");
        jp5.m8570try(gt3Var, "configNotifier");
        this.f4260do = new ReentrantLock();
        k0f<Configuration> s = k0f.s();
        this.f4262if = s;
        this.f4261for = l0f.s();
        s.mo1523case(application.getResources().getConfiguration());
        a aVar = new a();
        jp5.m8570try(aVar, "listener");
        gt3Var.f14120do.add(aVar);
    }
}
