package defpackage;

/* loaded from: classes.dex */
public interface pz<T> extends az<f10<T>> {
    /* renamed from: if */
    zy mo6356if(mz mzVar);
}
