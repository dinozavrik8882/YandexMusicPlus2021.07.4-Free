package defpackage;

/* loaded from: classes2.dex */
public class n5c {

    /* renamed from: do, reason: not valid java name */
    public static volatile a f25121do;

    /* loaded from: classes2.dex */
    public interface a {
        /* renamed from: do */
        void mo4795do();
    }

    /* renamed from: do, reason: not valid java name */
    public static void m10777do() {
        a aVar = f25121do;
        if (aVar == null) {
            return;
        }
        aVar.mo4795do();
    }
}
