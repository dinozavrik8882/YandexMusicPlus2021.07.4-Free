package defpackage;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import defpackage.vxc;

/* loaded from: classes2.dex */
public final class z67 extends RecyclerView.l {

    /* renamed from: case, reason: not valid java name */
    public final int f46751case;

    /* renamed from: do, reason: not valid java name */
    public final float f46752do;

    /* renamed from: for, reason: not valid java name */
    public final float f46753for;

    /* renamed from: if, reason: not valid java name */
    public final float f46754if;

    /* renamed from: new, reason: not valid java name */
    public final float f46755new;

    /* renamed from: try, reason: not valid java name */
    public final Paint f46756try;

    public z67(float f, float f2, float f3, float f4, int i) {
        this.f46752do = f;
        this.f46754if = f2;
        this.f46753for = f3;
        this.f46755new = f4;
        Paint paint = new Paint(1);
        paint.setColor(i);
        paint.setStrokeWidth(f2);
        this.f46756try = paint;
        this.f46751case = paint.getAlpha();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    /* renamed from: case */
    public void mo1162case(Canvas canvas, RecyclerView recyclerView, RecyclerView.y yVar) {
        w67 w67Var;
        jp5.m8570try(canvas, "c");
        jp5.m8570try(recyclerView, "parent");
        jp5.m8570try(yVar, "state");
        RecyclerView.e adapter = recyclerView.getAdapter();
        v67 v67Var = adapter instanceof v67 ? (v67) adapter : null;
        if (v67Var == null) {
            by.N("Trying to get offset for RV with null JuicyCatalogMenuActionsAdapter", null, 2);
            return;
        }
        jp5.m8560case(recyclerView, "$this$children");
        jp5.m8560case(recyclerView, "$this$iterator");
        ef efVar = new ef(recyclerView);
        while (efVar.hasNext()) {
            View view = (View) efVar.next();
            int adapterPosition = recyclerView.b(view).getAdapterPosition();
            if (adapterPosition != -1) {
                w67 m15960if = v67Var.m15960if(adapterPosition);
                int i = adapterPosition + 1;
                w67 m15960if2 = i < v67Var.getItemCount() ? v67Var.m15960if(i) : null;
                if (m15960if2 != null && (m15960if == (w67Var = w67.COMMON_ACTION_ENTITY) || m15960if == w67.TEXT_ACTION_ENTITY) && (m15960if2 == w67Var || m15960if2 == w67.TEXT_ACTION_ENTITY)) {
                    int paddingLeft = recyclerView.getPaddingLeft();
                    float translationY = view.getTranslationY() + view.getBottom();
                    int width = recyclerView.getWidth() - recyclerView.getPaddingRight();
                    this.f46756try.setAlpha((int) (view.getAlpha() * this.f46751case));
                    canvas.drawLine(paddingLeft, translationY, width, translationY, this.f46756try);
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    /* renamed from: new */
    public void mo282new(Rect rect, View view, RecyclerView recyclerView, RecyclerView.y yVar) {
        w67 w67Var;
        jp5.m8570try(rect, "outRect");
        jp5.m8570try(view, "view");
        jp5.m8570try(recyclerView, "parent");
        jp5.m8570try(yVar, "state");
        RecyclerView.e adapter = recyclerView.getAdapter();
        v67 v67Var = adapter instanceof v67 ? (v67) adapter : null;
        if (v67Var == null) {
            by.N("Trying to get offset for RV with null JuicyCatalogMenuActionsAdapter adapter", null, 2);
            return;
        }
        RecyclerView.b0 m1101continue = recyclerView.m1101continue(view);
        Integer valueOf = m1101continue == null ? null : Integer.valueOf(m1101continue.getAdapterPosition());
        w67 m15960if = valueOf != null ? v67Var.m15960if(valueOf.intValue()) : null;
        w67 w67Var2 = w67.HEADER;
        if (m15960if == w67Var2 || m15960if == (w67Var = w67.DESCRIPTION) || m15960if == w67.FOOTER) {
            return;
        }
        boolean z = v67Var.m15960if(0) == w67Var2;
        boolean z2 = v67Var.m15960if(0) == w67Var || v67Var.m15960if(1) == w67Var;
        int i = z ? 1 : 0;
        if (z2) {
            i++;
        }
        int a = recyclerView.a(view);
        int i2 = a - i;
        int m1224if = yVar.m1224if() - i;
        boolean z3 = i2 == 0;
        boolean z4 = m1224if > 0 && i2 == m1224if + (-2);
        boolean z5 = i2 != 0 && v67Var.m15960if(a + (-1)) == w67.SHARED_ENTITY;
        w67 w67Var3 = w67.SHARED_ENTITY;
        boolean z6 = m15960if == w67Var3;
        boolean z7 = i2 != m1224if - 1 && v67Var.m15960if(a + 1) == w67Var3;
        boolean z8 = z3 || z5 || z6;
        boolean z9 = z4 || z7 || z6;
        view.setOutlineProvider(new vxc(this.f46755new, (z8 && z9) ? vxc.a.ALL : z8 ? vxc.a.TOP : z9 ? vxc.a.BOTTOM : vxc.a.NONE));
        view.setClipToOutline(true);
        rect.set(0, z3 ? (int) this.f46752do : 0, 0, (z4 || z7 || z6) ? (int) this.f46753for : 0);
    }
}
