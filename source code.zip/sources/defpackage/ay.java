package defpackage;

/* loaded from: classes.dex */
public final class ay implements Runnable {

    /* renamed from: catch, reason: not valid java name */
    public final /* synthetic */ Exception f2649catch;

    /* renamed from: class, reason: not valid java name */
    public final /* synthetic */ qh4 f2650class;

    /* renamed from: const, reason: not valid java name */
    public final /* synthetic */ String f2651const;

    public ay(Exception exc, qh4 qh4Var, String str) {
        this.f2649catch = exc;
        this.f2650class = qh4Var;
        this.f2651const = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String valueOf = String.valueOf(this.f2649catch);
        StringBuilder sb = new StringBuilder(valueOf.length() + 30);
        sb.append("Error consuming purchase; ex: ");
        sb.append(valueOf);
        ti2.m14992case("BillingClient", sb.toString());
        this.f2650class.m12732do(fx.f12682const, this.f2651const);
    }
}
