package de.hdodenhof.circleimageview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import defpackage.pa5;

/* loaded from: classes2.dex */
public class CircleImageView extends ImageView {

    /* renamed from: catch, reason: not valid java name */
    public static final ImageView.ScaleType f8369catch = ImageView.ScaleType.CENTER_CROP;

    /* renamed from: class, reason: not valid java name */
    public static final Bitmap.Config f8370class = Bitmap.Config.ARGB_8888;

    /* renamed from: abstract, reason: not valid java name */
    public boolean f8371abstract;

    /* renamed from: const, reason: not valid java name */
    public final RectF f8372const;

    /* renamed from: continue, reason: not valid java name */
    public boolean f8373continue;

    /* renamed from: default, reason: not valid java name */
    public int f8374default;

    /* renamed from: extends, reason: not valid java name */
    public float f8375extends;

    /* renamed from: final, reason: not valid java name */
    public final RectF f8376final;

    /* renamed from: finally, reason: not valid java name */
    public float f8377finally;

    /* renamed from: import, reason: not valid java name */
    public final Paint f8378import;

    /* renamed from: native, reason: not valid java name */
    public int f8379native;

    /* renamed from: package, reason: not valid java name */
    public ColorFilter f8380package;

    /* renamed from: private, reason: not valid java name */
    public boolean f8381private;

    /* renamed from: public, reason: not valid java name */
    public int f8382public;

    /* renamed from: return, reason: not valid java name */
    public int f8383return;

    /* renamed from: static, reason: not valid java name */
    public Bitmap f8384static;

    /* renamed from: strictfp, reason: not valid java name */
    public boolean f8385strictfp;

    /* renamed from: super, reason: not valid java name */
    public final Matrix f8386super;

    /* renamed from: switch, reason: not valid java name */
    public BitmapShader f8387switch;

    /* renamed from: throw, reason: not valid java name */
    public final Paint f8388throw;

    /* renamed from: throws, reason: not valid java name */
    public int f8389throws;

    /* renamed from: while, reason: not valid java name */
    public final Paint f8390while;

    /* loaded from: classes2.dex */
    public class b extends ViewOutlineProvider {
        public b(a aVar) {
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            if (CircleImageView.this.f8385strictfp) {
                ViewOutlineProvider.BACKGROUND.getOutline(view, outline);
                return;
            }
            Rect rect = new Rect();
            CircleImageView.this.f8376final.roundOut(rect);
            outline.setRoundRect(rect, rect.width() / 2.0f);
        }
    }

    public CircleImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f8372const = new RectF();
        this.f8376final = new RectF();
        this.f8386super = new Matrix();
        this.f8388throw = new Paint();
        this.f8390while = new Paint();
        this.f8378import = new Paint();
        this.f8379native = -16777216;
        this.f8382public = 0;
        this.f8383return = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, pa5.f28711do, 0, 0);
        this.f8382public = obtainStyledAttributes.getDimensionPixelSize(2, 0);
        this.f8379native = obtainStyledAttributes.getColor(0, -16777216);
        this.f8373continue = obtainStyledAttributes.getBoolean(1, false);
        this.f8383return = obtainStyledAttributes.getColor(3, 0);
        obtainStyledAttributes.recycle();
        super.setScaleType(f8369catch);
        this.f8381private = true;
        setOutlineProvider(new b(null));
        if (this.f8371abstract) {
            m4407if();
            this.f8371abstract = false;
        }
    }

    /* renamed from: do, reason: not valid java name */
    public final void m4406do() {
        Bitmap bitmap = null;
        if (this.f8385strictfp) {
            this.f8384static = null;
        } else {
            Drawable drawable = getDrawable();
            if (drawable != null) {
                if (drawable instanceof BitmapDrawable) {
                    bitmap = ((BitmapDrawable) drawable).getBitmap();
                } else {
                    try {
                        Bitmap createBitmap = drawable instanceof ColorDrawable ? Bitmap.createBitmap(2, 2, f8370class) : Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), f8370class);
                        Canvas canvas = new Canvas(createBitmap);
                        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                        drawable.draw(canvas);
                        bitmap = createBitmap;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            this.f8384static = bitmap;
        }
        m4407if();
    }

    public int getBorderColor() {
        return this.f8379native;
    }

    public int getBorderWidth() {
        return this.f8382public;
    }

    public int getCircleBackgroundColor() {
        return this.f8383return;
    }

    @Override // android.widget.ImageView
    public ColorFilter getColorFilter() {
        return this.f8380package;
    }

    @Override // android.widget.ImageView
    public ImageView.ScaleType getScaleType() {
        return f8369catch;
    }

    /* renamed from: if, reason: not valid java name */
    public final void m4407if() {
        float width;
        float height;
        int i;
        if (!this.f8381private) {
            this.f8371abstract = true;
            return;
        }
        if (getWidth() == 0 && getHeight() == 0) {
            return;
        }
        if (this.f8384static == null) {
            invalidate();
            return;
        }
        Bitmap bitmap = this.f8384static;
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        this.f8387switch = new BitmapShader(bitmap, tileMode, tileMode);
        this.f8388throw.setAntiAlias(true);
        this.f8388throw.setDither(true);
        this.f8388throw.setFilterBitmap(true);
        this.f8388throw.setShader(this.f8387switch);
        this.f8390while.setStyle(Paint.Style.STROKE);
        this.f8390while.setAntiAlias(true);
        this.f8390while.setColor(this.f8379native);
        this.f8390while.setStrokeWidth(this.f8382public);
        this.f8378import.setStyle(Paint.Style.FILL);
        this.f8378import.setAntiAlias(true);
        this.f8378import.setColor(this.f8383return);
        this.f8374default = this.f8384static.getHeight();
        this.f8389throws = this.f8384static.getWidth();
        RectF rectF = this.f8376final;
        int min = Math.min((getWidth() - getPaddingLeft()) - getPaddingRight(), (getHeight() - getPaddingTop()) - getPaddingBottom());
        float paddingLeft = ((r1 - min) / 2.0f) + getPaddingLeft();
        float paddingTop = ((r2 - min) / 2.0f) + getPaddingTop();
        float f = min;
        rectF.set(new RectF(paddingLeft, paddingTop, paddingLeft + f, f + paddingTop));
        this.f8377finally = Math.min((this.f8376final.height() - this.f8382public) / 2.0f, (this.f8376final.width() - this.f8382public) / 2.0f);
        this.f8372const.set(this.f8376final);
        if (!this.f8373continue && (i = this.f8382public) > 0) {
            float f2 = i - 1.0f;
            this.f8372const.inset(f2, f2);
        }
        this.f8375extends = Math.min(this.f8372const.height() / 2.0f, this.f8372const.width() / 2.0f);
        Paint paint = this.f8388throw;
        if (paint != null) {
            paint.setColorFilter(this.f8380package);
        }
        this.f8386super.set(null);
        float f3 = 0.0f;
        if (this.f8372const.height() * this.f8389throws > this.f8372const.width() * this.f8374default) {
            width = this.f8372const.height() / this.f8374default;
            height = 0.0f;
            f3 = (this.f8372const.width() - (this.f8389throws * width)) * 0.5f;
        } else {
            width = this.f8372const.width() / this.f8389throws;
            height = (this.f8372const.height() - (this.f8374default * width)) * 0.5f;
        }
        this.f8386super.setScale(width, width);
        Matrix matrix = this.f8386super;
        RectF rectF2 = this.f8372const;
        matrix.postTranslate(((int) (f3 + 0.5f)) + rectF2.left, ((int) (height + 0.5f)) + rectF2.top);
        this.f8387switch.setLocalMatrix(this.f8386super);
        invalidate();
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDraw(Canvas canvas) {
        if (this.f8385strictfp) {
            super.onDraw(canvas);
            return;
        }
        if (this.f8384static == null) {
            return;
        }
        if (this.f8383return != 0) {
            canvas.drawCircle(this.f8372const.centerX(), this.f8372const.centerY(), this.f8375extends, this.f8378import);
        }
        canvas.drawCircle(this.f8372const.centerX(), this.f8372const.centerY(), this.f8375extends, this.f8388throw);
        if (this.f8382public > 0) {
            canvas.drawCircle(this.f8376final.centerX(), this.f8376final.centerY(), this.f8377finally, this.f8390while);
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        m4407if();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        if (this.f8385strictfp) {
            return super.onTouchEvent(motionEvent);
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        if (!this.f8376final.isEmpty()) {
            if (Math.pow(y - this.f8376final.centerY(), 2.0d) + Math.pow(x - this.f8376final.centerX(), 2.0d) > Math.pow(this.f8377finally, 2.0d)) {
                z = false;
                return z && super.onTouchEvent(motionEvent);
            }
        }
        z = true;
        if (z) {
            return false;
        }
    }

    @Override // android.widget.ImageView
    public void setAdjustViewBounds(boolean z) {
        if (z) {
            throw new IllegalArgumentException("adjustViewBounds not supported.");
        }
    }

    public void setBorderColor(int i) {
        if (i == this.f8379native) {
            return;
        }
        this.f8379native = i;
        this.f8390while.setColor(i);
        invalidate();
    }

    public void setBorderOverlay(boolean z) {
        if (z == this.f8373continue) {
            return;
        }
        this.f8373continue = z;
        m4407if();
    }

    public void setBorderWidth(int i) {
        if (i == this.f8382public) {
            return;
        }
        this.f8382public = i;
        m4407if();
    }

    public void setCircleBackgroundColor(int i) {
        if (i == this.f8383return) {
            return;
        }
        this.f8383return = i;
        this.f8378import.setColor(i);
        invalidate();
    }

    public void setCircleBackgroundColorResource(int i) {
        setCircleBackgroundColor(getContext().getResources().getColor(i));
    }

    @Override // android.widget.ImageView
    public void setColorFilter(ColorFilter colorFilter) {
        if (colorFilter == this.f8380package) {
            return;
        }
        this.f8380package = colorFilter;
        Paint paint = this.f8388throw;
        if (paint != null) {
            paint.setColorFilter(colorFilter);
        }
        invalidate();
    }

    public void setDisableCircularTransformation(boolean z) {
        if (this.f8385strictfp == z) {
            return;
        }
        this.f8385strictfp = z;
        m4406do();
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        m4406do();
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        m4406do();
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        super.setImageResource(i);
        m4406do();
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        m4406do();
    }

    @Override // android.view.View
    public void setPadding(int i, int i2, int i3, int i4) {
        super.setPadding(i, i2, i3, i4);
        m4407if();
    }

    @Override // android.view.View
    public void setPaddingRelative(int i, int i2, int i3, int i4) {
        super.setPaddingRelative(i, i2, i3, i4);
        m4407if();
    }

    @Override // android.widget.ImageView
    public void setScaleType(ImageView.ScaleType scaleType) {
        if (scaleType != f8369catch) {
            throw new IllegalArgumentException(String.format("ScaleType %s not supported.", scaleType));
        }
    }
}
