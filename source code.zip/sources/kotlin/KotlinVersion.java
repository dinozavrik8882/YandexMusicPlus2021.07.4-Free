package kotlin;

import defpackage.ep5;
import defpackage.jp5;

/* loaded from: classes2.dex */
public final class KotlinVersion implements Comparable<KotlinVersion> {
    public static final int MAX_COMPONENT_VALUE = 255;
    private final int major;
    private final int minor;
    private final int patch;
    private final int version;
    public static final a Companion = new a(null);
    public static final KotlinVersion CURRENT = new KotlinVersion(1, 5, 20);

    /* loaded from: classes2.dex */
    public static final class a {
        public a(ep5 ep5Var) {
        }
    }

    public KotlinVersion(int i, int i2) {
        this(i, i2, 0);
    }

    public KotlinVersion(int i, int i2, int i3) {
        this.major = i;
        this.minor = i2;
        this.patch = i3;
        this.version = versionOf(i, i2, i3);
    }

    private final int versionOf(int i, int i2, int i3) {
        if (i >= 0 && 255 >= i && i2 >= 0 && 255 >= i2 && i3 >= 0 && 255 >= i3) {
            return (i << 16) + (i2 << 8) + i3;
        }
        throw new IllegalArgumentException(("Version components are out of range: " + i + '.' + i2 + '.' + i3).toString());
    }

    @Override // java.lang.Comparable
    public int compareTo(KotlinVersion kotlinVersion) {
        jp5.m8570try(kotlinVersion, "other");
        return this.version - kotlinVersion.version;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof KotlinVersion)) {
            obj = null;
        }
        KotlinVersion kotlinVersion = (KotlinVersion) obj;
        return kotlinVersion != null && this.version == kotlinVersion.version;
    }

    public final int getMajor() {
        return this.major;
    }

    public final int getMinor() {
        return this.minor;
    }

    public final int getPatch() {
        return this.patch;
    }

    public int hashCode() {
        return this.version;
    }

    public final boolean isAtLeast(int i, int i2) {
        int i3 = this.major;
        return i3 > i || (i3 == i && this.minor >= i2);
    }

    public final boolean isAtLeast(int i, int i2, int i3) {
        int i4;
        int i5 = this.major;
        return i5 > i || (i5 == i && ((i4 = this.minor) > i2 || (i4 == i2 && this.patch >= i3)));
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.major);
        sb.append('.');
        sb.append(this.minor);
        sb.append('.');
        sb.append(this.patch);
        return sb.toString();
    }
}
